package ir.miplus.gamino

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import androidx.fragment.app.FragmentActivity
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory
import ir.tapsell.mediation.Tapsell
import ir.tapsell.mediation.ad.AdStateListener
import ir.tapsell.mediation.ad.request.BannerSize
import ir.tapsell.mediation.ad.request.RequestResultListener
import ir.tapsell.mediation.ad.views.banner.BannerContainer

class InlineBannerFactory(
    private val activity: FragmentActivity,
    private val messenger: BinaryMessenger,
) : PlatformViewFactory(StandardMessageCodec.INSTANCE) {
    companion object {
        const val VIEW_TYPE = "ir.miplus.gamino/tapsell_inline_banner"
    }

    override fun create(context: Context, viewId: Int, args: Any?): PlatformView {
        val params = args as? Map<*, *> ?: emptyMap<Any, Any>()
        return InlineBannerView(context, activity, params, viewId, messenger)
    }
}

private class InlineBannerView(
    context: Context,
    private val activity: FragmentActivity,
    params: Map<*, *>,
    viewId: Int,
    messenger: BinaryMessenger,
) : PlatformView {
    private val root = FrameLayout(context)
    private val bannerContainer = BannerContainer(context)
    private val zoneId = params["zoneId"]?.toString()?.trim().orEmpty()
    private val stateChannel = MethodChannel(messenger, "ir.miplus.gamino/tapsell_inline_banner/$viewId")
    private var disposed = false

    init {
        root.addView(
            bannerContainer,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER,
            ),
        )
        if (zoneId.isNotEmpty()) requestBanner() else sendState("hidden")
    }

    private fun sendState(state: String) {
        if (disposed) return
        activity.runOnUiThread {
            if (!disposed) {
                try {
                    stateChannel.invokeMethod("state", state)
                } catch (_: Throwable) {
                    // Banner visibility is best-effort and must never affect the page.
                }
            }
        }
    }

    private fun requestBanner() {
        activity.runOnUiThread {
            if (disposed || activity.isFinishing || activity.isDestroyed) return@runOnUiThread
            try {
                Tapsell.requestBannerAd(
                    zoneId,
                    BannerSize.BANNER_320_100,
                    object : RequestResultListener {
                        override fun onSuccess(adId: String) {
                            if (disposed || activity.isFinishing || activity.isDestroyed) return
                            showBanner(adId)
                        }

                        override fun onFailure(message: String) {
                            sendState("hidden")
                        }
                    },
                )
            } catch (_: Throwable) {
                sendState("hidden")
            }
        }
    }

    private fun showBanner(adId: String) {
        activity.runOnUiThread {
            if (disposed || activity.isFinishing || activity.isDestroyed) return@runOnUiThread
            try {
                Tapsell.showBannerAd(
                    adId,
                    bannerContainer,
                    activity,
                    object : AdStateListener.Banner {
                        override fun onAdImpression() = Unit
                        override fun onAdClicked() = Unit
                        override fun onAdFailed(message: String) {
                            sendState("hidden")
                        }
                    },
                )
                sendState("loaded")
            } catch (_: Throwable) {
                sendState("hidden")
            }
        }
    }

    override fun getView(): View = root

    override fun dispose() {
        disposed = true
        root.removeAllViews()
        try {
            stateChannel.setMethodCallHandler(null)
        } catch (_: Throwable) {
            // Ignore cleanup failures.
        }
    }
}
