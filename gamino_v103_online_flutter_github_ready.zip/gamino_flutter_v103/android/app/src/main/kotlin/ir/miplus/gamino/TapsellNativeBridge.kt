package ir.miplus.gamino

import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.FragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import ir.tapsell.mediation.Tapsell
import ir.tapsell.mediation.ad.AdStateListener
import ir.tapsell.mediation.ad.request.RequestResultListener
import ir.tapsell.mediation.ad.show.AdShowCompletionState
import java.util.concurrent.atomic.AtomicBoolean

class TapsellNativeBridge(private val activity: FragmentActivity) {
    companion object {
        const val CHANNEL = "ir.miplus.gamino/tapsell_native"
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    fun register(flutterEngine: FlutterEngine) {
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result -> handle(call, result) }
    }

    private fun handle(call: MethodCall, result: MethodChannel.Result) {
        if (call.method == "openUrl") {
            val url = call.argument<String>("url")?.trim().orEmpty()
            if (url.isEmpty()) { result.success("invalid"); return }
            try {
                val uri = Uri.parse(url)
                val scheme = uri.scheme?.lowercase().orEmpty()
                if (scheme != "http" && scheme != "https") { result.success("invalid"); return }
                activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
                result.success("opened")
            } catch (_: Throwable) {
                result.success("unavailable")
            }
            return
        }

        val zoneId = call.argument<String>("zoneId")?.trim().orEmpty()
        if (zoneId.isEmpty()) {
            result.success("unavailable")
            return
        }

        when (call.method) {
            "showInterstitial" -> showInterstitial(zoneId, result)
            "showRewarded" -> showRewarded(zoneId, result)
            else -> result.notImplemented()
        }
    }

    private fun completeOnce(
        completed: AtomicBoolean,
        result: MethodChannel.Result,
        value: String,
    ) {
        mainHandler.post {
            if (completed.compareAndSet(false, true)) {
                result.success(value)
            }
        }
    }

    private fun showInterstitial(zoneId: String, result: MethodChannel.Result) {
        val completed = AtomicBoolean(false)

        try {
            Tapsell.requestInterstitialAd(zoneId, object : RequestResultListener {
                override fun onFailure(message: String) {
                    completeOnce(completed, result, "unavailable")
                }

                override fun onSuccess(adId: String) {
                    activity.runOnUiThread {
                        if (activity.isFinishing || activity.isDestroyed) {
                            completeOnce(completed, result, "unavailable")
                            return@runOnUiThread
                        }

                        try {
                            Tapsell.showInterstitialAd(
                                adId,
                                activity,
                                object : AdStateListener.Interstitial {
                                    override fun onAdClicked() = Unit

                                    override fun onAdClosed(completionState: AdShowCompletionState) {
                                        completeOnce(completed, result, "closed")
                                    }

                                    override fun onAdFailed(message: String) {
                                        completeOnce(completed, result, "unavailable")
                                    }

                                    override fun onAdImpression() = Unit
                                },
                            )
                        } catch (_: Throwable) {
                            completeOnce(completed, result, "unavailable")
                        }
                    }
                }
            })
        } catch (_: Throwable) {
            completeOnce(completed, result, "unavailable")
        }
    }

    private fun showRewarded(zoneId: String, result: MethodChannel.Result) {
        val completed = AtomicBoolean(false)
        val rewarded = AtomicBoolean(false)

        try {
            Tapsell.requestRewardedAd(zoneId, object : RequestResultListener {
                override fun onFailure(message: String) {
                    completeOnce(completed, result, "unavailable")
                }

                override fun onSuccess(adId: String) {
                    activity.runOnUiThread {
                        if (activity.isFinishing || activity.isDestroyed) {
                            completeOnce(completed, result, "unavailable")
                            return@runOnUiThread
                        }

                        try {
                            Tapsell.showRewardedAd(
                                adId,
                                activity,
                                object : AdStateListener.Rewarded {
                                    override fun onAdClicked() = Unit

                                    override fun onAdClosed(completionState: AdShowCompletionState) {
                                        // Some adapters may dispatch reward immediately before close.
                                        // A tiny grace period prevents a close callback racing the
                                        // official onRewarded callback from being classified as skipped.
                                        mainHandler.postDelayed(
                                            {
                                                completeOnce(
                                                    completed,
                                                    result,
                                                    if (rewarded.get()) "rewarded" else "incomplete",
                                                )
                                            },
                                            350L,
                                        )
                                    }

                                    override fun onAdFailed(message: String) {
                                        completeOnce(completed, result, "unavailable")
                                    }

                                    override fun onAdImpression() = Unit

                                    override fun onRewarded() {
                                        rewarded.set(true)
                                    }
                                },
                            )
                        } catch (_: Throwable) {
                            completeOnce(completed, result, "unavailable")
                        }
                    }
                }
            })
        } catch (_: Throwable) {
            completeOnce(completed, result, "unavailable")
        }
    }
}
