package ir.miplus.gamino

import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterFragmentActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        flutterEngine.platformViewsController.registry.registerViewFactory(
            InlineBannerFactory.VIEW_TYPE,
            InlineBannerFactory(this, flutterEngine.dartExecutor.binaryMessenger),
        )

        TapsellNativeBridge(this).register(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ir.miplus.gamino/app_control")
            .setMethodCallHandler { call, result ->
                if (call.method == "finishAndRemoveTask") {
                    finishAndRemoveTask()
                    result.success(null)
                } else {
                    result.notImplemented()
                }
            }
    }
}
