package ir.miplus.gamino

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import com.google.firebase.messaging.FirebaseMessaging
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterFragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GaminoPushReporter.flushAsync(applicationContext)
        handlePushIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handlePushIntent(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        AdiveryNativeBridge(this).register(flutterEngine)
        flutterEngine.platformViewsController.registry.registerViewFactory(
            AdiveryBannerFactory.VIEW_TYPE,
            AdiveryBannerFactory(flutterEngine.dartExecutor.binaryMessenger),
        )

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ir.miplus.gamino/app_control")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "finishAndRemoveTask" -> {
                        finishAndRemoveTask()
                        result.success(null)
                    }
                    "openUrl" -> {
                        val value = call.argument<String>("url").orEmpty()
                        try {
                            val uri = Uri.parse(value)
                            if (uri.scheme == "https" || uri.scheme == "http") {
                                startActivity(Intent(Intent.ACTION_VIEW, uri))
                                result.success("opened")
                            } else result.error("URL", "Unsupported URL", null)
                        } catch (error: Throwable) {
                            result.error("URL", error.message ?: "Unable to open URL", null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ir.miplus.gamino/push")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "requestPermission" -> {
                        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4107)
                        }
                        result.success(null)
                    }
                    "getToken" -> {
                        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val token = task.result.orEmpty()
                                getSharedPreferences("gamino_push_native_v1", MODE_PRIVATE).edit().putString("latest_fcm_token", token).apply()
                                result.success(token)
                            } else {
                                result.error("FCM_TOKEN", task.exception?.message ?: "FCM token unavailable", null)
                            }
                        }
                    }
                    "flushEvents" -> {
                        GaminoPushReporter.flushAsync(applicationContext)
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun handlePushIntent(source: Intent?) {
        if (source?.action != GaminoFirebaseMessagingService.ACTION_OPEN) return
        val eventUrl = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_EVENT_URL).orEmpty()
        val deliveryId = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_DELIVERY_ID).orEmpty()
        val trackingToken = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_TRACKING_TOKEN).orEmpty()
        val destinationType = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_DESTINATION_TYPE).orEmpty()
        val destinationUrl = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_DESTINATION_URL).orEmpty()

        GaminoPushReporter.recordEvent(applicationContext, eventUrl, deliveryId, trackingToken, "click")
        source.action = null

        if (destinationType == "link" && destinationUrl.isNotBlank()) {
            try {
                val uri = Uri.parse(destinationUrl)
                if (uri.scheme == "https" || uri.scheme == "http") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
            } catch (_: Throwable) {
                // The app remains open when the destination URL cannot be opened.
            }
        }
    }
}
