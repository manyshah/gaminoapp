# Adivery Flutter plugin and Firebase Messaging use their bundled consumer rules.
