import 'dart:convert';

import 'package:myket_iap/myket_iap.dart';
import 'package:myket_iap/util/iab_result.dart';
import 'package:myket_iap/util/inventory.dart';
import 'package:myket_iap/util/purchase.dart' as myket;

const String gaminoMarket = 'myket';
const String gaminoMarketRsaKey = String.fromEnvironment('GAMINO_MARKET_RSA', defaultValue: '');

const Map<int, String> gaminoCardProductIds = <int, String>{
  50: 'gamino_cards_50',
  100: 'gamino_cards_100',
  300: 'gamino_cards_300',
};

class GaminoStorePurchase {
  const GaminoStorePurchase({
    required this.market,
    required this.productId,
    required this.purchaseToken,
    required this.orderId,
    required this.packageName,
    required this.originalJson,
    required this.signature,
    required this.developerPayload,
    this.nativePurchase,
  });

  final String market;
  final String productId;
  final String purchaseToken;
  final String orderId;
  final String packageName;
  final String originalJson;
  final String signature;
  final String developerPayload;
  final Object? nativePurchase;

  Map<String, dynamic> toClaimJson() => <String, dynamic>{
        'market': market,
        'productId': productId,
        'purchaseToken': purchaseToken,
        'orderId': orderId,
        'packageName': packageName,
        'originalJson': originalJson,
        'signature': signature,
        'developerPayload': developerPayload,
      };
}

class GaminoMarketBillingException implements Exception {
  const GaminoMarketBillingException(this.message);
  final String message;
  @override
  String toString() => message;
}

class GaminoMarketBillingService {
  static bool _initialized = false;

  static bool get isBazaar => false;
  static bool get isMyket => true;
  static bool get isSupportedBuild => true;
  static String get marketLabel => 'مایکت';

  static Future<void> ensureReady() async {
    if (gaminoMarketRsaKey.trim().isEmpty) {
      throw const GaminoMarketBillingException('کلید پرداخت مایکت در این بیلد تنظیم نشده است.');
    }
    if (_initialized) return;
    final IabResult? result = await MyketIAP.init(rsaKey: gaminoMarketRsaKey, enableDebugLogging: false);
    if (result == null || result.isFailure()) {
      throw GaminoMarketBillingException('اتصال به پرداخت مایکت برقرار نشد${result == null ? '.' : ': $result'}');
    }
    _initialized = true;
  }

  static Future<GaminoStorePurchase> purchase({
    required String productId,
    required String developerPayload,
  }) async {
    await ensureReady();
    if (!gaminoCardProductIds.containsValue(productId)) {
      throw const GaminoMarketBillingException('شناسه محصول کارت معتبر نیست.');
    }
    final Map result = await MyketIAP.launchPurchaseFlow(sku: productId, payload: developerPayload);
    final IabResult? iabResult = result[MyketIAP.RESULT] as IabResult?;
    final myket.Purchase? purchase = result[MyketIAP.PURCHASE] as myket.Purchase?;
    if (iabResult == null || iabResult.isFailure() || purchase == null) {
      throw GaminoMarketBillingException(iabResult == null ? 'خرید مایکت تکمیل نشد.' : 'خرید مایکت تکمیل نشد: $iabResult');
    }
    return _fromMyket(purchase);
  }

  static Future<List<GaminoStorePurchase>> pendingPurchases() async {
    await ensureReady();
    final Map result = await MyketIAP.queryInventory(
      querySkuDetails: false,
      skus: gaminoCardProductIds.values.toList(growable: false),
    );
    final IabResult? iabResult = result[MyketIAP.RESULT] as IabResult?;
    if (iabResult == null || iabResult.isFailure()) {
      throw GaminoMarketBillingException(iabResult == null ? 'دریافت خریدهای مایکت انجام نشد.' : 'دریافت خریدهای مایکت انجام نشد: $iabResult');
    }
    final Inventory? inventory = result[MyketIAP.INVENTORY] as Inventory?;
    if (inventory == null) return const <GaminoStorePurchase>[];
    return inventory.mPurchaseMap.values
        .where((item) => gaminoCardProductIds.containsValue(item.mSku))
        .map(_fromMyket)
        .toList(growable: false);
  }

  static Future<void> consume(GaminoStorePurchase purchase) async {
    await ensureReady();
    if (purchase.market != gaminoMarket) {
      throw const GaminoMarketBillingException('مارکت خرید با نسخه نصب‌شده همخوانی ندارد.');
    }

    final native = purchase.nativePurchase;
    myket.Purchase? myketPurchase = native is myket.Purchase ? native : null;
    if (myketPurchase == null) {
      try {
        final decoded = jsonDecode(purchase.originalJson);
        if (decoded is Map) myketPurchase = myket.Purchase.fromJson(Map<String, dynamic>.from(decoded));
      } catch (_) {
        myketPurchase = null;
      }
    }
    if (myketPurchase == null) {
      throw const GaminoMarketBillingException('اطلاعات خرید مایکت برای مصرف کامل نیست.');
    }
    final Map result = await MyketIAP.consume(purchase: myketPurchase);
    final IabResult? iabResult = result[MyketIAP.RESULT] as IabResult?;
    if (iabResult == null || iabResult.isFailure()) {
      throw GaminoMarketBillingException(iabResult == null ? 'مصرف خرید مایکت تکمیل نشد.' : 'مصرف خرید مایکت تکمیل نشد: $iabResult');
    }
  }

  static Future<void> dispose() async {
    if (!_initialized) return;
    try {
      await MyketIAP.dispose();
    } catch (_) {}
    _initialized = false;
  }

  static GaminoStorePurchase _fromMyket(myket.Purchase purchase) => GaminoStorePurchase(
        market: 'myket',
        productId: purchase.mSku,
        purchaseToken: purchase.mToken,
        orderId: purchase.mOrderId,
        packageName: purchase.mPackageName,
        originalJson: purchase.mOriginalJson,
        signature: purchase.mSignature,
        developerPayload: purchase.mDeveloperPayload ?? '',
        nativePurchase: purchase,
      );
}
