import 'package:flutter_poolakey/flutter_poolakey.dart';

const String gaminoMarket = 'bazaar';
const String gaminoMarketRsaKey = String.fromEnvironment('GAMINO_MARKET_RSA', defaultValue: '');

const Map<int, String> gaminoCardProductIds = <int, String>{
  50: 'gamino_cards_50',
  100: 'gamino_cards_100',
  300: 'gamino_cards_300',
};

class GaminoStorePurchase {
  const GaminoStorePurchase({
    required this.market,
    required this.productId,
    required this.purchaseToken,
    required this.orderId,
    required this.packageName,
    required this.originalJson,
    required this.signature,
    required this.developerPayload,
    this.nativePurchase,
  });

  final String market;
  final String productId;
  final String purchaseToken;
  final String orderId;
  final String packageName;
  final String originalJson;
  final String signature;
  final String developerPayload;
  final Object? nativePurchase;

  Map<String, dynamic> toClaimJson() => <String, dynamic>{
        'market': market,
        'productId': productId,
        'purchaseToken': purchaseToken,
        'orderId': orderId,
        'packageName': packageName,
        'originalJson': originalJson,
        'signature': signature,
        'developerPayload': developerPayload,
      };
}

class GaminoMarketBillingException implements Exception {
  const GaminoMarketBillingException(this.message);
  final String message;
  @override
  String toString() => message;
}

class GaminoMarketBillingService {
  static bool _connected = false;

  static bool get isBazaar => true;
  static bool get isMyket => false;
  static bool get isSupportedBuild => true;
  static String get marketLabel => 'کافه‌بازار';

  static Future<void> ensureReady() async {
    if (gaminoMarketRsaKey.trim().isEmpty) {
      throw const GaminoMarketBillingException('کلید پرداخت کافه‌بازار در این بیلد تنظیم نشده است.');
    }
    if (_connected) return;
    var connected = false;
    await FlutterPoolakey.connect(
      gaminoMarketRsaKey,
      onSucceed: () => connected = true,
      onFailed: () => connected = false,
      onDisconnected: () => _connected = false,
    );
    _connected = connected;
    if (!_connected) {
      throw const GaminoMarketBillingException('اتصال به پرداخت کافه‌بازار برقرار نشد.');
    }
  }

  static Future<GaminoStorePurchase> purchase({
    required String productId,
    required String developerPayload,
  }) async {
    await ensureReady();
    if (!gaminoCardProductIds.containsValue(productId)) {
      throw const GaminoMarketBillingException('شناسه محصول کارت معتبر نیست.');
    }
    final PurchaseInfo purchase = await FlutterPoolakey.purchase(productId, payload: developerPayload);
    return _fromBazaar(purchase);
  }

  static Future<List<GaminoStorePurchase>> pendingPurchases() async {
    await ensureReady();
    final List<PurchaseInfo> rows = await FlutterPoolakey.getAllPurchasedProducts();
    return rows
        .where((item) => gaminoCardProductIds.containsValue(item.productId))
        .map(_fromBazaar)
        .toList(growable: false);
  }

  static Future<void> consume(GaminoStorePurchase purchase) async {
    await ensureReady();
    if (purchase.market != gaminoMarket) {
      throw const GaminoMarketBillingException('مارکت خرید با نسخه نصب‌شده همخوانی ندارد.');
    }
    final ok = await FlutterPoolakey.consume(purchase.purchaseToken);
    if (!ok) throw const GaminoMarketBillingException('مصرف خرید کافه‌بازار تکمیل نشد.');
  }

  static Future<void> dispose() async {
    if (!_connected) return;
    try {
      await FlutterPoolakey.disconnect();
    } catch (_) {}
    _connected = false;
  }

  static GaminoStorePurchase _fromBazaar(PurchaseInfo purchase) => GaminoStorePurchase(
        market: 'bazaar',
        productId: purchase.productId,
        purchaseToken: purchase.purchaseToken,
        orderId: purchase.orderId,
        packageName: purchase.packageName,
        originalJson: purchase.originalJson,
        signature: purchase.dataSignature,
        developerPayload: purchase.payload,
      );
}
