from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = "ir.miplus.gamino"
APP_NAME = "گامینو"
MIN_SDK = 23
COMPILE_SDK = 36
KOTLIN_VERSION = "2.1.10"
GOOGLE_SERVICES_VERSION = "4.5.0"
FIREBASE_BOM_VERSION = "34.17.0"
ADIVERY_NATIVE_VERSION = "4.9.0"

SETTINGS_GRADLE = f'''pluginManagement {{
    def flutterSdkPath = {{
        def properties = new Properties()
        file("local.properties").withInputStream {{ properties.load(it) }}
        def flutterSdkPath = properties.getProperty("flutter.sdk")
        assert flutterSdkPath != null, "flutter.sdk not set in local.properties"
        return flutterSdkPath
    }}()

    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

    repositories {{
        google()
        mavenCentral()
        gradlePluginPortal()
    }}
}}

plugins {{
    id "dev.flutter.flutter-plugin-loader" version "1.0.0"
    id "com.android.application" version "8.6.0" apply false
    id "org.jetbrains.kotlin.android" version "{KOTLIN_VERSION}" apply false
    id "com.google.gms.google-services" version "{GOOGLE_SERVICES_VERSION}" apply false
}}

include ":app"
'''

ROOT_BUILD_GRADLE = '''allprojects {
    repositories {
        google()
        mavenCentral()
        maven { url 'https://jitpack.io' }
    }
}

rootProject.buildDir = "../build"
subprojects {
    project.buildDir = "${rootProject.buildDir}/${project.name}"
}
subprojects {
    project.evaluationDependsOn(":app")
}

tasks.register("clean", Delete) {
    delete rootProject.buildDir
}
'''

APP_BUILD_GRADLE = f'''plugins {{
    id "com.android.application"
    id "kotlin-android"
    id "dev.flutter.flutter-gradle-plugin"
    id "com.google.gms.google-services"
}}


def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {{
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}}


android {{
    namespace = "{PACKAGE}"
    compileSdk = {COMPILE_SDK}
    ndkVersion = flutter.ndkVersion

    compileOptions {{
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }}

    kotlinOptions {{
        jvmTarget = "21"
    }}

    buildFeatures {{
        buildConfig = true
    }}

    signingConfigs {{
        release {{
            if (keystorePropertiesFile.exists()) {{
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
            }}
        }}
    }}

    defaultConfig {{
        applicationId = "{PACKAGE}"
        minSdk = {MIN_SDK}
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }}

    flavorDimensions "market"
    productFlavors {{
        bazaar {{
            dimension "market"
            buildConfigField "String", "GAMINO_MARKET", '"bazaar"'
            manifestPlaceholders = [
                marketApplicationId: "com.farsitel.bazaar",
                marketBindAddress: "com.farsitel.bazaar.InAppBillingService.BIND",
                marketPermission: "com.farsitel.bazaar.permission.PAY_THROUGH_BAZAAR"
            ]
        }}
        myket {{
            dimension "market"
            buildConfigField "String", "GAMINO_MARKET", '"myket"'
            manifestPlaceholders = [
                marketApplicationId: "ir.mservices.market",
                marketBindAddress: "ir.mservices.market.InAppBillingService.BIND",
                marketPermission: "ir.mservices.market.BILLING"
            ]
        }}
    }}

    buildTypes {{
        release {{
            signingConfig = signingConfigs.release
            minifyEnabled false
            shrinkResources false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }}
    }}
}}

dependencies {{
    implementation platform("com.google.firebase:firebase-bom:{FIREBASE_BOM_VERSION}")
    implementation "com.google.firebase:firebase-messaging"
    implementation "com.adivery:sdk:{ADIVERY_NATIVE_VERSION}"
}}

flutter {{
    source = "../.."
}}
'''

MANIFEST = f'''<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="com.google.android.gms.permission.AD_ID" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <application
        android:label="{APP_NAME}"
        android:icon="@mipmap/ic_launcher"
        android:roundIcon="@mipmap/ic_launcher">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
                android:name="io.flutter.embedding.android.NormalTheme"
                android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <service
            android:name=".GaminoFirebaseMessagingService"
            android:exported="false">
            <intent-filter>
                <action android:name="com.google.firebase.MESSAGING_EVENT" />
            </intent-filter>
        </service>
        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
</manifest>
'''

MAIN_ACTIVITY = r'''package ir.miplus.gamino

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import com.google.firebase.messaging.FirebaseMessaging
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterFragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GaminoPushReporter.flushAsync(applicationContext)
        handlePushIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handlePushIntent(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        AdiveryNativeBridge(this).register(flutterEngine)
        flutterEngine.platformViewsController.registry.registerViewFactory(
            AdiveryBannerFactory.VIEW_TYPE,
            AdiveryBannerFactory(flutterEngine.dartExecutor.binaryMessenger),
        )

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ir.miplus.gamino/app_control")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "finishAndRemoveTask" -> {
                        finishAndRemoveTask()
                        result.success(null)
                    }
                    "openUrl" -> {
                        val value = call.argument<String>("url").orEmpty()
                        try {
                            val uri = Uri.parse(value)
                            if (uri.scheme == "https" || uri.scheme == "http") {
                                startActivity(Intent(Intent.ACTION_VIEW, uri))
                                result.success("opened")
                            } else result.error("URL", "Unsupported URL", null)
                        } catch (error: Throwable) {
                            result.error("URL", error.message ?: "Unable to open URL", null)
                        }
                    }
                    "openMarketReview" -> {
                        val opened = try {
                            when (BuildConfig.GAMINO_MARKET) {
                                "bazaar" -> {
                                    startActivity(
                                        Intent(
                                            Intent.ACTION_EDIT,
                                            Uri.parse("bazaar://details?id=$packageName"),
                                        ).setPackage("com.farsitel.bazaar")
                                    )
                                    true
                                }
                                "myket" -> {
                                    startActivity(
                                        Intent(
                                            Intent.ACTION_VIEW,
                                            Uri.parse("myket://comment?id=$packageName"),
                                        ).setPackage("ir.mservices.market")
                                    )
                                    true
                                }
                                else -> false
                            }
                        } catch (_: Throwable) {
                            false
                        }
                        result.success(if (opened) "opened" else "unavailable")
                    }
                    else -> result.notImplemented()
                }
            }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ir.miplus.gamino/push")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "requestPermission" -> {
                        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4107)
                        }
                        result.success(null)
                    }
                    "getToken" -> {
                        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val token = task.result.orEmpty()
                                getSharedPreferences("gamino_push_native_v1", MODE_PRIVATE).edit().putString("latest_fcm_token", token).apply()
                                result.success(token)
                            } else {
                                result.error("FCM_TOKEN", task.exception?.message ?: "FCM token unavailable", null)
                            }
                        }
                    }
                    "flushEvents" -> {
                        GaminoPushReporter.flushAsync(applicationContext)
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun handlePushIntent(source: Intent?) {
        if (source?.action != GaminoFirebaseMessagingService.ACTION_OPEN) return
        val eventUrl = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_EVENT_URL).orEmpty()
        val deliveryId = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_DELIVERY_ID).orEmpty()
        val trackingToken = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_TRACKING_TOKEN).orEmpty()
        val destinationType = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_DESTINATION_TYPE).orEmpty()
        val destinationUrl = source.getStringExtra(GaminoFirebaseMessagingService.EXTRA_DESTINATION_URL).orEmpty()

        GaminoPushReporter.recordEvent(applicationContext, eventUrl, deliveryId, trackingToken, "click")
        source.action = null

        if (destinationType == "link" && destinationUrl.isNotBlank()) {
            try {
                val uri = Uri.parse(destinationUrl)
                if (uri.scheme == "https" || uri.scheme == "http") {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
            } catch (_: Throwable) {
                // The app remains open when the destination URL cannot be opened.
            }
        }
    }
}
'''


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def patch_pubspec() -> None:
    path = ROOT / "pubspec.yaml"
    text = path.read_text(encoding="utf-8")
    lines = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("tapsell_mediation:") or stripped.startswith("tapsell_mediation_legacy:") or stripped.startswith("adivery:"):
            continue
        lines.append(line)
    text = "\n".join(lines).rstrip() + "\n"
    market_dep_count = sum(1 for dep in ("flutter_poolakey:", "myket_iap:") if dep in text)
    if market_dep_count > 1:
        raise RuntimeError("Both market billing plugins are active at once; use scripts/select_market_iap.py before build")
    for required_file in (
        ROOT / "scripts" / "select_market_iap.py",
        ROOT / "lib" / "market_billing_bazaar.dart",
        ROOT / "lib" / "market_billing_myket.dart",
    ):
        if not required_file.is_file():
            raise RuntimeError(f"Missing market build selector file: {required_file.relative_to(ROOT)}")
    path.write_text(text, encoding="utf-8")


def patch_android() -> None:
    write(ROOT / "android" / "settings.gradle", SETTINGS_GRADLE)
    stale_settings = ROOT / "android" / "settings.gradle.kts"
    if stale_settings.exists():
        stale_settings.unlink()
    write(ROOT / "android" / "build.gradle", ROOT_BUILD_GRADLE)
    write(ROOT / "android" / "app" / "build.gradle", APP_BUILD_GRADLE)
    write(ROOT / "android" / "app" / "src" / "main" / "AndroidManifest.xml", MANIFEST)

    props = ROOT / "android" / "gradle.properties"
    old_lines = props.read_text(encoding="utf-8").splitlines() if props.exists() else []
    blocked_prefixes = ("TAPSELL_", "ADIVERY_")
    kept = []
    for line in old_lines:
        key = line.split("=", 1)[0].strip() if "=" in line else ""
        if key == "android.suppressUnsupportedCompileSdk" or key.startswith(blocked_prefixes):
            continue
        kept.append(line)
    kept.append(f"android.suppressUnsupportedCompileSdk={COMPILE_SDK}")
    write(props, "\n".join(kept).rstrip() + "\n")

    write(ROOT / "android" / "app" / "proguard-rules.pro", "# Adivery, Firebase and the selected market IAP plugin use bundled consumer rules.\n")


def patch_native() -> None:
    package_dir = ROOT / "android" / "app" / "src" / "main" / "kotlin" / "ir" / "miplus" / "gamino"
    package_dir.mkdir(parents=True, exist_ok=True)
    for stale_name in ("TapsellNativeBridge.kt", "InlineBannerView.kt", "GaminoApplication.kt"):
        stale = package_dir / stale_name
        if stale.exists():
            stale.unlink()
    write(package_dir / "MainActivity.kt", MAIN_ACTIVITY)


def install_launcher_icon() -> None:
    src_root = ROOT / "assets" / "android_icon"
    res_root = ROOT / "android" / "app" / "src" / "main" / "res"
    if not src_root.exists():
        return
    for src in src_root.glob("mipmap-*/*.png"):
        dest = res_root / src.parent.name / src.name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dest)


def verify() -> None:
    pubspec = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
    active_market_deps = [
        dep for dep in ("flutter_poolakey: 2.2.0+1.0.0", "myket_iap: 1.1.12")
        if dep in pubspec
    ]
    if len(active_market_deps) > 1:
        raise RuntimeError("Both Bazaar and Myket billing plugins are active in one Flutter build")
    for required_file in (
        ROOT / "scripts" / "select_market_iap.py",
        ROOT / "lib" / "market_billing_bazaar.dart",
        ROOT / "lib" / "market_billing_myket.dart",
    ):
        if not required_file.is_file():
            raise RuntimeError(f"Missing market build selector file: {required_file.relative_to(ROOT)}")
    if "adivery:" in pubspec or "tapsell_mediation:" in pubspec or "tapsell_mediation_legacy:" in pubspec:
        raise RuntimeError("Stale Flutter ad bridge dependency remains; Gamino uses the native Adivery SDK bridge")

    settings = (ROOT / "android" / "settings.gradle").read_text(encoding="utf-8")
    if f'version "{KOTLIN_VERSION}"' not in settings:
        raise RuntimeError(f"Kotlin {KOTLIN_VERSION} is not configured")
    if f'com.google.gms.google-services" version "{GOOGLE_SERVICES_VERSION}"' not in settings:
        raise RuntimeError("Google Services Gradle plugin is not configured")

    root_build = (ROOT / "android" / "build.gradle").read_text(encoding="utf-8")
    if "mavenCentral()" not in root_build or "https://jitpack.io" not in root_build or "maven.tapsell" in root_build.lower():
        raise RuntimeError("Android repositories are incomplete or stale")

    app = (ROOT / "android" / "app" / "build.gradle").read_text(encoding="utf-8")
    required = (
        f"compileSdk = {COMPILE_SDK}",
        f"minSdk = {MIN_SDK}",
        "JavaVersion.VERSION_21",
        'jvmTarget = "21"',
        'flavorDimensions "market"',
        'bazaar {',
        'myket {',
        'buildConfigField "String", "GAMINO_MARKET", \'"bazaar"\'',
        'buildConfigField "String", "GAMINO_MARKET", \'"myket"\'',
        "com.farsitel.bazaar",
        "ir.mservices.market",
        "com.google.gms.google-services",
        f"com.google.firebase:firebase-bom:{FIREBASE_BOM_VERSION}",
        "com.google.firebase:firebase-messaging",
        f"com.adivery:sdk:{ADIVERY_NATIVE_VERSION}",
    )
    if any(item not in app for item in required):
        raise RuntimeError("Android app Gradle market/flavor configuration is incomplete")
    if "tapsell" in app.lower():
        raise RuntimeError("Stale Tapsell Gradle configuration remains")

    manifest = (ROOT / "android" / "app" / "src" / "main" / "AndroidManifest.xml").read_text(encoding="utf-8")
    for item in ("android.permission.INTERNET", "android.permission.ACCESS_NETWORK_STATE", "com.google.android.gms.permission.AD_ID", "android.permission.POST_NOTIFICATIONS", "GaminoFirebaseMessagingService"):
        if item not in manifest:
            raise RuntimeError(f"Android manifest is missing {item}")

    if not (ROOT / "android" / "app" / "google-services.json").is_file():
        raise RuntimeError("google-services.json is missing")

    native_dir = ROOT / "android" / "app" / "src" / "main" / "kotlin" / "ir" / "miplus" / "gamino"
    java_dir = ROOT / "android" / "app" / "src" / "main" / "java" / "ir" / "miplus" / "gamino"
    main = (native_dir / "MainActivity.kt").read_text(encoding="utf-8")
    for item in (
        "FlutterFragmentActivity",
        "ir.miplus.gamino/push",
        "FirebaseMessaging.getInstance().token",
        '"openUrl"',
        '"openMarketReview"',
        "BuildConfig.GAMINO_MARKET",
        "bazaar://details?id=$packageName",
        "myket://comment?id=$packageName",
        "AdiveryNativeBridge(this).register",
        "AdiveryBannerFactory.VIEW_TYPE",
    ):
        if item not in main:
            raise RuntimeError(f"MainActivity is missing {item}")
    if 'call.argument<String>("market")' in main:
        raise RuntimeError("Market review must be selected by build flavor, not by a Dart argument")

    for required_file in ("GaminoFirebaseMessagingService.kt", "GaminoPushReporter.kt", "AdiveryBannerFactory.kt"):
        if not (native_dir / required_file).is_file():
            raise RuntimeError(f"Required native file is missing: {required_file}")
    if not (java_dir / "AdiveryNativeBridge.java").is_file():
        raise RuntimeError("Required native file is missing: AdiveryNativeBridge.java")
    bridge = (java_dir / "AdiveryNativeBridge.java").read_text(encoding="utf-8")
    banner = (native_dir / "AdiveryBannerFactory.kt").read_text(encoding="utf-8")
    if "com.adivery.sdk.Adivery" not in bridge or "prepareRewardedAd" not in bridge or "prepareInterstitialAd" not in bridge:
        raise RuntimeError("Native Adivery full-screen bridge is incomplete")
    if "AdiveryBannerAdView" not in banner or "BannerSize.LARGE_BANNER" not in banner:
        raise RuntimeError("Native Adivery banner bridge is incomplete")
    for stale_file in ("TapsellNativeBridge.kt", "InlineBannerView.kt", "GaminoApplication.kt"):
        if (native_dir / stale_file).exists():
            raise RuntimeError(f"Stale native ad bridge remains: {stale_file}")

    android_text = "\n".join(
        p.read_text(encoding="utf-8", errors="ignore")
        for p in (ROOT / "android").rglob("*")
        if p.is_file() and p.suffix.lower() in {".gradle", ".kts", ".kt", ".java", ".xml", ".properties"}
    )
    if "tapsell" in android_text.lower():
        raise RuntimeError("Stale Tapsell Android integration remains")


def main() -> None:
    patch_pubspec()
    patch_android()
    patch_native()
    install_launcher_icon()
    verify()
    print("Gamino Android preparation verified: Bazaar/Myket flavors + isolated market IAP + direct review + Adivery + Firebase, SDK 36, Java 21, Kotlin 2.1.10")


if __name__ == "__main__":
    main()
