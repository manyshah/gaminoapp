#!/usr/bin/env python3
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PUBSPEC = ROOT / "pubspec.yaml"
TARGET = ROOT / "lib" / "market_billing.dart"

MARKETS = {
    "bazaar": {
        "template": ROOT / "lib" / "market_billing_bazaar.dart",
        "dependency": "flutter_poolakey: 2.2.0+1.0.0",
        "forbidden": "myket_iap",
        "required_import": "package:flutter_poolakey/flutter_poolakey.dart",
    },
    "myket": {
        "template": ROOT / "lib" / "market_billing_myket.dart",
        "dependency": "myket_iap: 1.1.12",
        "forbidden": "flutter_poolakey",
        "required_import": "package:myket_iap/myket_iap.dart",
    },
}


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def select(market: str) -> None:
    cfg = MARKETS.get(market)
    if cfg is None:
        fail("market must be 'bazaar' or 'myket'")

    if not cfg["template"].is_file():
        fail(f"missing market template: {cfg['template'].relative_to(ROOT)}")
    if not PUBSPEC.is_file():
        fail("pubspec.yaml is missing")

    text = PUBSPEC.read_text(encoding="utf-8")
    lines = []
    insert_at = None
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("flutter_poolakey:") or stripped.startswith("myket_iap:"):
            continue
        lines.append(line)
        if stripped.startswith("image_picker:"):
            insert_at = len(lines)

    if insert_at is None:
        fail("could not find image_picker dependency anchor in pubspec.yaml")

    lines.insert(insert_at, f"  {cfg['dependency']}")
    updated = "\n".join(lines).rstrip() + "\n"

    # Exactly one market billing plugin must exist in the selected build.
    if updated.count("flutter_poolakey:") + updated.count("myket_iap:") != 1:
        fail("selected pubspec must contain exactly one market billing plugin")
    if cfg["dependency"] not in updated:
        fail("selected market dependency was not written")
    if re.search(rf"^\s*{re.escape(cfg['forbidden'])}:\s*", updated, flags=re.MULTILINE):
        fail("opposite market dependency is still present")

    PUBSPEC.write_text(updated, encoding="utf-8")
    shutil.copyfile(cfg["template"], TARGET)

    target_text = TARGET.read_text(encoding="utf-8")
    if cfg["required_import"] not in target_text:
        fail("selected billing implementation does not contain its required plugin import")
    if cfg["forbidden"] in target_text:
        fail("selected billing implementation still references the opposite market plugin")
    if f"const String gaminoMarket = '{market}';" not in target_text:
        fail("selected billing implementation market marker mismatch")

    marker = ROOT / ".gamino_market_selected"
    marker.write_text(market + "\n", encoding="utf-8")
    print(f"Selected Gamino market billing: {market}")
    print(f"Active dependency: {cfg['dependency']}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        fail("usage: python3 scripts/select_market_iap.py <bazaar|myket>")
    select(sys.argv[1].strip().lower())
