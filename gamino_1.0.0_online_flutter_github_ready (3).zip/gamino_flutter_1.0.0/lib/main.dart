import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as flutter_material show Text;
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:image_picker/image_picker.dart';

import 'market_billing.dart';

String faDigits(Object? value) {
  var result = value?.toString() ?? '';
  const western = '0123456789';
  const arabic = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  for (var i = 0; i < western.length; i++) {
    result = result.replaceAll(western[i], persian[i]);
    result = result.replaceAll(arabic[i], persian[i]);
  }
  return result.replaceAll('%', '٪');
}

String enDigits(Object? value) {
  var result = value?.toString() ?? '';
  const western = '0123456789';
  const arabic = '٠١٢٣٤٥٦٧٨٩';
  const persian = '۰۱۲۳۴۵۶۷۸۹';
  for (var i = 0; i < western.length; i++) {
    result = result.replaceAll(persian[i], western[i]);
    result = result.replaceAll(arabic[i], western[i]);
  }
  return result;
}

/// App-wide presentation wrapper: every numeric digit rendered through Text is
/// localized to Persian digits. Data sent to APIs/storage remains untouched.
class Text extends StatelessWidget {
  const Text(
    this.data, {
    super.key,
    this.style,
    this.strutStyle,
    this.textAlign,
    this.textDirection,
    this.locale,
    this.softWrap,
    this.overflow,
    this.textScaler,
    this.maxLines,
    this.semanticsLabel,
    this.textWidthBasis,
    this.textHeightBehavior,
    this.selectionColor,
  });

  final String data;
  final TextStyle? style;
  final StrutStyle? strutStyle;
  final TextAlign? textAlign;
  final TextDirection? textDirection;
  final Locale? locale;
  final bool? softWrap;
  final TextOverflow? overflow;
  final TextScaler? textScaler;
  final int? maxLines;
  final String? semanticsLabel;
  final TextWidthBasis? textWidthBasis;
  final TextHeightBehavior? textHeightBehavior;
  final Color? selectionColor;

  @override
  Widget build(BuildContext context) => flutter_material.Text(
        faDigits(data),
        style: style,
        strutStyle: strutStyle,
        textAlign: textAlign,
        textDirection: textDirection,
        locale: locale,
        softWrap: softWrap,
        overflow: overflow,
        textScaler: textScaler,
        maxLines: maxLines,
        semanticsLabel: semanticsLabel == null ? null : faDigits(semanticsLabel),
        textWidthBasis: textWidthBasis,
        textHeightBehavior: textHeightBehavior,
        selectionColor: selectionColor,
      );
}

const String kAppName = 'گامینو';
const String kGaminoBuildLabel = '1.0.0';
const String kGaminoApiBaseUrl = String.fromEnvironment('GAMINO_API_URL', defaultValue: 'https://gaminoapp.ir/gamino/api');
const String kAdiveryAppId = '5022e2c9-1da8-4a59-97ba-91699c379b51';
const String kAdiveryBannerPlacementId = '6557affd-786e-4a39-9885-cb074751e61f';
const String kAdiveryRewardedPlacementId = 'b2550d7c-eed0-40a8-8657-2f536b68d1f7';
const String kAdiveryInterstitialPlacementId = '92f6ad3f-078f-4fed-bb40-afa09e1e41f7';
const String kOwnerPackageName = 'ir.miplus.gamino';
const String kOwnerSignatureSha256 = '93:7A:45:CB:0C:47:B3:F6:20:A1:79:C1:D1:82:98:89:BF:F1:22:9F:92:5B:C4:D0:99:40:7B:28:7E:87:66:B6';
const String kOwnerAppLabel = 'گامینو';

// Stable global keys used by app-level refresh/auth flows and guest navigation.
// Keep these typed so every currentState access is checked against the actual
// State implementation instead of relying on dynamic/undefined globals.
final GlobalKey<_StudentBattleAppState> gaminoAppKey = GlobalKey<_StudentBattleAppState>();
final GlobalKey<_HomeShellState> gaminoHomeShellKey = GlobalKey<_HomeShellState>();
const MethodChannel _gaminoAppControlChannel = MethodChannel('ir.miplus.gamino/app_control');

Future<void> _openCurrentMarketReview(BuildContext context) async {
  final marketLabel = gaminoMarket == 'myket' ? 'مایکت' : 'کافه‌بازار';
  try {
    final result = await _gaminoAppControlChannel.invokeMethod<String>('openMarketReview');
    if (!context.mounted) return;
    if (result != 'opened') {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$marketLabel روی این دستگاه در دسترس نیست.')));
    }
  } on PlatformException catch (error) {
    if (!context.mounted) return;
    final message = (error.message ?? '').trim();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message.isEmpty ? 'باز کردن ثبت نظر $marketLabel انجام نشد.' : message)),
    );
  }
}
DateTime _suppressHomeExitUntil = DateTime.fromMillisecondsSinceEpoch(0);
void suppressHomeExitBriefly() { _suppressHomeExitUntil = DateTime.now().add(const Duration(milliseconds: 700)); }

class GaminoAdState {
  static bool userAdsDisabled = false;
  static bool adiveryInterstitialEnabled = true;
  static bool get bannerAdsDisabled => userAdsDisabled;
  static bool get allAdsDisabled => userAdsDisabled;
}

class HomeAdItem {
  const HomeAdItem({
    required this.id,
    required this.type,
    required this.imageUrl,
    required this.destinationUrl,
    required this.displaySeconds,
    required this.updatedAt,
  });

  final String id;
  final String type;
  final String imageUrl;
  final String destinationUrl;
  final int displaySeconds;
  final String updatedAt;

  bool get isAdivery => type == 'adivery' || type == 'tapsell';
  bool get isCustom => !isAdivery;

  factory HomeAdItem.fromJson(Map<String, dynamic> json) => HomeAdItem(
        id: json['id']?.toString() ?? '',
        type: (json['type']?.toString() ?? 'custom').toLowerCase(),
        imageUrl: json['imageUrl']?.toString() ?? '',
        destinationUrl: json['destinationUrl']?.toString() ?? '',
        displaySeconds: ((json['displaySeconds'] as num?)?.toInt() ?? 10).clamp(3, 120).toInt(),
        updatedAt: json['updatedAt']?.toString() ?? '',
      );
}


class CardPackage {
  const CardPackage({
    required this.id,
    required this.amount,
    required this.priceToman,
    required this.discountPercent,
    required this.sortOrder,
    this.published = true,
  });

  final String id;
  final int amount;
  final int priceToman;
  final int discountPercent;
  final int sortOrder;
  final bool published;

  factory CardPackage.fromJson(Map<String, dynamic> json) => CardPackage(
        id: json['id']?.toString() ?? '',
        amount: max(1, (json['amount'] as num?)?.toInt() ?? 100),
        priceToman: max(0, (json['priceToman'] as num?)?.toInt() ?? (json['price_toman'] as num?)?.toInt() ?? 0),
        discountPercent: ((json['discountPercent'] as num?)?.toInt() ?? (json['discount_percent'] as num?)?.toInt() ?? 0).clamp(0, 100).toInt(),
        sortOrder: max(0, (json['sortOrder'] as num?)?.toInt() ?? (json['sort_order'] as num?)?.toInt() ?? 0),
        published: json['published'] != false,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'amount': amount,
        'priceToman': priceToman,
        'discountPercent': discountPercent,
        'sortOrder': sortOrder,
        'published': published,
      };
}

const List<CardPackage> kDefaultCardPackages = [
  CardPackage(id: 'gamino_cards_50', amount: 50, priceToman: 5000, discountPercent: 0, sortOrder: 10),
  CardPackage(id: 'gamino_cards_100', amount: 100, priceToman: 20000, discountPercent: 0, sortOrder: 20),
  CardPackage(id: 'gamino_cards_300', amount: 300, priceToman: 35000, discountPercent: 0, sortOrder: 30),
];

String faMoney(int value) {
  final raw = max(0, value).toString();
  final out = StringBuffer();
  for (var i = 0; i < raw.length; i++) {
    if (i > 0 && (raw.length - i) % 3 == 0) out.write(',');
    out.write(raw[i]);
  }
  return faDigits(out.toString());
}

enum RewardedVideoOutcome { rewarded, incomplete, unavailable }

/// Native Adivery SDK bridge. Android uses Adivery SDK 4.9.0 directly,
/// keeping the current Gamino Flutter/Dart build toolchain unchanged.
class GaminoAdiveryService {
  static const MethodChannel _channel = MethodChannel('ir.miplus.gamino/adivery_native');
  static bool _initialized = false;
  static Completer<RewardedVideoOutcome>? _rewardCompleter;

  static void ensureInitialized() {
    if (_initialized || !Platform.isAndroid) return;
    _initialized = true;
    _channel.setMethodCallHandler((call) async {
      switch (call.method) {
        case 'onRewardedClosed':
          final args = Map<String, dynamic>.from(call.arguments as Map? ?? const {});
          if (args['placement']?.toString() != kAdiveryRewardedPlacementId) return;
          unawaited(_channel.invokeMethod<bool>('prepareRewarded', kAdiveryRewardedPlacementId));
          final completer = _rewardCompleter;
          if (completer != null && !completer.isCompleted) {
            completer.complete(args['isRewarded'] == true ? RewardedVideoOutcome.rewarded : RewardedVideoOutcome.incomplete);
          }
          break;
        case 'onInterstitialClosed':
          if (call.arguments?.toString() == kAdiveryInterstitialPlacementId) {
            unawaited(_channel.invokeMethod<bool>('prepareInterstitial', kAdiveryInterstitialPlacementId));
          }
          break;
        case 'onError':
          final args = Map<String, dynamic>.from(call.arguments as Map? ?? const {});
          debugPrint('[GaminoAdivery] ${args['placement']}: ${args['reason']}');
          if (args['placement']?.toString() == kAdiveryRewardedPlacementId) {
            final completer = _rewardCompleter;
            if (completer != null && !completer.isCompleted) completer.complete(RewardedVideoOutcome.unavailable);
          }
          break;
      }
    });
    unawaited(_channel.invokeMethod<bool>('prepareInterstitial', kAdiveryInterstitialPlacementId));
    unawaited(_channel.invokeMethod<bool>('prepareRewarded', kAdiveryRewardedPlacementId));
  }

  static Future<bool> _isLoaded(String placementId) async {
    ensureInitialized();
    try {
      return await _channel.invokeMethod<bool>('isLoaded', placementId).timeout(const Duration(seconds: 3)) == true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> showLessonInterstitial({required bool adsDisabled}) async {
    if (adsDisabled || !Platform.isAndroid) return;

    // Interstitial is the only Adivery format controlled by the Admin toggle.
    // Read the public server setting immediately before every display attempt so
    // changing the checkbox does not require an app release or a fresh login.
    try {
      final payload = await GaminoApiService.request('public.ad_settings', get: true)
          .timeout(const Duration(seconds: 4));
      GaminoAdState.adiveryInterstitialEnabled = payload['adiveryInterstitialEnabled'] != false;
    } catch (_) {
      // If the server cannot confirm the switch is enabled, do not show the ad.
      return;
    }
    if (!GaminoAdState.adiveryInterstitialEnabled) return;

    ensureInitialized();
    try {
      var loaded = await _isLoaded(kAdiveryInterstitialPlacementId);
      if (!loaded) {
        await _channel.invokeMethod<bool>('prepareInterstitial', kAdiveryInterstitialPlacementId);
        await Future<void>.delayed(const Duration(milliseconds: 700));
        loaded = await _isLoaded(kAdiveryInterstitialPlacementId);
      }
      if (loaded) await _channel.invokeMethod<bool>('show', kAdiveryInterstitialPlacementId);
    } catch (error) {
      debugPrint('[GaminoAdivery] lesson interstitial unavailable: $error');
    }
  }

  static Future<void> openExternalUrl(String url) async {
    final value = url.trim();
    if (value.isEmpty || !Platform.isAndroid) return;
    try {
      await _gaminoAppControlChannel.invokeMethod<String>('openUrl', <String, dynamic>{'url': value});
    } catch (error) {
      debugPrint('[GaminoLink] unable to open destination: $error');
    }
  }

  static Future<RewardedVideoOutcome> showRewardedVideo() async {
    if (!Platform.isAndroid) return RewardedVideoOutcome.unavailable;
    ensureInitialized();
    try {
      var loaded = await _isLoaded(kAdiveryRewardedPlacementId);
      if (!loaded) {
        await _channel.invokeMethod<bool>('prepareRewarded', kAdiveryRewardedPlacementId);
        await Future<void>.delayed(const Duration(milliseconds: 900));
        loaded = await _isLoaded(kAdiveryRewardedPlacementId);
      }
      if (!loaded) return RewardedVideoOutcome.unavailable;
      final completer = Completer<RewardedVideoOutcome>();
      _rewardCompleter = completer;
      final shown = await _channel.invokeMethod<bool>('show', kAdiveryRewardedPlacementId);
      if (shown != true) return RewardedVideoOutcome.unavailable;
      return await completer.future.timeout(
        const Duration(minutes: 3),
        onTimeout: () => RewardedVideoOutcome.unavailable,
      );
    } catch (error) {
      debugPrint('[GaminoAdivery] rewarded unavailable: $error');
      return RewardedVideoOutcome.unavailable;
    } finally {
      _rewardCompleter = null;
    }
  }
}

/// Inline Adivery banner. The native banner is laid out offstage while loading,
/// so no empty placeholder is visible. It appears only after a confirmed load.
class GaminoInlineBanner extends StatefulWidget {
  const GaminoInlineBanner({
    super.key,
    this.height = 108,
    this.slot = 'default',
  });

  final double height;
  final String slot;

  @override
  State<GaminoInlineBanner> createState() => _GaminoInlineBannerState();
}

class _GaminoInlineBannerState extends State<GaminoInlineBanner> {
  bool _loaded = false;
  bool _failed = false;
  MethodChannel? _bannerChannel;

  void _onPlatformViewCreated(int viewId) {
    final channel = MethodChannel('ir.miplus.gamino/adivery_banner/$viewId');
    _bannerChannel = channel;
    channel.setMethodCallHandler((call) async {
      if (!mounted) return;
      if (call.method == 'onLoaded') {
        setState(() { _loaded = true; _failed = false; });
      } else if (call.method == 'onError') {
        debugPrint('[GaminoAdivery] banner ${widget.slot} failed: ${call.arguments}');
        setState(() { _loaded = false; _failed = true; });
      }
    });
    unawaited(channel.invokeMethod<bool>('load'));
  }

  @override
  void dispose() {
    _bannerChannel?.setMethodCallHandler(null);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (GaminoAdState.bannerAdsDisabled || !Platform.isAndroid || _failed) return const SizedBox.shrink();
    final banner = SizedBox(
      height: widget.height,
      child: AndroidView(
        viewType: 'ir.miplus.gamino/adivery_banner',
        creationParams: <String, dynamic>{'placementId': kAdiveryBannerPlacementId},
        creationParamsCodec: const StandardMessageCodec(),
        onPlatformViewCreated: _onPlatformViewCreated,
      ),
    );
    return Offstage(
      offstage: !_loaded,
      child: Container(
        height: widget.height,
        alignment: Alignment.center,
        margin: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppPalette.primary.withOpacity(.06)),
        ),
        clipBehavior: Clip.antiAlias,
        child: banner,
      ),
    );
  }
}

/// Home slider inventory is controlled from the admin panel. It supports
/// custom image ads and Adivery banner slots, with a per-slide duration.
class GaminoHomeRotatingBanner extends StatefulWidget {
  const GaminoHomeRotatingBanner({super.key});

  @override
  State<GaminoHomeRotatingBanner> createState() => _GaminoHomeRotatingBannerState();
}

class _GaminoHomeRotatingBannerState extends State<GaminoHomeRotatingBanner> {
  final PageController _controller = PageController();
  Timer? _timer;
  List<HomeAdItem> _items = const [];
  int _index = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  Future<void> _load() async {
    try {
      final payload = await GaminoApiService.request('public.home_ads', get: true);
      final items = (payload['ads'] as List? ?? [])
          .whereType<Map>()
          .map((row) => HomeAdItem.fromJson(Map<String, dynamic>.from(row)))
          .where((item) => item.id.isNotEmpty && (item.isAdivery || item.imageUrl.trim().isNotEmpty))
          .toList();
      if (!mounted) return;
      setState(() {
        _items = items;
        _loading = false;
        _index = 0;
      });
      if (items.isNotEmpty) {
        _recordImpression(items.first);
        _scheduleNext();
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _reportCustomEvent(HomeAdItem item, String event) async {
    if (!item.isCustom) return;
    try {
      await GaminoApiService.request(
        'public.home_ad_event',
        body: {'id': item.id, 'event': event},
      );
    } catch (_) {}
  }

  void _recordImpression(HomeAdItem item) {
    if (!item.isCustom) return;
    unawaited(_reportCustomEvent(item, 'view'));
  }

  Future<void> _handleCustomTap(HomeAdItem item) async {
    if (!item.isCustom) return;
    unawaited(_reportCustomEvent(item, 'click'));
    await GaminoAdiveryService.openExternalUrl(item.destinationUrl);
  }

  void _scheduleNext() {
    _timer?.cancel();
    if (!mounted || _items.length < 2) return;
    final seconds = _items[_index.clamp(0, _items.length - 1).toInt()].displaySeconds;
    _timer = Timer(Duration(seconds: seconds), () {
      if (!mounted || !_controller.hasClients || _items.length < 2) return;
      final next = (_index + 1) % _items.length;
      _controller.animateToPage(
        next,
        duration: const Duration(milliseconds: 420),
        curve: Curves.easeInOutCubic,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  Widget _buildSlide(HomeAdItem item) {
    if (item.isAdivery) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2),
        child: GaminoInlineBanner(slot: 'home_${item.id}'),
      );
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(18),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: item.destinationUrl.trim().isEmpty ? null : () => _handleCustomTap(item),
          child: SizedBox(
            height: 108,
            width: double.infinity,
            child: Image.network(
              item.imageUrl,
              fit: BoxFit.cover,
              filterQuality: FilterQuality.medium,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (GaminoAdState.allAdsDisabled || _loading || _items.isEmpty) return const SizedBox.shrink();
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          height: 116,
          child: PageView.builder(
            controller: _controller,
            physics: const BouncingScrollPhysics(),
            itemCount: _items.length,
            onPageChanged: (value) {
              if (!mounted) return;
              setState(() => _index = value);
              _recordImpression(_items[value]);
              _scheduleNext();
            },
            itemBuilder: (_, index) => _buildSlide(_items[index]),
          ),
        ),
        if (_items.length > 1) ...[
          const SizedBox(height: 7),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_items.length, (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              width: i == _index ? 22 : 7,
              height: 7,
              margin: const EdgeInsets.symmetric(horizontal: 3),
              decoration: BoxDecoration(
                color: i == _index ? AppPalette.primary : AppPalette.primary.withOpacity(.18),
                borderRadius: BorderRadius.circular(99),
              ),
            )),
          ),
        ],
      ],
    );
  }
}

final RouteObserver<ModalRoute<void>> gaminoRouteObserver = RouteObserver<ModalRoute<void>>();

class StudySyncEvent {
  const StudySyncEvent({
    required this.id,
    required this.ownerPhone,
    required this.subject,
    required this.chapter,
    required this.seconds,
    required this.createdAt,
  });

  final String id;
  final String ownerPhone;
  final String subject;
  final String chapter;
  final int seconds;
  final String createdAt;

  factory StudySyncEvent.create({required String ownerPhone, required String subject, required String chapter, required int seconds}) {
    final random = Random.secure().nextInt(0x7fffffff);
    return StudySyncEvent(
      id: 'study_${DateTime.now().microsecondsSinceEpoch}_$random',
      ownerPhone: ownerPhone,
      subject: subject.trim().isEmpty ? 'عمومی' : subject.trim(),
      chapter: chapter.trim().isEmpty ? 'مطالعه' : chapter.trim(),
      seconds: seconds.clamp(1, 300).toInt(),
      createdAt: DateTime.now().toUtc().toIso8601String(),
    );
  }

  Map<String, dynamic> toJson() => {
    'eventId': id,
    'ownerPhone': ownerPhone,
    'subject': subject,
    'chapter': chapter,
    'seconds': seconds,
    'createdAt': createdAt,
  };

  factory StudySyncEvent.fromJson(Map<String, dynamic> json) => StudySyncEvent(
    id: json['eventId']?.toString() ?? '',
    ownerPhone: json['ownerPhone']?.toString() ?? '',
    subject: json['subject']?.toString() ?? 'عمومی',
    chapter: json['chapter']?.toString() ?? 'مطالعه',
    seconds: (json['seconds'] as num?)?.toInt() ?? 0,
    createdAt: json['createdAt']?.toString() ?? '',
  );
}

class StudySyncQueue {
  static const String _key = 'gamino_pending_study_sync_v1';

  static Future<List<StudySyncEvent>> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? const <String>[];
    final events = <StudySyncEvent>[];
    for (final item in raw) {
      try {
        final decoded = jsonDecode(item);
        if (decoded is Map) {
          final event = StudySyncEvent.fromJson(Map<String, dynamic>.from(decoded));
          if (event.id.isNotEmpty && event.ownerPhone.isNotEmpty && event.seconds > 0) events.add(event);
        }
      } catch (_) {}
    }
    return events;
  }

  static Future<void> _save(List<StudySyncEvent> events) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_key, events.map((event) => jsonEncode(event.toJson())).toList());
  }

  static Future<void> enqueue(StudySyncEvent event) async {
    final events = await _load();
    if (!events.any((item) => item.id == event.id)) events.add(event);
    await _save(events.length > 500 ? events.sublist(events.length - 500) : events);
  }

  static Future<List<StudySyncEvent>> forOwner(String phone) async {
    final events = await _load();
    return events.where((event) => event.ownerPhone == phone).toList();
  }

  static Future<void> remove(String id) async {
    final events = await _load();
    events.removeWhere((event) => event.id == id);
    await _save(events);
  }
}

class GaminoApiException implements Exception {
  const GaminoApiException(this.message, {this.isNetwork = false});
  final String message;
  final bool isNetwork;
  @override
  String toString() => message;
}

class RemoteSessionStore {
  static const _tokenKey = 'gamino_online_session_token_v1';
  static Future<String?> readToken() async => (await SharedPreferences.getInstance()).getString(_tokenKey);
  static Future<void> writeToken(String token) async => (await SharedPreferences.getInstance()).setString(_tokenKey, token);
  static Future<void> clear() async => (await SharedPreferences.getInstance()).remove(_tokenKey);
}

class GaminoApiService {
  static Future<Map<String, dynamic>> request(
    String action, {
    String? token,
    Map<String, dynamic>? body,
    bool get = false,
    Duration timeout = const Duration(seconds: 18),
  }) async {
    final uri = Uri.parse('$kGaminoApiBaseUrl/index.php?action=${Uri.encodeQueryComponent(action)}');
    final headers = <String, String>{'Accept': 'application/json'};
    if (token != null && token.isNotEmpty) headers['Authorization'] = 'Bearer $token';
    http.Response response;
    try {
      response = get
          ? await http.get(uri, headers: headers).timeout(timeout)
          : await http
              .post(uri, headers: {...headers, 'Content-Type': 'application/json; charset=utf-8'}, body: jsonEncode(body ?? const {}))
              .timeout(timeout);
    } catch (_) {
      throw const GaminoApiException('اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.', isNetwork: true);
    }
    Map<String, dynamic> decoded = const {};
    try {
      final raw = jsonDecode(response.body);
      if (raw is Map) decoded = Map<String, dynamic>.from(raw);
    } catch (_) {
      throw const GaminoApiException('پاسخ معتبر از سرور دریافت نشد.');
    }
    if (response.statusCode < 200 || response.statusCode >= 300 || decoded['ok'] != true) {
      throw GaminoApiException(decoded['error']?.toString() ?? 'درخواست سرور ناموفق بود.');
    }
    final data = decoded['data'];
    return data is Map ? Map<String, dynamic>.from(data) : <String, dynamic>{};
  }
}

class GaminoPushClient {
  static const MethodChannel _channel = MethodChannel('ir.miplus.gamino/push');
  static bool _syncing = false;

  static Future<void> syncDevice() async {
    if (!Platform.isAndroid || _syncing) return;
    final sessionToken = await RemoteSessionStore.readToken();
    if (sessionToken == null || sessionToken.isEmpty) return;
    _syncing = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('gamino_push_permission_requested_v1') != true) {
        await _channel.invokeMethod<void>('requestPermission');
        await prefs.setBool('gamino_push_permission_requested_v1', true);
      }
      final fcmToken = (await _channel.invokeMethod<String>('getToken'))?.trim() ?? '';
      if (fcmToken.isEmpty) return;
      await GaminoApiService.request(
        'push.device.register',
        token: sessionToken,
        body: {'fcmToken': fcmToken},
      );
      await _channel.invokeMethod<void>('flushEvents');
    } catch (error) {
      debugPrint('[GaminoPush] device sync unavailable: $error');
    } finally {
      _syncing = false;
    }
  }

  static Future<void> unregisterDevice(String sessionToken) async {
    if (!Platform.isAndroid || sessionToken.isEmpty) return;
    try {
      final fcmToken = (await _channel.invokeMethod<String>('getToken'))?.trim() ?? '';
      if (fcmToken.isNotEmpty) {
        await GaminoApiService.request(
          'push.device.unregister',
          token: sessionToken,
          body: {'fcmToken': fcmToken},
        );
      }
      await _channel.invokeMethod<void>('flushEvents');
    } catch (error) {
      debugPrint('[GaminoPush] device unregister unavailable: $error');
    }
  }
}

Future<List<QuizQuestion>> fetchPublishedQuestionsForUser(AppUser user) async {
  final token = await RemoteSessionStore.readToken();
  if (token == null || token.isEmpty) return const <QuizQuestion>[];
  final payload = await GaminoApiService.request('state', token: token, get: true).timeout(const Duration(milliseconds: 1400));
  final books = (payload['books'] as List? ?? [])
      .whereType<Map>()
      .map((item) => LearningBook.fromJson(Map<String, dynamic>.from(item)))
      .toList();
  return panelQuestionsForUser(user, books);
}

const List<String> kSeniorTracks = ['ریاضی', 'تجربی', 'انسانی'];

String normalizeEducationTrack(int grade, String track) {
  if (grade < 10) return '';
  return kSeniorTracks.contains(track) ? track : 'ریاضی';
}

String gradePathText(int grade, [String track = '']) {
  final base = 'پایه ${gradeLabel(grade)}';
  final normalized = normalizeEducationTrack(grade, track);
  return normalized.isEmpty ? base : '$base | $normalized';
}

class DescriptiveQuestion {
  const DescriptiveQuestion({
    required this.id,
    required this.question,
    required this.answer,
    this.imageUrl = '',
  });

  final String id;
  final String question;
  final String answer;
  final String imageUrl;

  Map<String, dynamic> toJson() => {
        'id': id,
        'question': question,
        'answer': answer,
        'imageUrl': imageUrl,
      };

  factory DescriptiveQuestion.fromJson(Map<String, dynamic> json) => DescriptiveQuestion(
        id: json['id']?.toString() ?? '',
        question: json['question']?.toString() ?? '',
        answer: json['answer']?.toString() ?? '',
        imageUrl: json['imageUrl']?.toString() ?? '',
      );
}

class LearningLesson {
  const LearningLesson({
    required this.id,
    required this.title,
    required this.lessonNumber,
    required this.pdfUrl,
    required this.sortOrder,
    required this.updatedAt,
    this.lessonText = '',
    this.lessonImageUrl = '',
    this.lessonPdfUrl = '',
    this.stepText = '',
    this.stepImageUrl = '',
    this.stepPdfUrl = '',
    this.questionImageUrl = '',
    this.questionPdfUrl = '',
    this.questions = const [],
    this.descriptiveQuestions = const [],
  });

  final String id;
  final String title;
  final int lessonNumber;
  final String pdfUrl;
  final int sortOrder;
  final String updatedAt;
  final String lessonText;
  final String lessonImageUrl;
  final String lessonPdfUrl;
  final String stepText;
  final String stepImageUrl;
  final String stepPdfUrl;
  final String questionImageUrl;
  final String questionPdfUrl;
  final List<QuizQuestion> questions;
  final List<DescriptiveQuestion> descriptiveQuestions;

  bool get hasPdf => pdfUrl.trim().isNotEmpty;
  bool get hasLessonContent => lessonText.trim().isNotEmpty || lessonImageUrl.trim().isNotEmpty || lessonPdfUrl.trim().isNotEmpty;
  bool get hasStepContent => stepText.trim().isNotEmpty || stepImageUrl.trim().isNotEmpty || stepPdfUrl.trim().isNotEmpty;
  bool get hasQuestionContent => questions.isNotEmpty || descriptiveQuestions.isNotEmpty || questionImageUrl.trim().isNotEmpty || questionPdfUrl.trim().isNotEmpty;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'lessonNumber': lessonNumber,
        'pdfUrl': pdfUrl,
        'sortOrder': sortOrder,
        'updatedAt': updatedAt,
        'lessonText': lessonText,
        'lessonImageUrl': lessonImageUrl,
        'lessonPdfUrl': lessonPdfUrl,
        'stepText': stepText,
        'stepImageUrl': stepImageUrl,
        'stepPdfUrl': stepPdfUrl,
        'questionImageUrl': questionImageUrl,
        'questionPdfUrl': questionPdfUrl,
        'questions': questions.map((item) => item.toJson()).toList(),
        'descriptiveQuestions': descriptiveQuestions.map((item) => item.toJson()).toList(),
      };

  factory LearningLesson.fromJson(Map<String, dynamic> json) {
    final rawQuestions = (json['questions'] as List? ?? [])
        .whereType<Map>()
        .map((item) => QuizQuestion.fromJson(Map<String, dynamic>.from(item)))
        .toList();
    final rawDescriptiveQuestions = (json['descriptiveQuestions'] as List? ?? [])
        .whereType<Map>()
        .map((item) => DescriptiveQuestion.fromJson(Map<String, dynamic>.from(item)))
        .where((item) => item.question.trim().isNotEmpty && item.answer.trim().isNotEmpty)
        .toList();
    return LearningLesson(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'درس',
      lessonNumber: (json['lessonNumber'] as num?)?.toInt() ?? 1,
      pdfUrl: json['pdfUrl']?.toString() ?? '',
      sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
      updatedAt: json['updatedAt']?.toString() ?? '',
      lessonText: json['lessonText']?.toString() ?? '',
      lessonImageUrl: json['lessonImageUrl']?.toString() ?? '',
      lessonPdfUrl: json['lessonPdfUrl']?.toString() ?? '',
      stepText: json['stepText']?.toString() ?? '',
      stepImageUrl: json['stepImageUrl']?.toString() ?? '',
      stepPdfUrl: json['stepPdfUrl']?.toString() ?? '',
      questionImageUrl: json['questionImageUrl']?.toString() ?? '',
      questionPdfUrl: json['questionPdfUrl']?.toString() ?? '',
      questions: rawQuestions,
      descriptiveQuestions: rawDescriptiveQuestions,
    );
  }
}

class LearningBook {
  const LearningBook({
    required this.id,
    required this.grade,
    required this.track,
    required this.title,
    required this.coverUrl,
    required this.pdfUrl,
    required this.sortOrder,
    required this.updatedAt,
    required this.lessons,
  });

  final String id;
  final int grade;
  final String track;
  final String title;
  final String coverUrl;
  final String pdfUrl;
  final int sortOrder;
  final String updatedAt;
  final List<LearningLesson> lessons;

  bool get hasPdf => pdfUrl.trim().isNotEmpty;

  Map<String, dynamic> toJson() => {
        'id': id,
        'grade': grade,
        'track': track,
        'title': title,
        'coverUrl': coverUrl,
        'pdfUrl': pdfUrl,
        'sortOrder': sortOrder,
        'updatedAt': updatedAt,
        'lessons': lessons.map((item) => item.toJson()).toList(),
      };

  factory LearningBook.fromJson(Map<String, dynamic> json) {
    final rawLessons = (json['lessons'] as List? ?? [])
        .whereType<Map>()
        .map((item) => LearningLesson.fromJson(Map<String, dynamic>.from(item)))
        .toList()
      ..sort((a, b) => a.sortOrder != b.sortOrder ? a.sortOrder.compareTo(b.sortOrder) : a.lessonNumber.compareTo(b.lessonNumber));
    return LearningBook(
      id: json['id']?.toString() ?? '',
      grade: (json['grade'] as num?)?.toInt() ?? 1,
      track: json['track']?.toString() ?? '',
      title: json['title']?.toString() ?? 'کتاب',
      coverUrl: json['coverUrl']?.toString() ?? '',
      pdfUrl: json['pdfUrl']?.toString() ?? '',
      sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
      updatedAt: json['updatedAt']?.toString() ?? '',
      lessons: rawLessons,
    );
  }
}

class GaminoMedalItem {
  const GaminoMedalItem({
    required this.id,
    required this.title,
    required this.description,
    required this.iconUrl,
    required this.metric,
    required this.target,
    required this.progress,
    required this.rawProgress,
    required this.sortOrder,
    required this.isUnlocked,
  });

  final String id;
  final String title;
  final String description;
  final String iconUrl;
  final String metric;
  final int target;
  final int progress;
  final int rawProgress;
  final int sortOrder;
  final bool isUnlocked;

  double get progressValue => target <= 0 ? 0.0 : (progress / target).clamp(0.0, 1.0).toDouble();
  int get percent => (progressValue * 100).round();

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'iconUrl': iconUrl,
        'metric': metric,
        'target': target,
        'progress': progress,
        'rawProgress': rawProgress,
        'sortOrder': sortOrder,
        'isUnlocked': isUnlocked,
      };

  factory GaminoMedalItem.fromJson(Map<String, dynamic> json) => GaminoMedalItem(
        id: json['id']?.toString() ?? '',
        title: json['title']?.toString() ?? 'مدال',
        description: json['description']?.toString() ?? '',
        iconUrl: json['iconUrl']?.toString() ?? '',
        metric: json['metric']?.toString() ?? '',
        target: max(1, (json['target'] as num?)?.toInt() ?? 1),
        progress: max(0, (json['progress'] as num?)?.toInt() ?? 0),
        rawProgress: max(0, (json['rawProgress'] as num?)?.toInt() ?? (json['progress'] as num?)?.toInt() ?? 0),
        sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
        isUnlocked: json['isUnlocked'] == true,
      );
}

class AppPalette {
  static const Color ink = Color(0xFF101827);
  static const Color muted = Color(0xFF64748B);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color canvas = Color(0xFFF3F6FF);
  static const Color primary = Color(0xFF3D5AFE);
  static const Color secondary = Color(0xFF7C3AED);
  static const Color cyan = Color(0xFF00B8D9);
  static const Color mint = Color(0xFF00C853);
  static const Color amber = Color(0xFFFFB300);
  static const Color coral = Color(0xFFFF6B6B);
  static const Color pink = Color(0xFFFF4FD8);

  static const LinearGradient heroGradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [Color(0xFF1D4ED8), Color(0xFF7C3AED), Color(0xFFFF4FD8)],
  );

  static const LinearGradient actionGradient = LinearGradient(
    begin: Alignment.centerRight,
    end: Alignment.centerLeft,
    colors: [Color(0xFF3D5AFE), Color(0xFF00B8D9)],
  );

  static const LinearGradient fireGradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [Color(0xFFFF8A00), Color(0xFFFF3D71)],
  );

  static const LinearGradient successGradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [Color(0xFF00C853), Color(0xFF00B8D9)],
  );

  static List<Color> gradientForIndex(int index) {
    final palettes = <List<Color>>[
      const [Color(0xFF3D5AFE), Color(0xFF00B8D9)],
      const [Color(0xFF7C3AED), Color(0xFFFF4FD8)],
      const [Color(0xFFFF8A00), Color(0xFFFF3D71)],
      const [Color(0xFF00C853), Color(0xFF00B8D9)],
      const [Color(0xFF0F172A), Color(0xFF475569)],
    ];
    return palettes[index.abs() % palettes.length];
  }
}

String gradeLabel(int grade) {
  const labels = {
    1: 'اول',
    2: 'دوم',
    3: 'سوم',
    4: 'چهارم',
    5: 'پنجم',
    6: 'ششم',
    7: 'هفتم',
    8: 'هشتم',
    9: 'نهم',
    10: 'دهم',
    11: 'یازدهم',
    12: 'دوازدهم',
  };
  return labels[grade] ?? grade.toString();
}

String gradeTitle(int grade) => 'پایه ${gradeLabel(grade)}';

String faNumber(int value) => faDigits(value);

String cupText(int value) => '${faNumber(value)} کاپ';


class GaminoLeagueTier {
  const GaminoLeagueTier({
    required this.id,
    required this.name,
    required this.minCups,
    required this.asset,
    required this.primaryColor,
    required this.secondaryColor,
    required this.winCups,
    required this.loseCups,
  });

  final String id;
  final String name;
  final int minCups;
  final String asset;
  final Color primaryColor;
  final Color secondaryColor;
  final int winCups;
  final int loseCups;
}

const List<GaminoLeagueTier> kGaminoLeagueTiers = [
  GaminoLeagueTier(
    id: 'bronze',
    name: 'برنزی',
    minCups: 0,
    asset: 'assets/league_legend.webp',
    primaryColor: Color(0xFFB56A35),
    secondaryColor: Color(0xFFF59E0B),
    winCups: 25,
    loseCups: -5,
  ),
  GaminoLeagueTier(
    id: 'silver',
    name: 'نقره‌ای',
    minCups: 500,
    asset: 'assets/league_gold.webp',
    primaryColor: Color(0xFF64748B),
    secondaryColor: Color(0xFF3D5AFE),
    winCups: 23,
    loseCups: -8,
  ),
  GaminoLeagueTier(
    id: 'gold',
    name: 'طلایی',
    minCups: 1000,
    asset: 'assets/league_crystal.webp',
    primaryColor: Color(0xFFE7AE15),
    secondaryColor: Color(0xFFFFB300),
    winCups: 20,
    loseCups: -13,
  ),
  GaminoLeagueTier(
    id: 'crystal',
    name: 'کریستال',
    minCups: 1800,
    asset: 'assets/league_ruler.webp',
    primaryColor: Color(0xFFE11D48),
    secondaryColor: Color(0xFFFF4FD8),
    winCups: 17,
    loseCups: -17,
  ),
  GaminoLeagueTier(
    id: 'ruler',
    name: 'حاکمان',
    minCups: 3000,
    asset: 'assets/league_bronze.webp',
    primaryColor: Color(0xFF7C3AED),
    secondaryColor: Color(0xFFFF4FD8),
    winCups: 16,
    loseCups: -18,
  ),
  GaminoLeagueTier(
    id: 'legend',
    name: 'اساطیر',
    minCups: 5000,
    asset: 'assets/league_silver.webp',
    primaryColor: Color(0xFF7C3AED),
    secondaryColor: Color(0xFF3D5AFE),
    winCups: 15,
    loseCups: -19,
  ),
];

GaminoLeagueTier leagueTierForCups(int cups) {
  var selected = kGaminoLeagueTiers.first;
  for (final tier in kGaminoLeagueTiers) {
    if (cups >= tier.minCups) selected = tier;
  }
  return selected;
}

GaminoLeagueTier? nextLeagueTierForCups(int cups) {
  for (final tier in kGaminoLeagueTiers) {
    if (cups < tier.minCups) return tier;
  }
  return null;
}

String leagueNameForCups(int cups) => leagueTierForCups(cups).name;

String leagueEnglishNameForCups(int cups) => leagueTierForCups(cups).id;

int leagueStartForCups(int cups) => leagueTierForCups(cups).minCups;

int leagueEndForCups(int cups) {
  final next = nextLeagueTierForCups(cups);
  if (next == null) return leagueTierForCups(cups).minCups + 2000;
  return next.minCups - 1;
}

String leagueRangeForCups(int cups) {
  final tier = leagueTierForCups(cups);
  final next = nextLeagueTierForCups(cups);
  if (next == null) return '+${faNumber(tier.minCups)} کاپ';
  return '${faNumber(tier.minCups)} تا ${faNumber(next.minCups - 1)} کاپ';
}

double leagueProgressForCups(int cups) {
  final tier = leagueTierForCups(cups);
  final next = nextLeagueTierForCups(cups);
  if (next == null) return 1.0;
  return ((cups - tier.minCups) / max(1, next.minCups - tier.minCups)).clamp(0.04, 1.0).toDouble();
}

int monthlyResetCups(int cups) => cups >= 5000 ? 5000 : (cups * .70).round();

String quizCupPhaseName(int cups) => leagueNameForCups(cups);

String quizCupPhaseRange(int cups) {
  if (cups >= 5000) return '+۵۰۰۰ کاپ';
  if (cups >= 3000) return '۳۰۰۰ تا ۴۹۹۹ کاپ';
  if (cups >= 1800) return '۱۸۰۰ تا ۲۹۹۹ کاپ';
  if (cups >= 1000) return '۱۰۰۰ تا ۱۷۹۹ کاپ';
  if (cups >= 500) return '۵۰۰ تا ۹۹۹ کاپ';
  return '۰ تا ۴۹۹ کاپ';
}

int quizWinCupDelta(int cups) {
  if (cups >= 5000) return 15;
  if (cups >= 3000) return 16;
  if (cups >= 1800) return 17;
  if (cups >= 1000) return 20;
  if (cups >= 500) return 23;
  return 25;
}

int quizLoseCupDelta(int cups) {
  if (cups >= 5000) return -19;
  if (cups >= 3000) return -18;
  if (cups >= 1800) return -17;
  if (cups >= 1000) return -13;
  if (cups >= 500) return -8;
  return -5;
}

int quizCupDelta(int cups, bool won) => won ? quizWinCupDelta(cups) : quizLoseCupDelta(cups);

String signedCupText(int value) {
  if (value > 0) return '+${faNumber(value)} کاپ';
  if (value < 0) return '-${faNumber(value.abs())} کاپ';
  return '۰ کاپ';
}

LeaderRow closestOpponentForCups(int cups, int grade) {
  final opponents = <LeaderRow>[
    LeaderRow(rank: 1, name: 'آراد', grade: grade, xp: cups + 18),
    LeaderRow(rank: 2, name: 'سارا', grade: grade, xp: max(0, cups - 24)),
    LeaderRow(rank: 3, name: 'مانی', grade: grade, xp: cups + 42),
    LeaderRow(rank: 4, name: 'هستی', grade: grade, xp: max(0, cups - 51)),
    LeaderRow(rank: 5, name: 'نیما', grade: grade, xp: cups + 73),
  ];
  opponents.sort((a, b) => (a.xp - cups).abs().compareTo((b.xp - cups).abs()));
  return opponents.first;
}

int currentCups(AppUser user) => max(0, user.cupsByGrade[user.grade] ?? user.xp);
int bestCups(AppUser user) => max(currentCups(user), user.bestCupsByGrade[user.grade] ?? user.bestXp);
int lossesCount(AppUser user) => max(0, user.matchesCount - user.wins);

List<int> gregorianToJalali(DateTime value) {
  final gy = value.year - 1600;
  final gm = value.month - 1;
  final gd = value.day - 1;
  const gdm = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  var gDayNo = 365 * gy + ((gy + 3) ~/ 4) - ((gy + 99) ~/ 100) + ((gy + 399) ~/ 400);
  for (var i = 0; i < gm; i++) {
    gDayNo += gdm[i];
  }
  if (gm > 1 && ((value.year % 4 == 0 && value.year % 100 != 0) || (value.year % 400 == 0))) {
    gDayNo++;
  }
  gDayNo += gd;

  var jDayNo = gDayNo - 79;
  final jNp = jDayNo ~/ 12053;
  jDayNo %= 12053;
  var jy = 979 + 33 * jNp + 4 * (jDayNo ~/ 1461);
  jDayNo %= 1461;
  if (jDayNo >= 366) {
    jy += (jDayNo - 1) ~/ 365;
    jDayNo = (jDayNo - 1) % 365;
  }
  const jdm = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
  var jm = 0;
  while (jm < 11 && jDayNo >= jdm[jm]) {
    jDayNo -= jdm[jm];
    jm++;
  }
  final jd = jDayNo + 1;
  return [jy, jm + 1, jd];
}

DateTime jalaliToGregorian(int jy, int jm, int jd) {
  jy -= 979;
  jm -= 1;
  jd -= 1;
  const jdm = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
  var jDayNo = 365 * jy + (jy ~/ 33) * 8 + (((jy % 33) + 3) ~/ 4);
  for (var i = 0; i < jm; ++i) {
    jDayNo += jdm[i];
  }
  jDayNo += jd;
  var gDayNo = jDayNo + 79;
  var gy = 1600 + 400 * (gDayNo ~/ 146097);
  gDayNo %= 146097;
  var leap = true;
  if (gDayNo >= 36525) {
    gDayNo--;
    gy += 100 * (gDayNo ~/ 36524);
    gDayNo %= 36524;
    if (gDayNo >= 365) {
      gDayNo++;
    } else {
      leap = false;
    }
  }
  gy += 4 * (gDayNo ~/ 1461);
  gDayNo %= 1461;
  if (gDayNo >= 366) {
    leap = false;
    gDayNo--;
    gy += gDayNo ~/ 365;
    gDayNo %= 365;
  }
  final gdm = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  var gm = 0;
  while (gm < 11 && gDayNo >= gdm[gm]) {
    gDayNo -= gdm[gm];
    gm++;
  }
  return DateTime(gy, gm + 1, gDayNo + 1);
}

String formatJalaliDate(DateTime value) {
  final parts = gregorianToJalali(value);
  String two(int v) => v.toString().padLeft(2, '0');
  return '${parts[0]}/${two(parts[1])}/${two(parts[2])}';
}

String formatReminderDateTime(DateTime value) {
  final time = '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';
  return '${formatJalaliDate(value)} - $time';
}

int stableLeaderSeed(String name) => name.codeUnits.fold<int>(0, (sum, code) => (sum * 31 + code) & 0x7fffffff);

ShopItem? avatarShopItemForTitle(String title) {
  final normalized = title.trim();
  if (normalized.isEmpty) return null;
  final state = gaminoAppKey.currentState;
  if (state == null) return null;
  for (final item in state.shopItems) {
    if (item.type == ShopItemType.avatar && item.title == normalized) return item;
  }
  return null;
}

String avatarDocumentIdForTitle(String title) {
  final item = avatarShopItemForTitle(title);
  if (item != null && item.id.trim().isNotEmpty) return 'avatar_${item.id}';
  return 'avatar_${stableLeaderSeed(title.trim().isEmpty ? 'unknown' : title.trim())}';
}

String avatarVersionForTitle(String title) => avatarShopItemForTitle(title)?.updatedAt ?? '';

Widget avatarImageForTitle(String avatar, {required BoxFit fit, String remoteUrl = ''}) {
  final item = avatarShopItemForTitle(avatar);
  final catalogUrl = item?.imageUrl.trim() ?? '';
  final url = catalogUrl.isNotEmpty ? catalogUrl : remoteUrl.trim();
  if (avatar.trim().isEmpty && url.isEmpty) {
    return Image.asset('assets/gamino_default_profile.webp', fit: fit, filterQuality: FilterQuality.high);
  }
  return CachedAvatarImage(
    url: url,
    version: item?.updatedAt ?? '',
    documentId: item != null && item.id.trim().isNotEmpty ? 'avatar_${item.id}' : avatarDocumentIdForTitle(avatar),
    fit: fit,
  );
}

class GaminoAvatarPlaceholder extends StatelessWidget {
  const GaminoAvatarPlaceholder({super.key, this.iconSize = 46});
  final double iconSize;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/gamino_default_profile.webp',
      fit: BoxFit.contain,
      filterQuality: FilterQuality.high,
    );
  }
}

class DefaultAvatarCircle extends StatelessWidget {
  const DefaultAvatarCircle({super.key, required this.size, this.borderColor = Colors.transparent, this.borderWidth = 0});

  final double size;
  final Color borderColor;
  final double borderWidth;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: DecoratedBox(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: borderColor, width: borderWidth),
        ),
        child: ClipOval(child: GaminoAvatarPlaceholder(iconSize: size * .48)),
      ),
    );
  }
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  GaminoAdiveryService.ensureInitialized();
  runApp(const GaminoSecureEntry());
}

class GaminoSecureEntry extends StatefulWidget {
  const GaminoSecureEntry({super.key});

  @override
  State<GaminoSecureEntry> createState() => _GaminoSecureEntryState();
}

class _GaminoSecureEntryState extends State<GaminoSecureEntry> {
  final Future<AppOwnershipStatus> _status = AppOwnershipGuard.verify();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<AppOwnershipStatus>(
      future: _status,
      builder: (context, snapshot) {
        if (snapshot.hasData && snapshot.data!.isValid) {
          // StudentBattleApp owns the single app Navigator. Keeping it out of
          // another MaterialApp is essential: a nested root Navigator can
          // consume Android Back before internal study/PDF routes get a chance
          // to pop, which makes the app appear to close from the reader.
          return StudentBattleApp(key: gaminoAppKey);
        }

        final child = !snapshot.hasData
            ? const SecureBootScreen()
            : SecureLockedScreen(status: snapshot.data!);
        return MaterialApp(
          title: kAppName,
          debugShowCheckedModeBanner: false,
          locale: const Locale('fa'),
          theme: ThemeData(
            useMaterial3: true,
            fontFamily: 'Roboto',
            scaffoldBackgroundColor: AppPalette.canvas,
            colorScheme: ColorScheme.fromSeed(seedColor: AppPalette.primary),
          ),
          home: child,
        );
      },
    );
  }
}

class AppOwnershipStatus {
  const AppOwnershipStatus({
    required this.isValid,
    required this.packageName,
    required this.signatureSha256,
    required this.appLabel,
    required this.reason,
  });

  final bool isValid;
  final String packageName;
  final String signatureSha256;
  final String appLabel;
  final String reason;
}

class AppOwnershipGuard {
  static const MethodChannel _channel = MethodChannel('ir.miplus.gamino/security');

  static String _clean(String value) => value.replaceAll(':', '').replaceAll(' ', '').toUpperCase();
  static bool _hasValue(String value) => value.trim().isNotEmpty && value.trim().toLowerCase() != 'unknown';

  static Future<AppOwnershipStatus> verify() async {
    try {
      final result = await _channel.invokeMapMethod<String, dynamic>('getAppIdentity');
      final packageName = result?['packageName']?.toString() ?? '';
      final signature = result?['signatureSha256']?.toString() ?? '';
      final appLabel = result?['appLabel']?.toString() ?? '';

      final issues = <String>[];

      if (_hasValue(packageName) && packageName != kOwnerPackageName) {
        issues.add('پکیج‌نیم برنامه معتبر نیست');
      }

      if (_hasValue(signature) && _clean(signature) != _clean(kOwnerSignatureSha256)) {
        issues.add('امضای برنامه با کی‌استور گامینو یکی نیست');
      }

      if (_hasValue(appLabel) && appLabel != kOwnerAppLabel) {
        issues.add('نام برنامه تغییر کرده است');
      }

      final valid = issues.isEmpty;

      return AppOwnershipStatus(
        isValid: valid,
        packageName: _hasValue(packageName) ? packageName : kOwnerPackageName,
        signatureSha256: _hasValue(signature) ? signature : 'not_checked',
        appLabel: _hasValue(appLabel) ? appLabel : kOwnerAppLabel,
        reason: valid ? 'OK' : issues.join('، '),
      );
    } catch (error) {
      // Some release builds recreate the Android folder and do not keep the native
      // MethodChannel used for reading package/signature. In that case the app
      // must not lock itself with Package/SHA256 = unknown.
      return const AppOwnershipStatus(
        isValid: true,
        packageName: kOwnerPackageName,
        signatureSha256: 'not_checked',
        appLabel: kOwnerAppLabel,
        reason: 'OK',
      );
    }
  }
}

class SecureBootScreen extends StatelessWidget {
  const SecureBootScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: AppPalette.canvas,
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}

class SecureLockedScreen extends StatelessWidget {
  const SecureLockedScreen({super.key, required this.status});

  final AppOwnershipStatus status;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppPalette.canvas,
        body: SafeArea(
          child: Center(
            child: Container(
              margin: const EdgeInsets.all(24),
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(28),
                boxShadow: const [BoxShadow(color: Color(0x11101827), blurRadius: 28, offset: Offset(0, 14))],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 78,
                    height: 78,
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFFFE4E6)),
                    child: const Icon(Icons.lock_rounded, color: Color(0xFFE11D48), size: 38),
                  ),
                  const SizedBox(height: 18),
                  const Text('نسخه غیرمجاز گامینو', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                  const SizedBox(height: 10),
                  Text(status.reason, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppPalette.muted, height: 1.8)),
                  const SizedBox(height: 18),
                  SelectableText(
                    'Package: ${status.packageName}\nSHA256: ${status.signatureSha256}',
                    textAlign: TextAlign.left,
                    style: const TextStyle(fontSize: 11, color: AppPalette.muted),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}


class StudentBattleApp extends StatefulWidget {
  const StudentBattleApp({super.key});

  @override
  State<StudentBattleApp> createState() => _StudentBattleAppState();
}

class _StudentBattleAppState extends State<StudentBattleApp> with WidgetsBindingObserver {
  AppUser? currentUser;
  bool isGuest = false;
  bool isBooting = true;
  bool showSplash = true;
  String saveStatus = 'در حال اتصال به حساب آنلاین...';
  String? _sessionToken;
  _AuthMode _authStartMode = _AuthMode.welcome;
  AppUser? _guestUserBackup;
  bool _authOpenedFromGuest = false;
  int _authOperationEpoch = 0;
  String? _pendingRegistrationRequestId;
  String? _pendingRegistrationSignature;
  final List<MyMistake> mistakes = [];
  final List<ShopItem> shopItems = [];
  final List<CardPackage> cardPackages = List<CardPackage>.of(kDefaultCardPackages);
  final List<LearningBook> learningBooks = [];
  final List<GaminoMedalItem> medalItems = [];
  QuizRoom? activeRoom;
  Timer? _studySyncTimer;
  bool _studySyncRunning = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _studySyncTimer = Timer.periodic(const Duration(seconds: 30), (_) => unawaited(_flushStudyQueue()));
    _startSplashTimer();
    _restoreRemoteSession();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(_flushStudyQueue());
      unawaited(refreshAvatarCatalog(silent: true));
      unawaited(GaminoPushClient.syncDevice());
      unawaited(gaminoHomeShellKey.currentState?.resumeClassQuizIfNeeded() ?? Future<void>.value());
    }
  }

  @override
  void dispose() {
    _studySyncTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _syncBannerAdState() => GaminoAdState.userAdsDisabled = currentUser?.hasActiveNoAds == true;

  Future<void> _startSplashTimer() async {
    await Future.delayed(const Duration(milliseconds: 1800));
    if (!mounted) return;
    if (isBooting) {
      final snapshot = await LocalSaveService.loadSnapshot();
      if (!mounted) return;
      if (snapshot != null) {
        _restoreSnapshot(snapshot, status: snapshot.isGuest ? 'حالت مهمان آفلاین — محتوای ذخیره‌شده آماده است' : 'آخرین اطلاعات ذخیره‌شده آماده است؛ همگام‌سازی در پس‌زمینه ادامه دارد');
      } else {
        setState(() { isBooting = false; saveStatus = 'ورود بدون انتظار برای شبکه'; });
      }
    }
    if (mounted) setState(() => showSplash = false);
  }

  Future<void> _restoreRemoteSession() async {
    final token = await RemoteSessionStore.readToken();
    final snapshot = await LocalSaveService.loadSnapshot();
    if (token == null || token.isEmpty) {
      if (snapshot != null && snapshot.isGuest) {
        _restoreSnapshot(snapshot, status: 'حالت مهمان آفلاین — محتوای ذخیره‌شده آماده است');
      } else if (mounted) {
        setState(() { isBooting = false; saveStatus = 'برای ادامه وارد حساب کاربری شو'; });
      }
      return;
    }
    _sessionToken = token;
    try {
      final payload = await GaminoApiService.request('state', token: token, get: true);
      if (!mounted) return;
      _applyRemoteState(payload, status: 'اطلاعات از سرور همگام شد');
      unawaited(_flushStudyQueue());
      unawaited(GaminoPushClient.syncDevice());
    } catch (_) {
      if (snapshot != null && !snapshot.isGuest) {
        _restoreSnapshot(snapshot, status: 'حالت آفلاین — آخرین محتوای ذخیره‌شده نمایش داده می‌شود');
      } else if (mounted) {
        setState(() { isBooting = false; saveStatus = 'اتصال برقرار نشد؛ اینترنت را بررسی کن'; });
      }
    }
  }

  void _restoreSnapshot(LocalAppSnapshot snapshot, {required String status}) {
    if (!mounted) return;
    setState(() {
      currentUser = snapshot.user;
      isGuest = snapshot.isGuest;
      mistakes
        ..clear()
        ..addAll(snapshot.mistakes);
      learningBooks
        ..clear()
        ..addAll(snapshot.books);
      medalItems
        ..clear()
        ..addAll(snapshot.medals);
      shopItems
        ..clear()
        ..addAll(snapshot.shopItems.map((item) => item.copy()));
      cardPackages
        ..clear()
        ..addAll(snapshot.cardPackages);
      for (final item in shopItems) {
        item.isUnlocked = item.isUnlocked || snapshot.unlockedShopItemIds.contains(item.id) || item.price == 0;
      }
      activeRoom = snapshot.activeRoom;
      saveStatus = status;
      isBooting = false;
      _syncBannerAdState();
    });
  }

  Future<void> _saveOfflineSnapshot() async {
    final user = currentUser;
    if (user == null) return;
    await LocalSaveService.saveSnapshot(LocalAppSnapshot(
      user: user,
      isGuest: isGuest,
      mistakes: List<MyMistake>.of(mistakes),
      activeRoom: activeRoom,
      unlockedShopItemIds: shopItems.where((item) => item.isUnlocked).map((item) => item.id).toList(),
      shopItems: shopItems.map((item) => item.copy()).toList(),
      cardPackages: List<CardPackage>.of(cardPackages),
      books: List<LearningBook>.of(learningBooks),
      medals: List<GaminoMedalItem>.of(medalItems),
    ));
  }


  void _applyRemoteState(Map<String, dynamic> payload, {String? status}) {
    final rawUser = Map<String, dynamic>.from(payload['user'] as Map? ?? {});
    final rawMistakes = (payload['mistakes'] as List? ?? []).whereType<Map>().map((item) => MyMistake.fromJson(Map<String, dynamic>.from(item))).toList();
    final rawUnlocked = (payload['unlockedShopItemIds'] as List? ?? []).map((item) => item.toString()).toSet();
    final rawShopItems = (payload['shopItems'] as List? ?? [])
        .whereType<Map>()
        .map((item) => ShopItem.fromJson(Map<String, dynamic>.from(item)))
        .toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    final rawBooks = (payload['books'] as List? ?? []).whereType<Map>().map((item) => LearningBook.fromJson(Map<String, dynamic>.from(item))).toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    final rawMedals = (payload['medals'] as List? ?? []).whereType<Map>().map((item) => GaminoMedalItem.fromJson(Map<String, dynamic>.from(item))).toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    final rawRoom = payload['activeRoom'];
    final rawSettings = Map<String, dynamic>.from(payload['settings'] as Map? ?? const {});
    final rawCardPackages = (rawSettings['card_packages'] as List? ?? const [])
        .whereType<Map>()
        .map((item) => CardPackage.fromJson(Map<String, dynamic>.from(item)))
        .where((item) => item.published)
        .toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    GaminoAdState.adiveryInterstitialEnabled = rawSettings['adivery_interstitial_enabled'] != false;
    setState(() {
      currentUser = AppUser.fromJson(rawUser);
      isGuest = false;
      mistakes
        ..clear()
        ..addAll(rawMistakes);
      learningBooks
        ..clear()
        ..addAll(rawBooks);
      medalItems
        ..clear()
        ..addAll(rawMedals);
      activeRoom = rawRoom is Map ? QuizRoom.fromJson(Map<String, dynamic>.from(rawRoom)) : null;
      shopItems
        ..clear()
        ..addAll(rawShopItems);
      cardPackages
        ..clear()
        ..addAll(rawCardPackages.isEmpty ? kDefaultCardPackages : rawCardPackages);
      for (final item in shopItems) {
        item.isUnlocked = item.isUnlocked || rawUnlocked.contains(item.id) || item.price == 0;
      }
      saveStatus = status ?? 'اطلاعات آنلاین همگام است';
      isBooting = false;
      _syncBannerAdState();
    });
    unawaited(_saveOfflineSnapshot());
  }

  Future<bool> _requestAndApply(String action, Map<String, dynamic> body, {String? successStatus}) async {
    final token = _sessionToken;
    if (token == null || isGuest || currentUser == null) return false;
    try {
      final payload = await GaminoApiService.request(action, token: token, body: body);
      if (!mounted) return false;
      _applyRemoteState(payload, status: successStatus ?? 'تغییرات در سرور ذخیره شد');
      return true;
    } on GaminoApiException catch (e) {
      if (mounted) setState(() => saveStatus = e.message);
      return false;
    }
  }

  Future<void> loginAsGuest(int grade, String track) async {
    var books = <LearningBook>[];
    try {
        final payload = await GaminoApiService.request('guest.books', body: {'grade': grade, 'track': normalizeEducationTrack(grade, track)});
        GaminoAdState.adiveryInterstitialEnabled = payload['adiveryInterstitialEnabled'] != false;
        books = (payload['books'] as List? ?? [])
          .whereType<Map>()
          .map((item) => LearningBook.fromJson(Map<String, dynamic>.from(item)))
          .toList()
        ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    } catch (_) {
      final snapshot = await LocalSaveService.loadSnapshot();
      if (snapshot != null && snapshot.isGuest && snapshot.user.grade == grade && snapshot.user.educationTrack == normalizeEducationTrack(grade, track)) {
        books = List<LearningBook>.of(snapshot.books);
      } else {
        books = <LearningBook>[];
      }
    }
    if (!mounted) return;
    setState(() {
      _guestUserBackup = null;
      _authOpenedFromGuest = false;
      isGuest = true;
      currentUser = AppUser.guest(grade: grade, track: track);
      mistakes.clear();
      learningBooks
        ..clear()
        ..addAll(books);
      medalItems.clear();
      activeRoom = null;
      shopItems.clear();
      saveStatus = 'حالت مهمان — گام‌به‌گام ${gradePathText(grade, track)} فعال است';
      _syncBannerAdState();
    });
    unawaited(_saveOfflineSnapshot());
  }

  Future<void> refreshLearningContent() async {
    final user = currentUser;
    if (user == null) return;
    try {
      if (isGuest) {
        final payload = await GaminoApiService.request('guest.books', body: {'grade': user.grade, 'track': user.educationTrack});
        GaminoAdState.adiveryInterstitialEnabled = payload['adiveryInterstitialEnabled'] != false;
        final books = (payload['books'] as List? ?? [])
            .whereType<Map>()
            .map((item) => LearningBook.fromJson(Map<String, dynamic>.from(item)))
            .toList()
          ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
        if (!mounted) return;
        setState(() {
          learningBooks
            ..clear()
            ..addAll(books);
          saveStatus = 'کتاب‌ها و درس‌ها به‌روز شدند';
        });
        unawaited(_saveOfflineSnapshot());
        return;
      }
      final token = _sessionToken;
      if (token == null || token.isEmpty) return;
      final payload = await GaminoApiService.request('state', token: token, get: true);
      if (mounted) _applyRemoteState(payload, status: 'کتاب‌ها و درس‌ها به‌روز شدند');
    } catch (_) {
      if (mounted) setState(() => saveStatus = 'اتصال اینترنت برقرار نیست؛ محتوای ذخیره‌شده نمایش داده می‌شود');
    }
  }

  Future<bool> refreshAvatarCatalog({bool silent = false}) async {
    if (isGuest || currentUser == null) return false;
    final token = _sessionToken;
    if (token == null || token.isEmpty) return false;
    try {
      final payload = await GaminoApiService.request('state', token: token, get: true);
      if (!mounted) return false;
      _applyRemoteState(payload, status: silent ? saveStatus : 'آواتارها از پنل به‌روز شدند');
      return true;
    } catch (_) {
      if (!silent && mounted) setState(() => saveStatus = 'اتصال برقرار نشد؛ آخرین آواتارهای ذخیره‌شده نمایش داده می‌شوند');
      return false;
    }
  }

  void openAuthFromGuest(_AuthMode mode) {
    if (!isGuest || currentUser == null) return;
    setState(() {
      _guestUserBackup = currentUser;
      _authOpenedFromGuest = true;
      _authStartMode = mode;
      _sessionToken = null;
      currentUser = null;
      isGuest = false;
      saveStatus = 'برای ادامه وارد حساب شو یا ثبت‌نام کن';
      _syncBannerAdState();
    });
  }

  void restoreGuestAfterAuth() {
    final guest = _guestUserBackup;
    if (guest == null) return;
    setState(() {
      currentUser = guest;
      isGuest = true;
      _authOpenedFromGuest = false;
      _authStartMode = _AuthMode.welcome;
      saveStatus = 'حالت مهمان — گام‌به‌گام ${gradePathText(guest.grade, guest.educationTrack)} فعال است';
      _syncBannerAdState();
    });
    unawaited(_saveOfflineSnapshot());
  }

  void cancelPendingAuthOperations() {
    _authOperationEpoch++;
  }

  String _registrationRequestId() {
    final random = Random.secure();
    final parts = List.generate(4, (_) => random.nextInt(1 << 30).toRadixString(16));
    return 'reg_${DateTime.now().microsecondsSinceEpoch}_${parts.join()}';
  }

  String _registrationSignature(String name, int grade, String track, String phone, String password) {
    return '${name.trim()}|$grade|$track|${phone.trim()}|${password.hashCode}';
  }

  String _registrationRequestIdFor(String signature) {
    if (_pendingRegistrationRequestId == null || _pendingRegistrationSignature != signature) {
      _pendingRegistrationRequestId = _registrationRequestId();
      _pendingRegistrationSignature = signature;
    }
    return _pendingRegistrationRequestId!;
  }

  void _clearPendingRegistration() {
    _pendingRegistrationRequestId = null;
    _pendingRegistrationSignature = null;
  }

  Future<String?> registerStudent(String name, int grade, {String? phone, String? password, String? track}) async {
    final epoch = ++_authOperationEpoch;
    final normalizedTrack = normalizeEducationTrack(grade, track ?? '');
    final safePhone = phone ?? '';
    final safePassword = password ?? '';
    final signature = _registrationSignature(name, grade, normalizedTrack, safePhone, safePassword);
    final requestId = _registrationRequestIdFor(signature);
    final body = {
      'name': name,
      'grade': grade,
      'track': normalizedTrack,
      'phone': safePhone,
      'password': safePassword,
      'requestId': requestId,
      'termsAccepted': true,
    };
    Map<String, dynamic>? result;
    GaminoApiException? lastError;
    for (var attempt = 0; attempt < 2; attempt++) {
      if (epoch != _authOperationEpoch) return null;
      try {
        result = await GaminoApiService.request(
          'auth.register',
          body: body,
          timeout: Duration(seconds: attempt == 0 ? 9 : 5),
        );
        break;
      } on GaminoApiException catch (e) {
        lastError = e;
        if (!e.isNetwork || attempt == 1) break;
        await Future<void>.delayed(const Duration(milliseconds: 350));
      }
    }
    if (epoch != _authOperationEpoch) return null;
    if (result == null) {
      if (lastError?.isNetwork == true) return 'اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.';
      _clearPendingRegistration();
      return lastError?.message ?? 'ثبت‌نام انجام نشد.';
    }
    final token = result['token']?.toString() ?? '';
    final state = result['state'];
    if (token.isEmpty || state is! Map) return 'ثبت‌نام انجام شد اما اطلاعات حساب کامل دریافت نشد. دوباره تلاش کنید.';
    if (epoch != _authOperationEpoch) return null;
    try {
      if (mounted) _applyRemoteState(Map<String, dynamic>.from(state), status: 'حساب کاربری آنلاین ساخته شد');
    } catch (_) {
      return 'ثبت‌نام انجام شد اما همگام‌سازی حساب کامل نشد. دوباره تلاش کنید.';
    }
    if (epoch != _authOperationEpoch) return null;
    _sessionToken = token;
    await RemoteSessionStore.writeToken(token);
    _clearPendingRegistration();
    _guestUserBackup = null;
    _authOpenedFromGuest = false;
    unawaited(_flushStudyQueue());
    unawaited(GaminoPushClient.syncDevice());
    return null;
  }

  Future<String?> loginStudent(String phone, String password) async {
    final epoch = ++_authOperationEpoch;
    try {
      final result = await GaminoApiService.request('auth.login', body: {'phone': phone, 'password': password}, timeout: const Duration(seconds: 10));
      if (epoch != _authOperationEpoch) return null;
      final token = result['token']?.toString() ?? '';
      final state = result['state'];
      if (token.isEmpty || state is! Map) return 'ورود انجام نشد. دوباره تلاش کنید.';
      try {
        if (mounted) _applyRemoteState(Map<String, dynamic>.from(state), status: 'حساب آنلاین بازیابی شد');
      } catch (_) {
        return 'اطلاعات حساب دریافت شد اما نمایش آن کامل نشد. دوباره تلاش کنید.';
      }
      if (epoch != _authOperationEpoch) return null;
      _sessionToken = token;
      await RemoteSessionStore.writeToken(token);
      _guestUserBackup = null;
      _authOpenedFromGuest = false;
      unawaited(_flushStudyQueue());
      unawaited(GaminoPushClient.syncDevice());
      return null;
    } on GaminoApiException catch (e) {
      if (epoch != _authOperationEpoch) return null;
      return e.isNetwork ? 'اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.' : e.message;
    } catch (_) {
      if (epoch != _authOperationEpoch) return null;
      return 'ورود انجام نشد. دوباره تلاش کنید.';
    }
  }

  Future<void> logout() async {
    final token = _sessionToken;
    if (token != null && !isGuest) {
      await GaminoPushClient.unregisterDevice(token);
      try { await GaminoApiService.request('auth.logout', token: token, body: const {}); } catch (_) {}
    }
    await RemoteSessionStore.clear();
    await LocalSaveService.clear();
    if (!mounted) return;
    setState(() {
      _sessionToken = null;
      currentUser = null;
      isGuest = false;
      mistakes.clear();
      learningBooks.clear();
      medalItems.clear();
      activeRoom = null;
      saveStatus = 'از حساب کاربری خارج شدی';
      for (final item in shopItems) { item.isUnlocked = false; }
      _syncBannerAdState();
    });
  }

  void completeChapter(Chapter chapter) => unawaited(_requestAndApply('activity.chapter_complete', {'chapterKey': chapter.title}, successStatus: 'پیشرفت فصل در سرور ثبت شد'));

  void applyQuizResult(QuizResult result) {
    final subject = result.questions.isEmpty ? 'عمومی' : result.questions.first.subject;
    unawaited(_requestAndApply('activity.quiz_result', {
      'answers': result.answers.entries.map((entry) => {'questionId': entry.key, 'selectedIndex': entry.value}).toList(),
      'subject': subject,
      'isCompetitive': result.isCompetitive,
      'quizSource': result.quizSource,
      if (result.roomCode != null && result.roomCode!.isNotEmpty) 'roomCode': result.roomCode,
    }, successStatus: 'نتیجه کوییز پس از اعتبارسنجی سرور ثبت شد'));
  }

  void applyMistakePracticeResult(QuizResult result) => applyQuizResult(result);
  void createRoom({required int maxPlayers, required String roomType}) => unawaited(_requestAndApply('room.create', {'maxPlayers': maxPlayers, 'roomType': roomType}, successStatus: 'اتاق آنلاین ساخته شد'));
  void joinRoom(String code) => unawaited(_requestAndApply('room.join', {'code': enDigits(code.trim())}, successStatus: 'به اتاق آنلاین وصل شدی'));
  Future<bool> buyShopItem(ShopItem item) => _requestAndApply('shop.purchase', {'itemId': item.id}, successStatus: 'خرید آواتار از سرور ثبت شد');
  Future<bool> selectShopItem(ShopItem item) => _requestAndApply('shop.select', {'itemId': item.id}, successStatus: 'آواتار انتخاب شد');
  Future<String?> prepareRewardVideoClaim() async {
    final token = _sessionToken;
    if (token == null || isGuest || currentUser == null) return null;
    try {
      final payload = await GaminoApiService.request('wallet.reward_prepare', token: token, body: const {});
      return payload['challenge']?.toString();
    } on GaminoApiException catch (e) {
      if (mounted) setState(() => saveStatus = e.message);
      return null;
    }
  }

  Future<bool> claimRewardVideo(String challenge) => _requestAndApply(
        'wallet.reward_claim',
        {'challenge': challenge},
        successStatus: 'پاداش ویدیویی پس از تأیید سرور اضافه شد',
      );

  Future<String?> prepareCardPurchase({required String productId, required String market}) async {
    final token = _sessionToken;
    if (token == null || isGuest || currentUser == null) return null;
    try {
      final payload = await GaminoApiService.request(
        'wallet.purchase_prepare',
        token: token,
        body: {'productId': productId, 'market': market},
      );
      return payload['challenge']?.toString();
    } on GaminoApiException catch (e) {
      if (mounted) setState(() => saveStatus = e.message);
      return null;
    }
  }

  Future<bool> claimCardPurchase(GaminoStorePurchase purchase) => _requestAndApply(
        'wallet.purchase_claim',
        purchase.toClaimJson(),
        successStatus: 'خرید کارت از ${GaminoMarketBillingService.marketLabel} تأیید و به موجودی اضافه شد',
      );
  void purchaseNoAds() { if (mounted) setState(() => saveStatus = 'خرید حذف تبلیغ بعد از اتصال درگاه پرداخت فعال می‌شود.'); }

  Future<bool> updateProfile({required String name, required int grade, String? track, String? bio}) => _requestAndApply('profile.update', {'name': name, 'grade': grade, 'track': normalizeEducationTrack(grade, track ?? currentUser?.educationTrack ?? ''), 'bio': bio ?? currentUser?.bio ?? '', 'phone': currentUser?.phone ?? ''}, successStatus: 'اطلاعات پروفایل آنلاین ذخیره شد');
  void updateThemeMode(String themeMode) => unawaited(_requestAndApply('profile.theme', {'themeMode': themeMode}, successStatus: 'ظاهر برنامه ذخیره شد'));
  Future<bool> updateAccount({required String name, required String phone, required String currentPassword, required String password}) => _requestAndApply('profile.update', {'name': currentUser?.name ?? name, 'grade': currentUser?.grade ?? 7, 'track': currentUser?.educationTrack ?? '', 'bio': currentUser?.bio ?? '', 'phone': phone, 'currentPassword': currentPassword, 'newPassword': password}, successStatus: 'اطلاعات حساب آنلاین ذخیره شد');

  Future<bool> addStudyTask(StudyTask task) => _requestAndApply('tasks.create', task.toJson(), successStatus: 'برنامه مطالعه در سرور ذخیره شد');
  Future<bool> toggleStudyTask(StudyTask task) => _requestAndApply('tasks.toggle', {'taskId': task.id}, successStatus: 'وضعیت برنامه به‌روزرسانی شد');
  Future<bool> updateStudyTask(StudyTask oldTask, StudyTask newTask) => _requestAndApply('tasks.update', {'taskId': oldTask.id, ...newTask.toJson()}, successStatus: 'برنامه مطالعه ویرایش شد');
  Future<bool> deleteStudyTask(StudyTask task) => _requestAndApply('tasks.delete', {'taskId': task.id}, successStatus: 'برنامه مطالعه حذف شد');
  Future<bool> markLevelNotified() => _requestAndApply('level.notified', const {}, successStatus: 'ارتقای لول ثبت شد');
  Future<void> trackStudy(String subject, String chapter, int seconds) async {
    final user = currentUser;
    if (user == null || isGuest || seconds <= 0) return;
    final safeSeconds = seconds.clamp(1, 300).toInt();
    final event = StudySyncEvent.create(
      ownerPhone: user.phone,
      subject: subject,
      chapter: chapter,
      seconds: safeSeconds,
    );
    // Backend is the single source of truth for study time. The client queues
    // a measured interval, but never increments the authoritative counters locally.
    await StudySyncQueue.enqueue(event);
    unawaited(_flushStudyQueue());
  }

  Future<void> _flushStudyQueue() async {
    if (_studySyncRunning || isGuest) return;
    final token = _sessionToken;
    final user = currentUser;
    if (token == null || token.isEmpty || user == null || user.phone.isEmpty) return;
    _studySyncRunning = true;
    try {
      final pending = await StudySyncQueue.forOwner(user.phone);
      Map<String, dynamic>? lastState;
      for (final event in pending) {
        try {
          lastState = await GaminoApiService.request(
            'activity.study_sync',
            token: token,
            body: event.toJson(),
          );
          await StudySyncQueue.remove(event.id);
        } catch (_) {
          break;
        }
      }
      if (lastState != null && mounted && currentUser?.phone == user.phone) {
        _applyRemoteState(lastState, status: 'زمان مطالعه همگام شد');
      }
    } finally {
      _studySyncRunning = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: kAppName,
      navigatorObservers: [gaminoRouteObserver],
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox.shrink()),
      themeMode: ThemeMode.light,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: AppPalette.primary, brightness: Brightness.light),
        scaffoldBackgroundColor: AppPalette.canvas,
        navigationBarTheme: NavigationBarThemeData(height: 72, backgroundColor: Colors.white, indicatorColor: AppPalette.primary.withOpacity(0.14), labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 12, fontWeight: FontWeight.w800))),
        appBarTheme: const AppBarTheme(backgroundColor: AppPalette.canvas, surfaceTintColor: Colors.transparent, elevation: 0, centerTitle: false, titleTextStyle: TextStyle(color: AppPalette.ink, fontSize: 20, fontWeight: FontWeight.w900)),
        filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(backgroundColor: AppPalette.mint, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15))),
        outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52), side: BorderSide(color: AppPalette.primary.withOpacity(0.35)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15))),
        inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: AppPalette.primary.withOpacity(0.08))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: AppPalette.primary, width: 1.4))),
        cardTheme: CardThemeData(elevation: 0, color: Colors.white, surfaceTintColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26), side: BorderSide(color: AppPalette.primary.withOpacity(.06)))),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: AppPalette.primary, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF111522),
        navigationBarTheme: const NavigationBarThemeData(height: 72, backgroundColor: Color(0xFF1A2030), indicatorColor: Color(0xFF343F92)),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF111522), surfaceTintColor: Colors.transparent, elevation: 0, centerTitle: false, titleTextStyle: TextStyle(color: Color(0xFFF7F8FF), fontSize: 20, fontWeight: FontWeight.w900)),
        filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(backgroundColor: AppPalette.mint, foregroundColor: Colors.white, minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15))),
        outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), textStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15))),
        inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF20283A), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Color(0xFF36405B))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: AppPalette.primary, width: 1.4))),
        cardTheme: CardThemeData(elevation: 0, color: const Color(0xFF1B2232), surfaceTintColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26), side: const BorderSide(color: Color(0xFF2B3448)))),
      ),
      home: showSplash || isBooting
          ? const AppSplashScreen()
          : currentUser == null
              ? AuthScreen(initialMode: _authStartMode, onGuest: loginAsGuest, onStudentLogin: loginStudent, onStudentRegister: registerStudent, onBackToGuest: _authOpenedFromGuest ? restoreGuestAfterAuth : null, onCancelPendingAuth: cancelPendingAuthOperations)
              : HomeShell(
                  key: gaminoHomeShellKey,
                  user: currentUser!, saveStatus: saveStatus, isGuest: isGuest, mistakes: mistakes, shopItems: shopItems, cardPackages: cardPackages, activeRoom: activeRoom,
                  learningBooks: learningBooks, medalItems: medalItems, onStudyTick: trackStudy,
                  onLogout: logout, onCompleteChapter: completeChapter, onQuizFinished: applyQuizResult, onMistakePracticeFinished: applyMistakePracticeResult,
                  onCreateRoom: createRoom, onJoinRoom: joinRoom, onBuyShopItem: buyShopItem, onSelectShopItem: selectShopItem, onPrepareReward: prepareRewardVideoClaim, onClaimReward: claimRewardVideo,
                  onPurchaseNoAds: purchaseNoAds, onUpdateProfile: updateProfile, onUpdateThemeMode: updateThemeMode, onUpdateAccount: updateAccount,
                  onAddStudyTask: addStudyTask, onToggleStudyTask: toggleStudyTask, onUpdateStudyTask: updateStudyTask, onDeleteStudyTask: deleteStudyTask,
                  onMarkLevelNotified: markLevelNotified,
                ),
    );
  }
}

class AppSplashScreen extends StatelessWidget {
  const AppSplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2FBFF),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.05,
            colors: [Color(0xFFFFFFFF), Color(0xFFF1FBFF), Color(0xFFEAF6FF)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Align(
                alignment: const Alignment(0, -0.22),
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: 1),
                  duration: const Duration(milliseconds: 780),
                  curve: Curves.easeOutCubic,
                  builder: (context, opacity, child) {
                    return Opacity(
                      opacity: opacity,
                      child: Transform.translate(
                        offset: Offset(0, (1 - opacity) * 16),
                        child: child,
                      ),
                    );
                  },
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 188,
                        height: 188,
                        child: Image.asset('assets/splash_logo.png', fit: BoxFit.contain, filterQuality: FilterQuality.high),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        'گامینو',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 46, fontWeight: FontWeight.w900, color: Color(0xFF102B63), letterSpacing: -.9),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'گامی نو در یادگیری',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Color(0xFF243B66)),
                      ),
                    ],
                  ),
                ),
              ),
              const Positioned(
                left: 0,
                right: 0,
                bottom: 48,
                child: Center(
                  child: SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2.4, color: Color(0xFF102B63)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class BootScreen extends StatelessWidget {
  const BootScreen({super.key, required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 78,
                      height: 78,
                      decoration: BoxDecoration(
                        gradient: AppPalette.actionGradient,
                        borderRadius: BorderRadius.circular(26),
                      ),
                      child: const Icon(Icons.save_alt_rounded, color: Colors.white, size: 36),
                    ),
                    const SizedBox(height: 18),
                    const Text('گامینو', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    Text(message, textAlign: TextAlign.center, style: const TextStyle(color: AppPalette.muted, height: 1.7)),
                    const SizedBox(height: 18),
                    const LinearProgressIndicator(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}


Future<void> showExitConfirmationDialog(BuildContext context) async {
  final shouldExit = await showDialog<bool>(
    context: context,
    barrierDismissible: true,
    barrierColor: Colors.black.withOpacity(.46),
    builder: (dialogContext) {
      return Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 30),
        child: Container(
          padding: const EdgeInsets.fromLTRB(22, 24, 22, 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(32),
            boxShadow: const [
              BoxShadow(color: Color(0x260F172A), blurRadius: 34, offset: Offset(0, 18)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  gradient: AppPalette.heroGradient,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: const [BoxShadow(color: Color(0x333D5AFE), blurRadius: 22, offset: Offset(0, 10))],
                ),
                child: const Icon(Icons.logout_rounded, color: Colors.white, size: 34),
              ),
              const SizedBox(height: 18),
              const Text(
                'می‌خوای از گامینو خارج بشی؟',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: AppPalette.ink),
              ),
              const SizedBox(height: 8),
              const Text(
                'اگه هنوز کارت تموم نشده، می‌تونی برگردی و ادامه بدی.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, height: 1.7, color: AppPalette.muted, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 22),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(dialogContext, false),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(50),
                        side: const BorderSide(color: Color(0xFFE1E5F2)),
                        foregroundColor: AppPalette.ink,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
                      ),
                      child: const Text('انصراف', style: TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => Navigator.pop(dialogContext, true),
                      style: FilledButton.styleFrom(
                        minimumSize: const Size.fromHeight(50),
                        backgroundColor: AppPalette.primary,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
                      ),
                      icon: const Icon(Icons.logout_rounded, size: 20),
                      label: const Text('خروج', style: TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    },
  );
  if (shouldExit == true) {
    try {
      await _gaminoAppControlChannel.invokeMethod<void>('finishAndRemoveTask');
    } catch (_) {
      await SystemNavigator.pop();
    }
  }
}


Future<bool> showGaminoConfirmationDialog(
  BuildContext context, {
  required String title,
  required String message,
  String confirmText = 'تایید',
  String cancelText = 'لغو',
  bool showAd = true,
}) async {
  final result = await showDialog<bool>(
    context: context,
    barrierDismissible: true,
    builder: (dialogContext) {
      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
        title: Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(height: 1.7, color: AppPalette.muted, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(cancelText),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(confirmText),
          ),
        ],
      );
    },
  );
  return result == true;
}

enum _AuthMode { welcome, login, register }

class PasswordRecoveryDialog extends StatefulWidget {
  const PasswordRecoveryDialog({super.key});

  @override
  State<PasswordRecoveryDialog> createState() => _PasswordRecoveryDialogState();
}

class _PasswordRecoveryDialogState extends State<PasswordRecoveryDialog> {
  final phoneController = TextEditingController();
  final codeController = TextEditingController();
  final passwordController = TextEditingController();
  final repeatController = TextEditingController();

  final phoneFocus = FocusNode(debugLabel: 'password_recovery_phone');
  final codeFocus = FocusNode(debugLabel: 'password_recovery_code');
  final passwordFocus = FocusNode(debugLabel: 'password_recovery_password');
  final repeatFocus = FocusNode(debugLabel: 'password_recovery_repeat');

  Timer? _timer;
  int step = 0;
  int cooldown = 0;
  bool busy = false;
  bool showPassword = false;
  String resetToken = '';
  String message = '';
  String error = '';

  bool get _validPhone => RegExp(r'^09\d{9}$').hasMatch(phoneController.text.trim());
  bool _validPassword(String value) => value.length >= 6 && RegExp(r'[A-Za-z]').hasMatch(value) && RegExp(r'\d').hasMatch(value);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) phoneFocus.requestFocus();
    });
  }

  void _startCooldown(int seconds) {
    _timer?.cancel();
    setState(() => cooldown = max(0, seconds));
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || cooldown <= 1) {
        timer.cancel();
        if (mounted) setState(() => cooldown = 0);
      } else {
        setState(() => cooldown--);
      }
    });
  }

  Future<void> _moveToStep(int next) async {
    FocusManager.instance.primaryFocus?.unfocus();
    try {
      await SystemChannels.textInput.invokeMethod<void>('TextInput.hide');
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      step = next;
      error = '';
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      switch (next) {
        case 0:
          phoneFocus.requestFocus();
          break;
        case 1:
          codeFocus.requestFocus();
          break;
        default:
          passwordFocus.requestFocus();
      }
    });
  }

  Future<void> _close() async {
    FocusManager.instance.primaryFocus?.unfocus();
    try {
      await SystemChannels.textInput.invokeMethod<void>('TextInput.hide');
    } catch (_) {}
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _requestCode() async {
    if (busy || cooldown > 0) return;
    if (!_validPhone) {
      setState(() => error = 'شماره موبایل را به‌صورت 09xxxxxxxxx وارد کن.');
      return;
    }
    setState(() {
      busy = true;
      error = '';
    });
    try {
      final data = await GaminoApiService.request(
        'auth.password_reset.request',
        body: {'phone': phoneController.text.trim()},
        timeout: const Duration(seconds: 15),
      );
      if (!mounted) return;
      message = data['message']?.toString() ?? 'اگر این شماره در گامینو ثبت شده باشد، کد بازیابی برای آن ارسال می‌شود.';
      _startCooldown((data['cooldownSeconds'] as num?)?.toInt() ?? 120);
      await _moveToStep(1);
    } on GaminoApiException catch (e) {
      if (mounted) setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _verifyCode() async {
    if (busy) return;
    final code = codeController.text.trim();
    if (!RegExp(r'^\d{6}$').hasMatch(code)) {
      setState(() => error = 'کد ۶ رقمی ارسال‌شده را وارد کن.');
      return;
    }
    setState(() {
      busy = true;
      error = '';
    });
    try {
      final data = await GaminoApiService.request(
        'auth.password_reset.verify',
        body: {'phone': phoneController.text.trim(), 'code': code},
        timeout: const Duration(seconds: 12),
      );
      if (!mounted) return;
      final token = data['resetToken']?.toString() ?? '';
      if (token.isEmpty) throw const GaminoApiException('تأیید کد کامل نشد. دوباره تلاش کن.');
      resetToken = token;
      await _moveToStep(2);
    } on GaminoApiException catch (e) {
      if (mounted) setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _complete() async {
    if (busy) return;
    final password = passwordController.text;
    if (!_validPassword(password)) {
      setState(() => error = 'رمز جدید باید حداقل ۶ کاراکتر و شامل حرف انگلیسی و عدد باشد.');
      passwordFocus.requestFocus();
      return;
    }
    if (password != repeatController.text) {
      setState(() => error = 'تکرار رمز با رمز جدید یکسان نیست.');
      repeatFocus.requestFocus();
      return;
    }
    setState(() {
      busy = true;
      error = '';
    });
    try {
      await GaminoApiService.request(
        'auth.password_reset.complete',
        body: {'phone': phoneController.text.trim(), 'resetToken': resetToken, 'password': password},
        timeout: const Duration(seconds: 12),
      );
      if (!mounted) return;
      FocusManager.instance.primaryFocus?.unfocus();
      Navigator.of(context).pop(true);
    } on GaminoApiException catch (e) {
      if (mounted) setState(() => error = e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget _stepIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(3, (index) {
        final active = index <= step;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: index == step ? 30 : 9,
          height: 7,
          margin: const EdgeInsets.symmetric(horizontal: 3),
          decoration: BoxDecoration(
            color: active ? AppPalette.primary : const Color(0xFFE1E5EF),
            borderRadius: BorderRadius.circular(999),
          ),
        );
      }),
    );
  }

  Widget _phoneStep() {
    return TextField(
      controller: phoneController,
      focusNode: phoneFocus,
      keyboardType: TextInputType.phone,
      textInputAction: TextInputAction.done,
      maxLength: 11,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(11)],
      onSubmitted: (_) => _requestCode(),
      decoration: const InputDecoration(
        labelText: 'شماره موبایل',
        hintText: '۰۹xxxxxxxxx',
        prefixIcon: Icon(Icons.phone_android_rounded),
        counterText: '',
      ),
    );
  }

  Widget _codeStep() {
    final count = codeController.text.length.clamp(0, 6);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: codeController,
          focusNode: codeFocus,
          keyboardType: TextInputType.number,
          textInputAction: TextInputAction.done,
          maxLength: 6,
          textAlign: TextAlign.center,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)],
          onChanged: (_) => setState(() {}),
          onSubmitted: (_) => _verifyCode(),
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 3),
          decoration: const InputDecoration(
            labelText: 'کد تأیید',
            prefixIcon: Icon(Icons.password_rounded),
            counterText: '',
          ),
        ),
        const SizedBox(height: 7),
        Row(
          textDirection: TextDirection.rtl,
          children: [
            Text('${faNumber(count)}/۶', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: AppPalette.muted)),
            const Spacer(),
            TextButton(
              onPressed: cooldown == 0 && !busy ? _requestCode : null,
              child: Text(cooldown > 0 ? 'ارسال مجدد ${faNumber(cooldown)} ثانیه' : 'ارسال مجدد کد'),
            ),
          ],
        ),
        if (message.isNotEmpty) ...[
          const SizedBox(height: 2),
          Text(message, textAlign: TextAlign.right, style: const TextStyle(fontSize: 11.5, color: AppPalette.muted, height: 1.65, fontWeight: FontWeight.w700)),
        ],
      ],
    );
  }

  Widget _passwordStep() {
    return Column(
      children: [
        TextField(
          controller: passwordController,
          focusNode: passwordFocus,
          keyboardType: TextInputType.visiblePassword,
          textInputAction: TextInputAction.next,
          obscureText: !showPassword,
          autocorrect: false,
          enableSuggestions: false,
          onSubmitted: (_) => repeatFocus.requestFocus(),
          decoration: InputDecoration(
            labelText: 'رمز جدید',
            prefixIcon: const Icon(Icons.lock_outline_rounded),
            suffixIcon: IconButton(
              onPressed: () => setState(() => showPassword = !showPassword),
              icon: Icon(showPassword ? Icons.visibility_off_rounded : Icons.visibility_rounded),
            ),
          ),
        ),
        const SizedBox(height: 11),
        TextField(
          controller: repeatController,
          focusNode: repeatFocus,
          keyboardType: TextInputType.visiblePassword,
          textInputAction: TextInputAction.done,
          obscureText: !showPassword,
          autocorrect: false,
          enableSuggestions: false,
          onSubmitted: (_) => _complete(),
          decoration: const InputDecoration(
            labelText: 'تکرار رمز جدید',
            prefixIcon: Icon(Icons.lock_outline_rounded),
          ),
        ),
        const SizedBox(height: 8),
        const Align(
          alignment: Alignment.centerRight,
          child: Text('حداقل ۶ کاراکتر، شامل حرف انگلیسی و عدد', textAlign: TextAlign.right, style: TextStyle(fontSize: 11, color: AppPalette.muted, fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    phoneController.dispose();
    codeController.dispose();
    passwordController.dispose();
    repeatController.dispose();
    phoneFocus.dispose();
    codeFocus.dispose();
    passwordFocus.dispose();
    repeatFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final title = step == 0 ? 'بازیابی رمز عبور' : step == 1 ? 'تأیید کد پیامک' : 'رمز جدید';
    final subtitle = step == 0
        ? 'شماره موبایل حساب گامینو را وارد کن.'
        : step == 1
            ? 'کد ۶ رقمی ارسال‌شده را وارد کن.'
            : 'رمز عبور جدیدت را تعیین کن.';
    final actionText = step == 0 ? 'ارسال کد' : step == 1 ? 'تأیید کد' : 'تغییر رمز';

    return PopScope(
      canPop: !busy,
      child: Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        backgroundColor: Colors.transparent,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 430),
          child: Container(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 18),
            decoration: BoxDecoration(
              color: const Color(0xFFFDFDFF),
              borderRadius: BorderRadius.circular(30),
              boxShadow: const [BoxShadow(color: Color(0x260F172A), blurRadius: 34, offset: Offset(0, 18))],
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    textDirection: TextDirection.rtl,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: 46,
                        height: 46,
                        decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.10), borderRadius: BorderRadius.circular(15)),
                        child: const Icon(Icons.lock_reset_rounded, color: AppPalette.primary, size: 27),
                      ),
                      const SizedBox(width: 11),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(title, textAlign: TextAlign.right, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                            const SizedBox(height: 3),
                            Text(subtitle, textAlign: TextAlign.right, style: const TextStyle(fontSize: 12.5, height: 1.55, color: AppPalette.muted, fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  _stepIndicator(),
                  const SizedBox(height: 18),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 180),
                    child: KeyedSubtree(
                      key: ValueKey(step),
                      child: step == 0 ? _phoneStep() : step == 1 ? _codeStep() : _passwordStep(),
                    ),
                  ),
                  if (error.isNotEmpty) ...[
                    const SizedBox(height: 9),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                      decoration: BoxDecoration(color: AppPalette.coral.withOpacity(.08), borderRadius: BorderRadius.circular(12)),
                      child: Text(error, textAlign: TextAlign.right, style: const TextStyle(color: AppPalette.coral, fontWeight: FontWeight.w800, fontSize: 11.5, height: 1.5)),
                    ),
                  ],
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      SizedBox(
                        width: 112,
                        height: 50,
                        child: OutlinedButton(
                          onPressed: busy ? null : _close,
                          style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                          child: const FittedBox(fit: BoxFit.scaleDown, child: Text('انصراف', maxLines: 1, softWrap: false)),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: SizedBox(
                          height: 50,
                          child: FilledButton(
                            onPressed: busy ? null : (step == 0 ? _requestCode : step == 1 ? _verifyCode : _complete),
                            style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                            child: busy
                                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                                : Text(actionText, maxLines: 1, style: const TextStyle(fontWeight: FontWeight.w900)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, this.initialMode = _AuthMode.welcome, required this.onGuest, required this.onStudentLogin, required this.onStudentRegister, this.onBackToGuest, this.onCancelPendingAuth});

  final _AuthMode initialMode;
  final Future<void> Function(int grade, String track) onGuest;
  final Future<String?> Function(String phone, String password) onStudentLogin;
  final Future<String?> Function(String name, int grade, {String? phone, String? password, String? track}) onStudentRegister;
  final VoidCallback? onBackToGuest;
  final VoidCallback? onCancelPendingAuth;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController loginPhoneController = TextEditingController();
  final TextEditingController registerPhoneController = TextEditingController();
  final TextEditingController loginPasswordController = TextEditingController();
  final TextEditingController registerPasswordController = TextEditingController();
  final TextEditingController repeatPasswordController = TextEditingController();
  final FocusNode nameFocusNode = FocusNode();
  final FocusNode registerPasswordFocusNode = FocusNode();
  final FocusNode repeatPasswordFocusNode = FocusNode();
  int selectedGrade = 7;
  String selectedTrack = '';
  bool showLoginPassword = false;
  bool showRegisterPassword = false;
  bool showRepeatPassword = false;
  bool acceptedTerms = false;
  late _AuthMode mode;
  bool isRegisterSubmitting = false;
  bool isLoginSubmitting = false;
  int _registerSequence = 0;
  int _loginSequence = 0;
  String? nameError;
  String? registerPhoneError;
  String? registerPasswordError;
  String? repeatPasswordError;
  String? loginPhoneError;
  String? loginPasswordError;

  @override
  void initState() {
    super.initState();
    mode = widget.initialMode;
    nameFocusNode.addListener(() {
      if (!nameFocusNode.hasFocus && mounted) _validateRegisterName();
    });
    registerPasswordFocusNode.addListener(() {
      if (!registerPasswordFocusNode.hasFocus && mounted) _validateRegisterPassword();
    });
    repeatPasswordFocusNode.addListener(() {
      if (!repeatPasswordFocusNode.hasFocus && mounted) _validateRepeatPassword();
    });
  }

  Future<void> _chooseGuestGrade() async {
    final grade = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
          children: [
            const Text('پایه تحصیلی را انتخاب کن', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            ...List.generate(12, (index) {
              final value = index + 1;
              return ListTile(
                leading: const Icon(Icons.school_outlined, color: AppPalette.primary),
                title: Text('پایه ${gradeLabel(value)}', style: const TextStyle(fontWeight: FontWeight.w800)),
                onTap: () => Navigator.pop(sheetContext, value),
              );
            }),
          ],
        ),
      ),
    );
    if (grade == null || !mounted) return;

    var track = '';
    if (grade >= 10) {
      final selectedTrack = await showModalBottomSheet<String>(
        context: context,
        showDragHandle: true,
        builder: (sheetContext) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('رشته پایه ${gradeLabel(grade)} را انتخاب کن', textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                for (final item in const ['ریاضی', 'تجربی', 'انسانی'])
                  ListTile(
                    leading: const Icon(Icons.menu_book_rounded, color: AppPalette.primary),
                    title: Text(item, style: const TextStyle(fontWeight: FontWeight.w900)),
                    onTap: () => Navigator.pop(sheetContext, item),
                  ),
              ],
            ),
          ),
        ),
      );
      if (selectedTrack == null || !mounted) return;
      track = selectedTrack;
    }

    await widget.onGuest(grade, track);
  }

  @override
  void dispose() {
    nameController.dispose();
    loginPhoneController.dispose();
    registerPhoneController.dispose();
    loginPasswordController.dispose();
    registerPasswordController.dispose();
    repeatPasswordController.dispose();
    nameFocusNode.dispose();
    registerPasswordFocusNode.dispose();
    repeatPasswordFocusNode.dispose();
    super.dispose();
  }

  bool _validName(String value) {
    final normalized = value.trim();
    return normalized.length >= 3 && normalized.length <= 20;
  }

  bool _validPhone(String value) => RegExp(r'^09\d{9}$').hasMatch(value.trim());

  bool _validPassword(String value) {
    final hasLetter = RegExp(r'[A-Za-z]').hasMatch(value);
    final hasNumber = RegExp(r'\d').hasMatch(value);
    return value.length >= 6 && hasLetter && hasNumber;
  }

  String? _passwordError(String value) {
    if (value.length < 6) return 'رمز عبور باید حداقل ۶ کاراکتر باشد.';
    if (!RegExp(r'[A-Za-z]').hasMatch(value)) return 'رمز عبور باید حداقل یک حرف انگلیسی داشته باشد.';
    if (!RegExp(r'\d').hasMatch(value)) return 'رمز عبور باید حداقل یک عدد داشته باشد.';
    return null;
  }

  void _validateRegisterName() {
    final value = nameController.text.trim();
    setState(() => nameError = _validName(value) ? null : 'نام باید بین ۳ تا ۲۰ کاراکتر باشد.');
  }

  void _validateRegisterPassword() {
    setState(() => registerPasswordError = _passwordError(registerPasswordController.text));
  }

  void _validateRepeatPassword() {
    final repeat = repeatPasswordController.text;
    final original = registerPasswordController.text;
    setState(() => repeatPasswordError = repeat == original && repeat.isNotEmpty ? null : 'تکرار رمز عبور با رمز اصلی یکسان نیست.');
  }

  String _friendlyAuthError(String raw) {
    final value = raw.trim();
    final lower = value.toLowerCase();
    if (lower.contains('اتصال') || lower.contains('اینترنت') || lower.contains('timeout') || lower.contains('network') || lower.contains('socket') || lower.contains('server') || lower.contains('سرور')) {
      return 'اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.';
    }
    return value.isEmpty ? 'عملیات انجام نشد. دوباره تلاش کنید.' : value;
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(_friendlyAuthError(message)), behavior: SnackBarBehavior.floating),
    );
  }

  void _cancelPendingOperations() {
    _registerSequence++;
    _loginSequence++;
    widget.onCancelPendingAuth?.call();
    if (mounted) {
      setState(() {
        isRegisterSubmitting = false;
        isLoginSubmitting = false;
      });
    }
  }

  Future<void> _submitRegister() async {
    if (isRegisterSubmitting) return;
    final name = nameController.text.trim();
    final phone = registerPhoneController.text.trim();
    final password = registerPasswordController.text;
    final repeat = repeatPasswordController.text;
    final nextNameError = _validName(name) ? null : 'نام باید بین ۳ تا ۲۰ کاراکتر باشد.';
    final nextPhoneError = _validPhone(phone) ? null : 'شماره تلفن باید با 09 شروع شود و دقیقاً ۱۱ رقم باشد.';
    final nextPasswordError = _passwordError(password);
    final nextRepeatError = password == repeat && repeat.isNotEmpty ? null : 'تکرار رمز عبور با رمز اصلی یکسان نیست.';
    setState(() {
      nameError = nextNameError;
      registerPhoneError = nextPhoneError;
      registerPasswordError = nextPasswordError;
      repeatPasswordError = nextRepeatError;
    });
    if (nextNameError != null || nextPhoneError != null || nextPasswordError != null || nextRepeatError != null) return;
    if (!acceptedTerms) {
      _showMessage('برای ثبت‌نام باید شرایط و حریم خصوصی را تایید کنید.');
      return;
    }

    final sequence = ++_registerSequence;
    setState(() => isRegisterSubmitting = true);
    String? error;
    try {
      error = await widget.onStudentRegister(
        name,
        selectedGrade,
        track: normalizeEducationTrack(selectedGrade, selectedTrack),
        phone: phone,
        password: password,
      ).timeout(
        const Duration(seconds: 17),
        onTimeout: () => 'اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.',
      );
    } catch (_) {
      error = 'اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.';
    }
    if (!mounted || sequence != _registerSequence || mode != _AuthMode.register) return;
    setState(() => isRegisterSubmitting = false);
    if (error != null) _showMessage(error);
  }

  Future<void> _submitLogin() async {
    if (isLoginSubmitting) return;
    final phone = loginPhoneController.text.trim();
    final password = loginPasswordController.text;
    final nextPhoneError = _validPhone(phone) ? null : 'شماره تلفن باید با 09 شروع شود و دقیقاً ۱۱ رقم باشد.';
    final nextPasswordError = _passwordError(password);
    setState(() {
      loginPhoneError = nextPhoneError;
      loginPasswordError = nextPasswordError;
    });
    if (nextPhoneError != null || nextPasswordError != null) return;

    final sequence = ++_loginSequence;
    setState(() => isLoginSubmitting = true);
    String? error;
    try {
      error = await widget.onStudentLogin(phone, password).timeout(
        const Duration(seconds: 12),
        onTimeout: () => 'اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.',
      );
    } catch (_) {
      error = 'اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.';
    }
    if (!mounted || sequence != _loginSequence || mode != _AuthMode.login) return;
    setState(() => isLoginSubmitting = false);
    if (error != null) _showMessage(error);
  }

  void _goBackFromForm() {
    _cancelPendingOperations();
    setState(() {
      mode = _AuthMode.welcome;
      loginPasswordController.clear();
      registerPasswordController.clear();
      repeatPasswordController.clear();
      nameError = null;
      registerPhoneError = null;
      registerPasswordError = null;
      repeatPasswordError = null;
      loginPhoneError = null;
      loginPasswordError = null;
    });
  }

  void _switchToRegister() {
    _cancelPendingOperations();
    setState(() {
      mode = _AuthMode.register;
      registerPhoneController.clear();
      registerPasswordController.clear();
      repeatPasswordController.clear();
      acceptedTerms = false;
      nameError = null;
      registerPhoneError = null;
      registerPasswordError = null;
      repeatPasswordError = null;
    });
  }

  void _switchToLogin() {
    _cancelPendingOperations();
    setState(() {
      mode = _AuthMode.login;
      loginPhoneController.clear();
      loginPasswordController.clear();
      loginPhoneError = null;
      loginPasswordError = null;
    });
  }

  Future<void> _showTermsDialog() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('شرایط و حریم خصوصی', textAlign: TextAlign.right),
        content: const SingleChildScrollView(
          child: Text(
            'با ثبت‌نام در گامینو، استفاده از حساب کاربری در چارچوب قوانین برنامه را می‌پذیرید. اطلاعات حساب و فعالیت آموزشی شما برای ارائه خدمات، ذخیره پیشرفت، پشتیبانی و بهبود تجربه یادگیری استفاده می‌شود. اطلاعات شخصی بدون مجوز در اختیار اشخاص دیگر قرار نمی‌گیرد، مگر در موارد الزامی قانونی. مسئولیت حفظ رمز عبور حساب بر عهده کاربر است.',
            textAlign: TextAlign.right,
            style: TextStyle(height: 1.9, fontWeight: FontWeight.w700, color: AppPalette.ink),
          ),
        ),
        actions: [
          FilledButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('متوجه شدم')),
        ],
      ),
    );
  }

  void _handleFormBack() {
    final backToGuest = widget.onBackToGuest;
    if (backToGuest != null) {
      _cancelPendingOperations();
      backToGuest();
      return;
    }
    _goBackFromForm();
  }

  Future<void> _handleSystemBack() async {
    final backToGuest = widget.onBackToGuest;
    if (backToGuest != null) {
      _cancelPendingOperations();
      backToGuest();
      return;
    }
    if (mode != _AuthMode.welcome) {
      _goBackFromForm();
      return;
    }
    await showExitConfirmationDialog(context);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _handleSystemBack();
      },
      child: Scaffold(
        body: SafeArea(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 240),
            child: mode == _AuthMode.welcome
                ? _buildWelcome()
                : mode == _AuthMode.login
                    ? _buildLogin()
                    : _buildRegister(),
          ),
        ),
      ),
    );
  }

  Widget _buildWelcome() {
    return Padding(
      key: const ValueKey('welcome'),
      padding: const EdgeInsets.fromLTRB(24, 24, 24, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Spacer(),
          Center(
            child: Container(
              width: 118,
              height: 118,
              decoration: BoxDecoration(
                gradient: AppPalette.actionGradient,
                borderRadius: BorderRadius.circular(34),
                boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.22), blurRadius: 26, offset: const Offset(0, 14))],
              ),
              child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 58),
            ),
          ),
          const SizedBox(height: 28),
          const Text('به گامینو خوش آمدید', textAlign: TextAlign.center, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppPalette.ink)),
          const SizedBox(height: 10),
          const Text('مسیر موفقیتت رو همین‌جا شروع کن', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: AppPalette.muted, fontWeight: FontWeight.w700)),
          const Spacer(),
          _PrimaryGradientButton(label: 'ثبت نام', onTap: _switchToRegister),
          const SizedBox(height: 14),
          OutlinedButton(onPressed: _switchToLogin, child: const Text('ورود')),
          const SizedBox(height: 26),
          Row(
            children: [
              Expanded(child: Divider(color: AppPalette.muted.withOpacity(.25))),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text('یا', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800)),
              ),
              Expanded(child: Divider(color: AppPalette.muted.withOpacity(.25))),
            ],
          ),
          const SizedBox(height: 26),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppPalette.ink, elevation: 0),
            onPressed: _chooseGuestGrade,
            icon: const Icon(Icons.person_outline_rounded),
            label: const Text('ورود به عنوان مهمان'),
          ),
          const SizedBox(height: 14),
          const Text(
            'برای حالت مهمان پایه تحصیلی را انتخاب می‌کنی؛ در پایه‌های دهم تا دوازدهم رشته هم مشخص می‌شود.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700),
          ),
          const Spacer(),
        ],
      ),
    );
  }

  Widget _buildLogin() {
    return _AuthFormLayout(
      key: const ValueKey('login'),
      title: 'ورود',
      subtitle: 'به حساب کاربری خود وارد شوید',
      onBack: _handleFormBack,
      children: [
        _AuthInput(
          controller: loginPhoneController,
          label: 'شماره تلفن',
          icon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
          maxLength: 11,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          errorText: loginPhoneError,
          onChanged: (_) { if (loginPhoneError != null) setState(() => loginPhoneError = null); },
        ),
        const SizedBox(height: 12),
        _AuthInput(
          controller: loginPasswordController,
          label: 'رمز عبور',
          icon: Icons.lock_outline_rounded,
          obscureText: !showLoginPassword,
          errorText: loginPasswordError,
          onChanged: (value) { if (loginPasswordError != null) setState(() => loginPasswordError = _passwordError(value)); },
          suffixIcon: IconButton(
            icon: Icon(showLoginPassword ? Icons.visibility_off_outlined : Icons.visibility_outlined),
            onPressed: () => setState(() => showLoginPassword = !showLoginPassword),
          ),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(
            onPressed: isLoginSubmitting ? null : () async {
              final changed = await showDialog<bool>(context: context, builder: (_) => const PasswordRecoveryDialog());
              if (changed == true && mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('رمز عبور با موفقیت تغییر کرد. حالا وارد حسابت شو.')));
              }
            },
            child: const Text('فراموشی رمز عبور؟'),
          ),
        ),
        const SizedBox(height: 12),
        _PrimaryGradientButton(label: isLoginSubmitting ? 'در حال ورود...' : 'ورود', onTap: isLoginSubmitting ? null : _submitLogin),
        const SizedBox(height: 18),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('حساب کاربری ندارید؟', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
            TextButton(onPressed: _switchToRegister, child: const Text('ثبت نام')),
          ],
        ),
      ],
    );
  }

  Widget _buildRegister() {
    return _AuthFormLayout(
      key: const ValueKey('register'),
      title: 'ثبت نام',
      subtitle: 'برای شروع، اطلاعات خود را وارد کنید',
      onBack: _handleFormBack,
      children: [
        _AuthInput(
          controller: nameController,
          focusNode: nameFocusNode,
          label: 'نام و نام خانوادگی',
          icon: Icons.person_outline_rounded,
          maxLength: 20,
          errorText: nameError,
          onChanged: (value) { if (nameError != null) setState(() => nameError = _validName(value) ? null : 'نام باید بین ۳ تا ۲۰ کاراکتر باشد.'); },
        ),
        const SizedBox(height: 12),
        _AuthInput(
          controller: registerPhoneController,
          label: 'شماره تلفن',
          icon: Icons.phone_outlined,
          keyboardType: TextInputType.phone,
          maxLength: 11,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          errorText: registerPhoneError,
          onChanged: (_) { if (registerPhoneError != null) setState(() => registerPhoneError = null); },
        ),
        const SizedBox(height: 12),
        GradeTrackPicker(
          grade: selectedGrade,
          track: selectedTrack,
          showHelper: false,
          onGradeChanged: (value) => setState(() {
            selectedGrade = value;
            selectedTrack = normalizeEducationTrack(value, selectedTrack);
          }),
          onTrackChanged: (value) => setState(() => selectedTrack = value),
        ),
        const SizedBox(height: 12),
        _AuthInput(
          controller: registerPasswordController,
          focusNode: registerPasswordFocusNode,
          label: 'رمز عبور',
          icon: Icons.lock_outline_rounded,
          obscureText: !showRegisterPassword,
          errorText: registerPasswordError,
          onChanged: (value) { if (registerPasswordError != null) setState(() => registerPasswordError = _passwordError(value)); },
          suffixIcon: IconButton(
            icon: Icon(showRegisterPassword ? Icons.visibility_off_outlined : Icons.visibility_outlined),
            onPressed: () => setState(() => showRegisterPassword = !showRegisterPassword),
          ),
        ),
        const SizedBox(height: 12),
        _AuthInput(
          controller: repeatPasswordController,
          focusNode: repeatPasswordFocusNode,
          label: 'تکرار رمز عبور',
          icon: Icons.lock_outline_rounded,
          obscureText: !showRepeatPassword,
          errorText: repeatPasswordError,
          onChanged: (value) { if (repeatPasswordError != null) setState(() => repeatPasswordError = value == registerPasswordController.text && value.isNotEmpty ? null : 'تکرار رمز عبور با رمز اصلی یکسان نیست.'); },
          suffixIcon: IconButton(
            icon: Icon(showRepeatPassword ? Icons.visibility_off_outlined : Icons.visibility_outlined),
            onPressed: () => setState(() => showRepeatPassword = !showRepeatPassword),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          textDirection: TextDirection.rtl,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Checkbox(
              value: acceptedTerms,
              onChanged: isRegisterSubmitting ? null : (value) => setState(() => acceptedTerms = value == true),
              visualDensity: VisualDensity.compact,
            ),
            const SizedBox(width: 4),
            Expanded(
              child: Wrap(
                alignment: WrapAlignment.start,
                crossAxisAlignment: WrapCrossAlignment.center,
                textDirection: TextDirection.rtl,
                children: [
                  InkWell(
                    onTap: _showTermsDialog,
                    borderRadius: BorderRadius.circular(6),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 4),
                      child: Text('شرایط و حریم خصوصی', style: TextStyle(color: AppPalette.primary, fontWeight: FontWeight.w900)),
                    ),
                  ),
                  const Text(' را تایید می‌کنم', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        _PrimaryGradientButton(
          label: isRegisterSubmitting ? 'در حال ثبت‌نام...' : 'ثبت نام',
          onTap: isRegisterSubmitting || !acceptedTerms ? null : _submitRegister,
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('قبلاً حساب کاربری دارید؟', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
            TextButton(onPressed: _switchToLogin, child: const Text('ورود')),
          ],
        ),
      ],
    );
  }
}


class GradeTrackPicker extends StatelessWidget {
  const GradeTrackPicker({
    super.key,
    required this.grade,
    required this.track,
    required this.onGradeChanged,
    required this.onTrackChanged,
    this.showHelper = true,
  });

  final int grade;
  final String track;
  final ValueChanged<int> onGradeChanged;
  final ValueChanged<String> onTrackChanged;
  final bool showHelper;

  @override
  Widget build(BuildContext context) {
    final needsTrack = grade >= 10;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        DropdownButtonFormField<int>(
          value: grade,
          decoration: InputDecoration(
            labelText: 'انتخاب پایه',
            prefixIcon: const Icon(Icons.school_outlined),
            helperText: showHelper ? 'اول تا نهم بدون رشته؛ دهم تا دوازدهم با رشته' : null,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
          ),
          items: List.generate(12, (index) => index + 1)
              .map((item) => DropdownMenuItem(value: item, child: Text('پایه ${gradeLabel(item)}')))
              .toList(),
          onChanged: (value) async {
            final selectedGrade = value ?? grade;
            onGradeChanged(selectedGrade);
            if (selectedGrade < 10) return;
            await Future<void>.delayed(Duration.zero);
            if (!context.mounted) return;
            final selectedTrack = await showModalBottomSheet<String>(
              context: context,
              showDragHandle: true,
              builder: (sheetContext) => SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'رشته پایه ${gradeLabel(selectedGrade)} را انتخاب کن',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 12),
                      for (final item in kSeniorTracks)
                        ListTile(
                          leading: const Icon(Icons.menu_book_rounded, color: AppPalette.primary),
                          title: Text(item, style: const TextStyle(fontWeight: FontWeight.w900)),
                          trailing: normalizeEducationTrack(selectedGrade, track) == item
                              ? const Icon(Icons.check_circle_rounded, color: AppPalette.mint)
                              : null,
                          onTap: () => Navigator.pop(sheetContext, item),
                        ),
                    ],
                  ),
                ),
              ),
            );
            if (selectedTrack != null) onTrackChanged(selectedTrack);
          },
        ),
        if (needsTrack) ...[
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: normalizeEducationTrack(grade, track),
            decoration: InputDecoration(
              labelText: 'انتخاب رشته',
              prefixIcon: const Icon(Icons.menu_book_outlined),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
            ),
            items: kSeniorTracks
                .map((item) => DropdownMenuItem<String>(value: item, child: Text(item)))
                .toList(),
            onChanged: (value) {
              if (value != null) onTrackChanged(value);
            },
          ),
        ],
      ],
    );
  }
}

class _AuthFormLayout extends StatelessWidget {
  const _AuthFormLayout({super.key, required this.title, required this.subtitle, required this.onBack, required this.children});

  final String title;
  final String subtitle;
  final VoidCallback onBack;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(24, 22, 24, 24),
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: IconButton.filledTonal(
            style: IconButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppPalette.ink),
            onPressed: onBack,
            icon: const Icon(Icons.close_rounded),
          ),
        ),
        const SizedBox(height: 22),
        Center(
          child: Container(
            width: 82,
            height: 82,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.08), shape: BoxShape.circle),
            child: Icon(title == 'ثبت نام' ? Icons.person_add_alt_1_rounded : Icons.login_rounded, color: AppPalette.secondary, size: 36),
          ),
        ),
        const SizedBox(height: 18),
        Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: AppPalette.ink)),
        const SizedBox(height: 8),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
        const SizedBox(height: 34),
        ...children,
      ],
    );
  }
}

class _AuthInput extends StatelessWidget {
  const _AuthInput({
    required this.controller,
    required this.label,
    required this.icon,
    this.keyboardType,
    this.obscureText = false,
    this.suffixIcon,
    this.maxLength,
    this.inputFormatters,
    this.focusNode,
    this.errorText,
    this.onChanged,
  });

  final TextEditingController controller;
  final String label;
  final IconData icon;
  final TextInputType? keyboardType;
  final bool obscureText;
  final Widget? suffixIcon;
  final int? maxLength;
  final List<TextInputFormatter>? inputFormatters;
  final FocusNode? focusNode;
  final String? errorText;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    final hasError = errorText != null && errorText!.trim().isNotEmpty;
    return TextField(
      controller: controller,
      focusNode: focusNode,
      keyboardType: keyboardType,
      obscureText: obscureText,
      maxLength: maxLength,
      inputFormatters: inputFormatters,
      onChanged: onChanged,
      buildCounter: maxLength == null ? null : (context, {required currentLength, required isFocused, maxLength}) => null,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        suffixIcon: suffixIcon,
        errorText: errorText,
        errorMaxLines: 2,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide(color: hasError ? const Color(0xFFDC2626) : AppPalette.primary.withOpacity(.08), width: hasError ? 1.4 : 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: BorderSide(color: hasError ? const Color(0xFFDC2626) : AppPalette.primary, width: 1.4),
        ),
        errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: Color(0xFFDC2626), width: 1.4)),
        focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: Color(0xFFDC2626), width: 1.6)),
        filled: true,
        fillColor: Colors.white,
      ),
    );
  }
}


class _PrimaryGradientButton extends StatelessWidget {
  const _PrimaryGradientButton({required this.label, required this.onTap});

  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: onTap == null ? .58 : 1,
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Container(
          height: 62,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: AppPalette.actionGradient,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [BoxShadow(color: AppPalette.secondary.withOpacity(.24), blurRadius: 22, offset: const Offset(0, 12))],
          ),
          child: Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
        ),
      ),
    );
  }
}


class AuthBenefitsStrip extends StatelessWidget {
  const AuthBenefitsStrip({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.school_outlined, 'انتخاب پایه'),
      (Icons.auto_graph_rounded, 'کاپ و کارت'),
      (Icons.error_outline_rounded, 'اشتباهات من'),
    ];
    return Row(
      children: items.map((item) {
        return Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 4),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppPalette.primary.withOpacity(.08)),
              boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.04), blurRadius: 14, offset: const Offset(0, 7))],
            ),
            child: Column(
              children: [
                Icon(item.$1, color: AppPalette.primary),
                const SizedBox(height: 6),
                Text(item.$2, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: AppPalette.ink)),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}

class GradeStartHint extends StatelessWidget {
  const GradeStartHint({super.key, required this.selectedGrade});

  final int selectedGrade;

  @override
  Widget build(BuildContext context) {
    final track = selectedGrade <= 6 ? 'مسیر دبستان' : selectedGrade <= 9 ? 'مسیر متوسطه اول' : 'مسیر متوسطه دوم';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppPalette.primary.withOpacity(.07),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppPalette.primary.withOpacity(.10)),
      ),
      child: Row(
        children: [
          const Icon(Icons.route_outlined, color: AppPalette.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              '$track فعال می‌شود؛ درس‌ها، سطح سوال‌ها و پیشنهاد تمرین بر اساس پایه $selectedGrade تنظیم می‌شوند.',
              style: const TextStyle(fontSize: 12.5, height: 1.6, color: AppPalette.ink, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class UserFlowV18Card extends StatelessWidget {
  const UserFlowV18Card({
    super.key,
    required this.user,
    required this.isGuest,
    required this.mistakesCount,
    required this.onOpenProfile,
    required this.onOpenQuiz,
    required this.onOpenStepByStep,
  });

  final AppUser user;
  final bool isGuest;
  final int mistakesCount;
  final VoidCallback onOpenProfile;
  final VoidCallback onOpenQuiz;
  final VoidCallback onOpenStepByStep;

  @override
  Widget build(BuildContext context) {
    final targetXp = max(500, user.level * 500);
    final remainingXp = max(0, targetXp - currentCups(user));
    final suggested = isGuest
        ? 'اول یک فصل از گام‌به‌گام را ببین.'
        : mistakesCount > 0
            ? 'اول $mistakesCount اشتباه ذخیره‌شده را مرور کن.'
            : remainingXp <= 120
                ? 'با یک کوییز دیگر احتمالاً Level بعدی باز می‌شود.'
                : 'یک کوییز کوتاه بده و کاپ بگیر.';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppPalette.primary.withOpacity(.08)),
        boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.05), blurRadius: 20, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(gradient: AppPalette.actionGradient, borderRadius: BorderRadius.circular(16)),
                child: const Icon(Icons.account_tree_outlined, color: Colors.white),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text('جریان کاربر گامینو', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppPalette.ink)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(child: _FlowMetric(label: 'پایه', value: gradeLabel(user.grade), icon: Icons.school_outlined)),
              const SizedBox(width: 8),
              Expanded(child: _FlowMetric(label: 'تا Level بعدی', value: '$remainingXp کاپ', icon: Icons.bolt_rounded)),
              const SizedBox(width: 8),
              Expanded(child: _FlowMetric(label: 'اشتباهات', value: '$mistakesCount', icon: Icons.refresh_rounded)),
            ],
          ),
          const SizedBox(height: 12),
          Text(suggested, style: const TextStyle(color: AppPalette.muted, height: 1.7, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: isGuest ? onOpenStepByStep : onOpenQuiz,
                  icon: Icon(isGuest ? Icons.menu_book_outlined : Icons.bolt_rounded),
                  label: Text(isGuest ? 'شروع گام‌به‌گام' : 'تمرین امروز'),
                ),
              ),
              const SizedBox(width: 10),
              IconButton.filledTonal(onPressed: onOpenProfile, icon: const Icon(Icons.tune_rounded), tooltip: 'پروفایل'),
            ],
          ),
        ],
      ),
    );
  }
}

class _FlowMetric extends StatelessWidget {
  const _FlowMetric({required this.label, required this.value, required this.icon});

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppPalette.canvas,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        children: [
          Icon(icon, color: AppPalette.primary, size: 20),
          const SizedBox(height: 6),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: AppPalette.muted, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class ProfileReadinessCard extends StatelessWidget {
  const ProfileReadinessCard({super.key, required this.user, required this.onEdit});

  final AppUser user;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final hasName = user.name.trim().isNotEmpty && user.name != 'دانش‌آموز';
    final hasGrade = user.grade >= 1 && user.grade <= 12;
    final hasPlan = user.studyTasks.isNotEmpty;
    final completed = [hasName, hasGrade, hasPlan].where((item) => item).length;
    final progress = completed / 3;
    return SectionCard(
      title: 'آماده‌سازی حساب دانش‌آموز',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: progress,
                    minHeight: 10,
                    backgroundColor: AppPalette.primary.withOpacity(.08),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text('${(progress * 100).round()}٪', style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
            ],
          ),
          const SizedBox(height: 12),
          _ReadinessLine(done: hasName, text: 'نام دانش‌آموز ثبت شده است'),
          _ReadinessLine(done: hasGrade, text: 'پایه تحصیلی مشخص شده است'),
          _ReadinessLine(done: hasPlan, text: 'حداقل یک برنامه مطالعه دارد'),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: onEdit,
            icon: const Icon(Icons.edit_note_rounded),
            label: const Text('تکمیل / ویرایش حساب'),
          ),
        ],
      ),
    );
  }
}

class _ReadinessLine extends StatelessWidget {
  const _ReadinessLine({required this.done, required this.text});

  final bool done;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(done ? Icons.check_circle : Icons.radio_button_unchecked, color: done ? AppPalette.mint : AppPalette.muted, size: 21),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700, color: AppPalette.ink))),
        ],
      ),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({
    super.key,
    required this.user,
    required this.saveStatus,
    required this.isGuest,
    required this.mistakes,
    required this.shopItems,
    required this.cardPackages,
    required this.activeRoom,
    required this.learningBooks,
    required this.medalItems,
    required this.onStudyTick,
    required this.onLogout,
    required this.onCompleteChapter,
    required this.onQuizFinished,
    required this.onMistakePracticeFinished,
    required this.onCreateRoom,
    required this.onJoinRoom,
    required this.onBuyShopItem,
    required this.onSelectShopItem,
    required this.onPrepareReward,
    required this.onClaimReward,
    required this.onPurchaseNoAds,
    required this.onUpdateProfile,
    required this.onUpdateThemeMode,
    required this.onUpdateAccount,
    required this.onAddStudyTask,
    required this.onToggleStudyTask,
    required this.onUpdateStudyTask,
    required this.onDeleteStudyTask,
    required this.onMarkLevelNotified,
  });

  final AppUser user;
  final String saveStatus;
  final bool isGuest;
  final List<MyMistake> mistakes;
  final List<ShopItem> shopItems;
  final List<CardPackage> cardPackages;
  final QuizRoom? activeRoom;
  final List<LearningBook> learningBooks;
  final List<GaminoMedalItem> medalItems;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;
  final Future<void> Function() onLogout;
  final void Function(Chapter chapter) onCompleteChapter;
  final void Function(QuizResult result) onQuizFinished;
  final void Function(QuizResult result) onMistakePracticeFinished;
  final void Function({required int maxPlayers, required String roomType}) onCreateRoom;
  final void Function(String code) onJoinRoom;
  final Future<bool> Function(ShopItem item) onBuyShopItem;
  final Future<bool> Function(ShopItem item) onSelectShopItem;
  final Future<String?> Function() onPrepareReward;
  final Future<bool> Function(String challenge) onClaimReward;
  final VoidCallback onPurchaseNoAds;
  final Future<bool> Function({required String name, required int grade, String? track, String? bio}) onUpdateProfile;
  final void Function(String themeMode) onUpdateThemeMode;
  final Future<bool> Function({required String name, required String phone, required String currentPassword, required String password}) onUpdateAccount;
  final Future<bool> Function(StudyTask task) onAddStudyTask;
  final Future<bool> Function(StudyTask task) onToggleStudyTask;
  final Future<bool> Function(StudyTask oldTask, StudyTask newTask) onUpdateStudyTask;
  final Future<bool> Function(StudyTask task) onDeleteStudyTask;
  final Future<bool> Function() onMarkLevelNotified;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with RouteAware {
  int selectedIndex = 2;
  int _quizInitialTabIndex = 0;
  bool _levelDialogOpen = false;
  int _locallyNotifiedLevel = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _maybeShowLevelUpDialog();
      resumeClassQuizIfNeeded();
    });
  }

  bool _classQuizResumeChecking = false;
  Future<void> resumeClassQuizIfNeeded() async {
    if (_classQuizResumeChecking || !mounted || widget.isGuest || ModalRoute.of(context)?.isCurrent != true) return;
    _classQuizResumeChecking = true;
    try {
      final payload = await ClassQuizApi.request('room.resume', const {}, timeout: const Duration(seconds: 7));
      if (!mounted || ModalRoute.of(context)?.isCurrent != true) return;
      final event = payload['event'];
      if (event is Map && (event['message']?.toString() ?? '').isNotEmpty) {
        await showDialog<void>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            content: Text(event['message'].toString(), textAlign: TextAlign.center, style: const TextStyle(height: 1.7, fontWeight: FontWeight.w800)),
            actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('باشه'))],
          ),
        );
      }
      if (!mounted || ModalRoute.of(context)?.isCurrent != true) return;
      final raw = payload['room'];
      if (raw is! Map) return;
      final room = ClassQuizRoomState.fromJson(Map<String, dynamic>.from(raw));
      final type = payload['type']?.toString() ?? '';
      if (type == 'waiting') {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => ClassQuizWaitingRoomScreen(user: widget.user, allBooks: widget.learningBooks.where((b) => b.grade == widget.user.grade && (widget.user.grade < 10 || normalizeEducationTrack(b.grade, b.track) == normalizeEducationTrack(widget.user.grade, widget.user.educationTrack))).toList(), initialRoom: room)));
      } else if (type == 'exam') {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => ClassQuizExamScreen(user: widget.user, initialRoom: room)));
      }
    } catch (_) {
      // With no internet, app opens normally on Home as requested.
    } finally {
      _classQuizResumeChecking = false;
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route != null) gaminoRouteObserver.subscribe(this, route);
  }

  @override
  void dispose() {
    gaminoRouteObserver.unsubscribe(this);
    super.dispose();
  }

  @override
  void didPopNext() {
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowLevelUpDialog());
  }

  @override
  void didUpdateWidget(covariant HomeShell oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (selectedIndex == 2 &&
        (oldWidget.user.level != widget.user.level ||
         oldWidget.user.lastLevelNotified != widget.user.lastLevelNotified)) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowLevelUpDialog());
    }
  }

  void goHome() => _selectTab(2);

  void _selectTab(int index) {
    if (selectedIndex == index) {
      if (index == 2) WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowLevelUpDialog());
      return;
    }
    HapticFeedback.selectionClick();
    setState(() {
      selectedIndex = index;
      if (index == 4) _quizInitialTabIndex = 0;
    });
    if (index == 2) WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowLevelUpDialog());
  }

  void openClassQuizHome() {
    if (!mounted) return;
    setState(() {
      selectedIndex = 4;
      _quizInitialTabIndex = 2;
    });
  }

  Future<void> _maybeShowLevelUpDialog() async {
    if (!mounted || widget.isGuest || selectedIndex != 2 || _levelDialogOpen || ModalRoute.of(context)?.isCurrent != true) return;
    final current = widget.user.level.clamp(1, 100).toInt();
    final serverNotified = widget.user.lastLevelNotified.clamp(1, 100).toInt();
    final previous = max(serverNotified, _locallyNotifiedLevel);
    if (current <= previous) return;
    _levelDialogOpen = true;
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
          insetPadding: const EdgeInsets.symmetric(horizontal: 28),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 24, 22, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 72,
                  height: 72,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    gradient: AppPalette.heroGradient,
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.22), blurRadius: 22, offset: const Offset(0, 10))],
                  ),
                  child: Text('$current', style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(height: 16),
                const Text('لول جدید باز شد!', textAlign: TextAlign.center, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                const SizedBox(height: 9),
                Text(
                  'آفرین! با ادامه مطالعه، از لول $previous به لول $current رسیدی.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 14.5, height: 1.7, fontWeight: FontWeight.w800, color: AppPalette.ink),
                ),
                const SizedBox(height: 5),
                const Text(
                  'ادامه بده؛ هر دقیقه مطالعه تو رو یک قدم جلوتر می‌بره.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12.5, height: 1.7, fontWeight: FontWeight.w700, color: AppPalette.muted),
                ),
                const SizedBox(height: 18),
                FilledButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('باشه')),
              ],
            ),
          ),
        ),
      );
      _locallyNotifiedLevel = current;
      await widget.onMarkLevelNotified();
    } finally {
      _levelDialogOpen = false;
    }
  }

  Future<void> _handleBackPressed() async {
    if (DateTime.now().isBefore(_suppressHomeExitUntil)) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    if (selectedIndex != 2) {
      setState(() => selectedIndex = 2);
      WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowLevelUpDialog());
      return;
    }
    await showExitConfirmationDialog(context);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      ProfileScreen(
        user: widget.user,
        isGuest: widget.isGuest,
        shopItems: widget.shopItems,
        cardPackages: widget.cardPackages,
        onBuyShopItem: widget.onBuyShopItem,
        onSelectShopItem: widget.onSelectShopItem,
        onPrepareReward: widget.onPrepareReward,
        onClaimReward: widget.onClaimReward,
        onPurchaseNoAds: widget.onPurchaseNoAds,
        onUpdateProfile: widget.onUpdateProfile,
        onUpdateThemeMode: widget.onUpdateThemeMode,
        onUpdateAccount: widget.onUpdateAccount,
        onAddStudyTask: widget.onAddStudyTask,
        onToggleStudyTask: widget.onToggleStudyTask,
        onUpdateStudyTask: widget.onUpdateStudyTask,
        onDeleteStudyTask: widget.onDeleteStudyTask,
        mistakes: widget.mistakes,
        onMistakePracticeFinished: widget.onMistakePracticeFinished,
        onLogout: widget.onLogout,
        onOpenMedals: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => GaminoMedalsScreen(user: widget.user, medals: widget.medalItems)),
        ),
      ),
      LeaderboardScreen(user: widget.user, isGuest: widget.isGuest),
      DashboardScreen(
        user: widget.user,
        learningBooks: widget.learningBooks,
        saveStatus: widget.saveStatus,
        isGuest: widget.isGuest,
        mistakesCount: widget.mistakes.length,
        onOpenQuiz: () => _selectTab(4),
        onOpenStepByStep: () => _selectTab(3),
        onOpenProfile: () => _selectTab(0),
        onOpenCardShop: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => GaminoShopScreen(
              user: widget.user,
              shopItems: widget.shopItems,
              cardPackages: widget.cardPackages,
              onBuyShopItem: widget.onBuyShopItem,
              onSelectShopItem: widget.onSelectShopItem,
              onPrepareReward: widget.onPrepareReward,
              onClaimReward: widget.onClaimReward,
              onPurchaseNoAds: widget.onPurchaseNoAds,
            ),
          ),
        ),
        onOpenSettings: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => AppSettingsScreen(
              user: widget.user,
              onUpdateProfile: widget.onUpdateProfile,
              onUpdateThemeMode: widget.onUpdateThemeMode,
              onUpdateAccount: widget.onUpdateAccount,
              onLogout: widget.onLogout,
            ),
          ),
        ),
        onStudyTick: widget.onStudyTick,
      ),
      StepByStepScreen(
        user: widget.user,
        isGuest: widget.isGuest,
        onCompleteChapter: widget.onCompleteChapter,
        onStudyTick: widget.onStudyTick,
        books: widget.learningBooks,
      ),
      QuizCenterScreen(
        user: widget.user,
        initialTabIndex: _quizInitialTabIndex,
        isGuest: widget.isGuest,
        mistakes: widget.mistakes,
        activeRoom: widget.activeRoom,
        onQuizFinished: widget.onQuizFinished,
        onMistakePracticeFinished: widget.onMistakePracticeFinished,
        onCreateRoom: widget.onCreateRoom,
        onJoinRoom: widget.onJoinRoom,
        books: widget.learningBooks,
      ),
    ];

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _handleBackPressed();
      },
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: Stack(
          children: [
            Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 110),
                child: KeyedSubtree(
                  key: ValueKey<int>(selectedIndex),
                  child: pages[selectedIndex],
                ),
              ),
            ),
            Positioned(left: 0, right: 0, bottom: 0, child: HomeBottomDock(selectedIndex: selectedIndex, onSelected: _selectTab)),
          ],
        ),
      ),
    );
  }
}

class HomeBottomDock extends StatelessWidget {
  const HomeBottomDock({super.key, required this.selectedIndex, required this.onSelected});

  final int selectedIndex;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(34),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.07),
              blurRadius: 26,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: _DockTab(
                  label: 'پروفایل',
                  icon: Icons.person_outline_rounded,
                  selectedIcon: Icons.person_rounded,
                  selected: selectedIndex == 0,
                  onTap: () => onSelected(0),
                ),
              ),
              Expanded(
                child: _DockTab(
                  label: 'رتبه‌بندی',
                  icon: Icons.leaderboard_outlined,
                  selectedIcon: Icons.leaderboard_rounded,
                  selected: selectedIndex == 1,
                  onTap: () => onSelected(1),
                ),
              ),
              SizedBox(
                width: 82,
                child: _HomeCenterDockTab(
                  selected: selectedIndex == 2,
                  onTap: () => onSelected(2),
                ),
              ),
              Expanded(
                child: _DockTab(
                  label: 'گام‌به‌گام',
                  icon: Icons.menu_book_outlined,
                  selectedIcon: Icons.menu_book_rounded,
                  selected: selectedIndex == 3,
                  onTap: () => onSelected(3),
                ),
              ),
              Expanded(
                child: _DockTab(
                  label: 'کوییز',
                  icon: Icons.sports_esports_outlined,
                  selectedIcon: Icons.sports_esports_rounded,
                  selected: selectedIndex == 4,
                  onTap: () => onSelected(4),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _HomeCenterDockTab extends StatelessWidget {
  const _HomeCenterDockTab({required this.selected, required this.onTap});

  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      customBorder: const CircleBorder(),
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOut,
            width: selected ? 64 : 58,
            height: selected ? 64 : 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: selected ? AppPalette.heroGradient : null,
              color: selected ? null : AppPalette.primary.withOpacity(.08),
              boxShadow: selected
                  ? const [BoxShadow(color: Color(0x333D5AFE), blurRadius: 18, offset: Offset(0, 8))]
                  : const [],
            ),
            child: Icon(Icons.home_rounded, color: selected ? Colors.white : Theme.of(context).colorScheme.onSurface.withOpacity(.58), size: selected ? 34 : 30),
          ),
        ],
      ),
    );
  }
}

class _DockTab extends StatelessWidget {
  const _DockTab({
    required this.label,
    required this.icon,
    required this.selectedIcon,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final IconData selectedIcon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppPalette.primary : Theme.of(context).colorScheme.onSurface.withOpacity(.58);
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 2),
        decoration: BoxDecoration(
          color: selected ? AppPalette.primary.withOpacity(.10) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(selected ? selectedIcon : icon, color: color, size: selected ? 27 : 24),
            const SizedBox(height: 4),
            Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11.2, fontWeight: selected ? FontWeight.w900 : FontWeight.w800, color: color),
            ),
          ],
        ),
      ),
    );
  }
}


class DashboardScreen extends StatelessWidget {
  const DashboardScreen({
    super.key,
    required this.user,
    required this.learningBooks,
    required this.saveStatus,
    required this.isGuest,
    required this.mistakesCount,
    required this.onOpenQuiz,
    required this.onOpenStepByStep,
    required this.onOpenProfile,
    required this.onOpenSettings,
    required this.onOpenCardShop,
    required this.onStudyTick,
  });

  final AppUser user;
  final List<LearningBook> learningBooks;
  final String saveStatus;
  final bool isGuest;
  final int mistakesCount;
  final VoidCallback onOpenQuiz;
  final VoidCallback onOpenStepByStep;
  final VoidCallback onOpenProfile;
  final VoidCallback onOpenSettings;
  final VoidCallback onOpenCardShop;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 22),
        children: [
          HomeMainHeader(user: user, isGuest: isGuest, onProfileTap: onOpenProfile, onSettingsTap: onOpenSettings),
          const SizedBox(height: 16),
          HomeStatsStrip(user: user, onCardTap: onOpenCardShop),
          if (!user.hasActiveNoAds) ...[
            const SizedBox(height: 16),
            const GaminoHomeRotatingBanner(),
          ],
          const SizedBox(height: 16),
          HomeMainFeatureGrid(
            user: user,
            isGuest: isGuest,
            mistakesCount: mistakesCount,
            learningBooks: learningBooks,
            onOpenStepByStep: onOpenStepByStep,
            onOpenQuiz: onOpenQuiz,
            onStudyTick: onStudyTick,
          ),
        ],
      ),
    );
  }
}

class GaminoLevelBadge extends StatelessWidget {
  const GaminoLevelBadge({super.key, required this.user, this.size = 30});
  final AppUser user;
  final double size;

  @override
  Widget build(BuildContext context) {
    final progress = user.level >= 100 ? 1.0 : user.levelProgress.clamp(0.0, 1.0).toDouble();
    // v106: compact level badge with a green progress arc and white remainder.
    // The blue core slightly overlaps the inner edge of the ring so there is no
    // visible gap between the level circle and its progress indicator.
    final effectiveSize = size * .84;
    final stroke = max(1.65, size * .060);
    final coreSize = effectiveSize - stroke * .92;
    return SizedBox(
      width: size,
      height: size,
      child: Center(
        child: SizedBox(
          width: effectiveSize,
          height: effectiveSize,
          child: Stack(
            alignment: Alignment.center,
            children: [
              SizedBox(
                width: effectiveSize,
                height: effectiveSize,
                child: CircularProgressIndicator(
                  value: progress,
                  strokeWidth: stroke,
                  strokeCap: StrokeCap.round,
                  backgroundColor: Colors.white,
                  valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF22C55E)),
                ),
              ),
              Container(
                width: coreSize,
                height: coreSize,
                alignment: Alignment.center,
                decoration: const BoxDecoration(color: AppPalette.primary, shape: BoxShape.circle),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    '${user.level.clamp(1, 100)}',
                    style: TextStyle(color: Colors.white, fontSize: size * .30, fontWeight: FontWeight.w900, height: 1),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomeMainHeader extends StatelessWidget {
  const HomeMainHeader({super.key, required this.user, required this.isGuest, required this.onProfileTap, required this.onSettingsTap});

  final AppUser user;
  final bool isGuest;
  final VoidCallback onProfileTap;
  final VoidCallback onSettingsTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        TicketNotificationBell(isGuest: isGuest),
        const Spacer(),
        Expanded(
          flex: 8,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerRight,
            child: Text(isGuest ? 'سلام مهمان' : 'سلام ${user.name}', textAlign: TextAlign.right, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppPalette.ink, height: 1.15)),
          ),
        ),
        const SizedBox(width: 12),
        GestureDetector(
          onTap: onProfileTap,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              SizedBox(width: 72, height: 72, child: avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl)),
              Positioned(bottom: -4, left: -4, child: GaminoLevelBadge(user: user, size: 30)),
            ],
          ),
        ),
      ],
    );
  }
}

class ClassScheduleEntry {
  const ClassScheduleEntry({required this.day, required this.title, this.start = '', this.end = '', this.room = ''});
  final int day;
  final String title;
  final String start;
  final String end;
  final String room;
  Map<String, dynamic> toJson() => {'day': day, 'title': title, 'start': start, 'end': end, 'room': room};
  factory ClassScheduleEntry.fromJson(Map<String, dynamic> json) => ClassScheduleEntry(
        day: ((json['day'] as num?)?.toInt() ?? 0).clamp(0, 6).toInt(),
        title: json['title']?.toString() ?? '',
        start: json['start']?.toString() ?? '',
        end: json['end']?.toString() ?? '',
        room: json['room']?.toString() ?? '',
      );
}

class ClassScheduleStore {
  static String _key(AppUser user, bool isGuest) => 'gamino_class_schedule_v98_${isGuest ? 'guest_${user.grade}_${user.educationTrack}' : user.phone}';
  static Future<List<ClassScheduleEntry>> loadLocal(AppUser user, bool isGuest) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key(user, isGuest));
    if (raw == null || raw.isEmpty) return <ClassScheduleEntry>[];
    try {
      final list = jsonDecode(raw);
      return (list as List? ?? []).whereType<Map>().map((e) => ClassScheduleEntry.fromJson(Map<String, dynamic>.from(e))).toList();
    } catch (_) { return <ClassScheduleEntry>[]; }
  }
  static Future<void> saveLocal(AppUser user, bool isGuest, List<ClassScheduleEntry> rows) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key(user, isGuest), jsonEncode(rows.map((e) => e.toJson()).toList()));
  }
}

class ClassScheduleScreen extends StatefulWidget {
  const ClassScheduleScreen({super.key, required this.user, required this.isGuest});
  final AppUser user;
  final bool isGuest;
  @override State<ClassScheduleScreen> createState() => _ClassScheduleScreenState();
}

class _ClassScheduleScreenState extends State<ClassScheduleScreen> {
  static const days = ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];
  List<ClassScheduleEntry> entries = [];
  bool loading = true;
  bool saving = false;

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final local = await ClassScheduleStore.loadLocal(widget.user, widget.isGuest);
    if (mounted) setState(() { entries=local; loading=false; });
    if (widget.isGuest) return;
    final token=await RemoteSessionStore.readToken(); if(token==null||token.isEmpty) return;
    try {
      final state=await GaminoApiService.request('state',token:token,get:true);
      final remote=(state['weeklySchedule'] as List? ?? []).whereType<Map>().map((e)=>ClassScheduleEntry.fromJson(Map<String,dynamic>.from(e))).toList();
      if(remote.isNotEmpty || local.isEmpty){ await ClassScheduleStore.saveLocal(widget.user,false,remote); if(mounted)setState(()=>entries=remote); }
    } catch (_) {}
  }
  Future<void> _save() async {
    setState(()=>saving=true);
    await ClassScheduleStore.saveLocal(widget.user,widget.isGuest,entries);
    if(!widget.isGuest){
      final token=await RemoteSessionStore.readToken();
      if(token!=null&&token.isNotEmpty){try{await GaminoApiService.request('schedule.save',token:token,body:{'entries':entries.map((e)=>e.toJson()).toList()});}catch(_){}}
    }
    if(!mounted)return; setState(()=>saving=false); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برنامه کلاسی ذخیره شد.')));
  }
  Future<void> _edit({ClassScheduleEntry? current,int? index}) async {
    var day=current?.day??0; final title=TextEditingController(text:current?.title??''); final start=TextEditingController(text:current?.start??''); final end=TextEditingController(text:current?.end??''); final room=TextEditingController(text:current?.room??'');
    final result=await showDialog<ClassScheduleEntry>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(
      shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(24)), title:Text(current==null?'افزودن کلاس':'ویرایش کلاس',textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w900)),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        DropdownButtonFormField<int>(value:day,items:List.generate(days.length,(i)=>DropdownMenuItem(value:i,child:Text(days[i]))),onChanged:(v)=>setLocal(()=>day=v??0),decoration:const InputDecoration(labelText:'روز')),
        const SizedBox(height:8),TextField(controller:title,decoration:const InputDecoration(labelText:'نام درس / کلاس')),
        const SizedBox(height:8),Row(children:[Expanded(child:TextField(controller:start,keyboardType:TextInputType.datetime,decoration:const InputDecoration(labelText:'شروع ۰۸:۰۰'))),const SizedBox(width:8),Expanded(child:TextField(controller:end,keyboardType:TextInputType.datetime,decoration:const InputDecoration(labelText:'پایان ۰۹:۳۰')))]),
        const SizedBox(height:8),TextField(controller:room,decoration:const InputDecoration(labelText:'کلاس / اتاق (اختیاری)')),
      ])),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('انصراف')),FilledButton(onPressed:(){final t=title.text.trim();if(t.isEmpty)return;Navigator.pop(ctx,ClassScheduleEntry(day:day,title:t,start:start.text.trim(),end:end.text.trim(),room:room.text.trim()));},child:const Text('ذخیره'))],
    )));
    title.dispose();start.dispose();end.dispose();room.dispose(); if(result==null)return; setState((){if(index==null)entries.add(result);else entries[index]=result;entries.sort((a,b)=>a.day!=b.day?a.day.compareTo(b.day):a.start.compareTo(b.start));}); await _save();
  }
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(automaticallyImplyLeading:false,title:const Text('برنامه کلاسی'),actions:[TextButton.icon(onPressed:saving?null:_save,icon:saving?const SizedBox(width:16,height:16,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.save_outlined),label:const Text('ذخیره'))]),
      floatingActionButton:FloatingActionButton.extended(backgroundColor:const Color(0xFF0F2B5B),foregroundColor:Colors.white,onPressed:()=>_edit(),icon:const Icon(Icons.add_rounded),label:const Text('افزودن کلاس')),
      body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.fromLTRB(16,8,16,110),children:[
        Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(24)),child:const Row(children:[Icon(Icons.edit_calendar_rounded,color:Color(0xFF1D4ED8)),SizedBox(width:10),Expanded(child:Text('برنامه هفتگی کلاس‌ها را اینجا ببین و هر زمان لازم بود ویرایش کن.',style:TextStyle(fontWeight:FontWeight.w800,height:1.6)))])),
        const SizedBox(height:14),
        for(var day=0;day<days.length;day++) ...[
          Padding(padding:const EdgeInsets.fromLTRB(4,12,4,8),child:Text(days[day],style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900,color:AppPalette.ink))),
          if(entries.where((e)=>e.day==day).isEmpty) Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:Colors.white.withOpacity(.65),borderRadius:BorderRadius.circular(18)),child:const Text('کلاسی ثبت نشده است.',style:TextStyle(color:AppPalette.muted,fontWeight:FontWeight.w700)))
          else ...entries.asMap().entries.where((row)=>row.value.day==day).map((row){final e=row.value;return Card(child:ListTile(leading:const CircleAvatar(backgroundColor:Color(0xFFEAF0FF),child:Icon(Icons.school_outlined,color:Color(0xFF1D4ED8))),title:Text(e.title,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text([if(e.start.isNotEmpty||e.end.isNotEmpty)'${e.start}${e.end.isNotEmpty?' تا ${e.end}':''}',if(e.room.isNotEmpty)e.room].join(' • '),style:const TextStyle(color:AppPalette.muted,fontWeight:FontWeight.w700)),trailing:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(onPressed:()=>_edit(current:e,index:row.key),icon:const Icon(Icons.edit_outlined)),IconButton(onPressed:()async{setState(()=>entries.removeAt(row.key));await _save();},icon:const Icon(Icons.delete_outline_rounded,color:AppPalette.coral))])));}),
        ]
      ]));
  }
}

class LastLearningStore {
  static const _key = 'gamino_last_learning_v98';

  static Future<void> save(LearningBook book, LearningLesson lesson, LessonContentChoice choice) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode({
      'bookId': book.id,
      'lessonId': lesson.id,
      'choice': choice.name,
      'savedAt': DateTime.now().toIso8601String(),
    }));
  }

  static Future<Map<String, dynamic>?> read() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return null;
    try {
      final value = jsonDecode(raw);
      return value is Map ? Map<String, dynamic>.from(value) : null;
    } catch (_) {
      return null;
    }
  }

  static Future<bool> openLast({
    required BuildContext context,
    required List<LearningBook> books,
    required Future<void> Function(String subject, String chapter, int seconds) onStudyTick,
    required bool adsDisabled,
  }) async {
    final saved = await read();
    if (saved == null || !context.mounted) return false;
    LearningBook? book;
    LearningLesson? lesson;
    for (final item in books) {
      if (item.id == saved['bookId']?.toString()) {
        book = item;
        for (final row in item.lessons) {
          if (row.id == saved['lessonId']?.toString()) { lesson = row; break; }
        }
        break;
      }
    }
    if (book == null || lesson == null || !context.mounted) return false;
    final choice = saved['choice']?.toString() ?? LessonContentChoice.stepByStep.name;
    if (choice == LessonContentChoice.sampleQuestions.name) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => LessonQuestionsScreen(book: book!, lesson: lesson!, onStudyTick: onStudyTick, adsDisabled: adsDisabled)));
    } else {
      Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderScreen(
        title: 'گام به گام — ${lesson!.title}',
        documentId: 'step_${lesson.id}_pdf',
        pdfUrl: lesson.stepPdfUrl,
        version: lesson.stepPdfUrl,
        subject: book!.title,
        chapter: lesson.title,
        onStudyTick: onStudyTick,
      )));
    }
    unawaited(GaminoAdiveryService.showLessonInterstitial(adsDisabled: adsDisabled));
    return true;
  }
}

class HomeMainFeatureGrid extends StatelessWidget {
  const HomeMainFeatureGrid({
    super.key,
    required this.user,
    required this.isGuest,
    required this.mistakesCount,
    required this.learningBooks,
    required this.onOpenStepByStep,
    required this.onOpenQuiz,
    required this.onStudyTick,
  });

  final AppUser user;
  final bool isGuest;
  final int mistakesCount;
  final List<LearningBook> learningBooks;
  final VoidCallback onOpenStepByStep;
  final VoidCallback onOpenQuiz;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;

  @override
  Widget build(BuildContext context) {
    final continueBook = learningBooks.isEmpty ? null : learningBooks.first;
    final continueLesson = continueBook == null || continueBook.lessons.isEmpty ? null : continueBook.lessons.first;
    final items = [
      _HomeMainAction(
        title: 'ادامه یادگیری',
        subtitle: continueLesson == null ? 'شروع مطالعه' : continueLesson.title,
        icon: Icons.bolt_rounded,
        colors: const [Color(0xFF8B5CF6), Color(0xFF3B82F6)],
        locked: false,
        onTap: () async {
          final opened = await LastLearningStore.openLast(
            context: context,
            books: learningBooks,
            onStudyTick: onStudyTick,
            adsDisabled: user.hasActiveNoAds,
          );
          if (!opened) onOpenStepByStep();
        },
      ),
      _HomeMainAction(
        title: 'گام به گام',
        subtitle: 'درسنامه و آموزش',
        icon: Icons.menu_book_rounded,
        colors: const [Color(0xFF1D8CF8), Color(0xFF3B82F6)],
        locked: false,
        onTap: onOpenStepByStep,
      ),
      _HomeMainAction(
        title: 'کوییز',
        subtitle: 'سوالات تستی',
        icon: Icons.edit_square,
        colors: const [Color(0xFFFFB300), Color(0xFFFF8A00)],
        locked: isGuest,
        onTap: isGuest ? null : onOpenQuiz,
      ),
      _HomeMainAction(
        title: 'گزارش پیشرفت',
        subtitle: 'آمار و تحلیل',
        icon: Icons.bar_chart_rounded,
        colors: const [Color(0xFF7C3AED), Color(0xFF3D5AFE)],
        locked: isGuest,
        onTap: isGuest ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProgressReportScreen(user: user, mistakesCount: mistakesCount))),
      ),
      _HomeMainAction(
        title: 'اشتباهات من',
        subtitle: 'مرور و یادگیری بهتر',
        icon: Icons.fact_check_rounded,
        colors: const [Color(0xFF0EA5E9), Color(0xFF0284C7)],
        locked: isGuest,
        onTap: isGuest ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => SmartReviewScreen(user: user, mistakesCount: mistakesCount))),
      ),
      _HomeMainAction(
        title: 'برنامه کلاسی',
        subtitle: 'برنامه هفتگی کلاس',
        icon: Icons.calendar_view_week_rounded,
        colors: const [Color(0xFF0F2B5B), Color(0xFF1D4ED8)],
        locked: false,
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ClassScheduleScreen(user: user, isGuest: isGuest))),
      ),
    ];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.05), blurRadius: 18, offset: const Offset(0, 10))],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: GridView.builder(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            childAspectRatio: .72,
          ),
          itemBuilder: (context, index) => HomeMainFeatureTile(action: items[index]),
        ),
      ),
    );
  }
}

class _HomeMainAction {
  const _HomeMainAction({required this.title, required this.subtitle, required this.icon, required this.colors, required this.onTap, this.locked = false});

  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;
  final VoidCallback? onTap;
  final bool locked;
}

class HomeMainFeatureTile extends StatelessWidget {
  const HomeMainFeatureTile({super.key, required this.action});

  final _HomeMainAction action;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: action.locked ? () => showGuestLockPrompt(context, feature: action.title) : action.onTap,
      child: Opacity(
        opacity: action.locked ? .52 : 1,
        child: Container(
          decoration: BoxDecoration(
            border: Border(
              left: BorderSide(color: AppPalette.primary.withOpacity(.06)),
              bottom: BorderSide(color: AppPalette.primary.withOpacity(.06)),
            ),
          ),
          padding: const EdgeInsets.fromLTRB(6, 10, 6, 12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: action.colors),
                  borderRadius: BorderRadius.circular(17),
                  boxShadow: [BoxShadow(color: action.colors.first.withOpacity(.20), blurRadius: 12, offset: const Offset(0, 7))],
                ),
                child: Icon(action.locked ? Icons.lock_outline_rounded : action.icon, color: Colors.white, size: 27),
              ),
              const SizedBox(height: 8),
              Text(action.title, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, height: 1.15, fontWeight: FontWeight.w900, color: AppPalette.ink)),
              const SizedBox(height: 5),
              Text(action.locked ? 'بعد از ورود فعال می‌شود' : action.subtitle, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9.7, height: 1.25, color: AppPalette.muted, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}

class MvpPresentationCard extends StatelessWidget {
  const MvpPresentationCard({super.key, required this.user, required this.isGuest, required this.mistakesCount});

  final AppUser user;
  final bool isGuest;
  final int mistakesCount;

  @override
  Widget build(BuildContext context) {
    final hasProfile = !isGuest && user.name.trim().isNotEmpty && user.grade >= 1 && user.grade <= 12;
    final hasProgress = currentCups(user) > 0 || user.completedChapters > 0 || user.quizHistory.isNotEmpty;
    final hasLearningPath = user.studyTasks.isNotEmpty || mistakesCount > 0;
    final completed = [hasProfile, hasProgress, hasLearningPath].where((item) => item).length;
    final readiness = (completed / 3).clamp(0.0, 1.0).toDouble();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFFFFFFFF), Color(0xFFF7F2FF)],
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppPalette.secondary.withOpacity(.09)),
        boxShadow: [BoxShadow(color: AppPalette.secondary.withOpacity(.06), blurRadius: 22, offset: const Offset(0, 12))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(gradient: AppPalette.heroGradient, borderRadius: BorderRadius.circular(18)),
                child: const Icon(Icons.workspace_premium_rounded, color: Colors.white),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('وضعیت سرویس‌های گامینو', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    SizedBox(height: 4),
                    Text('حساب، محتوا، پیشرفت، مسابقه و ابزارهای آموزشی به وضعیت فعلی سرویس آنلاین متصل‌اند.', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700, height: 1.5)),
                  ],
                ),
              ),
              Text('${(readiness * 100).round()}٪', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.secondary)),
            ],
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(value: readiness, minHeight: 10),
          ),
          const SizedBox(height: 12),
          _PresentationCheckLine(done: hasProfile, text: 'حساب دانش‌آموز و پایه مشخص شده است'),
          _PresentationCheckLine(done: hasProgress, text: 'پیشرفت، کاپ، کارت یا آزمون ثبت شده است'),
          _PresentationCheckLine(done: hasLearningPath, text: 'مسیر یادگیری، برنامه یا اشتباهات برای نمایش وجود دارد'),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AppIntroScreen())),
                  icon: const Icon(Icons.play_circle_outline_rounded),
                  label: const Text('معرفی اپ'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutAppScreen())),
                  icon: const Icon(Icons.info_outline_rounded),
                  label: const Text('درباره'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}


class FinalMvpReleaseCard extends StatelessWidget {
  const FinalMvpReleaseCard({super.key, required this.user, required this.isGuest, required this.mistakesCount});

  final AppUser user;
  final bool isGuest;
  final int mistakesCount;

  @override
  Widget build(BuildContext context) {
    final hasProfile = !isGuest && user.name.trim().isNotEmpty && user.grade >= 1 && user.grade <= 12;
    final hasOfflineData = currentCups(user) > 0 || user.coins > 0 || user.studyTasks.isNotEmpty || user.quizHistory.isNotEmpty;
    final hasLearningSignals = mistakesCount > 0 || user.completedChapters > 0 || user.dailyActivity > 0;
    final hasPresentationLayer = true;
    final completed = [hasProfile, hasOfflineData, hasLearningSignals, hasPresentationLayer].where((item) => item).length;
    final readiness = (completed / 4).clamp(0.0, 1.0).toDouble();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFFEEF2FF), Color(0xFFFFFFFF), Color(0xFFFFF7ED)],
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppPalette.amber.withOpacity(.18)),
        boxShadow: [BoxShadow(color: AppPalette.amber.withOpacity(.08), blurRadius: 22, offset: const Offset(0, 12))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(gradient: AppPalette.fireGradient, borderRadius: BorderRadius.circular(18)),
                child: const Icon(Icons.rocket_launch_rounded, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text('وضعیت حساب و سرویس‌های آنلاین', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    SizedBox(height: 4),
                    Text('خلاصه وضعیت پروفایل، داده‌های یادگیری و اتصال به سرویس‌های آنلاین گامینو.', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700, height: 1.5)),
                  ],
                ),
              ),
              Text('${(readiness * 100).round()}٪', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.coral)),
            ],
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(value: readiness, minHeight: 10, backgroundColor: AppPalette.amber.withOpacity(.12)),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _MvpChip(done: hasProfile, text: 'پروفایل'),
              _MvpChip(done: hasOfflineData, text: 'ذخیره آفلاین'),
              _MvpChip(done: hasLearningSignals, text: 'مسیر یادگیری'),
              const _MvpChip(done: true, text: 'صفحات ارائه'),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AppIntroScreen())),
                  icon: const Icon(Icons.slideshow_rounded),
                  label: const Text('معرفی گامینو'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BackendRoadmapScreen(user: user))),
                  icon: const Icon(Icons.hub_outlined),
                  label: const Text('وضعیت سرور'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MvpChip extends StatelessWidget {
  const _MvpChip({required this.done, required this.text});

  final bool done;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: done ? AppPalette.mint.withOpacity(.10) : AppPalette.canvas,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: done ? AppPalette.mint.withOpacity(.25) : AppPalette.primary.withOpacity(.08)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, size: 17, color: done ? AppPalette.mint : AppPalette.muted),
          const SizedBox(width: 6),
          Text(text, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: done ? AppPalette.ink : AppPalette.muted)),
        ],
      ),
    );
  }
}

class _PresentationCheckLine extends StatelessWidget {
  const _PresentationCheckLine({required this.done, required this.text});

  final bool done;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Icon(done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, color: done ? AppPalette.mint : AppPalette.muted, size: 22),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink, height: 1.45))),
        ],
      ),
    );
  }
}

class AppIntroScreen extends StatelessWidget {
  const AppIntroScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.menu_book_rounded, 'یادگیری', 'گام‌به‌گام، نمونه سوال، پاسخ تشریحی و مرور سریع برای پایه‌های مختلف.'),
      (Icons.sports_esports_rounded, 'رقابت', 'کوییز، کاپ، Level، کارت و مسابقه دوستان برای انگیزه بیشتر.'),
      (Icons.psychology_rounded, 'هوشمندی', 'مسیر پیشنهادی، اشتباهات من، معلم هوشمند و گزارش پیشرفت.'),
    ];
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('معرفی اپ')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(gradient: AppPalette.heroGradient, borderRadius: BorderRadius.circular(32)),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('گامینو', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
                  SizedBox(height: 10),
                  Text('یک پلتفرم آموزشی گیمیفای‌شده برای دانش‌آموزان؛ یادگیری، رقابت، پیشرفت و تمرین اشتباهات در یک تجربه ساده و جذاب.', style: TextStyle(color: Colors.white, height: 1.8, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            ...items.map((item) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: SectionCard(
                    title: item.$2,
                    child: Row(
                      children: [
                        Container(width: 46, height: 46, decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.09), borderRadius: BorderRadius.circular(16)), child: Icon(item.$1, color: AppPalette.primary)),
                        const SizedBox(width: 12),
                        Expanded(child: Text(item.$3, style: const TextStyle(height: 1.7, fontWeight: FontWeight.w700, color: AppPalette.ink))),
                      ],
                    ),
                  ),
                )),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.close_rounded),
              label: const Text('برگشت به اپ'),
            ),
          ],
        ),
      ),
    );
  }
}

class AboutAppScreen extends StatelessWidget {
  const AboutAppScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('درباره گامینو')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: const [
            SectionCard(
              title: 'هدف اپ',
              child: Text('''گامینو با هدف ایجاد یک محیط آموزشی کامل، جذاب و کاربردی برای دانش‌آموزان پایه اول تا دوازدهم طراحی شده است. ما تلاش می‌کنیم با ارائه محتوای آموزشی، نمونه‌سؤالات متنوع، آزمون‌ها و رقابت‌های آموزشی، مسیر یادگیری را آسان‌تر، مؤثرتر و لذت‌بخش‌تر کنیم.''', style: TextStyle(height: 1.9, fontWeight: FontWeight.w700, color: AppPalette.ink)),
            ),
            SizedBox(height: 12),
            SectionCard(
              title: 'چشم‌انداز',
              child: Text('''چشم‌انداز گامینو ایجاد بستری هوشمند و قابل اعتماد برای یادگیری است؛ بستری که دانش‌آموزان بتوانند در آن مهارت‌های خود را تقویت کنند، پیشرفت تحصیلی خود را بسنجند و با انگیزه بیشتری به اهداف آموزشی خود دست یابند.''', style: TextStyle(height: 1.9, fontWeight: FontWeight.w700, color: AppPalette.ink)),
            ),
            SizedBox(height: 12),
            SectionCard(
              title: 'چرا گامینو؟',
              child: Text('''گامینو تنها یک مجموعه از سؤال‌ها و آزمون‌ها نیست؛ بلکه محیطی برای رشد، تمرین و پیشرفت است. ما باور داریم که یادگیری زمانی مؤثرتر خواهد بود که با انگیزه، تعامل و چالش‌های جذاب همراه باشد. به همین دلیل تلاش کرده‌ایم ابزارهایی را فراهم کنیم که دانش‌آموزان علاوه بر یادگیری، از مسیر پیشرفت خود نیز لذت ببرند.''', style: TextStyle(height: 1.9, fontWeight: FontWeight.w700, color: AppPalette.ink)),
            ),
            SizedBox(height: 12),
            SectionCard(
              title: 'پیام به کاربران',
              child: Text('''از همراهی شما سپاسگزاریم. اعتماد شما بزرگ‌ترین انگیزه ما برای توسعه و بهبود گامینو است. امیدواریم بتوانیم در مسیر موفقیت تحصیلی و رشد علمی شما همراهی مؤثر باشیم.''', style: TextStyle(height: 1.9, fontWeight: FontWeight.w700, color: AppPalette.ink)),
            ),
            SizedBox(height: 12),
            SectionCard(
              title: 'گامینو',
              child: Text('گامی نو در آموزش', style: TextStyle(height: 1.8, fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.primary)),
            ),
          ],
        ),
      ),
    );
  }
}

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('قوانین و حریم خصوصی')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: const [
            SectionCard(
              title: 'قوانین و مقررات استفاده از گامینو',
              child: Text('''به گامینو خوش آمدید. استفاده از این اپلیکیشن به منزله پذیرش قوانین و مقررات زیر است. لطفاً پیش از استفاده، این موارد را مطالعه کنید.

1. پذیرش قوانین
با نصب، ثبت‌نام یا استفاده از گامینو، شما موافقت خود را با قوانین و مقررات این اپلیکیشن اعلام می‌کنید.

2. استفاده مجاز
کاربران موظف هستند از اپلیکیشن در چارچوب قوانین جمهوری اسلامی ایران استفاده کنند.
هرگونه سوءاستفاده از خدمات، ایجاد اختلال در عملکرد سامانه یا استفاده غیرمجاز از حساب کاربری دیگران ممنوع است.
کاربران مسئول حفظ اطلاعات حساب کاربری خود هستند.

3. محتوای آموزشی
گامینو تلاش می‌کند محتوای آموزشی دقیق و به‌روز ارائه دهد، اما مسئولیتی در قبال اشتباهات احتمالی یا تغییرات محتوای آموزشی نخواهد داشت.
محتوای موجود صرفاً با اهداف آموزشی ارائه می‌شود.

4. رقابت‌های آموزشی
کاربران موظف به رعایت اصول رقابت سالم و اخلاقی هستند.
هرگونه تقلب، استفاده از ابزارهای غیرمجاز یا سوءاستفاده از سیستم رتبه‌بندی می‌تواند منجر به محدودیت یا مسدود شدن حساب کاربری شود.

5. مالکیت معنوی
تمامی محتوا، طراحی، نام تجاری، لوگو و امکانات گامینو متعلق به این مجموعه بوده و هرگونه کپی‌برداری یا استفاده بدون مجوز ممنوع است.

6. تغییر قوانین
گامینو این حق را دارد که در صورت نیاز، قوانین و مقررات را به‌روزرسانی کند. ادامه استفاده از اپلیکیشن به منزله پذیرش نسخه جدید قوانین خواهد بود.''', style: TextStyle(height: 1.9, fontWeight: FontWeight.w700, color: AppPalette.ink)),
            ),
            SizedBox(height: 12),
            SectionCard(
              title: 'حریم خصوصی',
              child: Text('''حفظ حریم خصوصی کاربران برای گامینو اهمیت ویژه‌ای دارد. ما متعهد هستیم اطلاعات کاربران را با نهایت دقت و امنیت نگهداری کنیم.

اطلاعاتی که جمع‌آوری می‌شود
ممکن است اطلاعات زیر برای ارائه خدمات بهتر جمع‌آوری شود:
نام و نام خانوادگی
شماره تلفن یا ایمیل (در صورت ثبت‌نام)
اطلاعات تحصیلی مانند پایه و مقطع تحصیلی
سوابق آزمون‌ها، کوییزها و فعالیت‌های آموزشی

نحوه استفاده از اطلاعات
اطلاعات کاربران صرفاً برای موارد زیر استفاده می‌شود:
ارائه خدمات آموزشی
بهبود عملکرد اپلیکیشن
پشتیبانی و پاسخگویی به کاربران
تحلیل و ارتقای کیفیت خدمات

حفاظت از اطلاعات
ما از روش‌های متعارف امنیتی برای محافظت از اطلاعات کاربران استفاده می‌کنیم و تلاش می‌کنیم از دسترسی غیرمجاز به داده‌ها جلوگیری شود.

اشتراک‌گذاری اطلاعات
اطلاعات شخصی کاربران بدون رضایت آنان در اختیار اشخاص یا سازمان‌های دیگر قرار نخواهد گرفت، مگر در مواردی که قانون الزام کرده باشد.

حقوق کاربران
کاربران می‌توانند در صورت نیاز درخواست اصلاح یا حذف اطلاعات حساب کاربری خود را از طریق بخش پشتیبانی ثبت کنند.

تماس با ما
در صورت وجود هرگونه سؤال، پیشنهاد یا درخواست مرتبط با حریم خصوصی و قوانین، می‌توانید از طریق بخش پشتیبانی گامینو با ما در ارتباط باشید.

آخرین به‌روزرسانی: خرداد ۱۴۰۵
گامینو | گامی نو در یادگیری 📚✨''', style: TextStyle(height: 1.9, fontWeight: FontWeight.w700, color: AppPalette.ink)),
            ),
          ],
        ),
      ),
    );
  }
}

class HomeStudentHeader extends StatelessWidget {
  const HomeStudentHeader({super.key, required this.user, required this.isGuest, required this.onProfileTap, required this.onSettingsTap});

  final AppUser user;
  final bool isGuest;
  final VoidCallback onProfileTap;
  final VoidCallback onSettingsTap;

  @override
  Widget build(BuildContext context) {
    final initial = user.name.trim().isEmpty ? '؟' : user.name.characters.first;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: onProfileTap,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              SizedBox(width: 74, height: 74, child: avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl)),
              Positioned(
                bottom: -2,
                right: -2,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppPalette.primary,
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: Colors.white, width: 2),
                  ),
                  child: Text('${user.level}', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerRight,
                child: Text(
                  isGuest ? 'سلام مهمان' : 'سلام ${user.name}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.ink),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        _HeaderIconButton(icon: Icons.settings_outlined, onTap: onSettingsTap),
        const SizedBox(width: 8),
        _HeaderIconButton(icon: Icons.calendar_month_outlined, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExamCountdownScreen(user: user)))),
        const SizedBox(width: 8),
        _HeaderIconButton(icon: Icons.notifications_none_rounded, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReminderCenterScreen(user: user)))),
      ],
    );
  }

  IconData _avatarIcon(String avatar) {
    if (avatar.contains('طلایی')) return Icons.face_retouching_natural;
    if (avatar.contains('نابغه')) return Icons.psychology_alt_outlined;
    return Icons.person;
  }
}

class _HeaderIconButton extends StatelessWidget {
  const _HeaderIconButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.06), blurRadius: 16, offset: const Offset(0, 8))],
        ),
        child: Icon(icon, color: AppPalette.ink, size: 24),
      ),
    );
  }
}

class HomeStatsStrip extends StatelessWidget {
  const HomeStatsStrip({super.key, required this.user, required this.onCardTap});
  final AppUser user;
  final VoidCallback onCardTap;

  @override
  Widget build(BuildContext context) {
    final cups = currentCups(user);
    final tier = leagueTierForCups(cups);
    return Row(
      children: [
        Expanded(child: _HomeAssetStatPill(label: '$cups', subLabel: 'کاپ', assetPath: tier.asset, isLeague: true)),
        const SizedBox(width: 12),
        Expanded(child: _HomeAssetStatPill(label: '${user.coins}', subLabel: 'کارت', assetPath: 'assets/gamino_card_home.png', isCard: true, onTap: onCardTap)),
      ],
    );
  }
}

class _HomeAssetStatPill extends StatelessWidget {
  const _HomeAssetStatPill({
    required this.label,
    required this.subLabel,
    required this.assetPath,
    this.showPlus = false,
    this.isLeague = false,
    this.isCard = false,
    this.onTap,
  });
  final String label;
  final String subLabel;
  final String assetPath;
  final bool showPlus;
  final bool isLeague;
  final bool isCard;
  final VoidCallback? onTap;

  Widget _asset(double size) => SizedBox(
        width: size,
        height: size,
        child: Image.asset(
          assetPath,
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => const Icon(Icons.circle_outlined, color: AppPalette.muted),
        ),
      );

  Widget _valueBlock() => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(label, maxLines: 1, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.ink)),
          ),
          const SizedBox(height: 1),
          Text(subLabel, maxLines: 1, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: AppPalette.muted, fontWeight: FontWeight.w700)),
        ],
      );

  @override
  Widget build(BuildContext context) {
    // Use physical left/centre/right zones so RTL cannot swap the wallet/league assets.
    // Card: [asset | value] with the full remaining width reserved for the balance.
    // League: [space | value | tier].
    final child = Container(
      constraints: const BoxConstraints(minHeight: 74),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.05), blurRadius: 18, offset: const Offset(0, 9))],
      ),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(
          children: [
            SizedBox(
              width: 44,
              child: Align(
                alignment: Alignment.centerLeft,
                child: isCard || showPlus ? _asset(42) : const SizedBox(width: 34, height: 34),
              ),
            ),
            Expanded(child: Center(child: Directionality(textDirection: TextDirection.rtl, child: _valueBlock()))),
            if (showPlus || isLeague)
              SizedBox(
                width: 44,
                child: Align(
                  alignment: Alignment.centerRight,
                  child: showPlus
                      ? Container(
                          width: 30,
                          height: 30,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.10), shape: BoxShape.circle),
                          child: const Icon(Icons.add_rounded, size: 21, color: AppPalette.primary),
                        )
                      : _asset(38),
                ),
              ),
          ],
        ),
      ),
    );
    if (onTap == null) return child;
    return Material(color: Colors.transparent, child: InkWell(borderRadius: BorderRadius.circular(22), onTap: onTap, child: child));
  }
}

class SmartCoachHomeCard extends StatelessWidget {
  const SmartCoachHomeCard({
    super.key,
    required this.user,
    required this.isGuest,
    required this.mistakesCount,
    required this.onOpenAi,
    required this.onOpenReview,
  });

  final AppUser user;
  final bool isGuest;
  final int mistakesCount;
  final VoidCallback onOpenAi;
  final VoidCallback onOpenReview;

  String get weakSubject {
    if (user.skills.isEmpty) return 'ریاضی';
    final entries = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    return entries.first.key;
  }

  @override
  Widget build(BuildContext context) {
    final nextLevelXp = user.level * 500;
    final remainingXp = max(0, nextLevelXp - currentCups(user));
    final plan = isGuest
        ? ['یک فصل گام‌به‌گام را ببین', 'بعد از ورود، کوییز و پروفایل فعال می‌شود', 'برای ذخیره پیشرفت ثبت‌نام کن']
        : ['۱۰ دقیقه مرور $weakSubject', '۵ سوال هدفمند از $weakSubject', mistakesCount > 0 ? 'مرور $mistakesCount اشتباه ذخیره‌شده' : 'یک کوییز کوتاه برای شروع'];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppPalette.primary.withOpacity(.07)),
        boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.06), blurRadius: 22, offset: const Offset(0, 12))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  gradient: AppPalette.successGradient,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.auto_awesome_rounded, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('پیشنهاد هوشمند امروز', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    const SizedBox(height: 4),
                    Text(
                      isGuest ? 'مسیر مهمان برای شروع سریع' : 'تمرکز امروز: $weakSubject | تا سطح بعدی: $remainingXp کاپ',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ...plan.map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.10), borderRadius: BorderRadius.circular(9)),
                      child: const Icon(Icons.check_rounded, size: 16, color: AppPalette.primary),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(item, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink, height: 1.5))),
                  ],
                ),
              )),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: isGuest ? null : onOpenAi,
                  icon: const Icon(Icons.psychology_rounded),
                  label: const Text('معلم AI'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: isGuest ? null : onOpenReview,
                  icon: const Icon(Icons.replay_rounded),
                  label: const Text('تمرین امروز'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}


class WeeklyLearningPlannerCard extends StatelessWidget {
  const WeeklyLearningPlannerCard({super.key, required this.user, required this.mistakesCount, required this.isGuest});

  final AppUser user;
  final int mistakesCount;
  final bool isGuest;

  String get weakSubject {
    if (user.skills.isEmpty) return 'ریاضی';
    final entries = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    return entries.first.key;
  }

  @override
  Widget build(BuildContext context) {
    final nextLevelXp = max(250, user.level * 500);
    final progress = (currentCups(user) / nextLevelXp).clamp(0.0, 1.0).toDouble();
    final remainingXp = max(0, nextLevelXp - currentCups(user));
    final plan = isGuest
        ? [
            ('امروز', 'یک فصل گام‌به‌گام را باز کن', Icons.menu_book_rounded),
            ('بعدی', 'ثبت‌نام کن تا کوییز و پروفایل فعال شود', Icons.login_rounded),
            ('هدف', 'پیشرفتت بعد از ورود ذخیره می‌شود', Icons.save_rounded),
          ]
        : [
            ('امروز', 'مرور $weakSubject و حل ۵ سوال', Icons.auto_stories_rounded),
            ('فردا', mistakesCount > 0 ? 'تمرین $mistakesCount اشتباه ذخیره‌شده' : 'یک کوییز زمان‌دار کوتاه', Icons.replay_rounded),
            ('این هفته', '$remainingXp کاپ تا سطح بعدی جمع کن', Icons.bolt_rounded),
          ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFFFFFFFF), Color(0xFFF4F7FF)],
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppPalette.primary.withOpacity(.08)),
        boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.055), blurRadius: 22, offset: const Offset(0, 12))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(gradient: AppPalette.heroGradient, borderRadius: BorderRadius.circular(17)),
                child: const Icon(Icons.route_rounded, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('مسیر یادگیری هفته', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    const SizedBox(height: 4),
                    Text('برنامه کوتاه بر اساس سطح، کاپ و اشتباهات', style: TextStyle(color: AppPalette.muted.withOpacity(.95), fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              Chip(label: Text('${(progress * 100).round()}٪')),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: LinearProgressIndicator(value: progress, minHeight: 9),
          ),
          const SizedBox(height: 14),
          ...plan.map((item) => Container(
                margin: const EdgeInsets.only(bottom: 9),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppPalette.primary.withOpacity(.06))),
                child: Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.09), borderRadius: BorderRadius.circular(13)),
                      child: Icon(item.$3, color: AppPalette.primary, size: 19),
                    ),
                    const SizedBox(width: 10),
                    Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.primary)),
                    const SizedBox(width: 10),
                    Expanded(child: Text(item.$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink))),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

class ExamReadinessMiniCard extends StatelessWidget {
  const ExamReadinessMiniCard({super.key, required this.user, required this.mistakesCount});

  final AppUser user;
  final int mistakesCount;

  @override
  Widget build(BuildContext context) {
    final readiness = (42 + user.completedChapters * 4 + user.quizHistory.length * 3 - mistakesCount * 2).clamp(0, 96);
    final weak = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    final weakSubject = weak.isEmpty ? 'ریاضی' : weak.first.key;
    final status = readiness >= 75 ? 'آماده خوب' : readiness >= 55 ? 'نیاز به مرور' : 'شروع تمرین جدی';

    return InkWell(
      borderRadius: BorderRadius.circular(30),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExamSimulatorScreen(user: user))),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [BoxShadow(color: AppPalette.secondary.withOpacity(.055), blurRadius: 22, offset: const Offset(0, 12))],
        ),
        child: Row(
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 78,
                  height: 78,
                  child: CircularProgressIndicator(value: readiness / 100, strokeWidth: 8, backgroundColor: const Color(0xFFEFF2FF)),
                ),
                Text('$readiness٪', style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
              ],
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('آمادگی امتحان', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                  const SizedBox(height: 6),
                  Text('$status | تمرکز پیشنهادی: $weakSubject', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  const Text('برای شبیه‌ساز امتحان بزن', style: TextStyle(color: AppPalette.primary, fontWeight: FontWeight.w900)),
                ],
              ),
            ),
            const Icon(Icons.more_horiz_rounded, color: AppPalette.primary),
          ],
        ),
      ),
    );
  }
}


class FocusSessionMiniCard extends StatelessWidget {
  const FocusSessionMiniCard({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final weak = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    final focusSubject = weak.isEmpty ? 'ریاضی' : weak.first.key;
    final minutes = user.level >= 3 ? 30 : 25;

    return InkWell(
      borderRadius: BorderRadius.circular(30),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FocusTimerScreen(user: user))),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: const LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [Color(0xFF0F172A), Color(0xFF3D5AFE), Color(0xFF00B8D9)],
          ),
          boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.18), blurRadius: 22, offset: const Offset(0, 12))],
        ),
        child: Row(
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.16),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white.withOpacity(.18)),
              ),
              child: const Icon(Icons.timer_rounded, color: Colors.white, size: 38),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('جلسه تمرکز امروز', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  Text(
                    '$minutes دقیقه مطالعه هدفمند روی $focusSubject',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: Colors.white.withOpacity(.82), fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(999)),
                    child: const Text('شروع تمرکز', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12)),
                  ),
                ],
              ),
            ),
            const Icon(Icons.more_horiz_rounded, color: Colors.white, size: 30),
          ],
        ),
      ),
    );
  }
}

class StabilityUxCard extends StatelessWidget {
  const StabilityUxCard({super.key, required this.saveStatus, required this.mistakesCount, required this.isGuest});

  final String saveStatus;
  final int mistakesCount;
  final bool isGuest;

  @override
  Widget build(BuildContext context) {
    final checks = [
      ('منوی پایین تست شد', Icons.touch_app_rounded),
      ('همگام‌سازی آنلاین فعال است', Icons.save_rounded),
      (isGuest ? 'حالت مهمان فقط گام‌به‌گام دارد' : 'پروفایل و مسیرها آماده‌اند', Icons.verified_rounded),
    ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppPalette.primary.withOpacity(.07)),
        boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.05), blurRadius: 20, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(gradient: AppPalette.actionGradient, borderRadius: BorderRadius.circular(16)),
                child: const Icon(Icons.rule_rounded, color: Colors.white),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text('وضعیت همگام‌سازی آنلاین', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.ink)),
              ),
              Chip(label: Text('$mistakesCount خطا')),
            ],
          ),
          const SizedBox(height: 12),
          Text(saveStatus, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700, height: 1.5)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: checks.map((item) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: BoxDecoration(color: AppPalette.canvas, borderRadius: BorderRadius.circular(999)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(item.$2, color: AppPalette.primary, size: 16),
                  const SizedBox(width: 6),
                  Text(item.$1, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppPalette.ink)),
                ],
              ),
            )).toList(),
          ),
        ],
      ),
    );
  }
}


class FocusTimerScreen extends StatefulWidget {
  const FocusTimerScreen({super.key, required this.user});

  final AppUser user;

  @override
  State<FocusTimerScreen> createState() => _FocusTimerScreenState();
}

class _FocusTimerScreenState extends State<FocusTimerScreen> {
  Timer? timer;
  int selectedMinutes = 25;
  late int remainingSeconds;
  bool running = false;

  @override
  void initState() {
    super.initState();
    selectedMinutes = widget.user.level >= 3 ? 30 : 25;
    remainingSeconds = selectedMinutes * 60;
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void startOrPause() {
    if (running) {
      timer?.cancel();
      setState(() => running = false);
      return;
    }
    setState(() => running = true);
    timer = Timer.periodic(const Duration(seconds: 1), (tick) {
      if (!mounted) return;
      if (remainingSeconds <= 1) {
        tick.cancel();
        setState(() {
          remainingSeconds = 0;
          running = false;
        });
      } else {
        setState(() => remainingSeconds -= 1);
      }
    });
  }

  void resetTimer(int minutes) {
    timer?.cancel();
    setState(() {
      selectedMinutes = minutes;
      remainingSeconds = minutes * 60;
      running = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final percent = 1 - (remainingSeconds / (selectedMinutes * 60));
    final minutes = remainingSeconds ~/ 60;
    final seconds = remainingSeconds % 60;
    final weak = widget.user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    final focusSubject = weak.isEmpty ? 'ریاضی' : weak.first.key;

    return Scaffold(
      backgroundColor: AppPalette.canvas,
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('جلسه تمرکز')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(32),
              gradient: AppPalette.heroGradient,
              boxShadow: [BoxShadow(color: AppPalette.secondary.withOpacity(.20), blurRadius: 24, offset: const Offset(0, 14))],
            ),
            child: Column(
              children: [
                const Text('تمرکز بدون حواس‌پرتی', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text('پیشنهاد امروز: مرور $focusSubject', style: TextStyle(color: Colors.white.withOpacity(.84), fontWeight: FontWeight.w800)),
                const SizedBox(height: 24),
                SizedBox(
                  width: 190,
                  height: 190,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 176,
                        height: 176,
                        child: CircularProgressIndicator(
                          value: percent.clamp(0.0, 1.0).toDouble(),
                          strokeWidth: 12,
                          backgroundColor: Colors.white.withOpacity(.22),
                          valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text("${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}", style: const TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 4),
                          Text(running ? 'در حال تمرکز' : 'آماده شروع', style: TextStyle(color: Colors.white.withOpacity(.82), fontWeight: FontWeight.w800)),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: startOrPause,
                        icon: Icon(running ? Icons.pause_rounded : Icons.bolt_rounded),
                        label: Text(running ? 'توقف' : 'شروع'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    OutlinedButton.icon(
                      onPressed: () => resetTimer(selectedMinutes),
                      icon: const Icon(Icons.restart_alt_rounded),
                      label: const Text('ریست'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('انتخاب زمان', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [10, 15, 25, 30].map((minute) {
                    final selected = selectedMinutes == minute;
                    return ChoiceChip(
                      selected: selected,
                      label: Text('$minute دقیقه'),
                      onSelected: (_) => resetTimer(minute),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('قانون جلسه تمرکز', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                SizedBox(height: 10),
                Text('۱. فقط یک درس را انتخاب کن.\n۲. اعلان‌ها و پیام‌ها را نبین.\n۳. بعد از پایان، یک کوییز کوتاه بزن یا یک اشتباه را مرور کن.', style: TextStyle(height: 1.8, color: AppPalette.muted, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
        ),
      ),
    );
  }
}

class TodayMissionsSummary extends StatelessWidget {
  const TodayMissionsSummary({super.key, required this.user, required this.isGuest});

  final AppUser user;
  final bool isGuest;

  @override
  Widget build(BuildContext context) {
    final missions = [
      ('یک کوییز کامل را حل کن', '+20 کاپ', true),
      ('یک اشتباه را مرور کن', '+10 کاپ', user.dailyActivity > 0),
      ('۱۰ دقیقه مطالعه کن', '+15 کاپ', false),
    ];

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.05), blurRadius: 18, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(child: Text('ماموریت‌های امروز', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: isGuest ? AppPalette.muted : AppPalette.ink))),
              const Icon(Icons.flag_rounded, color: AppPalette.coral, size: 22),
            ],
          ),
          const SizedBox(height: 12),
          ...missions.map((mission) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Row(
                children: [
                  Icon(mission.$3 && !isGuest ? Icons.check_circle : Icons.radio_button_unchecked, size: 19, color: mission.$3 && !isGuest ? AppPalette.mint : AppPalette.muted.withOpacity(.6)),
                  const SizedBox(width: 7),
                  Expanded(child: Text(mission.$1, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppPalette.ink))),
                ],
              ),
            );
          }),
          const SizedBox(height: 6),
          Text(isGuest ? 'بعد از ورود فعال می‌شود' : 'فعالیت امروز: ${user.dailyActivity}', style: const TextStyle(fontSize: 11.5, color: AppPalette.muted, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class OverallProgressSummary extends StatelessWidget {
  const OverallProgressSummary({super.key, required this.user, required this.mistakesCount});

  final AppUser user;
  final int mistakesCount;

  @override
  Widget build(BuildContext context) {
    final progress = (0.18 + ((user.completedChapters + user.quizHistory.length) / 38)).clamp(0.0, 1.0).toDouble();
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.05), blurRadius: 18, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Expanded(child: Text('پیشرفت کلی', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppPalette.ink))),
              Icon(Icons.show_chart_rounded, color: AppPalette.secondary, size: 22),
            ],
          ),
          const SizedBox(height: 12),
          Center(
            child: SizedBox(
              width: 86,
              height: 86,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 82,
                    height: 82,
                    child: CircularProgressIndicator(
                      value: progress,
                      strokeWidth: 8,
                      backgroundColor: AppPalette.primary.withOpacity(.08),
                      valueColor: const AlwaysStoppedAnimation<Color>(AppPalette.primary),
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('${(progress * 100).round()}%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                      const Text('هفتگی', style: TextStyle(fontSize: 10, color: AppPalette.muted, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          ProgressMetricLine(value: '${user.completedChapters}', label: 'درسنامه کامل', icon: Icons.menu_book_rounded, color: AppPalette.mint),
          ProgressMetricLine(value: '${user.dailyActivity + user.quizHistory.length}', label: 'روز فعال', icon: Icons.local_fire_department_rounded, color: AppPalette.amber),
          ProgressMetricLine(value: '${user.quizHistory.length}', label: 'کوییز حل‌شده', icon: Icons.edit_square, color: AppPalette.secondary),
        ],
      ),
    );
  }
}

class ProgressMetricLine extends StatelessWidget {
  const ProgressMetricLine({super.key, required this.value, required this.label, required this.icon, required this.color});

  final String value;
  final String label;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: color, size: 16),
          ),
          const SizedBox(width: 7),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
          const SizedBox(width: 5),
          Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, color: AppPalette.muted, fontWeight: FontWeight.w700))),
        ],
      ),
    );
  }
}

class LocalSaveBanner extends StatelessWidget {
  const LocalSaveBanner({super.key, required this.saveStatus, required this.user, required this.mistakesCount});

  final String saveStatus;
  final AppUser user;
  final int mistakesCount;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppPalette.mint.withOpacity(.18)),
        boxShadow: [BoxShadow(color: AppPalette.mint.withOpacity(.08), blurRadius: 18, offset: const Offset(0, 10))],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: AppPalette.successGradient,
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Icon(Icons.cloud_done_outlined, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('همگام‌سازی آنلاین فعال است', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: AppPalette.ink)),
                const SizedBox(height: 4),
                Text(saveStatus, style: const TextStyle(color: AppPalette.muted, height: 1.5)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    Chip(label: Text('${user.quizHistory.length} آزمون ذخیره‌شده')),
                    Chip(label: Text('$mistakesCount اشتباه ذخیره‌شده')),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class LocalStorageScreen extends StatelessWidget {
  const LocalStorageScreen({super.key, required this.user, required this.mistakesCount, required this.saveStatus});

  final AppUser user;
  final int mistakesCount;
  final String saveStatus;

  @override
  Widget build(BuildContext context) {
    final history = user.quizHistory;
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('ذخیره و تاریخچه')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'ذخیره واقعی داخل گوشی',
            subtitle: 'در این نسخه کاپ، Level، کارت، برنامه مطالعه، خریدهای فروشگاه، اتاق فعال، اشتباهات و تاریخچه آزمون‌ها داخل حافظه گوشی ذخیره می‌شوند.',
            icon: Icons.save_alt_rounded,
          ),
          const SizedBox(height: 14),
          SectionCard(
            title: 'وضعیت ذخیره',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(saveStatus, style: const TextStyle(fontWeight: FontWeight.w800, height: 1.8)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: StatCard(title: 'آزمون‌ها', value: '${history.length}', icon: Icons.history_rounded)),
                    const SizedBox(width: 10),
                    Expanded(child: StatCard(title: 'اشتباهات', value: '$mistakesCount', icon: Icons.error_outline)),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: StatCard(title: 'کاپ', value: '${currentCups(user)}', icon: Icons.bolt)),
                    const SizedBox(width: 10),
                    Expanded(child: StatCard(title: 'کارت', value: '${user.coins}', icon: Icons.style_outlined)),
                  ],
                ),
              ],
            ),
          ),
          SectionCard(
            title: 'آخرین آزمون‌های ذخیره‌شده',
            child: history.isEmpty
                ? const Text('هنوز آزمونی ثبت نشده. یک کوییز بده تا نتیجه اینجا بماند و بعد از بستن اپ هم حذف نشود.', style: TextStyle(height: 1.7, color: AppPalette.muted))
                : Column(
                    children: history.take(10).map((item) => QuizHistoryTile(item: item)).toList(),
                  ),
          ),
          const InfoBox(
            title: 'وضعیت همگام‌سازی آنلاین',
            body: 'همگام‌سازی حساب و محتوای آموزشی آنلاین فعال است و داده‌های اصلی از سرور گامینو دریافت و ذخیره می‌شوند.',
            icon: Icons.upgrade_outlined,
          ),
        ],
      ),
    );
  }
}

class QuizHistoryTile extends StatelessWidget {
  const QuizHistoryTile({super.key, required this.item});

  final QuizHistoryEntry item;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppPalette.canvas,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppPalette.primary.withOpacity(.08)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: item.percent >= 70 ? AppPalette.mint.withOpacity(.15) : AppPalette.amber.withOpacity(.18),
            child: Icon(item.percent >= 70 ? Icons.verified_outlined : Icons.auto_fix_high_outlined),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${item.title} - ${item.subject}', style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text('درست: ${item.correctAnswers}/${item.totalQuestions} | درصد: ${item.percent}% | +${item.xpEarned} کاپ | +${item.coinsEarned} کارت', style: const TextStyle(color: AppPalette.muted, height: 1.5)),
                Text(_formatDate(item.createdAt), style: const TextStyle(color: AppPalette.muted, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    String two(int value) => value.toString().padLeft(2, '0');
    return '${formatJalaliDate(date)} - ${two(date.hour)}:${two(date.minute)}';
  }
}

class StepByStepScreen extends StatefulWidget {
  const StepByStepScreen({
    super.key,
    required this.user,
    required this.isGuest,
    required this.onCompleteChapter,
    required this.onStudyTick,
    required this.books,
  });

  final AppUser user;
  final bool isGuest;
  final void Function(Chapter chapter) onCompleteChapter;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;
  final List<LearningBook> books;

  @override
  State<StepByStepScreen> createState() => _StepByStepScreenState();
}

class _StepByStepScreenState extends State<StepByStepScreen> {
  bool _refreshing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _refresh());
  }

  Future<void> _refresh() async {
    if (_refreshing) return;
    if (mounted) setState(() => _refreshing = true);
    await gaminoAppKey.currentState?.refreshLearningContent();
    if (mounted) setState(() => _refreshing = false);
  }

  @override
  Widget build(BuildContext context) {
    final pageBooks = List<LearningBook>.of(widget.books)..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    final gradeText = gradePathText(widget.user.grade, widget.user.educationTrack);
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          children: [
            PageTitle(title: 'گام‌به‌گام', subtitle: '$gradeText — کتاب‌ها و درس‌ها', icon: Icons.menu_book_rounded),
            if (!widget.user.hasActiveNoAds) ...[
              const SizedBox(height: 12),
              const GaminoInlineBanner(slot: 'step_by_step'),
            ],
            if (_refreshing) ...[
              const SizedBox(height: 8),
              const LinearProgressIndicator(minHeight: 3),
            ],
            const SizedBox(height: 14),
            Text('کتاب‌های $gradeText', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AppPalette.ink)),
            const SizedBox(height: 10),
            if (pageBooks.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      const Icon(Icons.cloud_off_rounded, size: 42, color: AppPalette.primary),
                      const SizedBox(height: 12),
                      const Text('برای دریافت این محتوا، لطفاً اتصال اینترنت خود را روشن و بررسی کنید.', style: TextStyle(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 6),
                      const Text('اگر این محتوا قبلاً دانلود شده باشد، در حالت آفلاین هم باز می‌شود.', textAlign: TextAlign.center, style: TextStyle(color: AppPalette.muted, height: 1.7)),
                      const SizedBox(height: 12),
                      FilledButton.icon(onPressed: _refresh, icon: const Icon(Icons.refresh_rounded), label: const Text('تلاش دوباره')),
                    ],
                  ),
                ),
              )
            else
              ...pageBooks.map((book) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                    leading: _BookCover(url: book.coverUrl, documentId: 'book_cover_${book.id}', version: book.updatedAt, size: 58),
                    title: Text(book.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                    subtitle: Text('${book.lessons.length} درس${book.hasPdf ? ' • PDF کامل' : ''}', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookDetailScreen(book: book, onStudyTick: widget.onStudyTick, adsDisabled: widget.user.hasActiveNoAds))),
                  ),
                ),
              )),
          ],
        ),
      ),
    );
  }
}

class _BookCover extends StatefulWidget {
  const _BookCover({required this.url, required this.documentId, required this.version, this.size = 86});
  final String url;
  final String documentId;
  final String version;
  final double size;

  @override
  State<_BookCover> createState() => _BookCoverState();
}

class _BookCoverState extends State<_BookCover> {
  File? _file;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant _BookCover oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.url != widget.url || oldWidget.version != widget.version || oldWidget.documentId != widget.documentId) {
      _file = null;
      _load();
    }
  }

  Future<void> _load() async {
    if (_loading || widget.url.trim().isEmpty) return;
    _loading = true;
    try {
      final file = await MediaCacheStore.load(
        documentId: widget.documentId,
        sourceUrl: widget.url,
        version: widget.version,
        fallbackExtension: 'webp',
      );
      if (mounted) setState(() => _file = file);
    } catch (_) {
      // Keep the lightweight placeholder if the image is unavailable.
    } finally {
      _loading = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final placeholder = Container(
      width: widget.size,
      height: widget.size * 1.24,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: AppPalette.actionGradient,
      ),
      child: Icon(Icons.menu_book_rounded, size: widget.size * .42, color: Colors.white),
    );
    final file = _file;
    if (widget.url.trim().isEmpty || file == null) return placeholder;
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Image.file(
        file,
        width: widget.size,
        height: widget.size * 1.24,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => placeholder,
      ),
    );
  }
}

enum LessonContentChoice { stepByStep, sampleQuestions }

class BookDetailScreen extends StatelessWidget {
  const BookDetailScreen({super.key, required this.book, required this.onStudyTick, required this.adsDisabled});
  final LearningBook book;
  final bool adsDisabled;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;

  Future<void> _showLessonChoices(BuildContext context, LearningLesson lesson) async {
    final choice = await showDialog<LessonContentChoice>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
        title: Text(lesson.title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _LessonChoiceTile(
              icon: Icons.menu_book_outlined,
              title: 'گام به گام',
              subtitle: 'PDF گام‌به‌گام؛ پس از اولین دانلود آفلاین هم باز می‌شود',
              onTap: () => Navigator.pop(dialogContext, LessonContentChoice.stepByStep),
            ),
            _LessonChoiceTile(
              icon: Icons.quiz_outlined,
              title: 'نمونه سوالات',
              subtitle: lesson.hasQuestionContent
                  ? '${lesson.questions.length} تستی • ${lesson.descriptiveQuestions.length} تشریحی'
                  : 'هنوز از پنل ثبت نشده است',
              onTap: () => Navigator.pop(dialogContext, LessonContentChoice.sampleQuestions),
            ),
          ],
        ),
      ),
    );
    if (!context.mounted || choice == null) return;
    await LastLearningStore.save(book, lesson, choice);
    if (!context.mounted) return;
    // Open learning content first. Advertising is requested only after the
    // route transition starts, so the student never waits for ad inventory.
    if (choice == LessonContentChoice.sampleQuestions) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => LessonQuestionsScreen(book: book, lesson: lesson, onStudyTick: onStudyTick, adsDisabled: adsDisabled)));
      unawaited(GaminoAdiveryService.showLessonInterstitial(adsDisabled: adsDisabled));
      return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderScreen(
      title: 'گام به گام — ${lesson.title}',
      documentId: 'step_${lesson.id}_pdf',
      pdfUrl: lesson.stepPdfUrl,
      version: lesson.stepPdfUrl,
      subject: book.title,
      chapter: lesson.title,
      onStudyTick: onStudyTick,
    )));
    unawaited(GaminoAdiveryService.showLessonInterstitial(adsDisabled: adsDisabled));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text(book.title)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _BookCover(url: book.coverUrl, documentId: 'book_cover_${book.id}', version: book.updatedAt, size: 92),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(book.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 7),
                        Text(gradePathText(book.grade, book.track), style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
                        if (book.hasPdf) ...[
                          const SizedBox(height: 12),
                          BookPdfDownloadButton(book: book, onStudyTick: onStudyTick),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text('درس‌های کتاب', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          if (book.lessons.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('هنوز درسی برای این کتاب ثبت نشده است.', textAlign: TextAlign.center, style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700))))
          else
            ...book.lessons.asMap().entries.map((entry) {
              final lesson = entry.value;
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: Container(
                    width: 42,
                    height: 42,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.10), borderRadius: BorderRadius.circular(14)),
                    child: Text('${entry.key + 1}', style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.primary)),
                  ),
                  title: Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                  subtitle: const Text('گام به گام و نمونه سوالات', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
                  onTap: () => _showLessonChoices(context, lesson),
                ),
              );
            }),
        ],
      ),
    );
  }
}

class BookPdfDownloadButton extends StatefulWidget {
  const BookPdfDownloadButton({super.key, required this.book, required this.onStudyTick});
  final LearningBook book;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;

  @override
  State<BookPdfDownloadButton> createState() => _BookPdfDownloadButtonState();
}

class _BookPdfDownloadButtonState extends State<BookPdfDownloadButton> {
  bool _loading = false;
  bool _cached = false;
  int _progress = 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _checkCache();
  }

  Future<void> _checkCache() async {
    final documentId = 'book_${widget.book.id}_pdf';
    final cached = await PdfCacheStore.hasValidCache(
      documentId: documentId,
      sourceUrl: widget.book.pdfUrl,
      version: widget.book.pdfUrl,
    );
    final partial = cached ? 0 : await PdfCacheStore.partialProgress(documentId: documentId);
    if (!mounted) return;
    setState(() {
      _cached = cached;
      _progress = partial;
      if (!cached && partial > 0) _error = 'دانلود قبلی نیمه‌کاره است؛ برای ادامه دکمه زیر را بزن.';
    });
  }

  Future<void> _download() async {
    if (_loading) return;
    setState(() { _loading = true; _error = null; });
    try {
      await PdfCacheStore.load(
        documentId: 'book_${widget.book.id}_pdf',
        sourceUrl: widget.book.pdfUrl,
        version: widget.book.pdfUrl,
        onProgress: (value) { if (mounted) setState(() => _progress = value); },
      );
      if (!mounted) return;
      setState(() { _loading = false; _cached = true; _progress = 100; });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کتاب دانلود شد و برای استفاده آفلاین روی گوشی ذخیره شد.')));
    } catch (error) {
      if (!mounted) return;
      final saved = await PdfCacheStore.partialProgress(documentId: 'book_${widget.book.id}_pdf');
      setState(() {
        _loading = false;
        _progress = saved;
        _error = error is GaminoApiException ? error.message : 'لطفاً اتصال اینترنت خود را روشن و بررسی کنید؛ سپس تلاش دوباره را بزنید.';
      });
    }
  }

  void _open() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderScreen(
      title: widget.book.title,
      documentId: 'book_${widget.book.id}_pdf',
      pdfUrl: widget.book.pdfUrl,
      version: widget.book.pdfUrl,
      subject: widget.book.title,
      chapter: 'کتاب کامل',
      onStudyTick: widget.onStudyTick,
    )));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          LinearProgressIndicator(value: _progress > 0 ? _progress / 100 : null, minHeight: 7),
          const SizedBox(height: 7),
          Text('در حال دانلود... $_progress٪', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted)),
        ],
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        FilledButton.icon(
          onPressed: _cached ? _open : _download,
          icon: Icon(_cached ? Icons.picture_as_pdf_rounded : _error == null ? Icons.download_rounded : Icons.refresh_rounded),
          label: Text(_cached ? 'مشاهده کتاب' : _error == null ? 'دانلود کتاب' : 'تلاش دوباره'),
        ),
        if (_error != null) ...[
          const SizedBox(height: 6),
          Text(_error!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppPalette.coral)),
        ],
      ],
    );
  }
}

class _LessonChoiceTile extends StatelessWidget {
  const _LessonChoiceTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.10), borderRadius: BorderRadius.circular(14)),
        child: Icon(icon, color: AppPalette.primary),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
      subtitle: Text(subtitle, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700, fontSize: 12)),
      onTap: onTap,
    );
  }
}

class LessonContentScreen extends StatelessWidget {
  const LessonContentScreen({
    super.key,
    required this.title,
    required this.emptyMessage,
    required this.text,
    required this.imageUrl,
    required this.pdfUrl,
    required this.version,
    required this.documentIdPrefix,
    required this.subject,
    required this.chapter,
    required this.onStudyTick,
  });

  final String title;
  final String emptyMessage;
  final String text;
  final String imageUrl;
  final String pdfUrl;
  final String version;
  final String documentIdPrefix;
  final String subject;
  final String chapter;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;

  @override
  Widget build(BuildContext context) {
    final hasText = text.trim().isNotEmpty;
    final hasImage = imageUrl.trim().isNotEmpty;
    final hasPdf = pdfUrl.trim().isNotEmpty;
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text(title)),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (!hasText && !hasImage && !hasPdf)
                  Card(child: Padding(padding: const EdgeInsets.all(18), child: Text(emptyMessage, textAlign: TextAlign.center, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800, height: 1.7))))
                else ...[
                  if (hasText)
                    Card(child: Padding(padding: const EdgeInsets.all(18), child: Text(text, textAlign: TextAlign.right, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, height: 1.9)))),
                  if (hasImage) ...[
                    const SizedBox(height: 12),
                    CachedMediaImage(url: imageUrl, version: version, documentId: '${documentIdPrefix}_image'),
                  ],
                  if (hasPdf) ...[
                    const SizedBox(height: 12),
                    Card(
                      child: ListTile(
                        leading: const Icon(Icons.picture_as_pdf_outlined, color: AppPalette.primary),
                        title: const Text('نمایش PDF داخل اپ', style: TextStyle(fontWeight: FontWeight.w900)),
                        subtitle: const Text('فایل بعد از اولین نمایش در کش گوشی ذخیره می‌شود.', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
                        trailing: const Icon(Icons.more_horiz_rounded),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderScreen(
                          title: title,
                          documentId: '${documentIdPrefix}_pdf',
                          pdfUrl: pdfUrl,
                          version: version,
                          subject: subject,
                          chapter: chapter,
                          onStudyTick: onStudyTick,
                        ))),
                      ),
                    ),
                  ],
                ],
              ],
            ),
          ),
          const GaminoInlineBanner(slot: 'lesson_study_bottom'),
        ],
      ),
    );
  }
}

class LessonQuestionsScreen extends StatefulWidget {
  const LessonQuestionsScreen({super.key, required this.book, required this.lesson, required this.onStudyTick, required this.adsDisabled});
  final LearningBook book;
  final LearningLesson lesson;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;
  final bool adsDisabled;

  @override
  State<LessonQuestionsScreen> createState() => _LessonQuestionsScreenState();
}

class _LessonQuestionsScreenState extends State<LessonQuestionsScreen> with WidgetsBindingObserver {
  DateTime? _activeSince;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _activeSince = DateTime.now();
    _timer = Timer.periodic(const Duration(seconds: 45), (_) => unawaited(_flushStudyTime()));
  }

  Future<void> _flushStudyTime() async {
    final since = _activeSince;
    if (since == null) return;
    final seconds = DateTime.now().difference(since).inSeconds;
    if (seconds < 5) return;
    _activeSince = DateTime.now();
    await widget.onStudyTick(widget.book.title, widget.lesson.title, seconds.clamp(1, 60).toInt());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _activeSince = DateTime.now();
    } else if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      unawaited(_flushStudyTime());
      _activeSince = null;
    }
  }

  @override
  void dispose() {
    unawaited(_flushStudyTime());
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lesson = widget.lesson;
    final book = widget.book;
    final hasImage = lesson.questionImageUrl.trim().isNotEmpty;
    final hasPdf = lesson.questionPdfUrl.trim().isNotEmpty;
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text('نمونه سوالات — ${lesson.title}')),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (lesson.questions.isEmpty && lesson.descriptiveQuestions.isEmpty && !hasImage && !hasPdf)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(18),
                      child: Text(
                        'نمونه سوالات این درس هنوز در پنل مدیریت ثبت نشده است.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800, height: 1.7),
                      ),
                    ),
                  )
                else ...[
                  ...lesson.questions.map((q) => Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(q.text, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5, height: 1.7)),
                              const SizedBox(height: 12),
                              ...List.generate(q.options.length, (index) {
                                final isCorrect = index == q.correctIndex;
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                                    decoration: BoxDecoration(
                                      color: isCorrect ? const Color(0xFFE8F8EF) : const Color(0xFFF6F7FC),
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(color: isCorrect ? const Color(0xFF22A06B) : const Color(0xFFE7EAF8)),
                                    ),
                                    child: Row(
                                      children: [
                                        Icon(
                                          isCorrect ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                                          color: isCorrect ? const Color(0xFF22A06B) : AppPalette.muted,
                                          size: 21,
                                        ),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Text(
                                            q.options[index],
                                            style: TextStyle(
                                              fontWeight: FontWeight.w800,
                                              color: isCorrect ? const Color(0xFF167A52) : AppPalette.ink,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              }),
                              if (q.explanation.trim().isNotEmpty) ...[
                                const SizedBox(height: 6),
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(color: const Color(0xFFF0FAF5), borderRadius: BorderRadius.circular(14)),
                                  child: Text('توضیح: ${q.explanation}', style: const TextStyle(color: Color(0xFF167A52), fontWeight: FontWeight.w700, height: 1.7)),
                                ),
                              ],
                            ],
                          ),
                        ),
                      )),
                  if (lesson.descriptiveQuestions.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    const Text('سوالات تشریحی', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                    const SizedBox(height: 10),
                    ...lesson.descriptiveQuestions.asMap().entries.map((entry) {
                      final index = entry.key + 1;
                      final item = entry.value;
                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text('سوال $index', style: const TextStyle(color: AppPalette.primary, fontWeight: FontWeight.w900, fontSize: 13)),
                              const SizedBox(height: 6),
                              Text(item.question, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5, height: 1.8)),
                              if (item.imageUrl.trim().isNotEmpty) ...[
                                const SizedBox(height: 12),
                                CachedMediaImage(
                                  url: item.imageUrl,
                                  version: lesson.updatedAt,
                                  documentId: 'descriptive_${lesson.id}_${item.id}',
                                ),
                              ],
                              const SizedBox(height: 12),
                              Container(
                                padding: const EdgeInsets.all(13),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF4F7FF),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: const Color(0xFFE2E7FA)),
                                ),
                                child: Text('پاسخ: ${item.answer}', style: const TextStyle(fontWeight: FontWeight.w800, height: 1.8, color: AppPalette.ink)),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  ],
                  if (hasImage) ...[
                    const SizedBox(height: 8),
                    const Text('تصویر نمونه سوالات', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                    const SizedBox(height: 8),
                    CachedMediaImage(url: lesson.questionImageUrl, version: lesson.updatedAt, documentId: 'question_image_${lesson.id}'),
                  ],
                  if (hasPdf) ...[
                    const SizedBox(height: 14),
                    FilledButton.icon(
                      onPressed: () async {
                        await _flushStudyTime();
                        _activeSince = null;
                        if (!context.mounted) return;
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => PdfReaderScreen(
                              title: 'نمونه سوالات — ${lesson.title}',
                              documentId: 'questions_pdf_${lesson.id}',
                              pdfUrl: lesson.questionPdfUrl,
                              version: lesson.updatedAt,
                              subject: book.title,
                              chapter: lesson.title,
                              onStudyTick: widget.onStudyTick,
                            ),
                          ),
                        );
                        if (mounted) _activeSince = DateTime.now();
                      },
                      icon: const Icon(Icons.picture_as_pdf_rounded),
                      label: const Text('مشاهده PDF نمونه سوالات'),
                    ),
                  ],
                ],
              ],
            ),
          ),
          if (!widget.adsDisabled) const GaminoInlineBanner(slot: 'questions_study_bottom'),
        ],
      ),
    );
  }
}

class MediaCacheStore {
  static final Map<String, Future<File>> _inflight = <String, Future<File>>{};
  // Central progress registry: the download belongs to the document, not to a
  // particular ListView/PDF widget. A newly mounted widget subscribes to the
  // already-running task and immediately receives the current percentage.
  static final Map<String, ValueNotifier<int>> _progress = <String, ValueNotifier<int>>{};

  static ValueNotifier<int> _progressForKey(String key) => _progress.putIfAbsent(key, () => ValueNotifier<int>(0));


  static String _safeFileName(String id) => base64UrlEncode(utf8.encode(id)).replaceAll('=', '');

  static String _extensionFromUrl(String url, String fallback) {
    final path = Uri.tryParse(url)?.path.toLowerCase() ?? '';
    final ext = path.split('.').last;
    if (['jpg', 'jpeg', 'png', 'webp', 'pdf'].contains(ext)) return ext;
    return fallback;
  }

  static String _resolveUrl(String sourceUrl) {
    final raw = sourceUrl.trim();
    if (raw.startsWith('http://') || raw.startsWith('https://')) return raw;
    final api = Uri.parse(kGaminoApiBaseUrl);
    if (raw.startsWith('/')) return '${api.scheme}://${api.authority}$raw';
    final basePath = api.path.endsWith('/') ? api.path : '${api.path}/';
    return api.replace(path: '$basePath$raw').toString();
  }

  static Future<Directory> _cacheDir() async {
    final root = await getApplicationDocumentsDirectory();
    final dir = Directory('${root.path}${Platform.pathSeparator}gamino_media_cache');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static Future<Map<String, dynamic>> _readMeta(SharedPreferences prefs, String key) async {
    final raw = prefs.getString(key);
    if (raw == null || raw.isEmpty) return <String, dynamic>{};
    try {
      final decoded = jsonDecode(raw);
      return decoded is Map ? Map<String, dynamic>.from(decoded) : <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  static Future<bool> hasValidCache({required String documentId, required String sourceUrl, required String version, String fallbackExtension = 'pdf'}) async {
    final prefs = await SharedPreferences.getInstance();
    final dir = await _cacheDir();
    final resolved = _resolveUrl(sourceUrl);
    final ext = _extensionFromUrl(resolved, fallbackExtension);
    final file = File('${dir.path}${Platform.pathSeparator}${_safeFileName(documentId)}.$ext');
    final meta = await _readMeta(prefs, 'gamino_media_cache_$documentId');
    return meta['sourceUrl'] == resolved && meta['version'] == version && await file.exists() && await file.length() > 0;
  }

  static Future<int> partialProgress({required String documentId}) async {
    final prefs = await SharedPreferences.getInstance();
    final meta = await _readMeta(prefs, 'gamino_media_partial_$documentId');
    final received = (meta['received'] as num?)?.toInt() ?? 0;
    final total = (meta['total'] as num?)?.toInt() ?? 0;
    if (received <= 0 || total <= 0) return 0;
    return ((received / total) * 100).clamp(0, 99).round();
  }

  static Future<File?> cachedFileForDocument({required String documentId}) async {
    final dir = await _cacheDir();
    final safe = _safeFileName(documentId);
    if (!await dir.exists()) return null;
    await for (final entity in dir.list(followLinks: false)) {
      if (entity is! File) continue;
      final name = entity.uri.pathSegments.isEmpty ? '' : entity.uri.pathSegments.last;
      if (name.endsWith('.part') || !name.startsWith('$safe.')) continue;
      try {
        if (await entity.length() > 0) return entity;
      } catch (_) {}
    }
    return null;
  }

  static Future<File> load({
    required String documentId,
    required String sourceUrl,
    required String version,
    required String fallbackExtension,
    void Function(int percent)? onProgress,
  }) {
    final key = '$documentId|$sourceUrl|$version|$fallbackExtension';
    final notifier = _progressForKey(key);
    void relay() => onProgress?.call(notifier.value);
    if (onProgress != null) {
      notifier.addListener(relay);
      // This is what fixes the stale percentage after scroll/re-entry.
      scheduleMicrotask(relay);
    }

    final active = _inflight[key];
    if (active != null) {
      return active.whenComplete(() {
        if (onProgress != null) notifier.removeListener(relay);
      });
    }

    final future = _loadInternal(
      documentId: documentId,
      sourceUrl: sourceUrl,
      version: version,
      fallbackExtension: fallbackExtension,
      onProgress: (percent) {
        final safe = percent.clamp(0, 100).toInt();
        if (notifier.value != safe) notifier.value = safe;
      },
    );
    _inflight[key] = future;
    future.then<void>((_) {
      _inflight.remove(key);
    }, onError: (Object _, StackTrace __) {
      _inflight.remove(key);
    });
    return future.whenComplete(() {
      if (onProgress != null) notifier.removeListener(relay);
    });
  }

  static Future<File> _loadInternal({
    required String documentId,
    required String sourceUrl,
    required String version,
    required String fallbackExtension,
    void Function(int percent)? onProgress,
  }) async {
    if (sourceUrl.trim().isEmpty) throw const GaminoApiException('اتصال اینترنت را بررسی کن و رفرش را بزن.');
    final resolvedUrl = _resolveUrl(sourceUrl);
    final uri = Uri.tryParse(resolvedUrl);
    if (uri == null || (uri.scheme != 'http' && uri.scheme != 'https')) throw const GaminoApiException('آدرس فایل معتبر نیست.');

    final prefs = await SharedPreferences.getInstance();
    final dir = await _cacheDir();
    final ext = _extensionFromUrl(resolvedUrl, fallbackExtension);
    final base = '${dir.path}${Platform.pathSeparator}${_safeFileName(documentId)}.$ext';
    final file = File(base);
    final part = File('$base.part');
    final metaKey = 'gamino_media_cache_$documentId';
    final partialKey = 'gamino_media_partial_$documentId';
    final meta = await _readMeta(prefs, metaKey);

    if (meta['sourceUrl'] == resolvedUrl && meta['version'] == version && await file.exists() && await file.length() > 0) {
      onProgress?.call(100);
      return file;
    }

    final partialMeta = await _readMeta(prefs, partialKey);
    final partialMatches = partialMeta['sourceUrl'] == resolvedUrl && partialMeta['version'] == version;
    if (!partialMatches && await part.exists()) await part.delete();
    if (!partialMatches) await prefs.remove(partialKey);

    var existing = await part.exists() ? await part.length() : 0;
    var knownTotal = partialMatches ? (partialMeta['total'] as num?)?.toInt() ?? 0 : 0;
    if (existing > 0 && knownTotal > 0) onProgress?.call(((existing / knownTotal) * 100).clamp(0, 99).round());

    final client = http.Client();
    IOSink? sink;
    try {
      final request = http.Request('GET', uri);
      request.headers['Accept'] = 'application/pdf,application/octet-stream,image/*,*/*';
      if (existing > 0) request.headers['Range'] = 'bytes=$existing-';
      final response = await client.send(request).timeout(const Duration(seconds: 35));

      if (response.statusCode == 416 && existing > 0 && knownTotal > 0 && existing >= knownTotal) {
        if (await file.exists()) await file.delete();
        await part.rename(file.path);
        await prefs.setString(metaKey, jsonEncode({'sourceUrl': resolvedUrl, 'version': version, 'cachedAt': DateTime.now().toIso8601String()}));
        await prefs.remove(partialKey);
        onProgress?.call(100);
        return file;
      }
      if (response.statusCode != 200 && response.statusCode != 206) {
        throw GaminoApiException('دانلود فایل ناموفق بود (${response.statusCode}). اتصال اینترنت را بررسی کن و رفرش را بزن.');
      }

      if (existing > 0 && response.statusCode != 206) {
        // Server did not honor Range. Keep the old partial until a valid full response is available,
        // then safely replace it rather than corrupting the cached file.
        existing = 0;
        if (await part.exists()) await part.delete();
      }

      final contentRange = response.headers['content-range'] ?? '';
      final match = RegExp(r'/([0-9]+)$').firstMatch(contentRange);
      knownTotal = match == null ? existing + (response.contentLength ?? 0) : int.tryParse(match.group(1) ?? '') ?? 0;
      if (knownTotal <= 0 && response.contentLength != null) knownTotal = existing + response.contentLength!;

      await prefs.setString(partialKey, jsonEncode({
        'sourceUrl': resolvedUrl,
        'version': version,
        'received': existing,
        'total': knownTotal,
        'updatedAt': DateTime.now().toIso8601String(),
      }));

      sink = part.openWrite(mode: existing > 0 ? FileMode.append : FileMode.write);
      var received = existing;
      var lastProgress = knownTotal > 0 ? ((received / knownTotal) * 100).clamp(0, 99).round() : 0;
      var lastPersistAt = DateTime.now();
      await for (final chunk in response.stream.timeout(const Duration(seconds: 35))) {
        sink.add(chunk);
        received += chunk.length;
        final progress = knownTotal > 0 ? ((received / knownTotal) * 100).clamp(0, 99).round() : 0;
        if (progress != lastProgress) {
          lastProgress = progress;
          onProgress?.call(progress);
        }
        // Persist resume metadata at a bounded cadence instead of on every
        // network chunk. This avoids SharedPreferences I/O becoming the
        // bottleneck while a large PDF is downloading.
        final now = DateTime.now();
        if (now.difference(lastPersistAt) >= const Duration(milliseconds: 700)) {
          lastPersistAt = now;
          await prefs.setString(partialKey, jsonEncode({
            'sourceUrl': resolvedUrl,
            'version': version,
            'received': received,
            'total': knownTotal,
            'updatedAt': now.toIso8601String(),
          }));
        }
      }
      await prefs.setString(partialKey, jsonEncode({
        'sourceUrl': resolvedUrl,
        'version': version,
        'received': received,
        'total': knownTotal,
        'updatedAt': DateTime.now().toIso8601String(),
      }));
      await sink.flush();
      await sink.close();
      sink = null;

      if (!await part.exists() || await part.length() == 0) throw const GaminoApiException('فایل دریافت‌شده خالی است.');
      if (knownTotal > 0 && await part.length() < knownTotal) throw const GaminoApiException('دانلود کامل نشد. اینترنت را بررسی کن و ادامه دانلود را بزن.');

      if (fallbackExtension == 'pdf') {
        final raf = await part.open();
        final header = await raf.read(5);
        await raf.close();
        if (header.length < 4 || utf8.decode(header.take(4).toList(), allowMalformed: true) != '%PDF') {
          throw const GaminoApiException('فایل دریافتی PDF معتبر نیست.');
        }
      }

      if (await file.exists()) await file.delete();
      await part.rename(file.path);
      await prefs.setString(metaKey, jsonEncode({'sourceUrl': resolvedUrl, 'version': version, 'cachedAt': DateTime.now().toIso8601String()}));
      await prefs.remove(partialKey);
      onProgress?.call(100);
      return file;
    } on GaminoApiException {
      rethrow;
    } catch (_) {
      throw const GaminoApiException('اتصال اینترنت را بررسی کن و دکمه رفرش / ادامه دانلود را بزن.');
    } finally {
      try { await sink?.flush(); } catch (_) {}
      try { await sink?.close(); } catch (_) {}
      client.close();
    }
  }
}

class CachedAvatarImage extends StatefulWidget {
  const CachedAvatarImage({
    super.key,
    required this.url,
    required this.version,
    required this.documentId,
    required this.fit,
  });

  final String url;
  final String version;
  final String documentId;
  final BoxFit fit;

  @override
  State<CachedAvatarImage> createState() => _CachedAvatarImageState();
}

class _CachedAvatarImageState extends State<CachedAvatarImage> {
  File? _file;
  int _generation = 0;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void didUpdateWidget(covariant CachedAvatarImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.url != widget.url || oldWidget.version != widget.version || oldWidget.documentId != widget.documentId) {
      _file = null;
      _reload();
    }
  }

  void _reload() {
    final generation = ++_generation;
    unawaited(_load(generation));
  }

  Future<void> _load(int generation) async {
    final url = widget.url.trim();
    if (url.isEmpty) {
      if (mounted && generation == _generation) setState(() => _file = null);
      return;
    }

    File? resolved;
    try {
      resolved = await MediaCacheStore.load(
        documentId: widget.documentId,
        sourceUrl: url,
        version: widget.version,
        fallbackExtension: 'webp',
      );
    } catch (_) {
      resolved = await MediaCacheStore.cachedFileForDocument(documentId: widget.documentId);
    }

    // Ignore a late response from the previous avatar/version. This matters
    // when the admin edits an avatar while an older image is still loading.
    if (mounted && generation == _generation) {
      setState(() => _file = resolved);
    }
  }

  @override
  Widget build(BuildContext context) {
    final file = _file;
    if (file == null) return const GaminoAvatarPlaceholder();
    return Image.file(
      file,
      fit: widget.fit,
      filterQuality: FilterQuality.high,
      errorBuilder: (_, __, ___) => const GaminoAvatarPlaceholder(),
    );
  }
}

class CachedMediaImage extends StatefulWidget {
  const CachedMediaImage({super.key, required this.url, required this.version, required this.documentId});
  final String url;
  final String version;
  final String documentId;

  @override
  State<CachedMediaImage> createState() => _CachedMediaImageState();
}

class _CachedMediaImageState extends State<CachedMediaImage> {
  File? _file;
  String? _error;
  int _progress = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant CachedMediaImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.url != widget.url || oldWidget.version != widget.version || oldWidget.documentId != widget.documentId) {
      _file = null;
      _error = null;
      _progress = 0;
      _load();
    }
  }

  Future<void> _load() async {
    final savedProgress = await MediaCacheStore.partialProgress(documentId: widget.documentId);
    if (mounted && savedProgress > 0) setState(() => _progress = savedProgress);
    try {
      final file = await MediaCacheStore.load(documentId: widget.documentId, sourceUrl: widget.url, version: widget.version, fallbackExtension: 'jpg', onProgress: (value) {
        if (mounted) setState(() => _progress = value);
      });
      if (!mounted) return;
      setState(() => _file = file);
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'تصویر قابل نمایش نیست.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: _file != null
          ? Image.file(_file!, fit: BoxFit.contain)
          : Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  if (_error == null) ...[
                    CircularProgressIndicator(value: _progress > 0 ? _progress / 100 : null),
                    const SizedBox(height: 12),
                    Text('در حال دریافت تصویر... $_progress٪', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800)),
                  ] else
                    Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: AppPalette.coral, fontWeight: FontWeight.w800)),
                ],
              ),
            ),
    );
  }
}

class PdfCacheStore {
  static Future<File> load({required String documentId, required String sourceUrl, required String version, void Function(int percent)? onProgress}) {
    return MediaCacheStore.load(documentId: documentId, sourceUrl: sourceUrl, version: version, fallbackExtension: 'pdf', onProgress: onProgress);
  }

  static Future<bool> hasValidCache({required String documentId, required String sourceUrl, required String version}) {
    return MediaCacheStore.hasValidCache(documentId: documentId, sourceUrl: sourceUrl, version: version, fallbackExtension: 'pdf');
  }

  static Future<int> partialProgress({required String documentId}) => MediaCacheStore.partialProgress(documentId: documentId);
}

class PdfReaderScreen extends StatefulWidget {
  const PdfReaderScreen({
    super.key,
    required this.title,
    required this.documentId,
    required this.pdfUrl,
    required this.version,
    required this.subject,
    required this.chapter,
    required this.onStudyTick,
  });

  final String title;
  final String documentId;
  final String pdfUrl;
  final String version;
  final String subject;
  final String chapter;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;

  @override
  State<PdfReaderScreen> createState() => _PdfReaderScreenState();
}

class _PdfReaderScreenState extends State<PdfReaderScreen> with WidgetsBindingObserver {
  File? _file;
  String? _error;
  bool _loading = true;
  int _downloadProgress = 0;
  DateTime? _activeSince;
  Timer? _studyTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _activeSince = null;
    _studyTimer = Timer.periodic(const Duration(seconds: 55), (_) => _flushStudyTime());
    _load();
  }

  Future<void> _load() async {
    try {
      final file = await PdfCacheStore.load(
        documentId: widget.documentId,
        sourceUrl: widget.pdfUrl,
        version: widget.version,
        onProgress: (value) { if (mounted) setState(() => _downloadProgress = value); },
      );
      if (!mounted) return;
      setState(() { _file = file; _loading = false; _downloadProgress = 100; });
      _activeSince = DateTime.now();
    } catch (error) {
      if (!mounted) return;
      final saved = await PdfCacheStore.partialProgress(documentId: widget.documentId);
      setState(() { _error = error is GaminoApiException ? error.message : 'برای دریافت این محتوا، لطفاً اتصال اینترنت خود را روشن و بررسی کنید؛ سپس تلاش دوباره را بزنید.'; _loading = false; _downloadProgress = saved; });
    }
  }

  Future<void> _flushStudyTime() async {
    final since = _activeSince;
    if (since == null) return;
    final seconds = DateTime.now().difference(since).inSeconds;
    if (seconds < 10) return;
    _activeSince = DateTime.now();
    await widget.onStudyTick(widget.subject, widget.chapter, seconds.clamp(1, 60).toInt());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      if (_file != null && _error == null && !_loading) _activeSince = DateTime.now();
    } else if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      unawaited(_flushStudyTime());
      _activeSince = null;
    }
  }

  @override
  void dispose() {
    unawaited(_flushStudyTime());
    _studyTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text(widget.title)),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(width: 46, height: 46, child: CircularProgressIndicator(value: _downloadProgress > 0 ? _downloadProgress / 100 : null, strokeWidth: 4)),
                        const SizedBox(height: 14),
                        Text('در حال دانلود PDF... $_downloadProgress٪', style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted)),
                      ],
                    ),
                  )
                : _error != null
                    ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.error_outline_rounded, size: 46, color: AppPalette.coral), const SizedBox(height: 12), Text(_error!, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, height: 1.7)), const SizedBox(height: 16), FilledButton.icon(onPressed: () { setState(() { _loading = true; _error = null; }); _load(); }, icon: const Icon(Icons.refresh_rounded), label: const Text('تلاش دوباره'))])))
                    : PDFView(
                        filePath: _file!.path,
                        enableSwipe: true,
                        swipeHorizontal: false,
                        autoSpacing: false,
                        pageFling: false,
                        pageSnap: false,
                        onError: (error) { if (mounted) setState(() => _error = 'نمایش PDF با خطا روبه‌رو شد.'); },
                      ),
          ),
          const GaminoInlineBanner(slot: 'pdf_study_bottom'),
        ],
      ),
    );
  }
}

class ChapterDetailScreen extends StatefulWidget {
  const ChapterDetailScreen({
    super.key,
    required this.subject,
    required this.chapter,
    required this.isGuest,
    required this.onComplete,
    required this.onStudyTick,
  });

  final Subject subject;
  final Chapter chapter;
  final bool isGuest;
  final VoidCallback onComplete;
  final Future<void> Function(String subject, String chapter, int seconds) onStudyTick;

  @override
  State<ChapterDetailScreen> createState() => _ChapterDetailScreenState();
}

class _ChapterDetailScreenState extends State<ChapterDetailScreen> with WidgetsBindingObserver {
  Timer? _timer;
  DateTime _startedAt = DateTime.now();
  bool _active = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _flushStudyTime());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _active = true;
      _startedAt = DateTime.now();
    } else if (_active) {
      _flushStudyTime();
      _active = false;
    }
  }

  void _flushStudyTime() {
    if (!_active || widget.isGuest) return;
    final seconds = DateTime.now().difference(_startedAt).inSeconds;
    if (seconds >= 5) {
      _startedAt = DateTime.now();
      unawaited(widget.onStudyTick(widget.subject.title, widget.chapter.title, seconds.clamp(1, 60).toInt()));
    }
  }

  @override
  void dispose() {
    _flushStudyTime();
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text('${widget.subject.title} - ${widget.chapter.title}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (!widget.isGuest)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              decoration: BoxDecoration(color: AppPalette.mint.withOpacity(.10), borderRadius: BorderRadius.circular(16)),
              child: const Row(children: [Icon(Icons.timer_outlined, color: AppPalette.mint), SizedBox(width: 8), Expanded(child: Text('زمان مطالعه این درس به‌صورت آنلاین برای Level ثبت می‌شود.', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: AppPalette.ink)))]),
            ),
          InfoBox(title: 'آموزش کوتاه', body: widget.chapter.lesson, icon: Icons.school_outlined),
          InfoBox(title: 'نمونه سوال', body: widget.chapter.sampleQuestion, icon: Icons.help_outline),
          InfoBox(title: 'پاسخ تشریحی', body: widget.chapter.answer, icon: Icons.check_circle_outline),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: widget.isGuest ? null : () { widget.onComplete(); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('فصل تکمیل شد و در حساب آنلاین ثبت شد.'))); },
            icon: const Icon(Icons.done_all),
            label: Text(widget.isGuest ? 'برای ثبت پیشرفت وارد شوید' : 'تکمیل این فصل'),
          ),
        ],
      ),
    );
  }
}

class QuizCenterScreen extends StatefulWidget {
  const QuizCenterScreen({
    super.key,
    required this.user,
    this.initialTabIndex = 0,
    required this.isGuest,
    required this.mistakes,
    required this.activeRoom,
    required this.onQuizFinished,
    required this.onMistakePracticeFinished,
    required this.onCreateRoom,
    required this.onJoinRoom,
    required this.books,
  });

  final AppUser user;
  final int initialTabIndex;
  final bool isGuest;
  final List<MyMistake> mistakes;
  final QuizRoom? activeRoom;
  final List<LearningBook> books;
  final void Function(QuizResult result) onQuizFinished;
  final void Function(QuizResult result) onMistakePracticeFinished;
  final void Function({required int maxPlayers, required String roomType}) onCreateRoom;
  final void Function(String code) onJoinRoom;

  @override
  State<QuizCenterScreen> createState() => _QuizCenterScreenState();
}

class _QuizCenterScreenState extends State<QuizCenterScreen> {
  bool loading = true;
  Object? loadError;
  late AppUser freshUser;
  late List<LearningBook> freshBooks;
  OnlineMatchOverview overview = OnlineMatchOverview.empty();

  @override
  void initState() {
    super.initState();
    freshUser = widget.user;
    freshBooks = List<LearningBook>.of(widget.books);
    if (!widget.isGuest) _load(); else loading = false;
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() { loading = true; loadError = null; });
    try {
      final token = await RemoteSessionStore.readToken();
      if (token == null || token.isEmpty) throw const GaminoApiException('برای ادامه وارد حساب شوید.');
      final responses = await Future.wait<Map<String, dynamic>>([
        GaminoApiService.request('state', token: token, get: true, timeout: const Duration(seconds: 8)),
        OnlineMatchApi.request('online.overview', const {}, timeout: const Duration(seconds: 8)),
      ]);
      final state = responses[0];
      final rawUser = state['user'];
      final rawBooks = state['books'];
      if (rawUser is Map) freshUser = AppUser.fromJson(Map<String, dynamic>.from(rawUser));
      if (rawBooks is List) {
        freshBooks = rawBooks.whereType<Map>().map((e) => LearningBook.fromJson(Map<String, dynamic>.from(e))).toList()
          ..sort((a,b) => a.sortOrder.compareTo(b.sortOrder));
      }
      overview = OnlineMatchOverview.fromJson(responses[1]);
      if (!mounted) return;
      setState(() => loading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() { loading = false; loadError = e; });
      WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) showClassQuizErrorDialog(context, e); });
    }
  }

  Future<void> _refreshOnlineOnly() async {
    try {
      final data = await OnlineMatchApi.request('online.overview', const {}, timeout: const Duration(seconds: 8));
      if (!mounted) return;
      setState(() => overview = OnlineMatchOverview.fromJson(data));
      await gaminoAppKey.currentState?.refreshLearningContent();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isGuest) {
      return const LockedScreen(
        title: 'کوییز برای مهمان قفل است',
        message: 'برای رقابت آنلاین، کوییز با دوستان، کاپ، کارت و ذخیره اشتباهات باید ثبت‌نام کنید.',
      );
    }
    if (loading) {
      return const SafeArea(child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [CircularProgressIndicator(), SizedBox(height: 12), Text('در حال دریافت اطلاعات کوییز...', style: TextStyle(fontWeight: FontWeight.w800))])));
    }
    if (loadError != null) {
      return SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('اطلاعات کوییز دریافت نشد.', style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                FilledButton(onPressed: _load, child: const Text('تلاش دوباره')),
              ],
            ),
          ),
        ),
      );
    }

    return DefaultTabController(
      length: 3,
      initialIndex: widget.initialTabIndex.clamp(0, 2).toInt(),
      child: SafeArea(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(18, 12, 18, 6),
              child: Align(alignment: Alignment.centerRight, child: Text('کوییز', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppPalette.ink))),
            ),
            const TabBar(
              isScrollable: true,
              tabs: [Tab(text: 'مسابقه'), Tab(text: 'آزمون‌ساز'), Tab(text: 'دوستان/کلاس')],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  QuickQuizPanel(user: freshUser, overview: overview, onChanged: _refreshOnlineOnly),
                  ExamBuilderPanel(user: freshUser, books: freshBooks, onQuizFinished: widget.onQuizFinished),
                  FriendsQuizPanel(
                    user: freshUser,
                    books: freshBooks,
                    activeRoom: widget.activeRoom,
                    onCreateRoom: widget.onCreateRoom,
                    onJoinRoom: widget.onJoinRoom,
                    onQuizFinished: widget.onQuizFinished,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

List<QuizQuestion> panelQuestionsForUser(AppUser user, List<LearningBook> books) {
  final remote = <QuizQuestion>[];
  for (final book in books) {
    if (book.grade != user.grade) continue;
    if (user.grade >= 10 && normalizeEducationTrack(book.grade, book.track) != normalizeEducationTrack(user.grade, user.educationTrack)) continue;
    for (final lesson in book.lessons) {
      remote.addAll(lesson.questions.where((q) {
        if (q.grade != user.grade) return false;
        if (user.grade >= 10 && normalizeEducationTrack(q.grade, q.track) != normalizeEducationTrack(user.grade, user.educationTrack)) return false;
        return true;
      }));
    }
  }
  return remote;
}

class OnlineMatchApi {
  static Future<Map<String, dynamic>> request(String action, Map<String, dynamic> body, {Duration timeout = const Duration(seconds: 12)}) async {
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) throw const GaminoApiException('برای ادامه وارد حساب شوید.');
    return GaminoApiService.request(action, token: token, body: body, timeout: timeout);
  }
}

class OnlineMatchProfile {
  const OnlineMatchProfile({required this.userId, required this.name, required this.avatar, required this.avatarUrl, required this.cups});
  final String userId;
  final String name;
  final String avatar;
  final String avatarUrl;
  final int cups;
  factory OnlineMatchProfile.fromJson(Map<String, dynamic> json) => OnlineMatchProfile(
    userId: json['userId']?.toString() ?? '',
    name: json['name']?.toString() ?? 'دانش‌آموز',
    avatar: json['avatar']?.toString() ?? '',
    avatarUrl: json['avatarUrl']?.toString() ?? '',
    cups: (json['cups'] as num?)?.toInt() ?? 0,
  );
  LeaderRow asLeader(int grade) => LeaderRow(userId: userId, rank: 0, name: name, grade: grade, xp: cups, avatar: avatar, avatarUrl: avatarUrl);
}

class OnlineMatchResultData {
  const OnlineMatchResultData({required this.result, required this.correct, required this.wrong, required this.total, required this.finishDuration, required this.finishedAt, required this.cupDelta});
  final String result;
  final int correct;
  final int wrong;
  final int total;
  final int finishDuration;
  final int finishedAt;
  final int cupDelta;
  bool get isWin => result == 'win';
  bool get isLoss => result == 'loss';
  bool get isDraw => result == 'draw';
  factory OnlineMatchResultData.fromJson(Map<String, dynamic> json) => OnlineMatchResultData(
    result: json['result']?.toString() ?? '',
    correct: (json['correct'] as num?)?.toInt() ?? 0,
    wrong: (json['wrong'] as num?)?.toInt() ?? 0,
    total: (json['total'] as num?)?.toInt() ?? 0,
    finishDuration: (json['finishDuration'] as num?)?.toInt() ?? 0,
    finishedAt: (json['finishedAt'] as num?)?.toInt() ?? 0,
    cupDelta: (json['cupDelta'] as num?)?.toInt() ?? 0,
  );
}

class OnlineMatchState {
  const OnlineMatchState({required this.matchId, required this.status, required this.grade, required this.serverNow, required this.startAt, required this.endAt, required this.questions, required this.answers, required this.attemptFinished, required this.opponentFinished, required this.me, required this.opponent, required this.result, required this.opponentResult});
  final String matchId;
  final String status;
  final int grade;
  final int serverNow;
  final int startAt;
  final int endAt;
  final List<QuizQuestion> questions;
  final Map<String,int> answers;
  final bool attemptFinished;
  final bool opponentFinished;
  final OnlineMatchProfile me;
  final OnlineMatchProfile opponent;
  final OnlineMatchResultData? result;
  final OnlineMatchResultData? opponentResult;
  bool get isFinal => status == 'final';
  factory OnlineMatchState.fromJson(Map<String, dynamic> json) {
    final rawAnswers = json['answers'] is Map ? Map<String,dynamic>.from(json['answers'] as Map) : <String,dynamic>{};
    final rawResult = json['result']; final rawOppResult = json['opponentResult'];
    return OnlineMatchState(
      matchId: json['matchId']?.toString() ?? '', status: json['status']?.toString() ?? 'countdown', grade: (json['grade'] as num?)?.toInt() ?? 1,
      serverNow: (json['serverNow'] as num?)?.toInt() ?? DateTime.now().millisecondsSinceEpoch ~/ 1000,
      startAt: (json['startAt'] as num?)?.toInt() ?? 0, endAt: (json['endAt'] as num?)?.toInt() ?? 0,
      questions: (json['questions'] as List? ?? []).whereType<Map>().map((e)=>QuizQuestion.fromJson(Map<String,dynamic>.from(e))).toList(),
      answers: rawAnswers.map((k,v)=>MapEntry(k,(v as num?)?.toInt() ?? -1)), attemptFinished: json['attemptFinished']==true, opponentFinished: json['opponentFinished']==true,
      me: OnlineMatchProfile.fromJson(Map<String,dynamic>.from(json['me'] as Map? ?? const {})), opponent: OnlineMatchProfile.fromJson(Map<String,dynamic>.from(json['opponent'] as Map? ?? const {})),
      result: rawResult is Map && rawResult.isNotEmpty ? OnlineMatchResultData.fromJson(Map<String,dynamic>.from(rawResult)) : null,
      opponentResult: rawOppResult is Map && rawOppResult.isNotEmpty ? OnlineMatchResultData.fromJson(Map<String,dynamic>.from(rawOppResult)) : null,
    );
  }
}

class OnlineMatchHistoryRow {
  const OnlineMatchHistoryRow({required this.matchId, required this.status, required this.opponent, required this.result, required this.opponentFinished, required this.startAt, required this.endAt, required this.createdAt});
  final String matchId;
  final String status;
  final OnlineMatchProfile opponent;
  final OnlineMatchResultData? result;
  final bool opponentFinished;
  final int startAt;
  final int endAt;
  final int createdAt;
  bool get isFinal => status == 'final';
  factory OnlineMatchHistoryRow.fromJson(Map<String,dynamic> json) {
    final raw = json['result'];
    return OnlineMatchHistoryRow(matchId: json['matchId']?.toString()??'', status: json['status']?.toString()??'countdown', opponent: OnlineMatchProfile.fromJson(Map<String,dynamic>.from(json['opponent'] as Map? ?? const {})), result: raw is Map && raw.isNotEmpty ? OnlineMatchResultData.fromJson(Map<String,dynamic>.from(raw)) : null, opponentFinished: json['opponentFinished']==true, startAt:(json['startAt'] as num?)?.toInt()??0,endAt:(json['endAt'] as num?)?.toInt()??0,createdAt:(json['createdAt'] as num?)?.toInt()??0);
  }
}

class OnlineMatchOverview {
  const OnlineMatchOverview({required this.activeCount, required this.history});
  final int activeCount;
  final List<OnlineMatchHistoryRow> history;
  factory OnlineMatchOverview.empty() => const OnlineMatchOverview(activeCount: 0, history: []);
  factory OnlineMatchOverview.fromJson(Map<String,dynamic> json) => OnlineMatchOverview(activeCount:(json['activeCount'] as num?)?.toInt()??0, history:(json['history'] as List? ?? []).whereType<Map>().map((e)=>OnlineMatchHistoryRow.fromJson(Map<String,dynamic>.from(e))).toList());
}

class QuickQuizPanel extends StatefulWidget {
  const QuickQuizPanel({super.key, required this.user, required this.overview, required this.onChanged});
  final AppUser user;
  final OnlineMatchOverview overview;
  final Future<void> Function() onChanged;
  @override State<QuickQuizPanel> createState()=>_QuickQuizPanelState();
}

class _QuickQuizPanelState extends State<QuickQuizPanel> {
  late OnlineMatchOverview overview;
  bool opening=false;
  @override void initState(){super.initState();overview=widget.overview;}
  @override void didUpdateWidget(covariant QuickQuizPanel oldWidget){super.didUpdateWidget(oldWidget);if(oldWidget.overview!=widget.overview)overview=widget.overview;}

  Future<void> _refresh() async {
    try { final data=await OnlineMatchApi.request('online.overview', const {}); if(!mounted)return; setState(()=>overview=OnlineMatchOverview.fromJson(data)); } catch(e){if(mounted) await showClassQuizErrorDialog(context,e);}
  }

  Future<void> _startSearch() async {
    if(opening)return;
    if(overview.activeCount>=10){await showClassQuizMessageDialog(context,title:'سقف مسابقه',message:'حداکثر ۱۰ مسابقه در حال انجام می‌توانی داشته باشی. بعد از تمام شدن یکی دوباره تلاش کن.',icon:Icons.hourglass_full_rounded);return;}
    setState(()=>opening=true);
    await Navigator.push(context, MaterialPageRoute(builder:(_)=>OnlineMatchSearchScreen(user:widget.user)));
    if(mounted)setState(()=>opening=false);
    await _refresh(); await widget.onChanged();
  }

  Future<void> _openHistory(OnlineMatchHistoryRow row) async {
    if(opening)return;setState(()=>opening=true);
    try {
      final data=await OnlineMatchApi.request('online.match.status', {'matchId':row.matchId});
      final raw=data['match']; if(raw is! Map) throw const GaminoApiException('اطلاعات مسابقه دریافت نشد.');
      final match=OnlineMatchState.fromJson(Map<String,dynamic>.from(raw));
      if(!mounted)return;
      if(!match.isFinal && !match.attemptFinished) await Navigator.push(context,MaterialPageRoute(builder:(_)=>OnlineMatchExamScreen(initial:match,user:widget.user)));
      else await Navigator.push(context,MaterialPageRoute(builder:(_)=>OnlineMatchResultScreen(matchId:match.matchId,user:widget.user,initial:match)));
    } catch(e){if(mounted)await showClassQuizErrorDialog(context,e);} finally {if(mounted)setState(()=>opening=false);}
    await _refresh(); await widget.onChanged();
  }

  Color _historyColor(OnlineMatchHistoryRow row){if(!row.isFinal)return const Color(0xFFFFF8E1);if(row.result?.isWin==true)return const Color(0xFFEAFBF0);if(row.result?.isLoss==true)return const Color(0xFFFFECEC);return Colors.white;}
  String _statusText(OnlineMatchHistoryRow row){if(!row.isFinal)return 'در حال انجام';if(row.result?.isWin==true)return 'برد';if(row.result?.isLoss==true)return 'باخت';return 'مساوی';}

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          CupScoringPreviewCard(cups: currentCups(widget.user)),
          const SizedBox(height: 12),
          FilledButton(onPressed: opening ? null : _startSearch, child: const Text('شروع مسابقه')),
          const SizedBox(height: 18),
          Row(
            children: [
              const Expanded(child: Text('تاریخچه بازی‌ها', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
              Text('${overview.history.length}/۲۰', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
            ],
          ),
          const SizedBox(height: 8),
          if (overview.history.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 30),
              child: Center(child: Text('هنوز مسابقه‌ای ثبت نشده است.', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700))),
            )
          else
            ...overview.history.map((row) => Card(
                  color: _historyColor(row),
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    onTap: () => _openHistory(row),
                    leading: SizedBox(
                      width: 40,
                      height: 40,
                      child: avatarImageForTitle(row.opponent.avatar, fit: BoxFit.contain, remoteUrl: row.opponent.avatarUrl),
                    ),
                    title: Text(row.opponent.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                    subtitle: Text(_statusText(row), style: const TextStyle(fontWeight: FontWeight.w800)),
                    trailing: row.isFinal
                        ? Text(
                            row.result == null || row.result!.cupDelta == 0 ? 'بدون تغییر کاپ' : signedCupText(row.result!.cupDelta),
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              color: row.result!.cupDelta > 0 ? AppPalette.mint : row.result!.cupDelta < 0 ? AppPalette.coral : AppPalette.muted,
                            ),
                          )
                        : const SizedBox.shrink(),
                  ),
                )),
        ],
      ),
    );
  }
}

class OnlineMatchSearchScreen extends StatefulWidget {
  const OnlineMatchSearchScreen({super.key, required this.user});
  final AppUser user;
  @override
  State<OnlineMatchSearchScreen> createState() => _OnlineMatchSearchScreenState();
}

class _OnlineMatchSearchScreenState extends State<OnlineMatchSearchScreen> with WidgetsBindingObserver {
  static const Duration _normalPollDelay = Duration(milliseconds: 1500);
  static const Duration _requestTimeout = Duration(seconds: 4);
  static const int _searchDurationMs = 30000;

  final Stopwatch _searchClock = Stopwatch();
  Timer? _uiTimer;
  Timer? _pollTimer;
  String _searchSessionId = '';
  int _searchGeneration = 0;
  int _elapsedAnchorMs = 0;
  int _displayedRemaining = 30;
  int _consecutiveFailures = 0;
  bool _searchActive = false;
  bool _checking = false;
  bool _deadlineCheckRunning = false;
  bool _closing = false;
  bool _cancelling = false;
  bool _weakConnection = false;
  bool _cancelledByLifecycle = false;
  AppLifecycleState _lifecycle = AppLifecycleState.resumed;
  OnlineMatchState? _lifecycleRecoveredMatch;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _beginSearch());
  }

  @override
  void dispose() {
    _stopClientLoops();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _lifecycle = state;
    if (state == AppLifecycleState.paused || state == AppLifecycleState.hidden || state == AppLifecycleState.detached) {
      if (_searchActive && !_closing && !_cancelledByLifecycle) {
        _cancelledByLifecycle = true;
        _cancelForLifecycle();
      }
      return;
    }
    if (state == AppLifecycleState.resumed && _cancelledByLifecycle && mounted) {
      final recovered = _lifecycleRecoveredMatch;
      _cancelledByLifecycle = false;
      _lifecycleRecoveredMatch = null;
      if (recovered != null) {
        _openMatch(recovered);
      } else if (!_closing) {
        _closing = true;
        Navigator.pop(context);
      }
    }
  }

  String _newSearchSessionId() {
    final stamp = DateTime.now().microsecondsSinceEpoch;
    final nonce = Random.secure().nextInt(0x7fffffff);
    return 'qs_${stamp}_$nonce';
  }

  int get _elapsedMs => min(_searchDurationMs, _elapsedAnchorMs + _searchClock.elapsedMilliseconds);
  int get _remainingSeconds => max(0, ((_searchDurationMs - _elapsedMs) + 999) ~/ 1000);

  void _stopClientLoops() {
    _uiTimer?.cancel();
    _uiTimer = null;
    _pollTimer?.cancel();
    _pollTimer = null;
    _searchClock.stop();
  }

  void _startLocalClock() {
    _elapsedAnchorMs = 0;
    _searchClock
      ..reset()
      ..start();
    _displayedRemaining = 30;
    _uiTimer?.cancel();
    _uiTimer = Timer.periodic(const Duration(milliseconds: 200), (_) => _tickLocalTimer());
  }

  void _syncElapsedForward(Map<String, dynamic> queue) {
    final serverElapsedMs = (((queue['elapsed'] as num?)?.toInt() ?? 0).clamp(0, 30)) * 1000;
    final current = _elapsedMs;
    if (serverElapsedMs > current + 500) {
      _elapsedAnchorMs = serverElapsedMs;
      _searchClock
        ..reset()
        ..start();
    }
  }

  void _tickLocalTimer() {
    if (!mounted || !_searchActive || _closing) return;
    final next = _remainingSeconds;
    if (next != _displayedRemaining) {
      _displayedRemaining = next;
      setState(() {});
    }
    if (_elapsedMs >= _searchDurationMs && !_deadlineCheckRunning) {
      _finalCheckAtDeadline();
    }
  }

  Duration get _nextPollDelay {
    if (_consecutiveFailures <= 0) return _normalPollDelay;
    if (_consecutiveFailures == 1) return const Duration(seconds: 2);
    if (_consecutiveFailures == 2) return const Duration(seconds: 3);
    return const Duration(seconds: 4);
  }

  void _schedulePoll({Duration? delay}) {
    _pollTimer?.cancel();
    if (!_searchActive || _closing || !mounted) return;
    final generation = _searchGeneration;
    _pollTimer = Timer(delay ?? _nextPollDelay, () async {
      if (!mounted || !_searchActive || _closing || generation != _searchGeneration) return;
      await _checkStatus(generation);
      if (mounted && _searchActive && !_closing && generation == _searchGeneration && !_deadlineCheckRunning) {
        _schedulePoll();
      }
    });
  }

  void _markSuccess() {
    if (_consecutiveFailures == 0 && !_weakConnection) return;
    _consecutiveFailures = 0;
    if (_weakConnection && mounted) setState(() => _weakConnection = false);
  }

  void _markFailure() {
    _consecutiveFailures++;
    if (_consecutiveFailures >= 3 && !_weakConnection && mounted) setState(() => _weakConnection = true);
  }

  Future<void> _beginSearch() async {
    if (!mounted || _closing) return;
    _searchGeneration++;
    final generation = _searchGeneration;
    _searchSessionId = _newSearchSessionId();
    _consecutiveFailures = 0;
    _weakConnection = false;
    _deadlineCheckRunning = false;
    _searchActive = true;
    _startLocalClock();
    if (mounted) setState(() {});
    await _sendStart(generation);
    if (mounted && _searchActive && !_closing && generation == _searchGeneration) _schedulePoll();
  }

  Future<void> _sendStart(int generation) async {
    if (!mounted || !_searchActive || _closing || generation != _searchGeneration) return;
    try {
      final data = await OnlineMatchApi.request(
        'online.queue.start',
        {'searchSessionId': _searchSessionId},
        timeout: _requestTimeout,
      );
      if (!mounted || generation != _searchGeneration || !_searchActive) return;
      _markSuccess();
      await _consume(data, generation);
    } catch (error) {
      if (!mounted || generation != _searchGeneration || !_searchActive) return;
      if (error is GaminoApiException && !error.isNetwork) {
        _searchActive = false;
        _stopClientLoops();
        await showClassQuizErrorDialog(context, error);
        if (mounted && !_closing) {
          _closing = true;
          Navigator.pop(context);
        }
        return;
      }
      _markFailure();
    }
  }

  Future<void> _checkStatus(int generation) async {
    if (_checking || !_searchActive || _closing || !mounted || generation != _searchGeneration) return;
    _checking = true;
    try {
      final data = await OnlineMatchApi.request(
        'online.queue.status',
        {'searchSessionId': _searchSessionId},
        timeout: _requestTimeout,
      );
      if (!mounted || generation != _searchGeneration || !_searchActive) return;
      _markSuccess();
      final queue = Map<String, dynamic>.from(data['queue'] as Map? ?? const {});
      final status = queue['status']?.toString() ?? '';
      await _consume(data, generation);
      // A lost start response can leave the client unsure whether it joined. Starting
      // again with the same searchSessionId is idempotent on the server.
      if (mounted && _searchActive && !_closing && generation == _searchGeneration && status == 'idle' && _remainingSeconds > 0) {
        await _sendStart(generation);
      }
    } catch (_) {
      if (mounted && generation == _searchGeneration && _searchActive) _markFailure();
    } finally {
      _checking = false;
    }
  }

  bool _responseBelongsToCurrentSearch(Map<String, dynamic> queue, int generation) {
    if (generation != _searchGeneration) return false;
    final responseSession = queue['searchSessionId']?.toString() ?? '';
    return responseSession.isEmpty || responseSession == _searchSessionId;
  }

  Future<void> _consume(Map<String, dynamic> data, int generation) async {
    if (!mounted || !_searchActive || generation != _searchGeneration) return;
    final queue = Map<String, dynamic>.from(data['queue'] as Map? ?? const {});
    if (!_responseBelongsToCurrentSearch(queue, generation)) return;
    _syncElapsedForward(queue);

    final rawMatch = data['match'];
    if (rawMatch is Map) {
      await _openMatch(OnlineMatchState.fromJson(Map<String, dynamic>.from(rawMatch)));
      return;
    }

    final status = queue['status']?.toString() ?? '';
    if (status == 'stale') return;
    if (status == 'not_found' || (status == 'idle' && _remainingSeconds <= 0)) {
      await _showNoMatchDialog();
    }
  }

  Future<void> _finalCheckAtDeadline() async {
    if (_deadlineCheckRunning || !_searchActive || _closing || !mounted) return;
    _deadlineCheckRunning = true;
    _pollTimer?.cancel();
    _pollTimer = null;
    final generation = _searchGeneration;
    try {
      for (var attempt = 0; attempt < 2; attempt++) {
        try {
          final data = await OnlineMatchApi.request(
            'online.queue.status',
            {'searchSessionId': _searchSessionId},
            timeout: _requestTimeout,
          );
          if (!mounted || generation != _searchGeneration || !_searchActive) return;
          _markSuccess();
          final rawMatch = data['match'];
          if (rawMatch is Map) {
            await _openMatch(OnlineMatchState.fromJson(Map<String, dynamic>.from(rawMatch)));
            return;
          }
          final queue = Map<String, dynamic>.from(data['queue'] as Map? ?? const {});
          if (!_responseBelongsToCurrentSearch(queue, generation)) return;
          final status = queue['status']?.toString() ?? '';
          if (status == 'not_found' || status == 'idle') {
            await _showNoMatchDialog();
            return;
          }
          // The local clock can reach zero a fraction before the server's original
          // joinedAt TTL because of network transit. Give the authoritative server
          // one short final observation without resetting or extending the 30s TTL.
          if (attempt == 0 && status == 'searching') {
            await Future<void>.delayed(const Duration(milliseconds: 700));
            continue;
          }
          await _showNoMatchDialog();
          return;
        } catch (_) {
          _markFailure();
          if (attempt == 0) continue;
          await _showDeadlineConnectionDialog();
          return;
        }
      }
    } finally {
      _deadlineCheckRunning = false;
    }
  }

  Future<void> _openMatch(OnlineMatchState match) async {
    if (!mounted || _closing) return;
    _searchActive = false;
    _stopClientLoops();
    _closing = true;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => OnlineMatchExamScreen(initial: match, user: widget.user)),
    );
  }

  Future<void> _showNoMatchDialog() async {
    if (!mounted || _closing) return;
    _searchActive = false;
    _stopClientLoops();
    final retry = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 440),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.10), borderRadius: BorderRadius.circular(20)),
                  child: const Icon(Icons.search_off_rounded, color: AppPalette.primary, size: 30),
                ),
                const SizedBox(height: 16),
                const Text('حریفی پیدا نشد', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 22),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 50,
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(backgroundColor: AppPalette.coral, foregroundColor: Colors.white),
                          onPressed: () => Navigator.pop(ctx, false),
                          icon: const Icon(Icons.close_rounded),
                          label: const Text('انصراف', style: TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: SizedBox(
                        height: 50,
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(backgroundColor: AppPalette.mint, foregroundColor: Colors.white),
                          onPressed: () => Navigator.pop(ctx, true),
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('تلاش دوباره', style: TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (!mounted) return;
    if (retry == true) {
      await _beginSearch();
    } else if (!_closing) {
      _closing = true;
      Navigator.pop(context);
    }
  }

  Future<void> _showDeadlineConnectionDialog() async {
    if (!mounted || _closing) return;
    _searchActive = false;
    _stopClientLoops();
    final retry = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => _ClassQuizDialogFrame(
        icon: Icons.wifi_off_rounded,
        title: 'ارتباط با سرور برقرار نشد',
        child: const Text('اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, color: AppPalette.muted, height: 1.7)),
        actions: [
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppPalette.coral, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('انصراف'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppPalette.mint, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('تلاش دوباره'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    if (retry == true) {
      _searchActive = true;
      _deadlineCheckRunning = false;
      await _finalCheckAtDeadline();
    } else if (!_closing) {
      await _cancelAndPop();
    }
  }

  Future<void> _retryConnectionNow() async {
    if (!_searchActive || _checking || _closing) return;
    _pollTimer?.cancel();
    _pollTimer = null;
    await _checkStatus(_searchGeneration);
    if (mounted && _searchActive && !_closing && !_deadlineCheckRunning) _schedulePoll();
  }

  Future<void> _cancelAndPop() async {
    if (_closing || _cancelling) return;
    _cancelling = true;
    _searchActive = false;
    _stopClientLoops();
    try {
      final data = await OnlineMatchApi.request(
        'online.queue.cancel',
        {'searchSessionId': _searchSessionId},
        timeout: _requestTimeout,
      );
      final rawMatch = data['match'];
      if (rawMatch is Map && mounted) {
        _cancelling = false;
        _searchActive = true;
        await _openMatch(OnlineMatchState.fromJson(Map<String, dynamic>.from(rawMatch)));
        return;
      }
    } catch (_) {
      // Server TTL is still fixed at 30 seconds, so a failed cancel cannot leave a
      // waiting user in the matchmaking queue indefinitely.
    }
    _cancelling = false;
    if (mounted && !_closing) {
      _closing = true;
      Navigator.pop(context);
    }
  }

  Future<void> _cancelForLifecycle() async {
    _searchActive = false;
    _stopClientLoops();
    try {
      final data = await OnlineMatchApi.request(
        'online.queue.cancel',
        {'searchSessionId': _searchSessionId},
        timeout: _requestTimeout,
      );
      final rawMatch = data['match'];
      if (rawMatch is Map) _lifecycleRecoveredMatch = OnlineMatchState.fromJson(Map<String, dynamic>.from(rawMatch));
    } catch (_) {}
    if (!mounted) return;
    if (_lifecycle == AppLifecycleState.resumed && _cancelledByLifecycle) {
      final recovered = _lifecycleRecoveredMatch;
      _cancelledByLifecycle = false;
      _lifecycleRecoveredMatch = null;
      if (recovered != null) {
        await _openMatch(recovered);
      } else if (!_closing) {
        _closing = true;
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _cancelAndPop();
      },
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(26, 32, 26, 26),
                  decoration: BoxDecoration(
                    color: AppPalette.surface,
                    borderRadius: BorderRadius.circular(32),
                    boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(.08), blurRadius: 28, offset: const Offset(0, 14))],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 82,
                        height: 82,
                        child: ShaderMask(
                          blendMode: BlendMode.srcIn,
                          shaderCallback: (bounds) => const SweepGradient(
                            colors: [AppPalette.primary, AppPalette.cyan, AppPalette.mint, AppPalette.amber, AppPalette.pink, AppPalette.primary],
                          ).createShader(bounds),
                          child: const CircularProgressIndicator(strokeWidth: 7),
                        ),
                      ),
                      const SizedBox(height: 24),
                      const Text('در حال جستجوی حریف...', textAlign: TextAlign.center, style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                      const SizedBox(height: 10),
                      Text('$_displayedRemaining ثانیه', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AppPalette.muted)),
                      if (_weakConnection) ...[
                        const SizedBox(height: 16),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                          decoration: BoxDecoration(color: AppPalette.amber.withOpacity(.10), borderRadius: BorderRadius.circular(16)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.wifi_off_rounded, size: 19, color: AppPalette.amber),
                              const SizedBox(width: 7),
                              const Flexible(child: Text('اتصال ضعیف است', style: TextStyle(fontWeight: FontWeight.w900, color: AppPalette.amber))),
                              const SizedBox(width: 4),
                              TextButton(onPressed: _checking ? null : _retryConnectionNow, child: const Text('تلاش دوباره')),
                            ],
                          ),
                        ),
                      ],
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        height: 54,
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(
                            backgroundColor: AppPalette.coral,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                          ),
                          onPressed: _cancelling ? null : _cancelAndPop,
                          icon: _cancelling
                              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                              : const Icon(Icons.close_rounded),
                          label: const Text('انصراف', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class OnlineMatchExamScreen extends StatefulWidget {
  const OnlineMatchExamScreen({super.key,required this.initial,required this.user});final OnlineMatchState initial;final AppUser user;
  @override State<OnlineMatchExamScreen> createState()=>_OnlineMatchExamScreenState();
}
class _OnlineMatchExamScreenState extends State<OnlineMatchExamScreen> with WidgetsBindingObserver {
  late OnlineMatchState match;late Map<String,int> answers;final Map<String,int> versions={};final Set<String> pending={};Timer? tickTimer;Timer? syncTimer;final Stopwatch clock=Stopwatch();int anchor=0;bool online=true;bool finishing=false;bool expired=false;
  @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);match=widget.initial;answers=Map<String,int>.from(match.answers);_anchor(match.serverNow);tickTimer=Timer.periodic(const Duration(seconds:1),(_)=>_tick());syncTimer=Timer.periodic(const Duration(seconds:5),(_)=>_sync());}
  @override void dispose(){tickTimer?.cancel();syncTimer?.cancel();clock.stop();WidgetsBinding.instance.removeObserver(this);super.dispose();}
  @override void didChangeAppLifecycleState(AppLifecycleState state){if(state==AppLifecycleState.resumed)_sync();}
  void _anchor(int v){anchor=v;clock..reset()..start();}
  int get now=>anchor+clock.elapsed.inSeconds;int get remaining=>max(0,match.endAt-now);int get countdown=>max(0,match.startAt-now);int get answered=>answers.values.where((v)=>v>=0).length;
  String _tm(int s)=>'${(s~/60).toString().padLeft(2,'0')}:${(s%60).toString().padLeft(2,'0')}';
  void _tick(){if(!mounted)return;if(now>=match.endAt&&!expired){expired=true;finishing=true;setState((){});_expire();return;}setState((){});}
  Future<void> _select(QuizQuestion q,int v) async {if(finishing||now>=match.endAt)return;final ver=DateTime.now().microsecondsSinceEpoch;setState((){answers[q.id]=v;versions[q.id]=ver;pending.add(q.id);});await _syncOne(q.id);}
  Future<void> _syncOne(String qid) async {if(!pending.contains(qid)||now>=match.endAt)return;final ver=versions[qid]??DateTime.now().microsecondsSinceEpoch;try{final d=await OnlineMatchApi.request('online.match.answer',{'matchId':match.matchId,'questionId':qid,'selectedIndex':answers[qid]??-1,'version':ver},timeout:const Duration(seconds:5));if((versions[qid]??0)==ver)pending.remove(qid);final sn=(d['serverNow'] as num?)?.toInt();if(sn!=null)_anchor(sn);if(mounted&&!online)setState(()=>online=true);}catch(_){if(mounted&&online)setState(()=>online=false);}}
  Future<void> _sync() async {if(finishing||!mounted||ModalRoute.of(context)?.isCurrent!=true||now>=match.endAt)return;if(pending.isNotEmpty){for(final q in List<String>.from(pending)){if(now>=match.endAt)break;await _syncOne(q);}return;}try{final d=await OnlineMatchApi.request('online.match.status',{'matchId':match.matchId},timeout:const Duration(seconds:5));final raw=d['match'];if(raw is Map){match=OnlineMatchState.fromJson(Map<String,dynamic>.from(raw));_anchor(match.serverNow);}if(mounted&&!online)setState(()=>online=true);}catch(_){if(mounted&&online)setState(()=>online=false);}}
  List<Map<String,dynamic>> _payload()=>answers.entries.map((e)=>{'questionId':e.key,'selectedIndex':e.value,'version':versions[e.key]??DateTime.now().microsecondsSinceEpoch}).toList();
  Future<void> _finish() async {if(finishing)return;final un=max(0,match.questions.length-answered);final ok=await showClassQuizConfirm(context,title:'پایان مسابقه',message:un>0?'$un سؤال بدون پاسخ داری و غلط محسوب می‌شوند. مطمئنی پایان می‌دهی؟':'پاسخ‌ها بعد از پایان قفل می‌شوند. مطمئنی پایان می‌دهی؟',confirmLabel:'پایان');if(!ok||!mounted)return;setState(()=>finishing=true);if(now<match.endAt)for(final q in List<String>.from(pending)){if(now>=match.endAt)break;await _syncOne(q);}try{final d=await OnlineMatchApi.request('online.match.finish',{'matchId':match.matchId,'answers':now<match.endAt?_payload():const <Map<String,dynamic>>[]},timeout:const Duration(seconds:10));final raw=d['match'];if(raw is! Map)throw const GaminoApiException('نتیجه دریافت نشد.');final next=OnlineMatchState.fromJson(Map<String,dynamic>.from(raw));await gaminoAppKey.currentState?.refreshLearningContent();if(!mounted)return;Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>OnlineMatchResultScreen(matchId:next.matchId,user:widget.user,initial:next)));}catch(e){if(mounted){setState(()=>finishing=false);await showClassQuizErrorDialog(context,e);}}}
  Future<void> _expire() async {try{final d=await OnlineMatchApi.request('online.match.status',{'matchId':match.matchId},timeout:const Duration(seconds:8));final raw=d['match'];if(raw is! Map)throw const GaminoApiException('نتیجه دریافت نشد.');final next=OnlineMatchState.fromJson(Map<String,dynamic>.from(raw));await gaminoAppKey.currentState?.refreshLearningContent();if(mounted)Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>OnlineMatchResultScreen(matchId:next.matchId,user:widget.user,initial:next)));}catch(e){if(mounted){setState(()=>finishing=false);await showClassQuizErrorDialog(context,e);}}}
  @override Widget build(BuildContext context){if(countdown>0)return Scaffold(body:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[const Text('آماده باش',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:12),Text('$countdown',style:const TextStyle(fontSize:72,fontWeight:FontWeight.w900,color:AppPalette.mint))])));return Scaffold(appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('مسابقه با ${match.opponent.name}',style:const TextStyle(fontSize:16,fontWeight:FontWeight.w900)),Text('${_tm(remaining)} • پاسخ داده‌شده $answered از ${match.questions.length}',style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700))]),actions:[Padding(padding:const EdgeInsets.symmetric(horizontal:10),child:Center(child:Text(online?'همگام شد':'آفلاین',style:TextStyle(fontSize:12,fontWeight:FontWeight.w900,color:online?AppPalette.mint:AppPalette.amber))))]),body:Stack(children:[ListView.builder(padding:const EdgeInsets.fromLTRB(14,12,14,110),itemCount:match.questions.length+1,itemBuilder:(context,index){if(index==match.questions.length)return Padding(padding:const EdgeInsets.only(top:8),child:FilledButton(onPressed:finishing?null:_finish,child:const Text('پایان مسابقه')));final q=match.questions[index];final selected=answers[q.id]??-1;return Card(margin:const EdgeInsets.only(bottom:12),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('سؤال ${index+1} • ${q.subject}',style:const TextStyle(color:AppPalette.primary,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(q.text,style:const TextStyle(fontSize:16,height:1.7,fontWeight:FontWeight.w800)),const SizedBox(height:8),...List.generate(4,(i)=>RadioListTile<int>(value:i,groupValue:selected>=0?selected:null,onChanged:finishing?null:(v){if(v!=null)_select(q,v);},title:Text(q.options[i],style:const TextStyle(fontWeight:FontWeight.w700)),contentPadding:EdgeInsets.zero))])));}),if(finishing)Positioned.fill(child:ColoredBox(color:Colors.black.withOpacity(.18),child:const Center(child:CircularProgressIndicator()))) ]));}
}

class OnlineMatchResultScreen extends StatefulWidget {
  const OnlineMatchResultScreen({super.key,required this.matchId,required this.user,this.initial});final String matchId;final AppUser user;final OnlineMatchState? initial;
  @override State<OnlineMatchResultScreen> createState()=>_OnlineMatchResultScreenState();
}
class _OnlineMatchResultScreenState extends State<OnlineMatchResultScreen>{OnlineMatchState? match;Timer? poll;bool loading=false;
  @override void initState(){super.initState();match=widget.initial;_refresh();if(match?.isFinal!=true)poll=Timer.periodic(const Duration(seconds:5),(_)=>_refresh());}
  @override void dispose(){poll?.cancel();super.dispose();}
  Future<void> _refresh() async {if(loading)return;loading=true;try{final d=await OnlineMatchApi.request('online.match.status',{'matchId':widget.matchId},timeout:const Duration(seconds:6));final raw=d['match'];if(raw is Map&&mounted){final next=OnlineMatchState.fromJson(Map<String,dynamic>.from(raw));setState(()=>match=next);if(next.isFinal){poll?.cancel();await gaminoAppKey.currentState?.refreshLearningContent();}}}catch(_){}finally{loading=false;}}
  String _time(int s)=>'${s~/60}:${(s%60).toString().padLeft(2,'0')}';
  Future<void> _openOpponent() async {final m=match;if(m==null||m.opponent.userId.isEmpty)return;await Navigator.push(context,MaterialPageRoute(builder:(_)=>PublicStudentProfileScreen(row:m.opponent.asLeader(m.grade),currentUser:widget.user)));}
  @override Widget build(BuildContext context){final m=match;if(m==null)return const Scaffold(body:Center(child:CircularProgressIndicator()));final r=m.result;return Scaffold(appBar:AppBar(title:const Text('نتیجه مسابقه')),body:ListView(padding:const EdgeInsets.all(16),children:[Row(children:[Expanded(child:_OnlineProfileTile(profile:m.me,label:'من')),const SizedBox(width:10),Expanded(child:InkWell(onTap:_openOpponent,borderRadius:BorderRadius.circular(20),child:_OnlineProfileTile(profile:m.opponent,label:'حریف')))]),const SizedBox(height:14),Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[Text(m.isFinal?(r?.isWin==true?'برد':r?.isLoss==true?'باخت':'مساوی'):'در انتظار پایان حریف',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900,color:m.isFinal?(r?.isWin==true?AppPalette.mint:r?.isLoss==true?AppPalette.coral:AppPalette.ink):AppPalette.amber)),const SizedBox(height:10),if(r!=null)...[Text('${r.correct} درست • ${r.wrong} غلط',style:const TextStyle(fontWeight:FontWeight.w800)),Text('زمان پایان شما: ${_time(r.finishDuration)}',style:const TextStyle(color:AppPalette.muted,fontWeight:FontWeight.w700)),if(m.opponentResult!=null)Text('زمان پایان حریف: ${_time(m.opponentResult!.finishDuration)}',style:const TextStyle(color:AppPalette.muted,fontWeight:FontWeight.w700)),if(m.isFinal)Text(r.cupDelta==0?'بدون تغییر کاپ':signedCupText(r.cupDelta),style:TextStyle(fontWeight:FontWeight.w900,color:r.cupDelta>0?AppPalette.mint:r.cupDelta<0?AppPalette.coral:AppPalette.muted))],if(!m.opponentFinished)const Padding(padding:EdgeInsets.only(top:8),child:Text('بازی حریف در حال انجام است',style:TextStyle(color:AppPalette.amber,fontWeight:FontWeight.w800))) ]))),const SizedBox(height:12),FilledButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>OnlineMatchAnalysisScreen(matchId:m.matchId))),child:const Text('تحلیل بازی'))]));}
}
class _OnlineProfileTile extends StatelessWidget {const _OnlineProfileTile({required this.profile,required this.label});final OnlineMatchProfile profile;final String label;@override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(20)),child:Column(children:[SizedBox(width:54,height:54,child:avatarImageForTitle(profile.avatar,fit:BoxFit.contain,remoteUrl:profile.avatarUrl)),const SizedBox(height:7),Text(profile.name,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w900)),Text(label,style:const TextStyle(fontSize:12,color:AppPalette.muted,fontWeight:FontWeight.w700))]));}

class OnlineMatchAnalysisScreen extends StatefulWidget {const OnlineMatchAnalysisScreen({super.key,required this.matchId});final String matchId;@override State<OnlineMatchAnalysisScreen> createState()=>_OnlineMatchAnalysisScreenState();}
class _OnlineMatchAnalysisScreenState extends State<OnlineMatchAnalysisScreen>{Map<String,dynamic>? data;Object? error;@override void initState(){super.initState();_load();}Future<void> _load()async{try{final d=await OnlineMatchApi.request('online.match.analysis',{'matchId':widget.matchId});if(mounted)setState(()=>data=Map<String,dynamic>.from(d['analysis'] as Map? ?? const {}));}catch(e){if(mounted)setState(()=>error=e);}}
  @override Widget build(BuildContext context){if(data==null&&error==null)return const Scaffold(body:Center(child:CircularProgressIndicator()));if(error!=null)return Scaffold(appBar:AppBar(title:const Text('تحلیل بازی')),body:Center(child:FilledButton(onPressed:(){setState((){error=null;data=null;});_load();},child:const Text('تلاش دوباره'))));final d=data!;final qs=(d['questions'] as List? ?? []).whereType<Map>().map((e)=>QuizQuestion.fromJson(Map<String,dynamic>.from(e))).toList();final me=Map<String,dynamic>.from(d['me'] as Map? ?? const {});final oppRaw=d['opponent'];final opp=oppRaw is Map?Map<String,dynamic>.from(oppRaw):null;return DefaultTabController(length:2,child:Scaffold(appBar:AppBar(title:const Text('تحلیل بازی'),bottom:const TabBar(tabs:[Tab(text:'من'),Tab(text:'حریف')])),body:TabBarView(children:[_AnalysisList(questions:qs,result:me),opp==null?const Center(child:Text('بازی در حال انجام است',style:TextStyle(fontWeight:FontWeight.w900,color:AppPalette.amber))):_AnalysisList(questions:qs,result:opp)])));}
}
class _AnalysisList extends StatelessWidget {const _AnalysisList({required this.questions,required this.result});final List<QuizQuestion> questions;final Map<String,dynamic> result;@override Widget build(BuildContext context){final ans=Map<String,dynamic>.from(result['answers'] as Map? ?? const {});return ListView(padding:const EdgeInsets.all(14),children:[Text('${(result['correct'] as num?)?.toInt()??0} درست • ${(result['wrong'] as num?)?.toInt()??0} غلط',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:10),...questions.asMap().entries.map((e){final q=e.value;final sel=(ans[q.id] as num?)?.toInt()??-1;final good=sel==q.correctIndex;return Card(color:good?const Color(0xFFEAFBF0):const Color(0xFFFFECEC),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('سؤال ${e.key+1}',style:TextStyle(fontWeight:FontWeight.w900,color:good?AppPalette.mint:AppPalette.coral)),const SizedBox(height:6),Text(q.text,style:const TextStyle(fontWeight:FontWeight.w800,height:1.6)),const SizedBox(height:6),Text(sel>=0?'پاسخ شما: ${q.options[sel]}':'بدون پاسخ'),Text('پاسخ درست: ${q.options[q.correctIndex]}',style:const TextStyle(fontWeight:FontWeight.w800))])));})]);}}

class ExamBuilderPanel extends StatefulWidget {
  const ExamBuilderPanel({super.key, required this.user, required this.books, required this.onQuizFinished});
  final AppUser user;
  final List<LearningBook> books;
  final void Function(QuizResult result) onQuizFinished;

  @override
  State<ExamBuilderPanel> createState() => _ExamBuilderPanelState();
}

class _ExamBuilderPanelState extends State<ExamBuilderPanel> {
  final Set<String> selectedBookIds = <String>{};
  bool _selectionInitialized = false;
  int questionCount = 10;

  List<LearningBook> get gradeBooks => widget.books
      .where((b) =>
          b.grade == widget.user.grade &&
          (widget.user.grade < 10 ||
              normalizeEducationTrack(b.grade, b.track) ==
                  normalizeEducationTrack(widget.user.grade, widget.user.educationTrack)))
      .toList();

  void _syncSelection(List<LearningBook> books) {
    final available = books.map((b) => b.id).toSet();
    selectedBookIds.removeWhere((id) => !available.contains(id));
    if (!_selectionInitialized) {
      selectedBookIds
        ..clear()
        ..addAll(available);
      _selectionInitialized = true;
    }
  }

  List<QuizQuestion> _buildBalancedQuestions(List<LearningBook> books) {
    final selectedBooks = books.where((b) => selectedBookIds.contains(b.id)).toList();
    if (selectedBooks.isEmpty) return const <QuizQuestion>[];

    final random = Random();
    final pools = <List<QuizQuestion>>[];
    for (final book in selectedBooks) {
      final localIds = <String>{};
      final pool = <QuizQuestion>[];
      for (final lesson in book.lessons) {
        for (final question in lesson.questions) {
          if (question.id.trim().isNotEmpty && localIds.add(question.id)) {
            pool.add(question);
          }
        }
      }
      pool.shuffle(random);
      pools.add(pool);
    }

    final positions = List<int>.filled(pools.length, 0);
    final globallyUsed = <String>{};
    final result = <QuizQuestion>[];
    while (result.length < questionCount) {
      var addedInRound = false;
      for (var i = 0; i < pools.length && result.length < questionCount; i++) {
        final pool = pools[i];
        while (positions[i] < pool.length && globallyUsed.contains(pool[positions[i]].id)) {
          positions[i]++;
        }
        if (positions[i] >= pool.length) continue;
        final question = pool[positions[i]++];
        if (globallyUsed.add(question.id)) {
          result.add(question);
          addedInRound = true;
        }
      }
      if (!addedInRound) break;
    }
    return result;
  }

  int get _timeLimitSeconds => questionCount == 10 ? 900 : questionCount == 20 ? 1800 : 2700;

  Future<void> _startExam(List<LearningBook> books) async {
    final questions = _buildBalancedQuestions(books);
    if (questions.isEmpty) return;

    if (questions.length < questionCount) {
      final proceed = await showClassQuizConfirm(
        context,
        title: 'تعداد سؤال محدود است',
        message:
            'از ${faNumber(questionCount)} سؤال درخواستی، ${faNumber(questions.length)} سؤال غیرتکراری در کتاب‌های انتخاب‌شده موجود است. آزمون با همین تعداد شروع شود؟',
        confirmLabel: 'شروع آزمون',
      );
      if (!proceed || !mounted) return;
    }

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PracticeAllQuestionsScreen(
          title: 'آزمون‌ساز شخصی',
          questions: questions,
          timeLimitSeconds: _timeLimitSeconds,
          userGrade: widget.user.grade,
          onComplete: widget.onQuizFinished,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final books = gradeBooks;
    _syncSelection(books);
    final allSelected = books.isNotEmpty && selectedBookIds.length == books.length;
    final availableQuestionCount = _buildBalancedQuestions(books).length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const InfoBox(
          title: 'آزمون‌ساز شخصی',
          body: 'کتاب‌ها را انتخاب کن و یک آزمون تمرینی بساز.',
          icon: Icons.tune_outlined,
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                CheckboxListTile(
                  value: allSelected,
                  controlAffinity: ListTileControlAffinity.leading,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                  title: const Text('همه کتاب‌ها', style: TextStyle(fontWeight: FontWeight.w900)),
                  subtitle: Text('${selectedBookIds.length} از ${books.length} کتاب انتخاب شده'),
                  onChanged: books.isEmpty
                      ? null
                      : (value) => setState(() {
                            if (value == true) {
                              selectedBookIds
                                ..clear()
                                ..addAll(books.map((b) => b.id));
                            } else {
                              selectedBookIds.clear();
                            }
                          }),
                ),
                const Divider(height: 1),
                ...books.map(
                  (book) => CheckboxListTile(
                    value: selectedBookIds.contains(book.id),
                    controlAffinity: ListTileControlAffinity.leading,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                    title: Text(book.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                    onChanged: (value) => setState(() {
                      if (value == true) {
                        selectedBookIds.add(book.id);
                      } else {
                        selectedBookIds.remove(book.id);
                      }
                    }),
                  ),
                ),
                if (books.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(12),
                    child: Text('برای پایه شما هنوز کتابی ثبت نشده است.', textAlign: TextAlign.center),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<int>(
          value: questionCount,
          decoration: InputDecoration(
            labelText: 'تعداد سؤال',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
          ),
          items: const [
            DropdownMenuItem(value: 10, child: Text('۱۰ سؤال • ۱۵ دقیقه')),
            DropdownMenuItem(value: 20, child: Text('۲۰ سؤال • ۳۰ دقیقه')),
            DropdownMenuItem(value: 30, child: Text('۳۰ سؤال • ۴۵ دقیقه')),
          ],
          onChanged: (value) => setState(() => questionCount = value ?? 10),
        ),
        const SizedBox(height: 10),
        Text(
          selectedBookIds.isEmpty
              ? 'حداقل یک کتاب را انتخاب کن.'
              : 'سؤال‌های غیرتکراری آماده: $availableQuestionCount',
          textAlign: TextAlign.center,
          style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: selectedBookIds.isEmpty || availableQuestionCount == 0 ? null : () => _startExam(books),
          child: const Text('شروع آزمون'),
        ),
      ],
    );
  }
}

class ExamBuilderMistakesScreen extends StatelessWidget {
  const ExamBuilderMistakesScreen({
    super.key,
    required this.result,
    required this.userGrade,
    required this.onComplete,
  });

  final QuizResult result;
  final int userGrade;
  final void Function(QuizResult result) onComplete;

  int _questionNumber(WrongAnswer wrong) {
    final index = result.questions.indexWhere((question) => question.id == wrong.question.id);
    return index < 0 ? 1 : index + 1;
  }

  String _selectedAnswer(WrongAnswer wrong) {
    final index = wrong.selectedIndex;
    if (index < 0 || index >= wrong.question.options.length) return 'بدون پاسخ';
    return wrong.question.options[index];
  }

  Future<void> _practiceAgain(BuildContext context) async {
    final questions = result.wrongAnswers.map((wrong) => wrong.question).toList();
    if (questions.isEmpty) return;
    final seconds = max(300, questions.length * 90);
    await Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => PracticeAllQuestionsScreen(
          title: 'تمرین دوباره اشتباهات',
          questions: questions,
          timeLimitSeconds: seconds,
          userGrade: userGrade,
          onComplete: onComplete,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final wrongs = result.wrongAnswers;
    return Scaffold(
      appBar: AppBar(title: const Text('اشتباهات من')),
      body: wrongs.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.check_circle_rounded, size: 72, color: AppPalette.mint),
                    const SizedBox(height: 14),
                    const Text('همه پاسخ‌ها درست بود', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 18),
                    FilledButton(onPressed: () => Navigator.pop(context), child: const Text('بازگشت')),
                  ],
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
              children: [
                ...wrongs.map((wrong) {
                  final q = wrong.question;
                  final number = _questionNumber(wrong);
                  return Card(
                    margin: const EdgeInsets.only(bottom: 14),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(q.subject, style: const TextStyle(color: AppPalette.primary, fontWeight: FontWeight.w900)),
                              ),
                              Text('سؤال $number', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800)),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(q.text, style: const TextStyle(fontSize: 16, height: 1.7, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFEEEE),
                              border: Border.all(color: const Color(0xFFFFB4B4)),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('پاسخ شما', style: TextStyle(color: AppPalette.coral, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 5),
                                Text(_selectedAnswer(wrong), style: const TextStyle(fontWeight: FontWeight.w800)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: const Color(0xFFEAFBF0),
                              border: Border.all(color: const Color(0xFF9BE7B0)),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('پاسخ درست', style: TextStyle(color: AppPalette.mint, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 5),
                                Text(q.options[q.correctIndex], style: const TextStyle(fontWeight: FontWeight.w800)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
                FilledButton(
                  onPressed: () => _practiceAgain(context),
                  child: const Text('تمرین دوباره اشتباهات'),
                ),
                const SizedBox(height: 8),
                OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('بازگشت')),
              ],
            ),
    );
  }
}

class PracticeAllQuestionsScreen extends StatefulWidget {
  const PracticeAllQuestionsScreen({
    super.key,
    required this.title,
    required this.questions,
    required this.timeLimitSeconds,
    required this.userGrade,
    required this.onComplete,
  });
  final String title;
  final List<QuizQuestion> questions;
  final int timeLimitSeconds;
  final int userGrade;
  final void Function(QuizResult result) onComplete;

  @override
  State<PracticeAllQuestionsScreen> createState() => _PracticeAllQuestionsScreenState();
}

class _PracticeAllQuestionsScreenState extends State<PracticeAllQuestionsScreen> {
  final Map<String, int> answers = {};
  Timer? timer;
  late int remaining;
  bool done = false;

  @override
  void initState() {
    super.initState();
    remaining = widget.timeLimitSeconds;
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || done) return;
      if (remaining <= 1) {
        _finish(skipConfirm: true);
      } else {
        setState(() => remaining--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  String _tm(int seconds) =>
      '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';

  Future<void> _finish({bool skipConfirm = false}) async {
    if (done) return;
    final unanswered = max(0, widget.questions.length - answers.values.where((value) => value >= 0).length);
    if (!skipConfirm) {
      final ok = await showClassQuizConfirm(
        context,
        title: 'پایان آزمون',
        message: unanswered > 0
            ? '${faNumber(unanswered)} سؤال بدون پاسخ داری و غلط محسوب می‌شوند. پایان بدهی؟'
            : 'آزمون پایان داده شود؟',
        confirmLabel: 'پایان',
      );
      if (!ok) return;
    }

    done = true;
    timer?.cancel();
    final wrong = <WrongAnswer>[];
    var correct = 0;
    for (final question in widget.questions) {
      final selected = answers[question.id] ?? -1;
      if (selected == question.correctIndex) {
        correct++;
      } else {
        wrong.add(WrongAnswer(question: question, selectedIndex: selected));
      }
    }
    final allAnswers = <String, int>{
      for (final question in widget.questions) question.id: answers[question.id] ?? -1,
    };
    final result = QuizResult(
      questions: widget.questions,
      correctAnswers: correct,
      totalQuestions: widget.questions.length,
      xpEarned: 0,
      coinsEarned: 0,
      wrongAnswers: wrong,
      answers: allAnswers,
      quizSource: 'exam_builder',
    );
    widget.onComplete(result);
    if (!mounted) return;
    await Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ExamBuilderMistakesScreen(
          result: result,
          userGrade: widget.userGrade,
          onComplete: widget.onComplete,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, result) {
          if (!didPop) _finish();
        },
        child: Scaffold(
          appBar: AppBar(
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                Text(
                  '${_tm(remaining)} • پاسخ داده‌شده ${answers.length} از ${widget.questions.length}',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          body: ListView.builder(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 110),
            itemCount: widget.questions.length + 1,
            itemBuilder: (context, index) {
              if (index == widget.questions.length) {
                return FilledButton(onPressed: _finish, child: const Text('پایان آزمون'));
              }
              final question = widget.questions[index];
              final selected = answers[question.id] ?? -1;
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'سؤال ${index + 1} • ${question.subject}',
                        style: const TextStyle(color: AppPalette.primary, fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        question.text,
                        style: const TextStyle(fontSize: 16, height: 1.7, fontWeight: FontWeight.w800),
                      ),
                      ...List.generate(
                        question.options.length,
                        (i) => RadioListTile<int>(
                          value: i,
                          groupValue: selected >= 0 ? selected : null,
                          onChanged: (value) {
                            if (value != null) setState(() => answers[question.id] = value);
                          },
                          title: Text(question.options[i]),
                          contentPadding: EdgeInsets.zero,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      );
}


class ClassQuizMember {
  const ClassQuizMember({
    required this.userId,
    required this.name,
    required this.avatarUrl,
    required this.isOwner,
    required this.online,
    required this.connectionQuality,
  });
  final String userId;
  final String name;
  final String avatarUrl;
  final bool isOwner;
  final bool online;
  final String connectionQuality;

  bool get connectionGood => connectionQuality == 'good';
  bool get connectionWeak => connectionQuality == 'weak';
  bool get connectionOffline => connectionQuality == 'offline';

  factory ClassQuizMember.fromJson(Map<String, dynamic> json) {
    final rawQuality = json['connectionQuality']?.toString();
    final quality = rawQuality == 'good' || rawQuality == 'weak' || rawQuality == 'offline'
        ? rawQuality!
        : (json['online'] == true ? 'good' : 'offline');
    return ClassQuizMember(
      userId: json['userId']?.toString() ?? '',
      name: json['name']?.toString() ?? 'دانش‌آموز',
      avatarUrl: json['avatarUrl']?.toString() ?? '',
      isOwner: json['isOwner'] == true,
      online: quality != 'offline',
      connectionQuality: quality,
    );
  }
}

class ClassQuizBookRef {
  const ClassQuizBookRef({required this.id, required this.title});
  final String id;
  final String title;
  factory ClassQuizBookRef.fromJson(Map<String, dynamic> json) => ClassQuizBookRef(id: json['id']?.toString() ?? '', title: json['title']?.toString() ?? 'کتاب');
}

class ClassQuizRoomState {
  const ClassQuizRoomState({
    required this.roomId,
    required this.matchId,
    required this.code,
    required this.name,
    required this.grade,
    required this.status,
    required this.isOwner,
    required this.hasPassword,
    required this.memberCount,
    required this.members,
    required this.books,
    required this.questionCountRequested,
    required this.actualQuestionCount,
    required this.startAt,
    required this.endAt,
    required this.serverNow,
    required this.questions,
    required this.answers,
    required this.attemptFinished,
  });

  final String roomId;
  final String matchId;
  final String code;
  final String name;
  final int grade;
  final String status;
  final bool isOwner;
  final bool hasPassword;
  final int memberCount;
  final List<ClassQuizMember> members;
  final List<ClassQuizBookRef> books;
  final int questionCountRequested;
  final int actualQuestionCount;
  final int startAt;
  final int endAt;
  final int serverNow;
  final List<QuizQuestion> questions;
  final Map<String, int> answers;
  final bool attemptFinished;

  bool get isWaiting => status == 'waiting';
  bool get isStarted => status == 'countdown' || status == 'running';

  factory ClassQuizRoomState.fromJson(Map<String, dynamic> json) {
    final rawAnswersValue = json['answers'];
    final rawAnswers = rawAnswersValue is Map
        ? Map<String, dynamic>.from(rawAnswersValue)
        : <String, dynamic>{};
    return ClassQuizRoomState(
      roomId: json['roomId']?.toString() ?? '',
      matchId: json['matchId']?.toString() ?? json['roomId']?.toString() ?? '',
      code: json['code']?.toString() ?? '',
      name: json['name']?.toString() ?? 'اتاق',
      grade: (json['grade'] as num?)?.toInt() ?? 1,
      status: json['status']?.toString() ?? 'waiting',
      isOwner: json['isOwner'] == true,
      hasPassword: json['hasPassword'] == true,
      memberCount: (json['memberCount'] as num?)?.toInt() ?? 0,
      members: (json['members'] as List? ?? []).whereType<Map>().map((e) => ClassQuizMember.fromJson(Map<String, dynamic>.from(e))).toList(),
      books: (json['books'] as List? ?? []).whereType<Map>().map((e) => ClassQuizBookRef.fromJson(Map<String, dynamic>.from(e))).toList(),
      questionCountRequested: (json['questionCountRequested'] as num?)?.toInt() ?? 10,
      actualQuestionCount: (json['actualQuestionCount'] as num?)?.toInt() ?? 0,
      startAt: (json['startAt'] as num?)?.toInt() ?? 0,
      endAt: (json['endAt'] as num?)?.toInt() ?? 0,
      serverNow: (json['serverNow'] as num?)?.toInt() ?? (DateTime.now().millisecondsSinceEpoch ~/ 1000),
      questions: (json['questions'] as List? ?? []).whereType<Map>().map((e) => QuizQuestion.fromJson(Map<String, dynamic>.from(e))).toList(),
      answers: rawAnswers.map((key, value) => MapEntry(key, (value as num?)?.toInt() ?? -1)),
      attemptFinished: json['attemptFinished'] == true,
    );
  }
}

class ClassQuizRandomRoom {
  const ClassQuizRandomRoom({required this.roomId, required this.code, required this.name, required this.memberCount, required this.hasPassword});
  final String roomId;
  final String code;
  final String name;
  final int memberCount;
  final bool hasPassword;
  factory ClassQuizRandomRoom.fromJson(Map<String, dynamic> json) => ClassQuizRandomRoom(
        roomId: json['roomId']?.toString() ?? '',
        code: json['code']?.toString() ?? '',
        name: json['name']?.toString() ?? 'اتاق',
        memberCount: (json['memberCount'] as num?)?.toInt() ?? 0,
        hasPassword: json['hasPassword'] == true,
      );
}

class ClassQuizRankRow {
  const ClassQuizRankRow({required this.userId, required this.name, required this.avatarUrl, required this.correct, required this.wrong, required this.total, required this.rank, required this.finishOrder});
  final String userId;
  final String name;
  final String avatarUrl;
  final int correct;
  final int wrong;
  final int total;
  final int rank;
  final int finishOrder;
  factory ClassQuizRankRow.fromJson(Map<String, dynamic> json) => ClassQuizRankRow(
        userId: json['userId']?.toString() ?? '',
        name: json['name']?.toString() ?? 'دانش‌آموز',
        avatarUrl: json['avatarUrl']?.toString() ?? '',
        correct: (json['correct'] as num?)?.toInt() ?? 0,
        wrong: (json['wrong'] as num?)?.toInt() ?? 0,
        total: (json['total'] as num?)?.toInt() ?? 0,
        rank: (json['rank'] as num?)?.toInt() ?? 0,
        finishOrder: (json['finishOrder'] as num?)?.toInt() ?? 0,
      );
}

class ClassQuizRankingState {
  const ClassQuizRankingState({required this.matchId, required this.isFinal, required this.rows});
  final String matchId;
  final bool isFinal;
  final List<ClassQuizRankRow> rows;
  factory ClassQuizRankingState.fromJson(Map<String, dynamic> json) => ClassQuizRankingState(
        matchId: json['matchId']?.toString() ?? '',
        isFinal: json['final'] == true,
        rows: (json['rows'] as List? ?? []).whereType<Map>().map((e) => ClassQuizRankRow.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}

class ClassQuizApi {
  static Future<Map<String, dynamic>> request(String action, Map<String, dynamic> body, {Duration timeout = const Duration(seconds: 18)}) async {
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) throw const GaminoApiException('برای ادامه وارد حساب شوید.');
    return GaminoApiService.request(action, token: token, body: body, timeout: timeout);
  }

  static ClassQuizRoomState roomFromPayload(Map<String, dynamic> payload) {
    final raw = payload['room'];
    if (raw is! Map) throw const GaminoApiException('اطلاعات اتاق دریافت نشد.');
    return ClassQuizRoomState.fromJson(Map<String, dynamic>.from(raw));
  }
}

class _ClassQuizDialogFrame extends StatelessWidget {
  const _ClassQuizDialogFrame({required this.icon, required this.title, required this.child, required this.actions});
  final IconData icon;
  final String title;
  final Widget child;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final actionChildren = <Widget>[];
    for (var i = 0; i < actions.length; i++) {
      if (i > 0) actionChildren.add(const SizedBox(width: 10));
      actionChildren.add(Expanded(child: SizedBox(height: 48, child: actions[i])));
    }
    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 460),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.10), borderRadius: BorderRadius.circular(18)),
                child: Icon(icon, color: AppPalette.primary, size: 28),
              ),
              const SizedBox(height: 14),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              child,
              const SizedBox(height: 18),
              Row(children: actionChildren),
            ],
          ),
        ),
      ),
    );
  }
}

Future<bool> showClassQuizConfirm(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'تأیید',
  IconData icon = Icons.help_outline_rounded,
  bool destructive = false,
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => _ClassQuizDialogFrame(
      icon: icon,
      title: title,
      child: Text(message, textAlign: TextAlign.center, style: const TextStyle(height: 1.75, fontWeight: FontWeight.w700, color: AppPalette.muted)),
      actions: [
        OutlinedButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
        FilledButton(
          style: destructive ? FilledButton.styleFrom(backgroundColor: AppPalette.coral) : null,
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result == true;
}

Future<bool> showClassQuizJoinConfirm(BuildContext context) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 34, vertical: 24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: AppPalette.primary.withOpacity(.09),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.login_rounded, color: AppPalette.primary, size: 23),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'ورود به اتاق',
                      textAlign: TextAlign.right,
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              const Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'می‌خواهی وارد این اتاق شوی؟',
                  style: TextStyle(fontSize: 14.5, height: 1.6, fontWeight: FontWeight.w700, color: AppPalette.muted),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 46,
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('انصراف'),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: SizedBox(
                      height: 46,
                      child: FilledButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('ورود'),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ),
  );
  return result == true;
}

Future<void> showClassQuizErrorDialog(BuildContext context, Object error) async {
  if (!context.mounted) return;
  final apiError = error is GaminoApiException ? error : const GaminoApiException('عملیات انجام نشد. دوباره تلاش کنید.');
  final isNetwork = apiError.isNetwork;
  await showDialog<void>(
    context: context,
    builder: (ctx) => _ClassQuizDialogFrame(
      icon: isNetwork ? Icons.wifi_off_rounded : Icons.error_outline_rounded,
      title: isNetwork ? 'خطا در اتصال' : 'عملیات انجام نشد',
      child: Text(apiError.message, textAlign: TextAlign.center, style: const TextStyle(height: 1.75, fontWeight: FontWeight.w700, color: AppPalette.muted)),
      actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('باشه'))],
    ),
  );
}

Future<void> showClassQuizMessageDialog(BuildContext context, {required String title, required String message, IconData icon = Icons.info_outline_rounded}) async {
  if (!context.mounted) return;
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => _ClassQuizDialogFrame(
      icon: icon,
      title: title,
      child: Text(message, textAlign: TextAlign.center, style: const TextStyle(height: 1.75, fontWeight: FontWeight.w700, color: AppPalette.muted)),
      actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('باشه'))],
    ),
  );
}

Future<String?> showClassQuizPasswordDialog(BuildContext context) async {
  final controller = TextEditingController();
  final value = await showDialog<String>(
    context: context,
    builder: (ctx) => _ClassQuizDialogFrame(
      icon: Icons.lock_outline_rounded,
      title: 'رمز اتاق',
      child: TextField(
        controller: controller,
        autofocus: true,
        keyboardType: TextInputType.number,
        maxLength: 20,
        obscureText: true,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        decoration: const InputDecoration(labelText: 'رمز عددی', hintText: 'رمز اتاق را وارد کنید'),
      ),
      actions: [
        OutlinedButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('ادامه')),
      ],
    ),
  );
  controller.dispose();
  return value;
}

class _ClassQuizBusyOverlay extends StatelessWidget {
  const _ClassQuizBusyOverlay({this.label = 'در حال دریافت اطلاعات...'});
  final String label;
  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: Colors.black.withOpacity(.16),
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 20)]),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.6)),
              const SizedBox(width: 12),
              Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
            ]),
          ),
        ),
      ),
    );
  }
}

class FriendsQuizPanel extends StatefulWidget {
  const FriendsQuizPanel({
    super.key,
    required this.user,
    required this.books,
    required this.activeRoom,
    required this.onCreateRoom,
    required this.onJoinRoom,
    required this.onQuizFinished,
  });

  final AppUser user;
  final List<LearningBook> books;
  final QuizRoom? activeRoom;
  final void Function({required int maxPlayers, required String roomType}) onCreateRoom;
  final void Function(String code) onJoinRoom;
  final void Function(QuizResult result) onQuizFinished;

  @override
  State<FriendsQuizPanel> createState() => _FriendsQuizPanelState();
}

class _FriendsQuizPanelState extends State<FriendsQuizPanel> {
  final TextEditingController codeController = TextEditingController();
  bool busy = false;
  bool initialLoading = true;
  bool randomLoading = false;
  bool randomLoadedOnce = false;
  String busyLabel = 'در حال دریافت اطلاعات...';
  List<ClassQuizRandomRoom> randomRooms = const [];
  List<String> lastRandomRoomIds = const [];
  int randomRefreshRemaining = 0;
  Timer? randomCooldownTimer;

  List<LearningBook> get gradeBooks => widget.books.where((b) {
        if (b.grade != widget.user.grade) return false;
        if (widget.user.grade >= 10 && normalizeEducationTrack(b.grade, b.track) != normalizeEducationTrack(widget.user.grade, widget.user.educationTrack)) return false;
        return true;
      }).toList();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _resumeIfNeeded());
  }

  @override
  void dispose() {
    randomCooldownTimer?.cancel();
    codeController.dispose();
    super.dispose();
  }

  Future<void> _showError(Object error) async {
    if (!mounted) return;
    await showClassQuizErrorDialog(context, error);
  }

  Future<void> _resumeIfNeeded({bool showConnectionError = true}) async {
    if (!mounted || busy || ModalRoute.of(context)?.isCurrent != true) return;
    var shouldLoadRooms = false;
    setState(() => initialLoading = true);
    try {
      final payload = await ClassQuizApi.request('room.resume', const {}, timeout: const Duration(seconds: 7));
      final event = payload['event'];
      if (event is Map && (event['message']?.toString() ?? '').isNotEmpty && mounted) {
        await showClassQuizMessageDialog(
          context,
          title: 'وضعیت اتاق',
          message: event['message'].toString(),
          icon: Icons.info_outline_rounded,
        );
      }
      if (!mounted || ModalRoute.of(context)?.isCurrent != true) return;
      final raw = payload['room'];
      if (raw is Map) {
        final room = ClassQuizRoomState.fromJson(Map<String, dynamic>.from(raw));
        final type = payload['type']?.toString() ?? '';
        if (type == 'waiting') {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ClassQuizWaitingRoomScreen(
                user: widget.user,
                allBooks: gradeBooks,
                initialRoom: room,
              ),
            ),
          );
        } else if (type == 'exam') {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ClassQuizExamScreen(user: widget.user, initialRoom: room)),
          );
        }
      } else {
        shouldLoadRooms = true;
      }
    } catch (e) {
      if (showConnectionError && mounted) await _showError(e);
    } finally {
      if (mounted) setState(() => initialLoading = false);
    }
    if (shouldLoadRooms && mounted && ModalRoute.of(context)?.isCurrent == true) {
      await _loadRandom(refresh: false);
    }
  }

  Future<void> _createRoom() async {
    if (busy || initialLoading) return;
    if (gradeBooks.isEmpty) {
      await _showError(const GaminoApiException('برای پایه شما هنوز کتابی در پنل منتشر نشده است.'));
      return;
    }
    // Backend is the only source of truth. Before creating, resolve any real waiting room.
    setState(() { busy = true; busyLabel = 'در حال بررسی وضعیت اتاق...'; });
    try {
      final resume = await ClassQuizApi.request('room.resume', const {}, timeout: const Duration(seconds: 7));
      final raw = resume['room'];
      if (raw is Map && (resume['type']?.toString() ?? '') == 'waiting') {
        final existing = ClassQuizRoomState.fromJson(Map<String, dynamic>.from(raw));
        if (!mounted) return;
        setState(() => busy = false);
        await Navigator.push(context, MaterialPageRoute(builder: (_) => ClassQuizWaitingRoomScreen(user: widget.user, allBooks: gradeBooks, initialRoom: existing)));
        if (mounted) await _resumeIfNeeded(showConnectionError: false);
        return;
      }
    } catch (e) {
      if (mounted) setState(() => busy = false);
      if (mounted) await _showError(e);
      return;
    }
    if (mounted) setState(() => busy = false);

    final config = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => _ClassQuizRoomConfigDialog(books: gradeBooks, initialQuestionCount: 10, title: 'ساخت اتاق جدید'),
    );
    if (config == null || !mounted) return;
    final ok = await showClassQuizConfirm(context, title: 'ساخت اتاق', message: 'ساخت این اتاق ۵ کارت هزینه دارد. اتاق ساخته شود؟', confirmLabel: 'ساخت اتاق', icon: Icons.add_home_work_outlined);
    if (!ok || !mounted) return;
    setState(() { busy = true; busyLabel = 'در حال ساخت اتاق...'; });
    try {
      final payload = await ClassQuizApi.request('room.create', {
        ...config,
        'requestId': 'create_${DateTime.now().microsecondsSinceEpoch}_${Random.secure().nextInt(1 << 30)}',
      });
      final room = ClassQuizApi.roomFromPayload(payload);
      await gaminoAppKey.currentState?.refreshLearningContent();
      if (!mounted) return;
      setState(() => busy = false);
      await Navigator.push(context, MaterialPageRoute(builder: (_) => ClassQuizWaitingRoomScreen(user: widget.user, allBooks: gradeBooks, initialRoom: room)));
      if (mounted) await _resumeIfNeeded(showConnectionError: false);
    } catch (e) {
      if (mounted) setState(() => busy = false);
      if (mounted) await _showError(e);
    } finally {
      if (mounted && busy) setState(() => busy = false);
    }
  }

  Future<ClassQuizRoomState?> _joinCode(String code, {bool? knownHasPassword}) async {
    final clean = enDigits(code.trim());
    if (!RegExp(r'^\d{5}$').hasMatch(clean)) {
      await _showError(const GaminoApiException('کد اتاق باید ۵ رقمی باشد.'));
      return null;
    }
    String password = '';
    if (knownHasPassword == true) {
      final pass = await showClassQuizPasswordDialog(context);
      if (pass == null) return null;
      password = pass;
    }
    if (!mounted) return null;
    final confirm = await showClassQuizJoinConfirm(context);
    if (!confirm) return null;
    try {
      var payload = await ClassQuizApi.request('room.join', {'code': clean, if (password.isNotEmpty) 'password': password});
      return ClassQuizApi.roomFromPayload(payload);
    } on GaminoApiException catch (e) {
      if (knownHasPassword != true && e.message.contains('رمز اتاق')) {
        final pass = await showClassQuizPasswordDialog(context);
        if (pass == null) return null;
        final payload = await ClassQuizApi.request('room.join', {'code': clean, 'password': pass});
        return ClassQuizApi.roomFromPayload(payload);
      }
      rethrow;
    }
  }

  Future<void> _joinManual() async {
    if (busy) return;
    setState(() { busy = true; busyLabel = 'در حال ورود به اتاق...'; });
    try {
      final room = await _joinCode(codeController.text);
      if (room != null && mounted) {
        setState(() => busy = false);
        await Navigator.push(context, MaterialPageRoute(builder: (_) => ClassQuizWaitingRoomScreen(user: widget.user, allBooks: gradeBooks, initialRoom: room)));
        if (mounted) await _resumeIfNeeded(showConnectionError: false);
      }
    } catch (e) {
      if (mounted) setState(() => busy = false);
      if (mounted) await _showError(e);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _loadRandom({bool refresh = false}) async {
    if (randomLoading || (refresh && randomRefreshRemaining > 0)) return;
    setState(() { randomLoading = true; busyLabel = 'در حال دریافت اتاق‌ها...'; });
    try {
      final payload = await ClassQuizApi.request('room.random', {
        'excludeRoomIds': refresh ? lastRandomRoomIds : const <String>[],
        'limit': 10,
      });
      final rooms = (payload['rooms'] as List? ?? []).whereType<Map>().map((e) => ClassQuizRandomRoom.fromJson(Map<String, dynamic>.from(e))).toList();
      if (!mounted) return;
      setState(() {
        randomRooms = rooms;
        randomLoadedOnce = true;
        lastRandomRoomIds = rooms.map((e) => e.roomId).toList();
        if (refresh || randomRefreshRemaining == 0) randomRefreshRemaining = 30;
      });
      randomCooldownTimer?.cancel();
      randomCooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (!mounted) return timer.cancel();
        if (randomRefreshRemaining <= 1) {
          timer.cancel();
          setState(() => randomRefreshRemaining = 0);
        } else {
          setState(() => randomRefreshRemaining--);
        }
      });
    } catch (e) {
      if (mounted) await _showError(e);
    } finally {
      if (mounted) setState(() => randomLoading = false);
    }
  }

  Future<void> _joinRandom(ClassQuizRandomRoom item) async {
    if (busy) return;
    setState(() { busy = true; busyLabel = 'در حال ورود به اتاق...'; });
    try {
      final room = await _joinCode(item.code, knownHasPassword: item.hasPassword);
      if (room != null && mounted) {
        setState(() => busy = false);
        await Navigator.push(context, MaterialPageRoute(builder: (_) => ClassQuizWaitingRoomScreen(user: widget.user, allBooks: gradeBooks, initialRoom: room)));
        if (mounted) await _resumeIfNeeded(showConnectionError: false);
      }
    } catch (e) {
      if (mounted) setState(() => busy = false);
      if (mounted) await _showError(e);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final blocked = initialLoading || busy || randomLoading;
    return Stack(
      children: [
        ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const InfoBox(
              title: 'کوییز دوستان و کلاس',
              body: 'یک اتاق واقعی برای دانش‌آموزان پایه خودت بساز یا با کد وارد اتاق دوستانت شو. ساخت اتاق ۵ کارت و ورود اعضا رایگان است.',
              icon: Icons.groups_2_rounded,
            ),
            const SizedBox(height: 14),
            FilledButton.icon(onPressed: blocked ? null : _createRoom, icon: const Icon(Icons.add_circle_outline_rounded), label: const Text('ساخت اتاق')),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    TextField(
                      controller: codeController,
                      enabled: !blocked,
                      keyboardType: TextInputType.number,
                      maxLength: 5,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: const InputDecoration(labelText: 'کد ۵ رقمی اتاق', prefixIcon: Icon(Icons.numbers_rounded), counterText: ''),
                    ),
                    const SizedBox(height: 10),
                    SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: blocked ? null : _joinManual, icon: const Icon(Icons.login_rounded), label: const Text('ورود با کد'))),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Expanded(child: Text('ورود شانسی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
                TextButton.icon(
                  onPressed: blocked || randomRefreshRemaining > 0 ? null : () => _loadRandom(refresh: randomLoadedOnce),
                  icon: const Icon(Icons.refresh_rounded),
                  label: Text(randomRefreshRemaining > 0 ? '${randomRefreshRemaining}ث' : (randomLoadedOnce ? 'اتاق‌های جدید' : 'نمایش اتاق‌ها')),
                ),
              ],
            ),
            if (!randomLoadedOnce && !randomLoading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 18),
                child: Text('در حال دریافت اتاق‌ها...', textAlign: TextAlign.center, style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
              )
            else if (randomLoadedOnce && randomRooms.isEmpty)
              Container(
                margin: const EdgeInsets.symmetric(vertical: 12),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24)),
                child: const Center(
                  child: Text('اتاق فعال برای ورود پیدا نشد', style: TextStyle(fontWeight: FontWeight.w900)),
                ),
              )
            else
              ...randomRooms.map((room) => Card(
                    child: ListTile(
                      title: Row(
                        children: [
                          Expanded(
                            child: Text(
                              room.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.right,
                              style: const TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Text('${room.memberCount} نفر', style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted)),
                        ],
                      ),
                      trailing: const Icon(Icons.chevron_right_rounded),
                      onTap: blocked ? null : () => _joinRandom(room),
                    ),
                  )),
          ],
        ),
        if (initialLoading) const _ClassQuizBusyOverlay(label: 'در حال بررسی وضعیت اتاق...') else if (busy || randomLoading) _ClassQuizBusyOverlay(label: busyLabel),
      ],
    );
  }
}

class _ClassQuizRoomConfigDialog extends StatefulWidget {
  const _ClassQuizRoomConfigDialog({required this.books, required this.initialQuestionCount, required this.title, this.initialName = '', this.hasPassword = false, this.initialBookIds});
  final List<LearningBook> books;
  final int initialQuestionCount;
  final String title;
  final String initialName;
  final bool hasPassword;
  final Set<String>? initialBookIds;
  @override
  State<_ClassQuizRoomConfigDialog> createState() => _ClassQuizRoomConfigDialogState();
}

class _ClassQuizRoomConfigDialogState extends State<_ClassQuizRoomConfigDialog> {
  late final TextEditingController nameController;
  late final TextEditingController passwordController;
  late Set<String> selectedBookIds;
  late int questionCount;
  bool usePassword = false;
  bool removeExistingPassword = false;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.initialName);
    passwordController = TextEditingController();
    selectedBookIds = widget.initialBookIds == null ? widget.books.map((b) => b.id).toSet() : Set<String>.from(widget.initialBookIds!);
    questionCount = widget.initialQuestionCount;
    usePassword = widget.hasPassword;
  }

  @override
  void dispose() {
    nameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final name = nameController.text.trim();
    if (name.isNotEmpty && (name.characters.length < 3 || name.characters.length > 25 || name.contains('\n') || name.contains('\r'))) {
      await showClassQuizErrorDialog(context, const GaminoApiException('نام اتاق باید تک‌خطی و بین ۳ تا ۲۵ کاراکتر باشد.'));
      return;
    }
    if (selectedBookIds.isEmpty) {
      await showClassQuizErrorDialog(context, const GaminoApiException('حداقل یک کتاب انتخاب کن.'));
      return;
    }
    final password = passwordController.text;
    if (usePassword && password.isNotEmpty && !RegExp(r'^\d{1,20}$').hasMatch(password)) {
      await showClassQuizErrorDialog(context, const GaminoApiException('رمز باید فقط عدد و بین ۱ تا ۲۰ رقم باشد.'));
      return;
    }
    if (!widget.hasPassword && usePassword && password.isEmpty) {
      await showClassQuizErrorDialog(context, const GaminoApiException('رمز عددی را وارد کن.'));
      return;
    }
    final result = <String, dynamic>{
      'name': name,
      'bookIds': selectedBookIds.toList(),
      'questionCount': questionCount,
    };
    if (!widget.hasPassword) result['password'] = usePassword ? password : '';
    if (widget.hasPassword) {
      if (removeExistingPassword) {
        result['password'] = '';
      } else if (password.isNotEmpty) {
        result['password'] = password;
      }
    }
    Navigator.pop(context, result);
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.sizeOf(context).height;
    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 520, maxHeight: screenHeight * .86),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.10), borderRadius: BorderRadius.circular(15)),
                    child: const Icon(Icons.tune_rounded, color: AppPalette.primary),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Text(widget.title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900))),
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                ],
              ),
              const SizedBox(height: 12),
              Flexible(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TextField(
                        controller: nameController,
                        maxLength: 25,
                        maxLines: 1,
                        decoration: const InputDecoration(labelText: 'نام اتاق', hintText: 'اختیاری؛ در صورت خالی بودن خودکار ساخته می‌شود', prefixIcon: Icon(Icons.meeting_room_outlined)),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.045), borderRadius: BorderRadius.circular(18)),
                        child: !widget.hasPassword
                            ? SwitchListTile(
                                contentPadding: EdgeInsets.zero,
                                title: const Text('اتاق رمز داشته باشد', style: TextStyle(fontWeight: FontWeight.w900)),
                                subtitle: const Text('رمز فقط عددی و بین ۱ تا ۲۰ رقم است.', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w600)),
                                value: usePassword,
                                onChanged: (v) => setState(() => usePassword = v),
                              )
                            : SwitchListTile(
                                contentPadding: EdgeInsets.zero,
                                title: const Text('حذف رمز فعلی', style: TextStyle(fontWeight: FontWeight.w900)),
                                subtitle: const Text('در صورت خاموش بودن، رمز فعلی حفظ می‌شود.', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w600)),
                                value: removeExistingPassword,
                                onChanged: (v) => setState(() => removeExistingPassword = v),
                              ),
                      ),
                      if ((usePassword && !removeExistingPassword) || (widget.hasPassword && !removeExistingPassword)) ...[
                        const SizedBox(height: 10),
                        TextField(
                          controller: passwordController,
                          keyboardType: TextInputType.number,
                          maxLength: 20,
                          obscureText: true,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          decoration: InputDecoration(labelText: widget.hasPassword ? 'رمز جدید (خالی = بدون تغییر)' : 'رمز عددی', prefixIcon: const Icon(Icons.lock_outline_rounded)),
                        ),
                      ],
                      const SizedBox(height: 12),
                      const Text('تعداد سؤال', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 8),
                      SegmentedButton<int>(
                        segments: const [
                          ButtonSegment(value: 10, label: Text('۱۰ سؤال')),
                          ButtonSegment(value: 20, label: Text('۲۰ سؤال')),
                          ButtonSegment(value: 30, label: Text('۳۰ سؤال')),
                        ],
                        selected: {questionCount},
                        onSelectionChanged: (value) => setState(() => questionCount = value.first),
                      ),
                      const SizedBox(height: 16),
                      Row(children: [
                        const Expanded(child: Text('کتاب‌ها', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900))),
                        Text('${selectedBookIds.length} انتخاب', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
                      ]),
                      const SizedBox(height: 6),
                      ...widget.books.map((book) => Container(
                            margin: const EdgeInsets.only(bottom: 6),
                            decoration: BoxDecoration(color: selectedBookIds.contains(book.id) ? AppPalette.primary.withOpacity(.055) : Colors.transparent, borderRadius: BorderRadius.circular(14)),
                            child: CheckboxListTile(
                              contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                              dense: true,
                              title: Text(book.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
                              value: selectedBookIds.contains(book.id),
                              onChanged: (v) => setState(() => v == true ? selectedBookIds.add(book.id) : selectedBookIds.remove(book.id)),
                            ),
                          )),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(child: SizedBox(height: 48, child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')))),
                const SizedBox(width: 10),
                Expanded(child: SizedBox(height: 48, child: FilledButton(onPressed: _submit, child: Text(widget.title.contains('تنظیمات') ? 'ذخیره' : 'ادامه')))),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}

class ClassQuizWaitingRoomScreen extends StatefulWidget {
  const ClassQuizWaitingRoomScreen({super.key, required this.user, required this.allBooks, required this.initialRoom});
  final AppUser user;
  final List<LearningBook> allBooks;
  final ClassQuizRoomState initialRoom;
  @override
  State<ClassQuizWaitingRoomScreen> createState() => _ClassQuizWaitingRoomScreenState();
}

class _ClassQuizWaitingRoomScreenState extends State<ClassQuizWaitingRoomScreen> {
  late ClassQuizRoomState room;
  Timer? pollTimer;
  bool requestBusy = false;
  bool actionBusy = false;
  String actionLabel = 'در حال دریافت اطلاعات...';
  bool transitioned = false;
  bool routeClosing = false;

  @override
  void initState() {
    super.initState();
    room = widget.initialRoom;
    pollTimer = Timer.periodic(const Duration(seconds: 4), (_) => _poll());
    WidgetsBinding.instance.addPostFrameCallback((_) => _poll());
  }

  @override
  void dispose() {
    pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _error(Object e) async {
    if (!mounted) return;
    await showClassQuizErrorDialog(context, e);
  }

  Future<void> _showEvent(Map<dynamic, dynamic> event) async {
    final message = event['message']?.toString() ?? '';
    if (message.isEmpty || !mounted) return;
    await showClassQuizMessageDialog(context, title: 'وضعیت اتاق', message: message, icon: Icons.info_outline_rounded);
  }

  Future<void> _poll() async {
    if (!mounted || requestBusy || transitioned || routeClosing || ModalRoute.of(context)?.isCurrent != true) return;
    requestBusy = true;
    try {
      final payload = await ClassQuizApi.request('room.status', {'roomId': room.roomId}, timeout: const Duration(seconds: 8));
      final event = payload['event'];
      final raw = payload['room'];
      if (event is Map) await _showEvent(event);
      if (!mounted) return;
      if (raw is! Map) {
        if (!routeClosing && !transitioned) {
          routeClosing = true;
          transitioned = true;
          pollTimer?.cancel();
          if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
        }
        return;
      }
      final next = ClassQuizRoomState.fromJson(Map<String, dynamic>.from(raw));
      setState(() => room = next);
      if (next.isStarted && !transitioned) {
        transitioned = true;
        pollTimer?.cancel();
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ClassQuizExamScreen(user: widget.user, initialRoom: next)));
      }
    } catch (_) {
      // Heartbeat failure is represented by the yellow offline icon on peers.
    } finally {
      requestBusy = false;
    }
  }

  Future<void> _editSettings() async {
    final config = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => _ClassQuizRoomConfigDialog(
        books: widget.allBooks,
        initialQuestionCount: room.questionCountRequested,
        title: 'تنظیمات اتاق',
        initialName: room.name,
        hasPassword: room.hasPassword,
        initialBookIds: room.books.map((b) => b.id).toSet(),
      ),
    );
    if (config == null || !mounted) return;
    final ok = await showClassQuizConfirm(context, title: 'ذخیره تنظیمات', message: 'تنظیمات جدید برای همه اعضای اتاق اعمال شود؟', confirmLabel: 'ذخیره');
    if (!ok) return;
    setState(() { actionBusy = true; actionLabel = 'در حال ذخیره تنظیمات...'; });
    try {
      final payload = await ClassQuizApi.request('room.update', {'roomId': room.roomId, ...config});
      final next = ClassQuizApi.roomFromPayload(payload);
      if (mounted) setState(() => room = next);
    } catch (e) {
      if (mounted) await _error(e);
    } finally {
      if (mounted) setState(() => actionBusy = false);
    }
  }

  Future<void> _kick(ClassQuizMember member) async {
    final ok = await showClassQuizConfirm(context, title: 'حذف عضو', message: '${member.name} از اتاق حذف شود؟ این کاربر دیگر نمی‌تواند به همین اتاق برگردد.', confirmLabel: 'حذف', icon: Icons.person_remove_alt_1_rounded, destructive: true);
    if (!ok) return;
    setState(() { actionBusy = true; actionLabel = 'در حال حذف عضو...'; });
    try {
      final payload = await ClassQuizApi.request('room.kick', {'roomId': room.roomId, 'userId': member.userId});
      if (mounted) setState(() => room = ClassQuizApi.roomFromPayload(payload));
    } catch (e) {
      if (mounted) await _error(e);
    } finally {
      if (mounted) setState(() => actionBusy = false);
    }
  }

  Future<void> _start() async {
    if (actionBusy || routeClosing || transitioned) return;
    if (room.memberCount < 2) {
      await _error(const GaminoApiException('برای شروع حداقل مدیر و یک عضو دیگر لازم است.'));
      return;
    }
    final ok = await showClassQuizConfirm(context, title: 'شروع کوییز', message: 'کوییز برای همه اعضای فعلی شروع شود؟ بعد از شروع ورود عضو جدید و تغییر تنظیمات ممکن نیست.', confirmLabel: 'شروع', icon: Icons.play_circle_outline_rounded);
    if (!ok) return;
    setState(() { actionBusy = true; actionLabel = 'در حال شروع کوییز...'; });
    try {
      final payload = await ClassQuizApi.request('room.start', {'roomId': room.roomId}, timeout: const Duration(seconds: 25));
      final next = ClassQuizApi.roomFromPayload(payload);
      if (!mounted) return;
      transitioned = true;
      pollTimer?.cancel();
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ClassQuizExamScreen(user: widget.user, initialRoom: next)));
    } catch (e) {
      if (mounted) await _error(e);
    } finally {
      if (mounted) setState(() => actionBusy = false);
    }
  }

  Future<void> _leave() async {
    if (actionBusy || routeClosing || transitioned) return;
    final owner = room.isOwner;
    final ok = await showClassQuizConfirm(
      context,
      title: owner ? 'خروج و بستن اتاق' : 'خروج از اتاق',
      message: owner ? 'با خروج شما، اتاق بسته می‌شود و همه اعضای منتظر خارج می‌شوند. ادامه می‌دهی؟' : 'از این اتاق خارج شوی؟',
      confirmLabel: 'خروج',
      icon: Icons.logout_rounded,
      destructive: owner,
    );
    if (!ok || !mounted || routeClosing || transitioned) return;

    routeClosing = true;
    pollTimer?.cancel();
    setState(() {
      actionBusy = true;
      actionLabel = owner ? 'در حال بستن اتاق...' : 'در حال خروج از اتاق...';
    });

    try {
      await ClassQuizApi.request('room.leave', {'roomId': room.roomId});
      if (!mounted) return;
      transitioned = true;
      if (Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      } else {
        gaminoHomeShellKey.currentState?.openClassQuizHome();
      }
    } catch (e) {
      routeClosing = false;
      if (mounted) {
        setState(() => actionBusy = false);
        pollTimer = Timer.periodic(const Duration(seconds: 4), (_) => _poll());
        await _error(e);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop && !routeClosing && !transitioned) _leave();
      },
      child: Scaffold(
        appBar: AppBar(title: Text(room.name, maxLines: 1, overflow: TextOverflow.ellipsis), automaticallyImplyLeading: false),
        body: Stack(
          children: [
            SafeArea(
              child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    children: [
                      const Text('کد ورود', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      SelectableText(faDigits(room.code), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 7, color: AppPalette.primary)),
                      const SizedBox(height: 8),
                      Text('پایه ${gradeLabel(room.grade)} • ${room.memberCount}/40 نفر', style: const TextStyle(fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        const Expanded(child: Text('تنظیمات اتاق', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
                        if (room.isOwner) IconButton(onPressed: _editSettings, icon: const Icon(Icons.settings_rounded)),
                      ]),
                      Text('تعداد سؤال انتخابی: ${room.questionCountRequested}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 8),
                      Wrap(spacing: 7, runSpacing: 7, children: room.books.map((b) => Chip(label: Text(b.title))).toList()),
                      if (room.hasPassword) const Padding(padding: EdgeInsets.only(top: 8), child: Text('این اتاق رمز دارد.', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700))),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Text('اعضای اتاق', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              ...room.members.map((member) {
                final connectionColor = member.connectionGood
                    ? AppPalette.mint
                    : (member.connectionWeak ? AppPalette.amber : AppPalette.coral);
                final connectionIcon = member.connectionOffline ? Icons.wifi_off_rounded : Icons.wifi_rounded;
                final connectionLabel = member.connectionGood
                    ? 'اتصال خوب'
                    : (member.connectionWeak ? 'اتصال ضعیف' : 'اتصال قطع است');
                return Card(
                  child: ListTile(
                    leading: SizedBox(
                      width: 40,
                      height: 40,
                      child: avatarImageForTitle('', fit: BoxFit.contain, remoteUrl: member.avatarUrl),
                    ),
                    title: Row(
                      children: [
                        Flexible(child: Text(member.name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900))),
                        const SizedBox(width: 7),
                        Tooltip(
                          message: connectionLabel,
                          child: Icon(connectionIcon, size: 16, color: connectionColor),
                        ),
                        if (member.isOwner) ...[
                          const SizedBox(width: 7),
                          const Text('مدیر', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900, color: AppPalette.mint)),
                        ],
                      ],
                    ),
                    trailing: room.isOwner && !member.isOwner
                        ? IconButton(onPressed: () => _kick(member), icon: const Icon(Icons.person_remove_alt_1_rounded, color: AppPalette.coral))
                        : null,
                  ),
                );
              }),
              const SizedBox(height: 14),
              if (room.isOwner) ...[
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: AppPalette.mint, foregroundColor: Colors.white),
                    onPressed: actionBusy || routeClosing ? null : _start,
                    child: const Text('شروع کوییز'),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: AppPalette.coral, foregroundColor: Colors.white),
                    onPressed: actionBusy || routeClosing ? null : _leave,
                    child: const Text('لغو و خروج از اتاق'),
                  ),
                ),
              ] else
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: OutlinedButton(onPressed: actionBusy || routeClosing ? null : _leave, child: const Text('خروج از اتاق')),
                ),
                ],
              ),
            ),
            if (actionBusy) _ClassQuizBusyOverlay(label: actionLabel),
          ],
        ),
      ),
    );
  }
}

class ClassQuizExamScreen extends StatefulWidget {
  const ClassQuizExamScreen({super.key, required this.user, required this.initialRoom});
  final AppUser user;
  final ClassQuizRoomState initialRoom;
  @override
  State<ClassQuizExamScreen> createState() => _ClassQuizExamScreenState();
}

class _ClassQuizExamScreenState extends State<ClassQuizExamScreen> with WidgetsBindingObserver {
  late ClassQuizRoomState room;
  late Map<String, int> answers;
  final Map<String, int> versions = {};
  final Set<String> pending = {};
  Timer? secondTimer;
  Timer? syncTimer;
  Stopwatch serverClock = Stopwatch();
  int serverAnchor = 0;
  bool online = true;
  bool finishing = false;
  bool expiredHandled = false;
  bool started = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    room = widget.initialRoom;
    answers = Map<String, int>.from(room.answers);
    _anchor(room.serverNow);
    secondTimer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
    syncTimer = Timer.periodic(const Duration(seconds: 5), (_) => _syncPendingAndHeartbeat());
    WidgetsBinding.instance.addPostFrameCallback((_) => _tick());
  }

  @override
  void dispose() {
    secondTimer?.cancel();
    syncTimer?.cancel();
    serverClock.stop();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _syncPendingAndHeartbeat();
  }

  void _anchor(int serverSeconds) {
    serverAnchor = serverSeconds;
    serverClock
      ..reset()
      ..start();
  }

  int get serverNow => serverAnchor + serverClock.elapsed.inSeconds;
  int get remaining => max(0, room.endAt - serverNow);
  int get countdownRemaining => max(0, room.startAt - serverNow);
  int get answeredCount => answers.values.where((v) => v >= 0).length;

  String _timeText(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  void _tick() {
    if (!mounted) return;
    if (!started && serverNow >= room.startAt) started = true;
    if (room.endAt > 0 && serverNow >= room.endAt && !expiredHandled) {
      expiredHandled = true;
      finishing = true;
      setState(() {});
      _handleExpired();
      return;
    }
    setState(() {});
  }

  Future<void> _selectAnswer(QuizQuestion q, int selected) async {
    if (finishing || serverNow >= room.endAt) return;
    final version = DateTime.now().microsecondsSinceEpoch;
    setState(() {
      answers[q.id] = selected;
      versions[q.id] = version;
      pending.add(q.id);
    });
    await _syncOne(q.id);
  }

  Future<void> _syncOne(String qid) async {
    if (!pending.contains(qid) || serverNow >= room.endAt) return;
    final version = versions[qid] ?? DateTime.now().microsecondsSinceEpoch;
    final selected = answers[qid] ?? -1;
    try {
      final payload = await ClassQuizApi.request('room.answer', {'roomId': room.roomId, 'questionId': qid, 'selectedIndex': selected, 'version': version}, timeout: const Duration(seconds: 6));
      if (!mounted) return;
      if ((versions[qid] ?? 0) == version) pending.remove(qid);
      final now = (payload['serverNow'] as num?)?.toInt();
      if (now != null) _anchor(now);
      if (!online) setState(() => online = true);
    } catch (_) {
      if (mounted && online) setState(() => online = false);
    }
  }

  Future<void> _syncPendingAndHeartbeat() async {
    if (!mounted || finishing || ModalRoute.of(context)?.isCurrent != true) return;
    if (serverNow >= room.endAt) return;
    if (pending.isNotEmpty) {
      for (final qid in List<String>.from(pending)) {
        if (serverNow >= room.endAt) break;
        await _syncOne(qid);
      }
      return;
    }
    try {
      final payload = await ClassQuizApi.request('room.status', {'roomId': room.roomId}, timeout: const Duration(seconds: 6));
      final raw = payload['room'];
      if (raw is Map) {
        final next = ClassQuizRoomState.fromJson(Map<String, dynamic>.from(raw));
        room = next;
        _anchor(next.serverNow);
      }
      if (mounted && !online) setState(() => online = true);
    } catch (_) {
      if (mounted && online) setState(() => online = false);
    }
  }

  List<Map<String, dynamic>> _answerPayload() => answers.entries.map((e) => {'questionId': e.key, 'selectedIndex': e.value, 'version': versions[e.key] ?? DateTime.now().microsecondsSinceEpoch}).toList();

  Future<bool> _confirmFinish() async {
    final unanswered = max(0, room.questions.length - answeredCount);
    final offlineNote = online ? '' : '\n\nاینترنت قطع است؛ پاسخ‌های ارسال‌نشده فقط اگر قبل از پایان زمان اینترنت وصل شود ثبت می‌شوند.';
    final message = unanswered > 0
        ? '$unanswered سؤال بدون پاسخ داری و در صورت پایان، غلط محسوب می‌شوند. مطمئنی آزمون را تمام می‌کنی؟$offlineNote'
        : 'پاسخ‌ها بعد از پایان قفل می‌شوند. مطمئنی آزمون را تمام می‌کنی؟$offlineNote';
    return showClassQuizConfirm(context, title: 'پایان آزمون', message: message, confirmLabel: 'پایان آزمون');
  }

  Future<void> _manualFinish() async {
    if (finishing) return;
    final ok = await _confirmFinish();
    if (!ok || !mounted) return;
    setState(() => finishing = true);
    // While time remains, make one best-effort flush of the latest local choices.
    if (serverNow < room.endAt) {
      for (final qid in List<String>.from(pending)) {
        if (serverNow >= room.endAt) break;
        await _syncOne(qid);
      }
    }
    try {
      final payload = await ClassQuizApi.request('room.finish', {'roomId': room.roomId, 'answers': serverNow < room.endAt ? _answerPayload() : const <Map<String, dynamic>>[]}, timeout: const Duration(seconds: 12));
      final raw = payload['ranking'];
      if (raw is! Map) throw const GaminoApiException('رتبه‌بندی دریافت نشد.');
      await gaminoAppKey.currentState?.refreshLearningContent();
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ClassQuizRankingScreen(user: widget.user, initial: ClassQuizRankingState.fromJson(Map<String, dynamic>.from(raw)))));
    } catch (e) {
      if (!mounted) return;
      setState(() => finishing = false);
      await _showFinishConnectionError(e);
    }
  }

  Future<void> _handleExpired() async {
    // Do NOT submit pending offline answers after end_at. Server closes the
    // attempt from the answers that arrived before the deadline.
    try {
      final payload = await ClassQuizApi.request('room.ranking', {'matchId': room.matchId}, timeout: const Duration(seconds: 7));
      final raw = payload['ranking'];
      if (raw is! Map) throw const GaminoApiException('رتبه‌بندی دریافت نشد.');
      await gaminoAppKey.currentState?.refreshLearningContent();
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ClassQuizRankingScreen(user: widget.user, initial: ClassQuizRankingState.fromJson(Map<String, dynamic>.from(raw)))));
    } catch (_) {
      if (!mounted) return;
      await Future.delayed(const Duration(seconds: 3));
      if (!mounted) return;
      final retry = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => _ClassQuizDialogFrame(
          icon: Icons.wifi_off_rounded,
          title: 'خطا در اتصال',
          child: const Text('برای دریافت رتبه‌بندی اتصال اینترنت برقرار نیست.', textAlign: TextAlign.center, style: TextStyle(height: 1.7, fontWeight: FontWeight.w700, color: AppPalette.muted)),
          actions: [
            OutlinedButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('خروج')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تلاش دوباره')),
          ],
        ),
      );
      if (!mounted) return;
      if (retry != true) {
        Navigator.pop(context);
        return;
      }
      try {
        final payload = await ClassQuizApi.request('room.ranking', {'matchId': room.matchId}, timeout: const Duration(seconds: 7));
        final raw = payload['ranking'];
        if (raw is! Map) throw const GaminoApiException('رتبه‌بندی دریافت نشد.');
        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ClassQuizRankingScreen(user: widget.user, initial: ClassQuizRankingState.fromJson(Map<String, dynamic>.from(raw)))));
      } catch (_) {
        if (!mounted) return;
        await showClassQuizMessageDialog(context, title: 'عدم اتصال به اینترنت', message: 'رتبه‌بندی دریافت نشد. اتصال اینترنت را بررسی کنید.', icon: Icons.wifi_off_rounded);
        if (mounted) Navigator.pop(context);
      }
    }
  }

  Future<void> _showFinishConnectionError(Object e) async {
    if (!mounted) return;
    await showClassQuizErrorDialog(context, e);
  }

  @override
  Widget build(BuildContext context) {
    final countdown = countdownRemaining;
    if (countdown > 0) {
      return PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, result) {
          if (!didPop) _manualFinish();
        },
        child: Scaffold(
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('آماده باش', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 16),
                Text('$countdown', style: const TextStyle(fontSize: 72, fontWeight: FontWeight.w900, color: AppPalette.primary)),
              ],
            ),
          ),
        ),
      );
    }

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _manualFinish();
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(room.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
              Text('${_timeText(remaining)} • پاسخ داده‌شده $answeredCount از ${room.questions.length}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ],
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Center(
                child: Row(children: [
                  Icon(online ? Icons.cloud_done_rounded : Icons.cloud_off_rounded, size: 18, color: online ? AppPalette.mint : AppPalette.amber),
                  const SizedBox(width: 4),
                  Text(online ? 'همگام شد' : 'آفلاین', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: online ? AppPalette.mint : AppPalette.amber)),
                ]),
              ),
            ),
          ],
        ),
        body: Stack(
          children: [
            ListView.builder(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 110),
              itemCount: room.questions.length + 1,
              itemBuilder: (context, index) {
                if (index == room.questions.length) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: FilledButton.icon(onPressed: finishing ? null : _manualFinish, icon: const Icon(Icons.flag_rounded), label: const Text('پایان آزمون')),
                  );
                }
                final q = room.questions[index];
                final selected = answers[q.id] ?? -1;
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('سؤال ${index + 1} • ${q.subject}', style: const TextStyle(color: AppPalette.primary, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 8),
                        Text(q.text, style: const TextStyle(fontSize: 16, height: 1.7, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 8),
                        ...List.generate(4, (optionIndex) => RadioListTile<int>(
                              value: optionIndex,
                              groupValue: selected >= 0 ? selected : null,
                              onChanged: finishing ? null : (value) { if (value != null) _selectAnswer(q, value); },
                              title: Text(q.options[optionIndex], style: const TextStyle(fontWeight: FontWeight.w700)),
                              contentPadding: EdgeInsets.zero,
                            )),
                      ],
                    ),
                  ),
                );
              },
            ),
            if (finishing)
              Positioned.fill(
                child: ColoredBox(
                  color: Colors.black.withOpacity(.18),
                  child: const Center(
                    child: Card(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 18),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [CircularProgressIndicator(), SizedBox(width: 14), Text('در حال پایان آزمون...', style: TextStyle(fontWeight: FontWeight.w900))]),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class ClassQuizRankingScreen extends StatefulWidget {
  const ClassQuizRankingScreen({super.key, required this.user, required this.initial});
  final AppUser user;
  final ClassQuizRankingState initial;
  @override
  State<ClassQuizRankingScreen> createState() => _ClassQuizRankingScreenState();
}

class _ClassQuizRankingScreenState extends State<ClassQuizRankingScreen> {
  late ClassQuizRankingState ranking;
  Timer? pollTimer;
  bool polling = false;

  @override
  void initState() {
    super.initState();
    ranking = widget.initial;
    if (!ranking.isFinal) pollTimer = Timer.periodic(const Duration(seconds: 5), (_) => _poll());
  }

  @override
  void dispose() {
    pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _poll() async {
    if (polling || ranking.isFinal || !mounted || ModalRoute.of(context)?.isCurrent != true) return;
    polling = true;
    try {
      final payload = await ClassQuizApi.request('room.ranking', {'matchId': ranking.matchId}, timeout: const Duration(seconds: 7));
      final raw = payload['ranking'];
      if (raw is Map && mounted) {
        final next = ClassQuizRankingState.fromJson(Map<String, dynamic>.from(raw));
        setState(() => ranking = next);
        if (next.isFinal) pollTimer?.cancel();
      }
    } catch (_) {
      // Keep the last known ranking on transient network failures.
    } finally {
      polling = false;
    }
  }

  void _exitToClassQuiz() {
    gaminoHomeShellKey.currentState?.openClassQuizHome();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _exitToClassQuiz();
      },
      child: Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(onPressed: _exitToClassQuiz, icon: const Icon(Icons.arrow_back_rounded)),
        title: Text(ranking.isFinal ? 'نتیجه نهایی' : 'رتبه‌بندی زنده'),
      ),
      body: SafeArea(
        child: ranking.rows.isEmpty
            ? const Center(child: Text('هنوز کسی آزمون را پایان نداده است.', style: TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted)))
            : ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: ranking.rows.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  final row = ranking.rows[index];
                  final me = row.userId == widget.user.id;
                  return Card(
                    child: ListTile(
                      tileColor: me ? AppPalette.primary.withOpacity(.06) : null,
                      leading: SizedBox(
                        width: 40,
                        height: 40,
                        child: avatarImageForTitle('', fit: BoxFit.contain, remoteUrl: row.avatarUrl),
                      ),
                      title: Text('${row.rank}. ${row.name}', style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: Text('درست ${row.correct} • غلط ${row.wrong}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      trailing: Text('پایان #${row.finishOrder}', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800)),
                    ),
                  );
                },
              ),
      ),
      ),
    );
  }
}


class MistakesPanel extends StatelessWidget {
  const MistakesPanel({super.key, required this.mistakes, required this.onMistakePracticeFinished});

  final List<MyMistake> mistakes;
  final void Function(QuizResult result) onMistakePracticeFinished;

  Future<void> _showEmptyDialog(BuildContext context) async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Row(
          textDirection: TextDirection.rtl,
          children: [
            Icon(Icons.check_circle_outline_rounded, color: AppPalette.mint),
            SizedBox(width: 10),
            Expanded(child: Text('اشتباهی برای مرور نداری', textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900))),
          ],
        ),
        content: const Text(
          'هنوز اشتباهی برای مرور ندارید.',
          textAlign: TextAlign.right,
          style: TextStyle(fontWeight: FontWeight.w700, color: AppPalette.muted),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('باشه'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasMistakes = mistakes.isNotEmpty;
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 30, 18, 28),
      children: [
        _MistakesActionCard(
          label: 'مشاهده اشتباهات من',
          icon: Icons.visibility_rounded,
          filled: false,
          enabled: true,
          onTap: () {
            if (!hasMistakes) {
              unawaited(_showEmptyDialog(context));
              return;
            }
            Navigator.push(context, MaterialPageRoute(builder: (_) => MistakesLearningScreen(mistakes: mistakes)));
          },
        ),
        const SizedBox(height: 14),
        _MistakesActionCard(
          label: 'شروع تست اشتباهات من',
          icon: Icons.bolt_rounded,
          filled: true,
          enabled: true,
          onTap: () {
            if (!hasMistakes) {
              unawaited(_showEmptyDialog(context));
              return;
            }
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MistakePracticeSessionScreen(
                  mistakes: mistakes,
                  onComplete: onMistakePracticeFinished,
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

class _MistakesActionCard extends StatelessWidget {
  const _MistakesActionCard({required this.label, required this.icon, required this.filled, required this.enabled, required this.onTap});

  final String label;
  final IconData icon;
  final bool filled;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final background = filled ? AppPalette.mint : Colors.white;
    final foreground = filled ? Colors.white : AppPalette.ink;
    final iconBackground = filled ? Colors.white : AppPalette.secondary.withOpacity(.10);
    final iconColor = filled ? AppPalette.mint : AppPalette.secondary;
    return Material(
      color: enabled ? background : background.withOpacity(.55),
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          height: 78,
          padding: const EdgeInsets.symmetric(horizontal: 18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: filled ? Colors.transparent : AppPalette.secondary.withOpacity(.28), width: 1.2),
            boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 18, offset: Offset(0, 8))],
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(color: iconBackground, borderRadius: BorderRadius.circular(16)),
                child: Icon(icon, color: iconColor, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  label,
                  textAlign: TextAlign.right,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: foreground),
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.chevron_right_rounded, color: foreground.withOpacity(.72), size: 28),
            ],
          ),
        ),
      ),
    );
  }
}

class MistakesLearningScreen extends StatelessWidget {
  const MistakesLearningScreen({super.key, required this.mistakes});
  final List<MyMistake> mistakes;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppPalette.canvas,
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('مشاهده و یادگیری')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 118),
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26)),
            child: const Row(
              textDirection: TextDirection.rtl,
              children: [
                CircleAvatar(radius: 28, backgroundColor: Color(0xFFEDEBFF), child: Icon(Icons.menu_book_rounded, color: AppPalette.secondary)),
                SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('یادگیری بدون کوییز', textAlign: TextAlign.right, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                      SizedBox(height: 8),
                      Text('اینجا فقط سوال و پاسخ درست را می‌بینی تا قبل از تست دوباره مرور کنی.', textAlign: TextAlign.right, style: TextStyle(fontSize: 14, height: 1.8, fontWeight: FontWeight.w700, color: AppPalette.muted)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          ...mistakes.map((mistake) {
            final q = mistake.question;
            final wrong = mistake.lastSelectedIndex >= 0 && mistake.lastSelectedIndex < q.options.length ? q.options[mistake.lastSelectedIndex] : 'بدون پاسخ';
            final correct = q.options[q.correctIndex];
            return Container(
              margin: const EdgeInsets.only(bottom: 16),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 18, offset: Offset(0, 8))]),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFD8D9E6))),
                    child: Text(q.subject, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted)),
                  ),
                  const SizedBox(height: 18),
                  Text(q.text, textAlign: TextAlign.right, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, height: 1.8, color: AppPalette.ink)),
                  const SizedBox(height: 14),
                  _LearningAnswerLine(label: 'پاسخ قبلی شما', value: wrong, color: AppPalette.coral),
                  _LearningAnswerLine(label: 'پاسخ درست', value: correct, color: AppPalette.mint),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}

class _LearningAnswerLine extends StatelessWidget {
  const _LearningAnswerLine({required this.label, required this.value, required this.color});
  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: color.withOpacity(.08), borderRadius: BorderRadius.circular(16), border: Border.all(color: color.withOpacity(.22))),
      child: Text('$label: $value', textAlign: TextAlign.right, style: TextStyle(color: color, fontWeight: FontWeight.w900, height: 1.6)),
    );
  }
}

class MistakePracticeSessionScreen extends StatefulWidget {
  const MistakePracticeSessionScreen({super.key, required this.mistakes, required this.onComplete});
  final List<MyMistake> mistakes;
  final void Function(QuizResult result) onComplete;

  @override
  State<MistakePracticeSessionScreen> createState() => _MistakePracticeSessionScreenState();
}

class _MistakePracticeSessionScreenState extends State<MistakePracticeSessionScreen> {
  int currentIndex = 0;
  int? selectedIndex;
  final Map<String, int> answers = {};
  bool completed = false;
  late final List<QuizQuestion> questions;
  Timer? _questionTimer;
  int remainingSeconds = 15;

  @override
  void initState() {
    super.initState();
    questions = widget.mistakes.map((m) => m.question).toList();
    _startQuestionTimer();
  }

  @override
  void dispose() {
    _questionTimer?.cancel();
    super.dispose();
  }

  void _startQuestionTimer() {
    _questionTimer?.cancel();
    if (completed || questions.isEmpty) return;
    remainingSeconds = 15;
    _questionTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || completed) {
        timer.cancel();
        return;
      }
      if (remainingSeconds <= 1) {
        timer.cancel();
        _next(force: true);
      } else {
        setState(() => remainingSeconds -= 1);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (questions.isEmpty) {
      return Scaffold(appBar: AppBar(automaticallyImplyLeading: false, title: const Text('تست اشتباهات من')), body: const Center(child: Text('سوالی برای تمرین وجود ندارد.')));
    }
    if (completed) {
      final wrong = _wrongAnswers();
      return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false, title: const Text('نتیجه تمرین')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            InfoBox(
              title: 'تمرین تمام شد',
              body: 'سوالات درست از لیست اشتباهات حذف شدند. ${wrong.length} سوال هنوز برای تمرین باقی مانده است.',
              icon: Icons.done_all_rounded,
            ),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.done_rounded), label: const Text('بازگشت')),
          ],
        ),
      );
    }

    final question = questions[currentIndex];
    final progress = (currentIndex + 1) / questions.length;
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('تست اشتباهات من')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          LinearProgressIndicator(value: progress),
          const SizedBox(height: 12),
          Row(
            textDirection: TextDirection.rtl,
            children: [
              Text('سوال ${currentIndex + 1} از ${questions.length}', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: remainingSeconds <= 5 ? const Color(0xFFFFF1F2) : Colors.white, borderRadius: BorderRadius.circular(14)),
                child: Text('$remainingSeconds ثانیه', style: TextStyle(color: remainingSeconds <= 5 ? AppPalette.coral : AppPalette.primary, fontWeight: FontWeight.w900)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Chip(label: Text(question.subject)),
                  const SizedBox(height: 12),
                  Text(question.text, textAlign: TextAlign.right, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, height: 1.8)),
                  const SizedBox(height: 16),
                  ...List.generate(question.options.length, (index) {
                    final selected = selectedIndex == index;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(18),
                        onTap: () => setState(() => selectedIndex = index),
                        child: Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(18),
                            color: selected ? Theme.of(context).colorScheme.primaryContainer : const Color(0xFFF2F4F8),
                            border: Border.all(color: selected ? Theme.of(context).colorScheme.primary : Colors.transparent),
                          ),
                          child: Row(
                            textDirection: TextDirection.rtl,
                            children: [
                              Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off),
                              const SizedBox(width: 8),
                              Expanded(child: Text(question.options[index], textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700))),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: () => _next(force: true),
                          icon: Icon(currentIndex == questions.length - 1 ? Icons.done_all_rounded : Icons.close_rounded),
                          label: Text(currentIndex == questions.length - 1 ? 'پایان تست' : 'سوال بعدی'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _finish,
                          icon: const Icon(Icons.stop_circle_outlined),
                          label: const Text('پایان'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  void _next({bool force = false}) {
    final q = questions[currentIndex];
    if (selectedIndex != null) {
      answers[q.id] = selectedIndex!;
    } else if (force) {
      answers[q.id] = -1;
    } else {
      return;
    }
    if (currentIndex == questions.length - 1) {
      _finish();
    } else {
      setState(() {
        currentIndex += 1;
        selectedIndex = answers[questions[currentIndex].id];
      });
      _startQuestionTimer();
    }
  }

  List<WrongAnswer> _wrongAnswers() {
    final wrong = <WrongAnswer>[];
    for (final q in questions) {
      final selected = answers[q.id];
      if (selected != q.correctIndex) {
        wrong.add(WrongAnswer(question: q, selectedIndex: selected ?? -1));
      }
    }
    return wrong;
  }

  void _finish() {
    if (selectedIndex != null && currentIndex < questions.length) {
      answers[questions[currentIndex].id] = selectedIndex!;
    }
    final wrong = _wrongAnswers();
    final correct = questions.length - wrong.length;
    final result = QuizResult(
      questions: questions,
      correctAnswers: correct,
      totalQuestions: questions.length,
      xpEarned: 0,
      coinsEarned: 0,
      wrongAnswers: wrong,
      answers: Map<String, int>.from(answers),
    );
    widget.onComplete(result);
    setState(() => completed = true);
  }
}

class CupScoringPreviewCard extends StatelessWidget {
  const CupScoringPreviewCard({super.key, required this.cups});
  final int cups;

  @override
  Widget build(BuildContext context) {
    final win = quizWinCupDelta(cups);
    final lose = quizLoseCupDelta(cups);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppPalette.primary.withOpacity(.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text('سیستم کاپ: ${quizCupPhaseName(cups)}', style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
          const SizedBox(height: 8),
          Row(
            textDirection: TextDirection.rtl,
            children: [
              Expanded(child: _CupDeltaBadge(label: 'برد', value: win, positive: true)),
              const SizedBox(width: 8),
              Expanded(child: _CupDeltaBadge(label: 'باخت', value: lose, positive: lose >= 0)),
            ],
          ),
          const SizedBox(height: 8),
          Text('حریف با نزدیک‌ترین کاپ و شروع هم‌زمان انتخاب می‌شود.', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _CupDeltaBadge extends StatelessWidget {
  const _CupDeltaBadge({required this.label, required this.value, required this.positive});
  final String label;
  final int value;
  final bool positive;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: positive ? const Color(0xFFEFFDF5) : const Color(0xFFFFF1F2),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text('$label: ${signedCupText(value)}', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, color: positive ? AppPalette.mint : AppPalette.coral)),
    );
  }
}

class MatchmakingOpponentCard extends StatelessWidget {
  const MatchmakingOpponentCard({super.key, required this.opponent, required this.startingCups});
  final LeaderRow opponent;
  final int startingCups;

  @override
  Widget build(BuildContext context) {
    final diff = (opponent.xp - startingCups).abs();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 12, offset: Offset(0, 6))]),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          SizedBox(
            width: 40,
            height: 40,
            child: opponent.avatar.isNotEmpty || opponent.avatarUrl.isNotEmpty
                ? avatarImageForTitle(opponent.avatar, fit: BoxFit.contain, remoteUrl: opponent.avatarUrl)
                : const GaminoAvatarPlaceholder(iconSize: 30),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('حریف هم‌زمان: ${opponent.name}', style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
                Text('${cupText(opponent.xp)} | اختلاف ${cupText(diff)}', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          const Icon(Icons.sync_rounded, color: AppPalette.secondary),
        ],
      ),
    );
  }
}

class QuizSessionScreen extends StatefulWidget {
  const QuizSessionScreen({
    super.key,
    required this.title,
    required this.questions,
    required this.onComplete,
    this.timeLimitSeconds,
    this.startingCups,
    this.userGrade,
    this.roomCode,
    this.quizSource = 'standard',
  });

  final String title;
  final List<QuizQuestion> questions;
  final void Function(QuizResult result) onComplete;
  final int? timeLimitSeconds;
  final int? startingCups;
  final int? userGrade;
  final String? roomCode;
  final String quizSource;

  @override
  State<QuizSessionScreen> createState() => _QuizSessionScreenState();
}

class _QuizSessionScreenState extends State<QuizSessionScreen> {
  int currentIndex = 0;
  int? selectedIndex;
  final Map<String, int> answers = {};
  QuizResult? result;
  Timer? timer;
  late int remainingSeconds;
  LeaderRow? matchedOpponent;

  @override
  void initState() {
    super.initState();
    remainingSeconds = widget.timeLimitSeconds ?? 45;
    if (widget.startingCups != null && widget.userGrade != null) {
      matchedOpponent = closestOpponentForCups(widget.startingCups!, widget.userGrade!);
    }
    timer = Timer.periodic(const Duration(seconds: 1), (_) => tickTimer());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void tickTimer() {
    if (!mounted || result != null || widget.questions.isEmpty) return;
    if (remainingSeconds <= 1) {
      handleTimeout();
      return;
    }
    setState(() => remainingSeconds -= 1);
  }

  void handleTimeout() {
    final question = widget.questions[currentIndex];
    answers[question.id] = selectedIndex ?? -1;

    if (currentIndex == widget.questions.length - 1) {
      finish();
    } else {
      setState(() {
        currentIndex += 1;
        selectedIndex = answers[widget.questions[currentIndex].id];
        remainingSeconds = widget.timeLimitSeconds ?? 45;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false, title: Text(widget.title)),
        body: const Center(child: Text('سوالی برای این بخش ثبت نشده است.')),
      );
    }

    if (result != null) {
      return Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false, title: Text(widget.title)),
        body: ResultView(result: result!),
      );
    }

    final question = widget.questions[currentIndex];
    final progress = (currentIndex + 1) / widget.questions.length;

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text(widget.title)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          LinearProgressIndicator(value: progress),
          const SizedBox(height: 10),
          TimerPill(remainingSeconds: remainingSeconds),
          if (matchedOpponent != null) ...[
            const SizedBox(height: 10),
            MatchmakingOpponentCard(opponent: matchedOpponent!, startingCups: widget.startingCups!),
          ],
          const SizedBox(height: 12),
          Text('سوال ${currentIndex + 1} از ${widget.questions.length}', style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Chip(label: Text(question.subject)),
                  const SizedBox(height: 12),
                  Text(question.text, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, height: 1.8)),
                  const SizedBox(height: 16),
                  ...List.generate(question.options.length, (index) {
                    final selected = selectedIndex == index;
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(18),
                        onTap: () => setState(() => selectedIndex = index),
                        child: Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(18),
                            color: selected ? Theme.of(context).colorScheme.primaryContainer : const Color(0xFFF2F4F8),
                            border: Border.all(
                              color: selected ? Theme.of(context).colorScheme.primary : Colors.transparent,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off),
                              const SizedBox(width: 8),
                              Expanded(child: Text(question.options[index], style: const TextStyle(fontWeight: FontWeight.w700))),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: selectedIndex == null ? null : next,
            icon: Icon(currentIndex == widget.questions.length - 1 ? Icons.done_all : Icons.close_rounded),
            label: Text(currentIndex == widget.questions.length - 1 ? 'پایان کوییز' : 'سوال بعدی'),
          ),
        ],
      ),
    );
  }

  void next() {
    final question = widget.questions[currentIndex];
    answers[question.id] = selectedIndex!;

    if (currentIndex == widget.questions.length - 1) {
      finish();
    } else {
      setState(() {
        currentIndex += 1;
        selectedIndex = answers[widget.questions[currentIndex].id];
        remainingSeconds = widget.timeLimitSeconds ?? 45;
      });
    }
  }

  void finish() {
    final wrongAnswers = <WrongAnswer>[];
    int correct = 0;

    for (final question in widget.questions) {
      final selected = answers[question.id];
      if (selected == question.correctIndex) {
        correct += 1;
      } else {
        wrongAnswers.add(WrongAnswer(question: question, selectedIndex: selected ?? -1));
      }
    }

    final won = correct > widget.questions.length / 2;
    final isRoomCompetition = widget.roomCode != null && widget.roomCode!.isNotEmpty;
    final isOnlineCompetition = widget.quizSource == 'online_competition' || isRoomCompetition;
    final isExamBuilder = widget.quizSource == 'exam_builder';
    final currentCupBase = widget.startingCups ?? 0;
    final earnedXp = isExamBuilder
        ? 0
        : (isOnlineCompetition
            ? quizCupDelta(currentCupBase, won)
            : max(1, min(30, correct * 3)));
    final earnedCoins = (isOnlineCompetition || isExamBuilder) ? 0 : min(20, correct);

    final quizResult = QuizResult(
      questions: widget.questions,
      correctAnswers: correct,
      totalQuestions: widget.questions.length,
      xpEarned: earnedXp,
      coinsEarned: earnedCoins,
      wrongAnswers: wrongAnswers,
      answers: Map<String, int>.from(answers),
      isCompetitive: isOnlineCompetition,
      quizSource: widget.quizSource,
      roomCode: widget.roomCode,
      startingCups: widget.startingCups,
      opponentName: matchedOpponent?.name,
      opponentCups: matchedOpponent?.xp,
    );

    timer?.cancel();
    widget.onComplete(quizResult);
    setState(() => result = quizResult);
  }
}

class ResultView extends StatelessWidget {
  const ResultView({super.key, required this.result});

  final QuizResult result;

  @override
  Widget build(BuildContext context) {
    final percent = ((result.correctAnswers / result.totalQuestions) * 100).round();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                const Icon(Icons.emoji_events_outlined, size: 64),
                const SizedBox(height: 12),
                Text('$percent٪', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
                Text('${result.correctAnswers} پاسخ درست از ${result.totalQuestions} سوال'),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  alignment: WrapAlignment.center,
                  children: [
                    Chip(label: Text(signedCupText(result.xpEarned))),
                    Chip(label: Text('+${result.coinsEarned} کارت')),
                    Chip(label: Text('${result.wrongAnswers.length} اشتباه')),
                  ],
                ),
                if (result.isCompetitive && result.startingCups != null) ...[
                  const SizedBox(height: 12),
                  Text(
                    'سطح شروع: ${quizCupPhaseName(result.startingCups!)} | ${quizCupPhaseRange(result.startingCups!)}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink),
                  ),
                  if (result.opponentName != null)
                    Text(
                      'حریف نزدیک: ${result.opponentName} با ${cupText(result.opponentCups ?? 0)}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontWeight: FontWeight.w700, color: AppPalette.muted),
                    ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        InfoBox(
          title: 'تحلیل پیشنهادی',
          body: result.wrongAnswers.isEmpty
              ? 'عالی بود؛ همه سوال‌ها درست جواب داده شد. مرحله بعدی، کوییز زمان‌دار یا رقابت با کلاس است.'
              : 'سوالات غلط در بخش «اشتباهات من» ذخیره شدند. پیشنهاد: اول توضیح هر سوال را بخوان، بعد دوباره همان اشتباهات را تمرین کن.',
          icon: Icons.insights_outlined,
        ),
        if (result.wrongAnswers.isNotEmpty) ...[
          const Text('سوالات غلط', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          ...result.wrongAnswers.map((wrong) {
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(wrong.question.text, style: const TextStyle(fontWeight: FontWeight.w800, height: 1.7)),
                    const SizedBox(height: 8),
                    Text('پاسخ درست: ${wrong.question.options[wrong.question.correctIndex]}'),
                    Text('توضیح: ${wrong.question.explanation}', style: const TextStyle(color: Colors.black54, height: 1.7)),
                  ],
                ),
              ),
            );
          }),
        ],
        FilledButton.icon(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.done_rounded),
          label: const Text('بازگشت'),
        ),
      ],
    );
  }
}



class StudyRoadmapScreen extends StatelessWidget {
  const StudyRoadmapScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final weakestSkill = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    final focusSubject = weakestSkill.isEmpty ? 'ریاضی' : weakestSkill.first.key;
    final roadmap = [
      RoadmapStep(title: 'امروز', description: 'یک فصل از $focusSubject را بخوان و یک کوییز کوتاه بده.', icon: Icons.today_outlined, isDone: user.dailyActivity > 0),
      RoadmapStep(title: 'این هفته', description: 'حداقل ۳ کوییز زمان‌دار بده و اشتباهاتت را دوباره تمرین کن.', icon: Icons.calendar_view_week_outlined, isDone: user.matchesCount >= 3),
      RoadmapStep(title: 'قبل از امتحان', description: 'از آزمون‌ساز، آزمون ۱۰ سوالی بساز و نتیجه را بررسی کن.', icon: Icons.fact_check_outlined, isDone: currentCups(user) >= 500),
      RoadmapStep(title: 'رقابت کلاسی', description: 'یک اتاق کلاسی بساز و لینک را برای همکلاسی‌ها بفرست.', icon: Icons.groups_2_outlined, isDone: user.wins > 0),
    ];

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('نقشه راه یادگیری')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'مسیر پیشنهادی پایه ${gradeLabel(user.grade)}',
            subtitle: 'تمرکز پیشنهادی امروز: $focusSubject',
            icon: Icons.route_outlined,
          ),
          const SizedBox(height: 12),
          ...roadmap.map((step) => Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: CircleAvatar(child: Icon(step.isDone ? Icons.check : step.icon)),
                  title: Text(step.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                  subtitle: Text(step.description, style: const TextStyle(height: 1.7)),
                  trailing: Chip(label: Text(step.isDone ? 'انجام شده' : 'در انتظار')),
                ),
              )),
          const InfoBox(
            title: 'هدف این بخش',
            body: 'در نسخه اصلی، این نقشه راه بر اساس عملکرد واقعی دانش‌آموز، فصل‌های ضعیف، زمان باقی‌مانده تا امتحان و برنامه مطالعه ساخته می‌شود.',
            icon: Icons.lightbulb_outline,
          ),
        ],
      ),
    );
  }
}

class ProgressReportScreen extends StatelessWidget {
  const ProgressReportScreen({super.key, required this.user, required this.mistakesCount});

  final AppUser user;
  final int mistakesCount;

  @override
  Widget build(BuildContext context) {
    final levelProgress = user.level >= 100 ? 1.0 : user.levelProgress.clamp(0.0, 1.0).toDouble();
    final nextLevelTarget = user.levelNextSeconds;
    final remainingStudySeconds = user.level >= 100 ? 0 : max(0, nextLevelTarget - user.studySeconds);
    final sortedSkills = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    final weakest = sortedSkills.isEmpty ? null : sortedSkills.first;
    final strongest = sortedSkills.isEmpty ? null : sortedSkills.last;

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('گزارش پیشرفت')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'تحلیل عملکرد ${user.name}',
            subtitle: 'Level ${user.level} | ${currentCups(user)} کاپ | ${user.coins} کارت',
            icon: Icons.analytics_outlined,
          ),
          const SizedBox(height: 12),
          SectionCard(
            title: 'پیشرفت تا Level بعدی',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                LinearProgressIndicator(value: levelProgress),
                const SizedBox(height: 8),
                Text(user.level >= 100 ? 'Level 100 کامل شده است.' : '${faNumber(user.studySeconds ~/ 60)} از ${faNumber(nextLevelTarget ~/ 60)} دقیقه مطالعه کل'),
                Text(user.level >= 100 ? 'به بالاترین Level رسیدی.' : 'تا Level ${user.level + 1} حدود ${faNumber((remainingStudySeconds / 60).ceil())} دقیقه مطالعه باقی مانده.'),
              ],
            ),
          ),
          Row(
            children: [
              Expanded(child: StatCard(title: 'مسابقات', value: '${user.matchesCount}', icon: Icons.sports_esports_outlined)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(title: 'برد', value: '${user.wins}', icon: Icons.emoji_events_outlined)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(title: 'اشتباهات', value: '$mistakesCount', icon: Icons.error_outline)),
            ],
          ),
          const SizedBox(height: 12),
          SectionCard(
            title: 'درس قوی و درس نیازمند تمرین',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('قوی‌ترین درس: ${strongest?.key ?? 'نامشخص'} ${strongest == null ? '' : '(${strongest.value}٪)'}'),
                const SizedBox(height: 8),
                Text('نیازمند تمرین: ${weakest?.key ?? 'نامشخص'} ${weakest == null ? '' : '(${weakest.value}٪)'}'),
                const SizedBox(height: 12),
                const Text('پیشنهاد: اول اشتباهات درس ضعیف‌تر را تمرین کن، بعد یک آزمون‌ساز زمان‌دار بگیر.'),
              ],
            ),
          ),
          IntelligenceLevelCard(user: user),
        ],
      ),
    );
  }
}

class RoadmapStep {
  const RoadmapStep({required this.title, required this.description, required this.icon, required this.isDone});

  final String title;
  final String description;
  final IconData icon;
  final bool isDone;
}

class AiTeacherScreen extends StatefulWidget {
  const AiTeacherScreen({super.key, required this.user});

  final AppUser user;

  @override
  State<AiTeacherScreen> createState() => _AiTeacherScreenState();
}

class _AiTeacherScreenState extends State<AiTeacherScreen> {
  final TextEditingController questionController = TextEditingController();
  final List<AiMessage> messages = [
    AiMessage(isUser: false, text: 'سلام! سوالت را بپرس. پاسخ بر اساس محتوای آموزشی منتشرشده برای پایه و رشته خودت از سرور گامینو پیدا می‌شود.'),
  ];

  @override
  void dispose() {
    questionController.dispose();
    super.dispose();
  }

  bool sending = false;

  Future<void> sendQuestion() async {
    final text = questionController.text.trim();
    if (text.isEmpty || sending) return;
    setState(() {
      sending = true;
      messages.add(AiMessage(isUser: true, text: text));
      questionController.clear();
    });
    try {
      final token = await RemoteSessionStore.readToken();
      if (token == null || token.isEmpty) throw const GaminoApiException('نشست کاربری پیدا نشد.');
      final data = await GaminoApiService.request('teacher.ask', token: token, body: {'question': text});
      final answer = data['answer']?.toString().trim() ?? '';
      final source = data['source']?.toString().trim() ?? '';
      if (!mounted) return;
      setState(() {
        messages.add(AiMessage(isUser: false, text: source.isEmpty ? answer : '$answer\n\nمنبع: $source'));
        sending = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        messages.add(AiMessage(isUser: false, text: 'دریافت پاسخ از سرور ناموفق بود. دوباره تلاش کن.'));
        sending = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('معلم هوشمند')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return Align(
                  alignment: message.isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    constraints: const BoxConstraints(maxWidth: 310),
                    decoration: BoxDecoration(
                      color: message.isUser ? Theme.of(context).colorScheme.primaryContainer : Colors.white,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Text(message.text, style: const TextStyle(height: 1.8)),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                children: [
                  Expanded(child: AppTextField(controller: questionController, label: 'سوالت را بنویس', icon: Icons.question_answer_outlined)),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 56,
                    height: 52,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        padding: EdgeInsets.zero,
                        minimumSize: const Size(56, 52),
                        fixedSize: const Size(56, 52),
                      ),
                      onPressed: sending ? null : sendQuestion,
                      child: const Icon(Icons.send_rounded),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AiMessage {
  const AiMessage({required this.isUser, required this.text});

  final bool isUser;
  final String text;
}

class TimerPill extends StatelessWidget {
  const TimerPill({super.key, required this.remainingSeconds});

  final int remainingSeconds;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Chip(
        avatar: const Icon(Icons.timer_outlined, size: 18),
        label: Text('$remainingSeconds ثانیه'),
      ),
    );
  }
}

class RoomScoreboard extends StatelessWidget {
  const RoomScoreboard({super.key, required this.rows});

  final List<LeaderRow> rows;

  @override
  Widget build(BuildContext context) {

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: const Color(0xFFF2F4F8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('اسکوربورد اتاق', style: TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          if (rows.isEmpty) const Text('هنوز امتیازی در این اتاق ثبت نشده است.'),
          ...rows.map((row) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  children: [
                    Text('${row.rank}.', style: const TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(width: 8),
                    Expanded(child: Text(row.name)),
                    Text('${row.xp} امتیاز', style: const TextStyle(fontWeight: FontWeight.w800)),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}


class DailyChallengeScreen extends StatelessWidget {
  const DailyChallengeScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final challenges = [
      const ChallengeItem(title: 'ورود و همگام‌سازی', description: 'حساب آنلاین فعال است و وضعیت فعلی از سرور دریافت شده.', reward: 'انجام شد', progress: 1.0),
      ChallengeItem(title: 'کوییز ثبت‌شده', description: 'حداقل یک کوییز واقعی از سوالات منتشرشده انجام بده.', reward: user.quizHistory.isNotEmpty ? 'انجام شد' : 'در انتظار', progress: user.quizHistory.isNotEmpty ? 1.0 : 0.0),
      ChallengeItem(title: 'تکمیل فصل', description: 'حداقل یک فصل آموزشی منتشرشده را کامل کن.', reward: user.completedChapters > 0 ? 'انجام شد' : 'در انتظار', progress: user.completedChapters > 0 ? 1.0 : 0.0),
      ChallengeItem(title: 'برد مسابقه', description: 'حداقل یک برد ثبت‌شده در حساب داشته باش.', reward: user.wins > 0 ? 'انجام شد' : 'در انتظار', progress: user.wins > 0 ? 1.0 : 0.0),
    ];

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('ماموریت‌های فعالیت')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'ماموریت‌های حساب',
            subtitle: 'وضعیت این ماموریت‌ها فقط از فعالیت‌های ثبت‌شده واقعی محاسبه می‌شود.',
            icon: Icons.local_fire_department_outlined,
          ),
          const SizedBox(height: 12),
          SectionCard(
            title: 'خلاصه وضعیت',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('موجودی فعلی: ${user.coins} کارت | Level ${user.level}'),
                const SizedBox(height: 10),
                const Text('پیشرفت این بخش از فعالیت‌های ثبت‌شده حساب آنلاین محاسبه می‌شود.'),
              ],
            ),
          ),
          ...challenges.map((challenge) => Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const CircleAvatar(child: Icon(Icons.flag_outlined)),
                          const SizedBox(width: 10),
                          Expanded(child: Text(challenge.title, style: const TextStyle(fontWeight: FontWeight.w900))),
                          Chip(label: Text(challenge.reward)),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(challenge.description, style: const TextStyle(color: Colors.black54, height: 1.7)),
                      const SizedBox(height: 10),
                      LinearProgressIndicator(value: challenge.progress),
                    ],
                  ),
                ),
              )),
        ],
      ),
    );
  }
}

class ChallengeItem {
  const ChallengeItem({required this.title, required this.description, required this.reward, required this.progress});

  final String title;
  final String description;
  final String reward;
  final double progress;
}

class QuestionBankScreen extends StatelessWidget {
  const QuestionBankScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('نمونه سوال')),
      body: FutureBuilder<List<QuizQuestion>>(
        future: fetchPublishedQuestionsForUser(user),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('دریافت سوالات ناموفق بود: ${snapshot.error}')));
          final questions = snapshot.data ?? const <QuizQuestion>[];
          final subjects = questions.map((question) => question.subject).toSet().toList();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              PageTitle(
                title: 'نمونه سوال پایه ${gradeLabel(user.grade)}',
                subtitle: 'فقط سوالات منتشرشده از پنل مدیریت نمایش داده می‌شوند.',
                icon: Icons.inventory_2_outlined,
              ),
              const SizedBox(height: 12),
              if (questions.isEmpty)
                const InfoBox(title: 'سوالی منتشر نشده', body: 'مدیر باید برای کتاب‌ها و درس‌های این پایه نمونه سوال ثبت و منتشر کند.', icon: Icons.info_outline),
              ...subjects.map((subject) {
                final rows = questions.where((question) => question.subject == subject).toList();
                return FeatureCard(
                  title: subject,
                  subtitle: '${rows.length} سوال منتشرشده',
                  icon: Icons.folder_copy_outlined,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuestionBankSubjectScreen(subject: subject, questions: rows))),
                );
              }),
            ],
          );
        },
      ),
    );
  }
}

class QuestionBankSubjectScreen extends StatelessWidget {
  const QuestionBankSubjectScreen({super.key, required this.subject, required this.questions});

  final String subject;
  final List<QuizQuestion> questions;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text('نمونه سوال $subject')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          InfoBox(
            title: 'فیلتر هوشمند',
            body: 'سوالات این بخش مستقیماً از محتوای منتشرشده پنل مدیریت خوانده می‌شوند.',
            icon: Icons.tune_outlined,
          ),
          ...questions.map((question) => Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(spacing: 8, children: [Chip(label: Text(question.chapter)), const Chip(label: Text('متوسط'))]),
                      const SizedBox(height: 8),
                      Text(question.text, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.7)),
                      const SizedBox(height: 8),
                      Text('پاسخ درست: ${question.options[question.correctIndex]}'),
                      Text('توضیح: ${question.explanation}', style: const TextStyle(color: Colors.black54, height: 1.7)),
                    ],
                  ),
                ),
              )),
        ],
      ),
    );
  }
}

class ExamCountdownScreen extends StatelessWidget {
  const ExamCountdownScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final skillRows = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    final exams = skillRows.take(3).map((entry) => ExamPlan(
      subject: entry.key,
      dateLabel: 'مهارت ثبت‌شده: ${entry.value}٪',
      progress: (entry.value / 100).clamp(0.0, 1.0).toDouble(),
      focus: entry.value < 50 ? 'اولویت بالا برای مرور و کوییز' : entry.value < 75 ? 'مرور تکمیلی و یک کوییز کوتاه' : 'مرور سبک برای حفظ آمادگی',
    )).toList();

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('آمادگی امتحان')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'آمادگی امتحان پایه ${gradeLabel(user.grade)}',
            subtitle: 'اولویت مرور بر اساس مهارت‌های واقعی ثبت‌شده حساب',
            icon: Icons.event_available_outlined,
          ),
          const SizedBox(height: 12),
          ...exams.map((exam) => SectionCard(
                title: exam.subject,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [Text(exam.dateLabel), Chip(label: Text(exam.progress < .5 ? 'اولویت بالا' : 'پایدار'))],
                    ),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(value: exam.progress),
                    const SizedBox(height: 10),
                    Text('پیشنهاد مرور: ${exam.focus}', style: const TextStyle(height: 1.7)),
                  ],
                ),
              )),
          const InfoBox(
            title: 'روش محاسبه',
            body: 'این اولویت‌ها از درصد مهارت ثبت‌شده هر درس ساخته می‌شوند و هیچ تاریخ یا پیشرفت ساختگی نمایش داده نمی‌شود.',
            icon: Icons.auto_awesome_outlined,
          ),
        ],
      ),
    );
  }
}

class ExamPlan {
  const ExamPlan({required this.subject, required this.dateLabel, required this.progress, required this.focus});

  final String subject;
  final String dateLabel;
  final double progress;
  final String focus;
}

class ParentReportScreen extends StatelessWidget {
  const ParentReportScreen({super.key, required this.user, required this.mistakesCount});

  final AppUser user;
  final int mistakesCount;

  @override
  Widget build(BuildContext context) {
    final averageSkill = user.skills.isEmpty ? 0 : (user.skills.values.reduce((a, b) => a + b) / user.skills.length).round();
    final weak = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('گزارش والدین')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'خلاصه عملکرد ${user.name}',
            subtitle: 'گزارش قابل نمایش برای خانواده و مشاور',
            icon: Icons.family_restroom_outlined,
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: StatCard(title: 'میانگین مهارت', value: '$averageSkill٪', icon: Icons.query_stats_outlined)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(title: 'اشتباهات', value: '$mistakesCount', icon: Icons.error_outline)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(title: 'فعالیت', value: '${user.dailyActivity}', icon: Icons.bolt_outlined)),
            ],
          ),
          const SizedBox(height: 12),
          SectionCard(
            title: 'جمع‌بندی مشاور',
            child: Text(
              'دانش‌آموز در Level ${user.level} قرار دارد و ${currentCups(user)} کاپ کسب کرده است. درس نیازمند تمرین بیشتر: ${weak.isEmpty ? 'نامشخص' : weak.first.key}. پیشنهاد می‌شود روزانه یک کوییز کوتاه و هفته‌ای یک آزمون زمان‌دار انجام شود.',
              style: const TextStyle(height: 1.8),
            ),
          ),
          SectionCard(
            title: 'وضعیت درس‌ها',
            child: Column(
              children: user.skills.entries.map((entry) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(entry.key), Text('${entry.value}٪')]),
                        const SizedBox(height: 6),
                        LinearProgressIndicator(value: entry.value / 100),
                      ],
                    ),
                  )).toList(),
            ),
          ),
          OutlinedButton.icon(
            onPressed: () => Clipboard.setData(ClipboardData(text: 'گزارش ${user.name}: Level ${user.level}، کاپ ${currentCups(user)}، میانگین مهارت $averageSkill٪')),
            icon: const Icon(Icons.copy_outlined),
            label: const Text('کپی خلاصه گزارش'),
          ),
        ],
      ),
    );
  }
}

class ClassManagementScreen extends StatelessWidget {
  const ClassManagementScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final code = 'CLS${user.grade}24';
    final link = 'https://edu-battle.app/class/$code';

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('مدیریت کلاس و دعوت')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'کلاس پایه ${gradeLabel(user.grade)}',
            subtitle: 'ساخت کلاس، ارسال لینک و تنظیم رقابت گروهی',
            icon: Icons.meeting_room_outlined,
          ),
          const SizedBox(height: 12),
          SectionCard(
            title: 'لینک دعوت کلاس',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SelectableText(link, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: () {
                    Clipboard.setData(ClipboardData(text: link));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لینک کلاس کپی شد')));
                  },
                  icon: const Icon(Icons.copy_outlined),
                  label: const Text('کپی لینک دعوت'),
                ),
              ],
            ),
          ),
          SectionCard(
            title: 'تنظیمات مسابقه کلاسی',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                ListTile(leading: Icon(Icons.timer_outlined), title: Text('زمان هر سوال'), subtitle: Text('۳۰ ثانیه')),
                ListTile(leading: Icon(Icons.people_outline), title: Text('حداکثر شرکت‌کننده'), subtitle: Text('۳۰ نفر')),
                ListTile(leading: Icon(Icons.rule_outlined), title: Text('قانون امتیازدهی'), subtitle: Text('پاسخ درست +۱۰، سرعت بیشتر +۲')),
              ],
            ),
          ),
          const InfoBox(
            title: 'وضعیت کلاس',
            body: 'این بخش فقط اطلاعاتی را نمایش می‌دهد که از حساب و سرویس‌های فعال گامینو قابل محاسبه باشد؛ داده ساختگی نمایش داده نمی‌شود.',
            icon: Icons.cloud_queue_outlined,
          ),
        ],
      ),
    );
  }
}

class WalletScreen extends StatelessWidget {
  const WalletScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('کیف پول کارت‌ها')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: '${user.coins} کارت',
            subtitle: 'با بازی و مطالعه کارت بگیر و آیتم پروفایل باز کن.',
            icon: Icons.account_balance_wallet_outlined,
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: StatCard(title: 'کارت فعلی', value: '${user.coins}', icon: Icons.style_outlined)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(title: 'Level', value: '${user.level}', icon: Icons.trending_up)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(title: 'برد', value: '${user.wins}', icon: Icons.emoji_events_outlined)),
            ],
          ),
          const SizedBox(height: 12),
          SectionCard(
            title: 'راه‌های گرفتن کارت',
            child: Column(
              children: const [
                ListTile(leading: Icon(Icons.quiz_outlined), title: Text('کوییز بده'), subtitle: Text('هر پاسخ درست کارت می‌دهد')),
                ListTile(leading: Icon(Icons.check_circle_outline), title: Text('فصل کامل کن'), subtitle: Text('هر فصل تکمیل‌شده پاداش دارد')),
                ListTile(leading: Icon(Icons.groups_2_outlined), title: Text('با دوستان مسابقه بده'), subtitle: Text('برد در مسابقه گروهی جایزه بیشتری دارد')),
              ],
            ),
          ),
          const InfoBox(
            title: 'ثبت تراکنش روی سرور',
            body: 'افزایش و کاهش کارت در نسخه آنلاین داخل لاگ تراکنش‌های سرور ثبت می‌شود؛ این صفحه دیگر سابقه ساختگی نمایش نمی‌دهد.',
            icon: Icons.receipt_long_outlined,
          ),
        ],
      ),
    );
  }
}

class CoinTransaction {
  const CoinTransaction({required this.title, required this.amount, required this.description});

  final String title;
  final String amount;
  final String description;
}

class FlashcardScreen extends StatelessWidget {
  const FlashcardScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final weak = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('مرور سریع')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'مرور سریع پایه ${gradeLabel(user.grade)}',
            subtitle: 'اولویت مرور از مهارت‌های واقعی حساب تعیین می‌شود.',
            icon: Icons.style_outlined,
          ),
          const SizedBox(height: 12),
          if (weak.isEmpty)
            const InfoBox(title: 'هنوز داده کافی نیست', body: 'بعد از انجام کوییزهای منتشرشده، درس‌های نیازمند مرور در این بخش مشخص می‌شوند.', icon: Icons.info_outline),
          ...weak.take(4).map((entry) => SectionCard(
                title: entry.key,
                child: Row(
                  children: [
                    Expanded(child: Text(entry.value < 50 ? 'اولویت مرور بالا' : entry.value < 75 ? 'مرور تکمیلی پیشنهاد می‌شود' : 'وضعیت مناسب؛ مرور سبک کافی است')),
                    Chip(label: Text('${entry.value}٪')),
                  ],
                ),
              )),
          const InfoBox(
            title: 'محتوای مرور',
            body: 'برای تمرین، از بخش اشتباهات من یا نمونه سوال استفاده کن؛ هر دو فقط از سوالات منتشرشده پنل مدیریت استفاده می‌کنند.',
            icon: Icons.fact_check_outlined,
          ),
        ],
      ),
    );
  }
}

class FlashItem {
  const FlashItem({required this.front, required this.back});

  final String front;
  final String back;
}

class StyleStudioScreen extends StatelessWidget {
  const StyleStudioScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final themes = [
      _ThemePreview(title: 'آبی رقابتی', subtitle: 'تم پیش‌فرض برای فضای آموزشی و جدی', colors: AppPalette.gradientForIndex(0), level: 1),
      _ThemePreview(title: 'بنفش قهرمانی', subtitle: 'برای کاربرهای Level 3 به بالا', colors: AppPalette.gradientForIndex(1), level: 3),
      _ThemePreview(title: 'نارنجی چالشی', subtitle: 'مناسب چالش و بردهای متوالی', colors: AppPalette.gradientForIndex(2), level: 5),
      _ThemePreview(title: 'سبز تمرکز', subtitle: 'برای برنامه مطالعه و مرور امتحان', colors: AppPalette.gradientForIndex(3), level: 7),
    ];

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('استودیو ظاهر')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'ظاهر گیمی پروفایل',
            subtitle: 'تم‌ها و آیتم‌های قابل استفاده بر اساس Level و وضعیت حساب نمایش داده می‌شوند.',
            icon: Icons.palette_outlined,
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              gradient: AppPalette.heroGradient,
              boxShadow: [BoxShadow(color: AppPalette.secondary.withOpacity(0.20), blurRadius: 26, offset: const Offset(0, 14))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SizedBox(
                      width: 68,
                      height: 68,
                      child: avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(user.name, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
                          Text('قاب ویژه | ${user.avatar} | ${user.coins} کارت', style: TextStyle(color: Colors.white.withOpacity(0.82))),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: const [
                    GlassChip(label: 'افکت ورود', icon: Icons.auto_awesome),
                    GlassChip(label: 'قاب رنگی', icon: Icons.crop_square),
                    GlassChip(label: 'نشان قهرمان', icon: Icons.workspace_premium),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'تم‌های قابل باز شدن',
            child: Column(children: themes.map((item) => _ThemePreviewCard(item: item, userLevel: user.level)).toList()),
          ),
          SectionCard(
            title: 'پیشنهاد طراحی برای ادامه پروژه',
            child: Column(
              children: const [
                _DesignBullet(icon: Icons.gradient_outlined, title: 'هر درس یک رنگ اختصاصی', body: 'ریاضی آبی، علوم سبز، فارسی بنفش و زبان نارنجی تا کاربر سریع‌تر مسیرش را تشخیص بدهد.'),
                _DesignBullet(icon: Icons.motion_photos_on_outlined, title: 'افکت پاداش بعد از برد', body: 'بعد از کوییز، کارت نتیجه با انیمیشن کارت، کاپ و مدال نمایش داده شود.'),
                _DesignBullet(icon: Icons.person_pin_circle_outlined, title: 'پروفایل کلکسیونی', body: 'آواتار، قاب، بک‌گراند و عنوان کاربر با کارت و Level آزاد شود.'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ThemePreview {
  const _ThemePreview({required this.title, required this.subtitle, required this.colors, required this.level});

  final String title;
  final String subtitle;
  final List<Color> colors;
  final int level;
}

class _ThemePreviewCard extends StatelessWidget {
  const _ThemePreviewCard({required this.item, required this.userLevel});

  final _ThemePreview item;
  final int userLevel;

  @override
  Widget build(BuildContext context) {
    final unlocked = userLevel >= item.level;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: LinearGradient(colors: item.colors),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.22), borderRadius: BorderRadius.circular(18)),
            child: Icon(unlocked ? Icons.check_circle_outline : Icons.lock_outline, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 4),
                Text(item.subtitle, style: TextStyle(color: Colors.white.withOpacity(0.82), height: 1.5)),
              ],
            ),
          ),
          Chip(label: Text(unlocked ? 'باز' : 'Level ${item.level}')),
        ],
      ),
    );
  }
}

class _DesignBullet extends StatelessWidget {
  const _DesignBullet({required this.icon, required this.title, required this.body});

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(gradient: AppPalette.actionGradient, borderRadius: BorderRadius.circular(15)),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
                const SizedBox(height: 4),
                Text(body, style: const TextStyle(color: AppPalette.muted, height: 1.6)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


class GoalCenterScreen extends StatelessWidget {
  const GoalCenterScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final xpTarget = 500;
    final weeklyXp = currentCups(user) % xpTarget;
    final xpPercent = weeklyXp / xpTarget;
    final matchTarget = 10;
    final matchProgress = min(user.matchesCount, matchTarget);
    final chapterTarget = 5;
    final chapterProgress = min(user.completedChapters, chapterTarget);

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('مرکز هدف‌گذاری')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'هدف‌های رشد ${user.name}',
            subtitle: 'هدف‌ها از پیشرفت ثبت‌شده حساب محاسبه می‌شوند تا مسیر مطالعه روشن‌تر باشد.',
            icon: Icons.flag_circle_outlined,
          ),
          const SizedBox(height: 14),
          SectionCard(
            title: 'هدف‌های این هفته',
            child: Column(
              children: [
                _GoalProgressTile(title: 'کسب کاپ هفتگی', value: weeklyXp, target: xpTarget, percent: xpPercent, icon: Icons.bolt_outlined),
                _GoalProgressTile(title: 'تعداد مسابقه', value: matchProgress, target: matchTarget, percent: matchProgress / matchTarget, icon: Icons.sports_esports_outlined),
                _GoalProgressTile(title: 'تکمیل فصل‌ها', value: chapterProgress, target: chapterTarget, percent: chapterProgress / chapterTarget, icon: Icons.menu_book_outlined),
              ],
            ),
          ),
          SectionCard(
            title: 'پیشنهاد برنامه فردا',
            child: Column(
              children: const [
                _PlanRow(time: '۱۷:۰۰', title: 'مرور ۲۰ دقیقه‌ای ریاضی', subtitle: 'تمرکز روی اشتباهات پرتکرار'),
                _PlanRow(time: '۱۸:۳۰', title: 'یک کوییز سریع علوم', subtitle: 'هدف: حداقل ۷۰٪ پاسخ درست'),
                _PlanRow(time: '۲۰:۰۰', title: 'فلش‌کارت فارسی', subtitle: '۵ کارت مرور قبل از خواب'),
              ],
            ),
          ),
          const InfoBox(
            title: 'مبنای هدف‌ها',
            body: 'پیشرفت هدف‌ها از کاپ، تعداد مسابقه و فصل‌های تکمیل‌شده حساب آنلاین محاسبه می‌شود.',
            icon: Icons.auto_graph_outlined,
          ),
        ],
      ),
    );
  }
}

class SmartReviewScreen extends StatelessWidget {
  const SmartReviewScreen({super.key, required this.user, required this.mistakesCount});

  final AppUser user;
  final int mistakesCount;

  @override
  Widget build(BuildContext context) {
    final skills = user.skills.entries.toList()..sort((a, b) => a.value.compareTo(b.value));
    final weakestSubject = skills.isEmpty ? 'عمومی' : skills.first.key;
    final weakestPercent = skills.isEmpty ? 0 : skills.first.value;
    final strongestSubject = skills.isEmpty ? 'عمومی' : skills.last.key;

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('مرور هوشمند اشتباهات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'مرور هوشمند',
            subtitle: 'این صفحه به دانش‌آموز می‌گوید اول کدام درس و کدام نوع سوال را دوباره تمرین کند.',
            icon: Icons.auto_fix_high_outlined,
          ),
          const SizedBox(height: 14),
          SectionCard(
            title: 'تشخیص سریع وضعیت',
            child: Column(
              children: [
                _InsightTile(icon: Icons.warning_amber_rounded, title: 'ضعیف‌ترین درس فعلی', value: '$weakestSubject - $weakestPercent٪', color: AppPalette.coral),
                _InsightTile(icon: Icons.verified_outlined, title: 'قوی‌ترین درس فعلی', value: strongestSubject, color: AppPalette.mint),
                _InsightTile(icon: Icons.replay_circle_filled_outlined, title: 'اشتباهات ذخیره‌شده', value: '$mistakesCount سوال', color: AppPalette.secondary),
              ],
            ),
          ),
          SectionCard(
            title: 'مسیر مرور پیشنهادی',
            child: Column(
              children: [
                _ReviewStep(number: '۱', title: 'شروع با $weakestSubject', body: 'اول ۵ سوال کوتاه از درس ضعیف‌تر حل کن.'),
                const _ReviewStep(number: '۲', title: 'تمرین اشتباهات من', body: 'سوالاتی که قبلاً غلط زدی دوباره حل می‌شوند.'),
                const _ReviewStep(number: '۳', title: 'کوییز ۳۰ ثانیه‌ای', body: 'بعد از مرور، یک آزمون کوتاه برای تثبیت بزن.'),
              ],
            ),
          ),
          const InfoBox(
            title: 'مبنای پیشنهاد مرور',
            body: 'اولویت مرور از مهارت‌های ثبت‌شده و اشتباهات واقعی حساب تعیین می‌شود؛ سوالات مرور نیز از محتوای منتشرشده پنل می‌آیند.',
            icon: Icons.psychology_alt_outlined,
          ),
        ],
      ),
    );
  }
}

class ReminderCenterScreen extends StatelessWidget {
  const ReminderCenterScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('اعلان‌ها و یادآوری‌ها')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'مرکز یادآوری',
            subtitle: 'پیشنهادهای مطالعه بر اساس برنامه و فعالیت حساب نمایش داده می‌شوند.',
            icon: Icons.notifications_active_outlined,
          ),
          const SizedBox(height: 14),
          SectionCard(
            title: 'یادآوری‌های پیشنهادی',
            child: Column(
              children: const [
                _ReminderPreviewTile(title: 'مطالعه روزانه', time: 'هر روز ساعت ۱۸:۰۰', status: 'فعال پیشنهادی', icon: Icons.event_note_outlined),
                _ReminderPreviewTile(title: 'چالش روزانه', time: 'هر روز ساعت ۲۰:۳۰', status: 'جایزه کارت', icon: Icons.local_fire_department_outlined),
                _ReminderPreviewTile(title: 'مسابقه با دوستان', time: 'قبل از شروع اتاق', status: 'اتاق آنلاین', icon: Icons.groups_2_outlined),
                _ReminderPreviewTile(title: 'مرور اشتباهات', time: 'یک روز بعد از کوییز', status: 'هوشمند', icon: Icons.replay_outlined),
              ],
            ),
          ),
          SectionCard(
            title: 'متن اعلان‌های آماده',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                _NotificationText(text: 'وقتشه ۱۰ دقیقه ریاضی مرور کنی و کاپ بگیری.'),
                _NotificationText(text: 'چالش امروز آماده‌ست؛ کارت رایگان رو از دست نده.'),
                _NotificationText(text: 'دوستت منتظرته؛ وارد اتاق مسابقه شو.'),
              ],
            ),
          ),
          const InfoBox(
            title: 'یادآوری داخل برنامه',
            body: 'این صفحه مرکز پیشنهادهای یادآوری داخل گامینو است. زمان‌های نمایش‌داده‌شده پیشنهاد مطالعه‌اند و به‌عنوان اعلان سیستمی گوشی ثبت نمی‌شوند.',
            icon: Icons.settings_suggest_outlined,
          ),
        ],
      ),
    );
  }
}

class BackendRoadmapScreen extends StatelessWidget {
  const BackendRoadmapScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('نقشه اتصال بک‌اند')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'وضعیت زیرساخت آنلاین',
            subtitle: 'زیرساخت اصلی حساب، محتوا، پیشرفت، کارت و کاپ به سرور متصل است.',
            icon: Icons.hub_outlined,
          ),
          const SizedBox(height: 14),
          SectionCard(
            title: 'بخش‌های متصل به سرور',
            child: Column(
              children: const [
                _RoadmapItem(step: '۱', title: 'ورود آنلاین', body: 'ثبت‌نام و ورود با API اختصاصی گامینو فعال است'),
                _RoadmapItem(step: '۲', title: 'داده آنلاین', body: 'کاربران، کاپ، کارت، اشتباهات و برنامه مطالعه روی سرور ذخیره می‌شوند'),
                _RoadmapItem(step: '۳', title: 'اتاق مسابقه', body: 'ساخت اتاق، ورود چندنفره و اسکوربورد سروری فعال است'),
                _RoadmapItem(step: '۴', title: 'پنل محتوای آموزشی', body: 'کتاب، درس، PDF، تصویر و نمونه‌سوال از پنل مدیریت می‌شوند'),
                _RoadmapItem(step: '۵', title: 'معلم هوشمند محتوایی', body: 'پاسخ بر اساس محتوای منتشرشده همان پایه و رشته از سرور تولید می‌شود'),
              ],
            ),
          ),
          SectionCard(
            title: 'وضعیت فعلی ${user.name}',
            child: Column(
              children: [
                _InsightTile(icon: Icons.storage_outlined, title: 'ذخیره اصلی', value: 'آنلاین روی سرور', color: AppPalette.primary),
                _InsightTile(icon: Icons.cloud_done_outlined, title: 'کش محتوا', value: 'PDF و تصویر روی گوشی', color: AppPalette.cyan),
                _InsightTile(icon: Icons.sports_score_outlined, title: 'اولویت محصول', value: 'کوییز با دوستان واقعی', color: AppPalette.amber),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


class ExamSimulatorScreen extends StatelessWidget {
  const ExamSimulatorScreen({super.key, required this.user});

  final AppUser user;

  Future<void> _submitResult(QuizResult result) async {
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) return;
    await GaminoApiService.request('activity.quiz_result', token: token, body: {
      'answers': result.answers.entries.map((entry) => {'questionId': entry.key, 'selectedIndex': entry.value}).toList(),
      'isCompetitive': false,
    });
  }

  @override
  Widget build(BuildContext context) {
    final weakSubject = user.skills.isEmpty ? 'عمومی' : user.skills.entries.reduce((a, b) => a.value <= b.value ? a : b).key;
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('شبیه‌ساز امتحان')),
      body: FutureBuilder<List<QuizQuestion>>(
        future: fetchPublishedQuestionsForUser(user),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          final all = snapshot.data ?? const <QuizQuestion>[];
          var suggestedQuestions = all.where((q) => q.subject == weakSubject).take(10).toList();
          if (suggestedQuestions.isEmpty) suggestedQuestions = all.take(10).toList();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              PageTitle(
                title: 'امتحان آزمایشی',
                subtitle: 'آزمون از نمونه‌سوال‌های واقعی منتشرشده برای پایه و رشته تو ساخته می‌شود.',
                icon: Icons.assignment_turned_in_outlined,
              ),
              const SizedBox(height: 14),
              SectionCard(
                title: 'پیشنهاد امروز',
                child: Column(children: [
                  _InsightTile(icon: Icons.school_outlined, title: 'تمرکز پیشنهادی', value: weakSubject, color: AppPalette.primary),
                  _InsightTile(icon: Icons.timer_outlined, title: 'زمان پیشنهادی', value: '۱۵ دقیقه', color: AppPalette.coral),
                  _InsightTile(icon: Icons.quiz_outlined, title: 'تعداد سوال', value: '${suggestedQuestions.length} سوال', color: AppPalette.cyan),
                ]),
              ),
              SectionCard(
                title: 'قوانین آزمون آزمایشی',
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                  _ReviewStep(number: '۱', title: 'آزمون زمان‌دار', body: 'برای پاسخ‌گویی ۱۵ دقیقه زمان داری.'),
                  _ReviewStep(number: '۲', title: 'اعتبارسنجی سرور', body: 'نتیجه و پاداش بر اساس پاسخ‌های واقعی در سرور محاسبه می‌شود.'),
                  _ReviewStep(number: '۳', title: 'ذخیره اشتباهات', body: 'سوالات غلط برای تمرین دوباره در حساب آنلاین ذخیره می‌شوند.'),
                ]),
              ),
              FilledButton.icon(
                onPressed: suggestedQuestions.isEmpty ? null : () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => QuizSessionScreen(
                    title: 'امتحان آزمایشی', questions: suggestedQuestions, timeLimitSeconds: 900,
                    userGrade: user.grade, onComplete: (result) => unawaited(_submitResult(result)),
                  )));
                },
                icon: const Icon(Icons.bolt_rounded),
                label: Text(suggestedQuestions.isEmpty ? 'هنوز سوالی منتشر نشده' : 'شروع شبیه‌ساز امتحان'),
              ),
            ],
          );
        },
      ),
    );
  }
}

class ReportCardScreen extends StatelessWidget {
  const ReportCardScreen({super.key, required this.user, required this.mistakesCount});

  final AppUser user;
  final int mistakesCount;

  int _estimatedScore(int skill) {
    final score = 8 + (skill * 12 / 100).round();
    return score.clamp(8, 20).toInt();
  }

  @override
  Widget build(BuildContext context) {
    final average = user.skills.isEmpty
        ? 0
        : user.skills.values.map(_estimatedScore).reduce((a, b) => a + b) / user.skills.length;
    final weak = user.skills.entries.reduce((a, b) => a.value <= b.value ? a : b);
    final strong = user.skills.entries.reduce((a, b) => a.value >= b.value ? a : b);
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('کارنامه تحلیلی')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(
            title: 'کارنامه تمرینی',
            subtitle: 'یک نمای خلاصه از وضعیت درس‌ها، نمره تخمینی و برنامه جبرانی برای ${user.name}.',
            icon: Icons.fact_check_outlined,
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(child: StatCard(title: 'میانگین', value: average.toStringAsFixed(1), icon: Icons.grade_outlined)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(title: 'قوی‌ترین', value: strong.key, icon: Icons.trending_up)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(title: 'اشتباه', value: '$mistakesCount', icon: Icons.error_outline)),
            ],
          ),
          const SizedBox(height: 16),
          SectionCard(
            title: 'نمره تخمینی هر درس',
            child: Column(
              children: user.skills.entries.map((entry) {
                final score = _estimatedScore(entry.value);
                return _ScoreRow(subject: entry.key, skill: entry.value, score: score);
              }).toList(),
            ),
          ),
          SectionCard(
            title: 'برنامه جبرانی پیشنهادی',
            child: Column(
              children: [
                _ReviewStep(number: '۱', title: 'تمرکز اصلی: ${weak.key}', body: 'این درس کمترین درصد مهارت را دارد؛ روزانه ۱۰ سوال از آن تمرین کن.'),
                const _ReviewStep(number: '۲', title: 'مرور اشتباهات', body: 'اول سوالاتی را حل کن که قبلاً غلط زده‌ای؛ این سریع‌ترین مسیر رشد است.'),
                const _ReviewStep(number: '۳', title: 'آزمون کوتاه', body: 'بعد از هر مرور، یک کوییز ۵ سوالی بده تا کاپ و کارت هم بگیری.'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ContentLibraryScreen extends StatelessWidget {
  const ContentLibraryScreen({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final subjects = user.skills.keys.toList();
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('کتابخانه محتوا')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const PageTitle(
            title: 'کتابخانه آموزشی',
            subtitle: 'محل نمایش ویدیو، جزوه، خلاصه درس، فلش‌کارت و تمرین‌های پیشنهادی.',
            icon: Icons.video_library_outlined,
          ),
          const SizedBox(height: 14),
          SectionCard(
            title: 'مسیر پیشنهادی پایه شما',
            child: Column(
              children: subjects.map((subject) => _ContentTile(subject: subject, grade: user.grade)).toList(),
            ),
          ),
          SectionCard(
            title: 'فرمت‌های آماده برای پنل ادمین',
            child: Column(
              children: const [
                _InsightTile(icon: Icons.play_circle_outline, title: 'ویدیو آموزشی', value: 'درس و فصل', color: AppPalette.primary),
                _InsightTile(icon: Icons.picture_as_pdf_outlined, title: 'جزوه PDF', value: 'خلاصه + مثال', color: AppPalette.coral),
                _InsightTile(icon: Icons.task_alt_outlined, title: 'تمرین', value: 'سوال تشریحی', color: AppPalette.mint),
                _InsightTile(icon: Icons.style_outlined, title: 'فلش‌کارت', value: 'مرور سریع', color: AppPalette.amber),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class BackupCenterScreen extends StatelessWidget {
  const BackupCenterScreen({super.key, required this.user, required this.mistakesCount, required this.saveStatus});

  final AppUser user;
  final int mistakesCount;
  final String saveStatus;

  String _summaryJson() {
    final data = {
      'version': '20',
      'name': user.name,
      'grade': user.grade,
      'level': user.level,
      'xp': currentCups(user),
      'coins': user.coins,
      'matchesCount': user.matchesCount,
      'wins': user.wins,
      'mistakesCount': mistakesCount,
      'completedChapters': user.completedChapters,
      'activeAvatar': user.avatar,
      'activeFrame': user.profileFrame,
      'activeTheme': user.themeName,
      'skills': user.skills,
      'medals': user.medals,
    };
    return const JsonEncoder.withIndent('  ').convert(data);
  }

  @override
  Widget build(BuildContext context) {
    final summary = _summaryJson();
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('پشتیبان‌گیری')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const PageTitle(
            title: 'پشتیبان‌گیری و انتقال داده',
            subtitle: 'این بخش برای آماده‌سازی انتقال از ذخیره آفلاین به دیتابیس آنلاین ساخته شده است.',
            icon: Icons.backup_outlined,
          ),
          const SizedBox(height: 14),
          SectionCard(
            title: 'وضعیت ذخیره فعلی',
            child: Column(
              children: [
                _InsightTile(icon: Icons.save_alt_outlined, title: 'وضعیت', value: saveStatus, color: AppPalette.primary),
                _InsightTile(icon: Icons.storage_outlined, title: 'نوع ذخیره', value: 'سرور گامینو', color: AppPalette.cyan),
                _InsightTile(icon: Icons.cloud_upload_outlined, title: 'مرحله بعد', value: 'Firebase / API', color: AppPalette.mint),
              ],
            ),
          ),
          SectionCard(
            title: 'خلاصه قابل انتقال',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: AppPalette.canvas, borderRadius: BorderRadius.circular(18)),
                  child: SelectableText(summary, textDirection: TextDirection.ltr, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: summary));
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خلاصه اطلاعات کپی شد')));
                    }
                  },
                  icon: const Icon(Icons.copy_all_outlined),
                  label: const Text('کپی خلاصه اطلاعات'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ScoreRow extends StatelessWidget {
  const _ScoreRow({required this.subject, required this.skill, required this.score});

  final String subject;
  final int skill;
  final int score;

  @override
  Widget build(BuildContext context) {
    final color = score >= 16 ? AppPalette.mint : score >= 12 ? AppPalette.amber : AppPalette.coral;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppPalette.canvas, borderRadius: BorderRadius.circular(20)),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: color.withOpacity(.16), child: Icon(Icons.menu_book_outlined, color: color)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(subject, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                LinearProgressIndicator(value: skill / 100, backgroundColor: Colors.white),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Text('$score/20', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: color)),
        ],
      ),
    );
  }
}

class _ContentTile extends StatelessWidget {
  const _ContentTile({required this.subject, required this.grade});

  final String subject;
  final int grade;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppPalette.canvas, borderRadius: BorderRadius.circular(20)),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(gradient: LinearGradient(colors: AppPalette.gradientForIndex(subject.hashCode)), borderRadius: BorderRadius.circular(16)),
            child: const Icon(Icons.play_lesson_outlined, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('$subject پایه ${gradeLabel(grade)}', style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                const Text('۳ ویدیو | ۲ جزوه | ۱۲ تمرین | ۸ فلش‌کارت', style: TextStyle(color: AppPalette.muted)),
              ],
            ),
          ),
          const Icon(Icons.more_horiz_rounded, color: AppPalette.primary),
        ],
      ),
    );
  }
}

class _GoalProgressTile extends StatelessWidget {
  const _GoalProgressTile({required this.title, required this.value, required this.target, required this.percent, required this.icon});

  final String title;
  final int value;
  final int target;
  final double percent;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final safePercent = percent.clamp(0.0, 1.0).toDouble();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppPalette.canvas, borderRadius: BorderRadius.circular(22)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppPalette.primary),
              const SizedBox(width: 8),
              Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink))),
              Text('$value / $target', style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted)),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(value: safePercent, minHeight: 9, backgroundColor: Colors.white),
          ),
        ],
      ),
    );
  }
}

class _PlanRow extends StatelessWidget {
  const _PlanRow({required this.time, required this.title, required this.subtitle});

  final String time;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(backgroundColor: AppPalette.primary.withOpacity(0.12), child: Text(time.split(':').first, style: const TextStyle(fontWeight: FontWeight.w900))),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
      subtitle: Text('$time | $subtitle'),
    );
  }
}

class _InsightTile extends StatelessWidget {
  const _InsightTile({required this.icon, required this.title, required this.value, required this.color});

  final IconData icon;
  final String title;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(20)),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: color.withOpacity(0.16), child: Icon(icon, color: color)),
          const SizedBox(width: 10),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink))),
          Text(value, style: TextStyle(fontWeight: FontWeight.w900, color: color)),
        ],
      ),
    );
  }
}

class _ReviewStep extends StatelessWidget {
  const _ReviewStep({required this.number, required this.title, required this.body});

  final String number;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(backgroundColor: AppPalette.secondary, child: Text(number, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 4),
                Text(body, style: const TextStyle(color: AppPalette.muted, height: 1.6)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ReminderPreviewTile extends StatelessWidget {
  const _ReminderPreviewTile({required this.title, required this.time, required this.status, required this.icon});

  final String title;
  final String time;
  final String status;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppPalette.canvas, borderRadius: BorderRadius.circular(22)),
      child: Row(
        children: [
          CircleAvatar(child: Icon(icon)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(time, style: const TextStyle(color: AppPalette.muted)),
              ],
            ),
          ),
          Chip(label: Text(status)),
        ],
      ),
    );
  }
}

class _NotificationText extends StatelessWidget {
  const _NotificationText({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppPalette.primary.withOpacity(0.07), borderRadius: BorderRadius.circular(18)),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink, height: 1.5)),
    );
  }
}

class _RoadmapItem extends StatelessWidget {
  const _RoadmapItem({required this.step, required this.title, required this.body});

  final String step;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: AppPalette.primary.withOpacity(0.08))),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(backgroundColor: AppPalette.ink, child: Text(step, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: AppPalette.ink)),
                const SizedBox(height: 4),
                Text(body, style: const TextStyle(color: AppPalette.muted, height: 1.6)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}




class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key, required this.user, required this.isGuest});

  final AppUser user;
  final bool isGuest;

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  String _period = 'کلی';
  bool _networkDialogOpen = false;

  Future<List<LeaderRow>> _loadRows() async {
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) return const <LeaderRow>[];
    final data = await GaminoApiService.request('leaderboard', token: token, body: {'grade': widget.user.grade, 'period': _period});
    final rawRows = data['rows'] as List? ?? const [];
    return rawRows.whereType<Map>().map((item) {
      final row = Map<String, dynamic>.from(item);
      return LeaderRow(
        userId: row['userId']?.toString() ?? '',
        rank: (row['rank'] as num?)?.toInt() ?? 0,
        name: row['name']?.toString() ?? 'دانش‌آموز',
        grade: (row['grade'] as num?)?.toInt() ?? widget.user.grade,
        xp: (row['xp'] as num?)?.toInt() ?? 0,
        avatar: row['avatar']?.toString() ?? '',
        avatarUrl: row['avatarUrl']?.toString() ?? '',
      );
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isGuest) {
      return const LockedScreen(
        title: 'رتبه‌بندی برای مهمان قفل است',
        message: 'برای دیدن رتبه‌بندی آنلاین باید ثبت‌نام کنید.',
      );
    }

    return SafeArea(
      child: FutureBuilder<List<LeaderRow>>(
        future: _loadRows(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (!mounted || _networkDialogOpen) return;
              _networkDialogOpen = true;
              showDialog<void>(
                context: context,
                barrierDismissible: false,
                builder: (dialogContext) => PopScope(
                  canPop: false,
                  onPopInvokedWithResult: (didPop, result) {
                    if (didPop) return;
                    Navigator.of(dialogContext).pop();
                    _networkDialogOpen = false;
                    gaminoHomeShellKey.currentState?.goHome();
                  },
                  child: AlertDialog(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                  title: const Text('اتصال اینترنت برقرار نیست', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900)),
                  content: const Text('برای مشاهده رتبه‌بندی، لطفاً دسترسی و اتصال اینترنت خود را بررسی کنید.', textAlign: TextAlign.center, style: TextStyle(height: 1.8, fontWeight: FontWeight.w700)),
                  actions: [
                    FilledButton.icon(
                      onPressed: () {
                        Navigator.pop(dialogContext);
                        _networkDialogOpen = false;
                        if (mounted) setState(() {});
                      },
                      icon: const Icon(Icons.refresh_rounded),
                      label: const Text('تلاش دوباره'),
                    ),
                  ],
                ),
                ),
              ).whenComplete(() => _networkDialogOpen = false);
            });
            return const Center(child: CircularProgressIndicator());
          }
          return ModernLeaderboardPage(
            rows: snapshot.data ?? const <LeaderRow>[],
            user: widget.user,
            period: _period,
            onPeriodChanged: (value) => setState(() => _period = value),
          );
        },
      ),
    );
  }
}

class _PremiumLeaderboardHeader extends StatelessWidget {
  const _PremiumLeaderboardHeader();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 390;
        final side = compact ? 14.0 : 18.0;
        return Padding(
          padding: EdgeInsets.fromLTRB(side, 12, side, 4),
          child: Row(
            children: [
              _LeaderboardPillButton(icon: Icons.leaderboard_outlined, label: compact ? '' : 'رتبه‌ها'),
              const SizedBox(width: 8),
              const _LeaderboardIconButton(icon: Icons.filter_alt_rounded),
              const Spacer(),
              Flexible(
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 16, vertical: 11),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: const [BoxShadow(color: Color(0x0D3D5AFE), blurRadius: 22, offset: Offset(0, 12))],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    textDirection: TextDirection.rtl,
                    children: [
                      Container(
                        width: compact ? 48 : 56,
                        height: compact ? 48 : 56,
                        decoration: BoxDecoration(
                          gradient: AppPalette.heroGradient,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: const [BoxShadow(color: Color(0x333D5AFE), blurRadius: 18, offset: Offset(0, 8))],
                        ),
                        child: const Icon(Icons.emoji_events_rounded, color: Colors.white, size: 31),
                      ),
                      const SizedBox(width: 12),
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text('رتبه‌بندی', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: TextStyle(fontSize: compact ? 18 : 21, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                            const SizedBox(height: 4),
                            const Text('رقابت بین دانش‌آموزان هم‌پایه', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _LeaderboardIconButton extends StatelessWidget {
  const _LeaderboardIconButton({required this.icon});
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: const [BoxShadow(color: Color(0x0A101827), blurRadius: 12, offset: Offset(0, 6))]),
      child: Icon(icon, color: AppPalette.secondary, size: 22),
    );
  }
}

class _LeaderboardPillButton extends StatelessWidget {
  const _LeaderboardPillButton({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 44,
      padding: EdgeInsets.symmetric(horizontal: label.isEmpty ? 12 : 14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: Color(0x0A101827), blurRadius: 12, offset: Offset(0, 6))]),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: AppPalette.secondary, size: 21),
          if (label.isNotEmpty) ...[
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(color: AppPalette.ink, fontWeight: FontWeight.w800)),
          ],
        ],
      ),
    );
  }
}

class StableLeaderboardPeriod extends StatefulWidget {
  const StableLeaderboardPeriod({super.key, required this.rows, required this.user, required this.period, required this.onPeriodChanged});

  final List<LeaderRow> rows;
  final AppUser user;
  final String period;
  final ValueChanged<String> onPeriodChanged;

  @override
  State<StableLeaderboardPeriod> createState() => _StableLeaderboardPeriodState();
}

class _StableLeaderboardPeriodState extends State<StableLeaderboardPeriod> {
  String? selectedKey;

  @override
  Widget build(BuildContext context) {
    final me = widget.rows.firstWhere(
      (row) => row.name == widget.user.name,
      orElse: () => LeaderRow(rank: 23, name: widget.user.name.isEmpty ? 'شما' : widget.user.name, grade: widget.user.grade, xp: currentCups(widget.user)),
    );
    final sorted = [...widget.rows]..sort((a, b) => a.rank.compareTo(b.rank));
    final top = sorted.where((row) => row.rank <= 3).toList();
    final seen = <String>{};
    final otherRows = sorted
        .where((row) => row.rank > 3)
        .where((row) => row.name != me.name)
        .where((row) => seen.add('${row.rank}-${row.name}'))
        .take(3)
        .toList();
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final pad = width < 360 ? 12.0 : 16.0;
        return ListView(
          padding: EdgeInsets.fromLTRB(pad, 8, pad, 118),
          children: [

            _LeaderboardSegmentButtons(selected: widget.period, onChanged: widget.onPeriodChanged),
            const SizedBox(height: 18),
            StableTopThree(rows: top, selectedKey: selectedKey, onTap: _toggle),
            const SizedBox(height: 16),
            for (final row in otherRows) StableLeaderListTile(row: row, selected: selectedKey == _key(row), onTap: () => _toggle(row)),
            StableLeaderListTile(row: me, selected: selectedKey == _key(me), onTap: () => _toggle(me), isMe: true),
          ],
        );
      },
    );
  }

  String _key(LeaderRow row) => '${row.rank}-${row.name}';

  void _toggle(LeaderRow row) {
    final key = _key(row);
    setState(() => selectedKey = selectedKey == key ? null : key);
  }
}

class _LeaderboardSegmentButtons extends StatelessWidget {
  const _LeaderboardSegmentButtons({required this.selected, required this.onChanged});
  final String selected;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    const items = ['ماهانه'];
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 360;
        return Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 12, offset: Offset(0, 6))],
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              for (final item in items)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 2),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () => onChanged(item),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        height: compact ? 48 : 54,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          gradient: selected == item ? AppPalette.heroGradient : null,
                          color: selected == item ? null : Colors.transparent,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Text(
                          item,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: selected == item ? Colors.white : AppPalette.muted,
                            fontWeight: FontWeight.w900,
                            fontSize: compact ? 13 : 14,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}



class StableTopThree extends StatelessWidget {
  const StableTopThree({super.key, required this.rows, required this.selectedKey, required this.onTap});
  final List<LeaderRow> rows;
  final String? selectedKey;
  final void Function(LeaderRow row) onTap;

  LeaderRow? _row(int rank) {
    for (final row in rows) {
      if (row.rank == rank) return row;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final first = _row(1);
    final second = _row(2);
    final third = _row(3);
    if (first == null && second == null && third == null) return const SizedBox.shrink();

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 390;
        return Container(
          width: double.infinity,
          padding: EdgeInsets.fromLTRB(compact ? 14 : 18, compact ? 20 : 26, compact ? 14 : 18, compact ? 16 : 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
            boxShadow: const [
              BoxShadow(color: Color(0x103D5AFE), blurRadius: 26, offset: Offset(0, 14)),
            ],
          ),
          child: Stack(
            children: [
              const Positioned(top: 46, left: 12, child: _PodiumConfettiDiamond(color: Color(0xFFCAB9FF), size: 12)),
              const Positioned(top: 128, left: 38, child: _PodiumConfettiDiamond(color: Color(0xFFDCE4FF), size: 10)),
              const Positioned(top: 58, left: 88, child: _PodiumConfettiStar(color: Color(0xFFDCE4FF), size: 12)),
              const Positioned(top: 32, right: 98, child: _PodiumConfettiStar(color: Color(0xFFFFD86F), size: 14)),
              const Positioned(top: 104, right: 28, child: _PodiumConfettiDiamond(color: Color(0xFFFFA57F), size: 11)),
              const Positioned(top: 140, right: 88, child: _PodiumConfettiStar(color: Color(0xFFFFCACA), size: 10)),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                textDirection: TextDirection.ltr,
                children: [
                  Expanded(
                    child: second == null
                        ? const SizedBox.shrink()
                        : _TopThreeShowcaseItem(
                            row: second,
                            rank: 2,
                            compact: compact,
                            selected: selectedKey == '${second.rank}-${second.name}',
                            onTap: () => onTap(second),
                          ),
                  ),
                  SizedBox(width: compact ? 10 : 16),
                  Expanded(
                    flex: 12,
                    child: first == null
                        ? const SizedBox.shrink()
                        : _TopThreeShowcaseItem(
                            row: first,
                            rank: 1,
                            compact: compact,
                            featured: true,
                            selected: selectedKey == '${first.rank}-${first.name}',
                            onTap: () => onTap(first),
                          ),
                  ),
                  SizedBox(width: compact ? 10 : 16),
                  Expanded(
                    child: third == null
                        ? const SizedBox.shrink()
                        : _TopThreeShowcaseItem(
                            row: third,
                            rank: 3,
                            compact: compact,
                            selected: selectedKey == '${third.rank}-${third.name}',
                            onTap: () => onTap(third),
                          ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _TopThreeShowcaseItem extends StatelessWidget {
  const _TopThreeShowcaseItem({
    required this.row,
    required this.rank,
    required this.compact,
    required this.selected,
    required this.onTap,
    this.featured = false,
  });

  final LeaderRow row;
  final int rank;
  final bool compact;
  final bool selected;
  final bool featured;
  final VoidCallback onTap;

  Color get accent {
    switch (rank) {
      case 1:
        return const Color(0xFFE7AE15);
      case 2:
        return const Color(0xFFB8C4DD);
      default:
        return const Color(0xFFD18653);
    }
  }

  Color get soft {
    switch (rank) {
      case 1:
        return const Color(0xFFFFF7DB);
      case 2:
        return const Color(0xFFF4F7FD);
      default:
        return const Color(0xFFFFEFE3);
    }
  }

  double get avatarSize => featured ? (compact ? 116 : 138) : (compact ? 92 : 112);
  double get crownSize => featured ? (compact ? 42 : 52) : (compact ? 28 : 36);
  double get badgeSize => featured ? (compact ? 46 : 56) : (compact ? 40 : 48);

  @override
  Widget build(BuildContext context) {
    final topPadding = featured ? 0.0 : (compact ? 42.0 : 52.0);
    return Padding(
      padding: EdgeInsets.only(top: topPadding),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: EdgeInsets.symmetric(horizontal: compact ? 4 : 6, vertical: 4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            border: selected ? Border.all(color: accent.withOpacity(.25), width: 1.2) : null,
          ),
          child: Column(
            children: [
              SizedBox(
                height: featured ? (compact ? 188 : 216) : (compact ? 158 : 182),
                child: Stack(
                  clipBehavior: Clip.none,
                  alignment: Alignment.topCenter,
                  children: [
                    Positioned(
                      top: 0,
                      child: Icon(Icons.workspace_premium_rounded, color: accent, size: crownSize),
                    ),
                    Positioned(
                      top: featured ? (compact ? 28 : 34) : (compact ? 18 : 24),
                      child: SizedBox(
                        width: avatarSize,
                        height: avatarSize,
                        child: row.avatar.isNotEmpty || row.avatarUrl.isNotEmpty
                            ? avatarImageForTitle(row.avatar, fit: BoxFit.contain, remoteUrl: row.avatarUrl)
                            : const GaminoAvatarPlaceholder(iconSize: 50),
                      ),
                    ),
                    Positioned(
                      top: featured ? (compact ? 124 : 148) : (compact ? 102 : 122),
                      child: Container(
                        width: badgeSize,
                        height: badgeSize,
                        decoration: BoxDecoration(
                          color: accent,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 4),
                          boxShadow: [
                            BoxShadow(color: accent.withOpacity(.24), blurRadius: 12, offset: const Offset(0, 6)),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            faNumber(rank),
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: featured ? (compact ? 24 : 30) : (compact ? 20 : 24),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Text(
                row.name,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: featured ? (compact ? 24 : 28) : (compact ? 20 : 23),
                  fontWeight: FontWeight.w900,
                  color: AppPalette.ink,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                textDirection: TextDirection.ltr,
                children: [
                  Icon(Icons.emoji_events_outlined, size: featured ? (compact ? 22 : 26) : (compact ? 19 : 22), color: accent),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      cupText(row.xp),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: featured ? (compact ? 17 : 20) : (compact ? 15 : 17),
                        fontWeight: FontWeight.w900,
                        color: accent,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PodiumConfettiStar extends StatelessWidget {
  const _PodiumConfettiStar({required this.color, required this.size});
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Icon(Icons.star_rounded, color: color, size: size);
  }
}

class _PodiumConfettiDot extends StatelessWidget {
  const _PodiumConfettiDot({required this.color, required this.size, this.angle = 0});
  final Color color;
  final double size;
  final double angle;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: angle,
      child: Container(
        width: size,
        height: size * .6,
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2)),
      ),
    );
  }
}

class _PodiumConfettiDiamond extends StatelessWidget {
  const _PodiumConfettiDiamond({required this.color, required this.size});
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: pi / 4,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2)),
      ),
    );
  }
}

class StableLeaderListTile extends StatelessWidget {
  const StableLeaderListTile({super.key, required this.row, required this.selected, required this.onTap, this.isMe = false});
  final LeaderRow row;
  final bool selected;
  final VoidCallback onTap;
  final bool isMe;

  @override
  Widget build(BuildContext context) {
    final initial = row.name.characters.isEmpty ? '؟' : row.name.characters.first;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 160),
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: isMe ? const Color(0xFFF1F0FF) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: selected ? AppPalette.primary : const Color(0x00000000), width: 1.5),
        boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 12, offset: Offset(0, 6))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Column(
              children: [
                Row(
                  textDirection: TextDirection.rtl,
                  children: [
                    SizedBox(width: 34, child: Text('${row.rank}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink))),
                    const SizedBox(width: 6),
                    SizedBox(
                      width: 36,
                      height: 36,
                      child: row.avatar.isNotEmpty || row.avatarUrl.isNotEmpty
                          ? avatarImageForTitle(row.avatar, fit: BoxFit.contain, remoteUrl: row.avatarUrl)
                          : const GaminoAvatarPlaceholder(iconSize: 26),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(isMe ? 'شما' : row.name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
                          const SizedBox(height: 2),
                          Text('پایه ${gradeLabel(row.grade)}', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700, fontSize: 12)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(width: 82, child: Text(cupText(row.xp), maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: const TextStyle(color: AppPalette.secondary, fontWeight: FontWeight.w900))),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class ModernLeaderboardPage extends StatelessWidget {
  const ModernLeaderboardPage({super.key, required this.rows, required this.user, required this.period, required this.onPeriodChanged});

  final List<LeaderRow> rows;
  final AppUser user;
  final String period;
  final ValueChanged<String> onPeriodChanged;

  @override
  Widget build(BuildContext context) {
    final sorted = [...rows]..sort((a, b) => a.rank.compareTo(b.rank));
    final me = sorted.firstWhere(
      (row) => row.name == user.name,
      orElse: () => LeaderRow(rank: sorted.length + 1, name: user.name.isEmpty ? 'شما' : user.name, grade: user.grade, xp: currentCups(user)),
    );
    final topRows = [1, 2, 3].map((rank) {
      return sorted.where((row) => row.rank == rank).cast<LeaderRow?>().firstWhere((row) => row != null, orElse: () => null);
    }).whereType<LeaderRow>().toList();
    final otherRows = sorted.where((row) => row.rank > 3 && row.rank <= 8).toList();
    if (me.rank > 8 && !otherRows.any((row) => row.name == me.name)) {
      otherRows.add(me);
      otherRows.sort((a, b) => a.rank.compareTo(b.rank));
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 118),
      children: [
        const _ModernLeaderboardHeader(),
        const SizedBox(height: 16),
        _ModernLeagueProgressCard(user: user),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
            boxShadow: const [BoxShadow(color: Color(0x0A101827), blurRadius: 22, offset: Offset(0, 10))],
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
            child: Column(
              children: [
                _ModernTopThreeSection(rows: topRows, user: user),
                const SizedBox(height: 8),
                const Divider(height: 20, color: Color(0xFFF0F1F7)),
                for (final row in otherRows) _ModernLeaderboardRow(row: row, user: user),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _ModernLeaderboardHeader extends StatelessWidget {
  const _ModernLeaderboardHeader();

  @override
  Widget build(BuildContext context) {
    return Row(
      textDirection: TextDirection.rtl,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 76,
          height: 76,
          decoration: BoxDecoration(
            gradient: AppPalette.heroGradient,
            borderRadius: BorderRadius.circular(24),
            boxShadow: const [BoxShadow(color: Color(0x223D5AFE), blurRadius: 20, offset: Offset(0, 10))],
          ),
          child: const Icon(Icons.emoji_events_rounded, color: Colors.white, size: 40),
        ),
        const SizedBox(width: 16),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('رتبه‌بندی', textAlign: TextAlign.right, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppPalette.ink)),
              SizedBox(height: 6),
              Text('رقابت کن، پیشرفت کن', textAlign: TextAlign.right, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppPalette.muted)),
            ],
          ),
        ),
      ],
    );
  }
}


class _ModernLeagueProgressCard extends StatelessWidget {
  const _ModernLeagueProgressCard({required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final cups = currentCups(user);
    final tier = leagueTierForCups(cups);
    final next = nextLeagueTierForCups(cups);
    final target = next?.minCups ?? max(cups, tier.minCups + 2000);
    final remain = max(0, target - cups);
    final progress = leagueProgressForCups(cups);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LeagueDetailsScreen(user: user))),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF7F1),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: const Color(0xFFF9E4D1)),
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                width: 62,
                height: 62,
                child: Image.asset(tier.asset, fit: BoxFit.contain),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      textDirection: TextDirection.rtl,
                      children: [
                        const Icon(Icons.more_horiz_rounded, color: AppPalette.ink, size: 22),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            'لیگ ${tier.name} پایه ${gradeLabel(user.grade)}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.right,
                            style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w900, color: AppPalette.ink),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),
                    Text(
                      '${cupText(cups)} / ${cupText(target)}',
                      textAlign: TextAlign.right,
                      style: const TextStyle(fontSize: 13.2, fontWeight: FontWeight.w900, color: AppPalette.primary),
                    ),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(999),
                      child: LinearProgressIndicator(
                        value: progress,
                        minHeight: 7,
                        backgroundColor: const Color(0xFFE5E7EB),
                        valueColor: AlwaysStoppedAnimation(tier.secondaryColor),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      next == null ? 'بالاترین لیگ فعال است' : 'تا لیگ ${next.name}: ${cupText(remain)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.right,
                      style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: AppPalette.muted),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LeagueDetailsScreen extends StatelessWidget {
  const LeagueDetailsScreen({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final cups = currentCups(user);
    final tier = leagueTierForCups(cups);
    final next = nextLeagueTierForCups(cups);
    final target = next?.minCups ?? max(cups, tier.minCups + 2000);
    final remain = max(0, target - cups);
    final progress = leagueProgressForCups(cups);

    return Scaffold(
      backgroundColor: AppPalette.canvas,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
          children: [
            Row(
              textDirection: TextDirection.ltr,
              children: [
                SizedBox(width: 58, height: 58, child: Image.asset(tier.asset, fit: BoxFit.contain)),
                const SizedBox(width: 14),
                const Expanded(
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('لیگ ماهانه', textAlign: TextAlign.left, style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            _LeagueCurrentCard(cups: cups, tier: tier, next: next, target: target, remain: remain, progress: progress),
            const SizedBox(height: 18),
            _LeaguePathCard(currentTier: tier, cups: cups),
          ],
        ),
      ),
    );
  }
}

class _LeagueCurrentCard extends StatelessWidget {
  const _LeagueCurrentCard({required this.cups, required this.tier, required this.next, required this.target, required this.remain, required this.progress});
  final int cups;
  final GaminoLeagueTier tier;
  final GaminoLeagueTier? next;
  final int target;
  final int remain;
  final double progress;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE9ECF7)),
        boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 20, offset: Offset(0, 10))],
      ),
      child: Column(
        children: [
          Row(
            textDirection: TextDirection.rtl,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('لیگ فعلی: ${tier.name}', textAlign: TextAlign.left, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    const SizedBox(height: 10),
                    Row(
                      textDirection: TextDirection.ltr,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('کاپ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.amber)),
                        const SizedBox(width: 6),
                        Text(faNumber(cups), style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: tier.secondaryColor)),
                        const SizedBox(width: 6),
                        const Icon(Icons.emoji_events_rounded, color: AppPalette.amber, size: 22),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _LeagueDeltaPill(icon: Icons.emoji_events_rounded, text: 'برد', value: signedCupText(tier.winCups), color: const Color(0xFF16A34A)),
                    const SizedBox(height: 8),
                    _LeagueDeltaPill(icon: Icons.emoji_events_rounded, text: 'باخت', value: signedCupText(tier.loseCups), color: const Color(0xFFE11D48)),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(width: 126, height: 126, child: Image.asset(tier.asset, fit: BoxFit.contain)),
            ],
          ),
          const SizedBox(height: 18),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(value: progress, minHeight: 9, backgroundColor: const Color(0xFFE5E7EB), valueColor: AlwaysStoppedAnimation(tier.secondaryColor)),
          ),
          const SizedBox(height: 10),
          Row(
            textDirection: TextDirection.rtl,
            children: [
              Text(cupText(target), style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.muted)),
              const Spacer(),
              Text(cupText(cups), style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.primary)),
              const Spacer(),
              Text(next == null ? 'بالاترین لیگ' : 'تا لیگ ${next!.name}: ${cupText(remain)}', style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted, fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }
}

class _LeagueDeltaPill extends StatelessWidget {
  const _LeagueDeltaPill({required this.icon, required this.text, required this.value, required this.color});
  final IconData icon;
  final String text;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 38,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFF),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE9ECF7)),
      ),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Text(text, style: const TextStyle(fontSize: 13.5, color: AppPalette.ink, fontWeight: FontWeight.w900)),
          const Spacer(),
          Text(value, style: TextStyle(fontSize: 15, color: color, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class _LeaguePathCard extends StatelessWidget {
  const _LeaguePathCard({required this.currentTier, required this.cups});
  final GaminoLeagueTier currentTier;
  final int cups;

  @override
  Widget build(BuildContext context) {
    final reversed = kGaminoLeagueTiers.reversed.toList();
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFE9ECF7)),
        boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 20, offset: Offset(0, 10))],
      ),
      child: Column(
        children: [
          const Text('مسیر لیگ‌ها', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink)),
          const SizedBox(height: 12),
          for (var i = 0; i < reversed.length; i++)
            _LeaguePathRow(
              tier: reversed[i],
              cups: cups,
              isCurrent: reversed[i].id == currentTier.id,
              isLast: i == reversed.length - 1,
            ),
        ],
      ),
    );
  }
}

class _LeaguePathRow extends StatelessWidget {
  const _LeaguePathRow({required this.tier, required this.cups, required this.isCurrent, required this.isLast});
  final GaminoLeagueTier tier;
  final int cups;
  final bool isCurrent;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    final passed = cups >= tier.minCups;
    final dotColor = isCurrent ? AppPalette.primary : (passed ? tier.secondaryColor : const Color(0xFFD8DCE8));
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.symmetric(horizontal: isCurrent ? 10 : 6, vertical: isCurrent ? 9 : 7),
      decoration: BoxDecoration(
        color: isCurrent ? const Color(0xFFF6F1FF) : Colors.transparent,
        borderRadius: BorderRadius.circular(18),
        border: isCurrent ? Border.all(color: AppPalette.primary) : null,
      ),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Column(
            children: [
              Container(width: 12, height: 12, decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle)),
              if (!isLast) Container(width: 2, height: 42, color: const Color(0xFFE1E5F0)),
            ],
          ),
          const SizedBox(width: 12),
          SizedBox(width: 52, height: 52, child: Image.asset(tier.asset, fit: BoxFit.contain)),
          const SizedBox(width: 12),
          Expanded(
            child: Row(
              textDirection: TextDirection.rtl,
              children: [
                Expanded(
                  child: Text(
                    tier.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.right,
                    style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900, color: isCurrent ? AppPalette.primary : tier.primaryColor),
                  ),
                ),
                if (isCurrent) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    decoration: BoxDecoration(color: const Color(0xFFEDE9FE), borderRadius: BorderRadius.circular(99)),
                    child: const Text('لیگ فعلی', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w900, color: AppPalette.secondary)),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 8),
          Row(
            textDirection: TextDirection.ltr,
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.emoji_events_rounded, color: passed ? AppPalette.amber : const Color(0xFFB8C0CF), size: 18),
              const SizedBox(width: 5),
              Text(faNumber(tier.minCups), style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w900, color: isCurrent ? AppPalette.primary : AppPalette.ink)),
            ],
          ),
        ],
      ),
    );
  }
}



class _ModernTopThreeSection extends StatelessWidget {
  const _ModernTopThreeSection({required this.rows, required this.user});
  final List<LeaderRow> rows;
  final AppUser user;

  LeaderRow? _find(int rank) {
    for (final row in rows) {
      if (row.rank == rank) return row;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final second = _find(2);
    final first = _find(1);
    final third = _find(3);
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 360;
        final sideWidth = compact ? 82.0 : 88.0;
        final centerWidth = compact ? 102.0 : 110.0;
        final gap = compact ? 2.0 : 4.0;
        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          textDirection: TextDirection.ltr,
          children: [
            SizedBox(width: sideWidth, child: second == null ? const SizedBox.shrink() : _ModernTopAvatarCard(row: second, rank: 2, user: user)),
            SizedBox(width: gap),
            SizedBox(width: centerWidth, child: first == null ? const SizedBox.shrink() : _ModernTopAvatarCard(row: first, rank: 1, user: user, featured: true)),
            SizedBox(width: gap),
            SizedBox(width: sideWidth, child: third == null ? const SizedBox.shrink() : _ModernTopAvatarCard(row: third, rank: 3, user: user)),
          ],
        );
      },
    );
  }
}

class _ModernTopAvatarCard extends StatelessWidget {
  const _ModernTopAvatarCard({required this.row, required this.rank, required this.user, this.featured = false});
  final LeaderRow row;
  final int rank;
  final AppUser user;
  final bool featured;

  Color get accent {
    switch (rank) {
      case 1:
        return const Color(0xFFE7AE15);
      case 2:
        return const Color(0xFF98A2B3);
      default:
        return const Color(0xFFB87943);
    }
  }

  double get avatarSize => featured ? 86 : 66;

  Widget _avatar() {
    if (row.name == user.name) {
      return avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl);
    }
    if (row.avatar.isNotEmpty || row.avatarUrl.isNotEmpty) {
      return avatarImageForTitle(row.avatar, fit: BoxFit.contain, remoteUrl: row.avatarUrl);
    }
    return const GaminoAvatarPlaceholder(iconSize: 42);
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(28),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PublicStudentProfileScreen(row: row, currentUser: row.name == user.name ? user : null))),
      child: Padding(
        padding: EdgeInsets.only(top: featured ? 0 : 14),
        child: Column(
          children: [
            SizedBox(
              height: featured ? 94 : 74,
              child: Center(
                child: SizedBox(width: avatarSize, height: avatarSize, child: _avatar()),
              ),
            ),
            SizedBox(width: double.infinity, child: FittedBox(fit: BoxFit.scaleDown, child: Text(row.name, maxLines: 1, textAlign: TextAlign.center, style: TextStyle(fontSize: featured ? 15.0 : 13.0, fontWeight: FontWeight.w900, color: AppPalette.ink)))),
            const SizedBox(height: 5),
            Row(
              mainAxisSize: MainAxisSize.min,
              textDirection: TextDirection.ltr,
              children: [
                Icon(Icons.emoji_events_outlined, size: featured ? 16 : 13, color: accent),
                const SizedBox(width: 4),
                Text(cupText(row.xp), style: TextStyle(fontWeight: FontWeight.w900, color: accent, fontSize: featured ? 12.5 : 11.2)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ModernLeaderboardRow extends StatelessWidget {
  const _ModernLeaderboardRow({required this.row, required this.user});
  final LeaderRow row;
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final rowAvatarTitle = row.avatar.isNotEmpty ? row.avatar : '';
    final rowAvatarUrl = row.avatarUrl;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PublicStudentProfileScreen(row: row, currentUser: row.name == user.name ? user : null))),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
          decoration: BoxDecoration(
            color: row.name == user.name ? const Color(0xFFF8F3FF) : Colors.transparent,
            borderRadius: row.name == user.name ? BorderRadius.circular(16) : BorderRadius.zero,
            border: const Border(bottom: BorderSide(color: Color(0xFFF0F1F7))),
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              SizedBox(width: 30, child: Text(faNumber(row.rank), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.muted))),
              const SizedBox(width: 10),
              SizedBox(
                width: 42,
                height: 42,
                child: row.name == user.name
                    ? avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl)
                    : (rowAvatarTitle.isNotEmpty || rowAvatarUrl.isNotEmpty)
                        ? avatarImageForTitle(rowAvatarTitle, fit: BoxFit.contain, remoteUrl: rowAvatarUrl)
                        : const GaminoAvatarPlaceholder(iconSize: 30),
              ),
              const SizedBox(width: 10),
              Expanded(child: Text(row.name, textAlign: TextAlign.right, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppPalette.ink))),
              const SizedBox(width: 10),
              Row(
                textDirection: TextDirection.ltr,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.emoji_events_outlined, color: Color(0xFF98A2B3), size: 18),
                  const SizedBox(width: 6),
                  Text(cupText(row.xp), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppPalette.muted)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModernPagerDots extends StatelessWidget {
  const _ModernPagerDots();

  @override
  Widget build(BuildContext context) {
    Widget dot(bool active) => Container(
          width: active ? 18 : 8,
          height: 6,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            color: active ? AppPalette.primary : const Color(0xFFD9D8E7),
            borderRadius: BorderRadius.circular(999),
          ),
        );
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [dot(true), dot(false), dot(false)]);
  }
}


class _ModernMyRankCard extends StatelessWidget {
  const _ModernMyRankCard({required this.row, required this.user});
  final LeaderRow row;
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F3FF),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE7D9FF)),
      ),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          SizedBox(width: 30, child: Text(faNumber(row.rank), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.primary))),
          const SizedBox(width: 10),
          SizedBox(
            width: 42,
            height: 42,
            child: avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl),
          ),
          const SizedBox(width: 10),
          const Expanded(child: Text('رتبه شما', textAlign: TextAlign.right, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink))),
          const SizedBox(width: 10),
          Row(
            textDirection: TextDirection.ltr,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.emoji_events_rounded, color: AppPalette.primary, size: 19),
              const SizedBox(width: 5),
              Text(cupText(row.xp), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.primary)),
            ],
          ),
        ],
      ),
    );
  }
}

class PublicStudentProfileScreen extends StatefulWidget {
  const PublicStudentProfileScreen({super.key, required this.row, this.currentUser});
  final LeaderRow row;
  final AppUser? currentUser;

  @override
  State<PublicStudentProfileScreen> createState() => _PublicStudentProfileScreenState();
}

class _PublicStudentProfileScreenState extends State<PublicStudentProfileScreen> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty || widget.row.userId.isEmpty) {
      return {'user': widget.currentUser?.toJson() ?? <String, dynamic>{}, 'likedByMe': false};
    }
    return GaminoApiService.request('profile.public', token: token, body: {'userId': widget.row.userId});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppPalette.canvas,
      body: SafeArea(
        child: FutureBuilder<Map<String, dynamic>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
            if (snapshot.hasError) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.person_off_outlined, size: 48, color: AppPalette.muted),
                      const SizedBox(height: 12),
                      const Text('پروفایل این کاربر در حال حاضر قابل نمایش نیست.', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
                      const SizedBox(height: 12),
                      FilledButton.icon(
                        onPressed: () => setState(() => _future = _load()),
                        icon: const Icon(Icons.refresh_rounded),
                        label: const Text('تلاش دوباره'),
                      ),
                    ],
                  ),
                ),
              );
            }
            final raw = Map<String, dynamic>.from(snapshot.data?['user'] as Map? ?? {});
            if (raw.isEmpty) {
              return const Center(child: Text('پروفایل کاربر پیدا نشد.', style: TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted)));
            }
            late final AppUser user;
            late final List<GaminoMedalItem> publicMedals;
            try {
              user = AppUser.fromJson(raw);
              publicMedals = (snapshot.data?['medals'] as List? ?? [])
                  .whereType<Map>()
                  .map((item) => GaminoMedalItem.fromJson(Map<String, dynamic>.from(item)))
                  .toList();
            } catch (_) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.person_off_outlined, size: 48, color: AppPalette.muted),
                      const SizedBox(height: 12),
                      const Text('اطلاعات این پروفایل کامل دریافت نشد.', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
                      const SizedBox(height: 12),
                      FilledButton.icon(
                        onPressed: () => setState(() => _future = _load()),
                        icon: const Icon(Icons.refresh_rounded),
                        label: const Text('تلاش دوباره'),
                      ),
                    ],
                  ),
                ),
              );
            }
            return StableProfilePageContent(
              user: user,
              rank: widget.row.rank,
              showBack: true,
              showPersonalTools: false,
              profileLikeKey: user.id.isNotEmpty ? user.id : widget.row.userId,
              initialProfileLikes: user.profileLikes,
              initialProfileLiked: snapshot.data?['likedByMe'] == true,
              allowProfileLike: widget.currentUser?.id != user.id,
              onOpenMedals: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => GaminoMedalsScreen(
                    user: user,
                    medals: publicMedals,
                    title: 'مدال‌های ${user.name}',
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({
    super.key,
    required this.user,
    required this.isGuest,
    required this.shopItems,
    required this.cardPackages,
    required this.onBuyShopItem,
    required this.onSelectShopItem,
    required this.onPrepareReward,
    required this.onClaimReward,
    required this.onPurchaseNoAds,
    required this.onUpdateProfile,
    required this.onUpdateThemeMode,
    required this.onUpdateAccount,
    required this.onAddStudyTask,
    required this.onToggleStudyTask,
    required this.onUpdateStudyTask,
    required this.onDeleteStudyTask,
    required this.mistakes,
    required this.onMistakePracticeFinished,
    required this.onLogout,
    required this.onOpenMedals,
  });

  final AppUser user;
  final bool isGuest;
  final List<ShopItem> shopItems;
  final List<CardPackage> cardPackages;
  final Future<bool> Function(ShopItem item) onBuyShopItem;
  final Future<bool> Function(ShopItem item) onSelectShopItem;
  final Future<String?> Function() onPrepareReward;
  final Future<bool> Function(String challenge) onClaimReward;
  final VoidCallback onPurchaseNoAds;
  final Future<bool> Function({required String name, required int grade, String? track, String? bio}) onUpdateProfile;
  final void Function(String themeMode) onUpdateThemeMode;
  final Future<bool> Function({required String name, required String phone, required String currentPassword, required String password}) onUpdateAccount;
  final Future<bool> Function(StudyTask task) onAddStudyTask;
  final Future<bool> Function(StudyTask task) onToggleStudyTask;
  final Future<bool> Function(StudyTask oldTask, StudyTask newTask) onUpdateStudyTask;
  final Future<bool> Function(StudyTask task) onDeleteStudyTask;
  final List<MyMistake> mistakes;
  final void Function(QuizResult result) onMistakePracticeFinished;
  final Future<void> Function() onLogout;
  final VoidCallback onOpenMedals;

  Future<void> _showEditProfileDialog(BuildContext context) async {
    await showDialog<void>(context: context, builder: (_) => EditProfileDialog(user: user, onSave: onUpdateProfile));
  }

  @override
  Widget build(BuildContext context) {
    if (isGuest) {
      return const LockedScreen(
        title: 'پروفایل برای مهمان قفل است',
        message: 'برای Level، کاپ، کارت، مدال، برنامه مطالعه و فروشگاه پروفایل باید ثبت‌نام کنید.',
      );
    }

    return SafeArea(
      child: StableProfilePageContent(
        user: user,
        rank: 4,
        onEditProfile: () => _showEditProfileDialog(context),
        onOpenSettings: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => AppSettingsScreen(user: user, onUpdateProfile: onUpdateProfile, onUpdateThemeMode: onUpdateThemeMode, onUpdateAccount: onUpdateAccount, onLogout: onLogout)),
        ),
        onOpenMistakes: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MistakesFullScreen(mistakes: mistakes, onMistakePracticeFinished: onMistakePracticeFinished))),
        onOpenStudyPlan: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => StudyPlanFullScreen(user: user, onAddStudyTask: onAddStudyTask, onToggleStudyTask: onToggleStudyTask, onUpdateStudyTask: onUpdateStudyTask, onDeleteStudyTask: onDeleteStudyTask)),
        ),
        onOpenShop: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => GaminoShopScreen(user: user, shopItems: shopItems, cardPackages: cardPackages, onBuyShopItem: onBuyShopItem, onSelectShopItem: onSelectShopItem, onPrepareReward: onPrepareReward, onClaimReward: onClaimReward, onPurchaseNoAds: onPurchaseNoAds),
          ),
        ),
        onOpenMedals: onOpenMedals,
        bottomChildren: const [],
      ),
    );
  }
}

class StableProfilePageContent extends StatelessWidget {
  const StableProfilePageContent({
    super.key,
    required this.user,
    required this.rank,
    this.showBack = false,
    this.onEditProfile,
    this.onOpenSettings,
    this.onOpenMistakes,
    this.onOpenStudyPlan,
    this.onOpenShop,
    this.onOpenMedals,
    this.showPersonalTools = true,
    this.profileLikeKey,
    this.initialProfileLikes = 0,
    this.initialProfileLiked = false,
    this.allowProfileLike = true,
    this.bottomChildren = const [],
  });

  final AppUser user;
  final int rank;
  final bool showBack;
  final VoidCallback? onEditProfile;
  final VoidCallback? onOpenSettings;
  final VoidCallback? onOpenMistakes;
  final VoidCallback? onOpenStudyPlan;
  final VoidCallback? onOpenShop;
  final VoidCallback? onOpenMedals;
  final bool showPersonalTools;
  final String? profileLikeKey;
  final int initialProfileLikes;
  final bool initialProfileLiked;
  final bool allowProfileLike;
  final List<Widget> bottomChildren;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 14),
      children: [
        Row(
          children: [
            if (showBack)
              IconButton.filledTonal(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close_rounded),
              )
            else
              IconButton.filledTonal(
                onPressed: onOpenSettings ?? onEditProfile,
                icon: const Icon(Icons.settings_outlined),
                tooltip: 'تنظیمات',
              ),
          ],
        ),
        const SizedBox(height: 2),
        CompactProfileHero(
          user: user,
          onEditProfile: onEditProfile,
          profileLikeKey: profileLikeKey,
          initialProfileLikes: initialProfileLikes,
          initialProfileLiked: initialProfileLiked,
          allowProfileLike: allowProfileLike,
        ),
        const SizedBox(height: 10),
        ProfileBioCard(user: user),
        const SizedBox(height: 14),
        CompactProfileStats(user: user),
        const SizedBox(height: 10),
        _StudyTimeSummary(user: user),
        const SizedBox(height: 12),
        ProfileQuickMenuGrid(
          user: user,
          onEditProfile: onEditProfile,
          onOpenSettings: onOpenSettings,
          onOpenMistakes: onOpenMistakes,
          onOpenStudyPlan: onOpenStudyPlan,
          onOpenShop: onOpenShop,
          onOpenMedals: onOpenMedals,
          showPersonalTools: showPersonalTools,
        ),
        if (bottomChildren.isNotEmpty) const SizedBox(height: 12),
        ...bottomChildren,
      ],
    );
  }
}


const String kDefaultProfileBio = 'در مسیر یادگیری، هر روز یک گام جلوتر.';

class ProfileLikePill extends StatefulWidget {
  const ProfileLikePill({
    super.key,
    required this.profileKey,
    required this.initialLikes,
    required this.initialLiked,
    this.allowLike = true,
  });

  final String profileKey;
  final int initialLikes;
  final bool initialLiked;
  final bool allowLike;

  @override
  State<ProfileLikePill> createState() => _ProfileLikePillState();
}

class _ProfileLikePillState extends State<ProfileLikePill> {
  late bool liked;
  late int likes;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    liked = widget.initialLiked;
    likes = max(0, widget.initialLikes);
  }

  Future<void> _toggleLike() async {
    if (!widget.allowLike || busy || widget.profileKey.isEmpty) return;
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) return;
    setState(() => busy = true);
    try {
      final data = await GaminoApiService.request('profile.like', token: token, body: {'userId': widget.profileKey});
      if (!mounted) return;
      setState(() {
        liked = data['liked'] == true;
        likes = max(0, (data['likes'] as num?)?.toInt() ?? likes);
      });
    } on GaminoApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: widget.allowLike && !busy ? _toggleLike : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: const Color(0xFFE11D48), width: 1.25),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            textDirection: TextDirection.ltr,
            children: [
              Icon(liked ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: const Color(0xFFE11D48), size: 20),
              const SizedBox(width: 5),
              Text(faNumber(likes), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: Color(0xFFE11D48))),
            ],
          ),
        ),
      ),
    );
  }
}

class ProfileBioCard extends StatelessWidget {
  const ProfileBioCard({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final text = user.bio.trim().isEmpty ? kDefaultProfileBio : user.bio.trim();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 14, offset: Offset(0, 8))],
      ),
      child: Row(
        textDirection: TextDirection.rtl,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('بیو', textAlign: TextAlign.right, textDirection: TextDirection.rtl, style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                const SizedBox(height: 4),
                Text(text, textAlign: TextAlign.right, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 12.5, height: 1.7, fontWeight: FontWeight.w700, color: AppPalette.muted)),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: const Color(0xFFF4F0FF), borderRadius: BorderRadius.circular(14)),
            child: const Icon(Icons.format_quote_rounded, color: AppPalette.secondary),
          ),
        ],
      ),
    );
  }
}

class CompactProfileHero extends StatelessWidget {
  const CompactProfileHero({
    super.key,
    required this.user,
    this.onEditProfile,
    this.profileLikeKey,
    this.initialProfileLikes = 0,
    this.initialProfileLiked = false,
    this.allowProfileLike = true,
  });
  final AppUser user;
  final VoidCallback? onEditProfile;
  final String? profileLikeKey;
  final int initialProfileLikes;
  final bool initialProfileLiked;
  final bool allowProfileLike;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: 114,
          height: 114,
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned.fill(child: avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl)),
              Positioned(bottom: 0, left: 0, child: GaminoLevelBadge(user: user, size: 34)),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(child: Text(user.name.isEmpty ? 'دانش‌آموز' : user.name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppPalette.ink))),
            if (onEditProfile != null) ...[
              const SizedBox(width: 6),
              Material(
                color: const Color(0xFFF2EEFF),
                borderRadius: BorderRadius.circular(999),
                child: InkWell(borderRadius: BorderRadius.circular(999), onTap: onEditProfile, child: const Padding(padding: EdgeInsets.all(7), child: Icon(Icons.edit_rounded, size: 18, color: AppPalette.secondary))),
              ),
            ],
          ],
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(color: const Color(0xFFF7F2FF), borderRadius: BorderRadius.circular(999), border: Border.all(color: const Color(0xFFECE2FF))),
              child: Text('پایه ${gradeLabel(user.grade)}', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800, color: AppPalette.muted)),
            ),
            if (profileLikeKey != null) ...[
              const SizedBox(width: 8),
              ProfileLikePill(profileKey: profileLikeKey!, initialLikes: initialProfileLikes, initialLiked: initialProfileLiked, allowLike: allowProfileLike),
            ],
          ],
        ),
      ],
    );
  }
}

class CompactProfileStats extends StatelessWidget {
  const CompactProfileStats({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final stats = [
      _CompactStatData('تعداد بازی', '${user.matchesCount}', Icons.sports_esports_outlined),
      _CompactStatData('کاپ فعلی', '${currentCups(user)}', Icons.hexagon_outlined),
      _CompactStatData('بیشترین کاپ', '${bestCups(user)}', Icons.emoji_events_outlined, tappable: true),
    ];
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 360;
        return Row(
          children: [
            for (var i = 0; i < stats.length; i++) ...[
              Expanded(
                child: CompactStatCard(
                  data: stats[i],
                  compact: compact,
                  onTap: stats[i].tappable
                      ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CupGradeHistoryScreen(user: user)))
                      : null,
                ),
              ),
              if (i != stats.length - 1) SizedBox(width: compact ? 7 : 10),
            ],
          ],
        );
      },
    );
  }
}

class _CompactStatData {
  const _CompactStatData(this.label, this.value, this.icon, {this.tappable = false});
  final String label;
  final String value;
  final IconData icon;
  final bool tappable;
}

class CompactStatCard extends StatelessWidget {
  const CompactStatCard({super.key, required this.data, required this.compact, this.onTap});
  final _CompactStatData data;
  final bool compact;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final content = Container(
      height: compact ? 88 : 94,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 14, offset: Offset(0, 8))],
      ),
      child: Stack(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(data.icon, color: AppPalette.secondary, size: compact ? 22 : 25),
                const SizedBox(height: 6),
                Text(data.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 19 : 22, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                const SizedBox(height: 2),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: onTap == null ? 3 : 14),
                  child: Text(data.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 10.5 : 11.5, fontWeight: FontWeight.w700, color: AppPalette.muted)),
                ),
              ],
            ),
          ),
          if (onTap != null)
            const Positioned(
              left: 5,
              top: 0,
              bottom: 0,
              child: Center(child: Icon(Icons.chevron_right_rounded, size: 21, color: AppPalette.muted)),
            ),
        ],
      ),
    );
    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      child: InkWell(borderRadius: BorderRadius.circular(20), onTap: onTap, child: content),
    );
  }
}

class CupGradeHistoryScreen extends StatelessWidget {
  const CupGradeHistoryScreen({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final grades = <int>{...user.bestCupsByGrade.keys, ...user.cupsByGrade.keys}
        .where((grade) => grade >= 1 && grade <= 12)
        .where((grade) => max(user.bestCupsByGrade[grade] ?? 0, user.cupsByGrade[grade] ?? 0) > 0)
        .toList()
      ..sort();
    return Scaffold(
      backgroundColor: AppPalette.canvas,
      appBar: AppBar(
        backgroundColor: AppPalette.canvas,
        elevation: 0,
        title: const Text('بیشترین کاپ', style: TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
      ),
      body: grades.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text('هنوز در هیچ پایه‌ای کاپی ثبت نشده است.', textAlign: TextAlign.center, style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800)),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
              itemCount: grades.length,
              separatorBuilder: (_, __) => const SizedBox(height: 9),
              itemBuilder: (context, index) {
                final grade = grades[index];
                final best = max(user.bestCupsByGrade[grade] ?? 0, user.cupsByGrade[grade] ?? 0);
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(19),
                    boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 14, offset: Offset(0, 8))],
                  ),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(color: AppPalette.secondary.withOpacity(.09), borderRadius: BorderRadius.circular(14)),
                        child: const Icon(Icons.emoji_events_rounded, color: AppPalette.secondary, size: 23),
                      ),
                      const SizedBox(width: 11),
                      Expanded(child: Text('پایه ${gradeLabel(grade)}', textAlign: TextAlign.right, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w900, color: AppPalette.ink))),
                      Text('${faNumber(best)} کاپ', style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w900, color: AppPalette.primary)),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

class ProfileQuickMenuGrid extends StatelessWidget {
  const ProfileQuickMenuGrid({
    super.key,
    required this.user,
    this.onEditProfile,
    this.onOpenSettings,
    this.onOpenMistakes,
    this.onOpenStudyPlan,
    this.onOpenShop,
    this.onOpenMedals,
    this.showPersonalTools = true,
  });

  final AppUser user;
  final VoidCallback? onEditProfile;
  final VoidCallback? onOpenSettings;
  final VoidCallback? onOpenMistakes;
  final VoidCallback? onOpenStudyPlan;
  final VoidCallback? onOpenShop;
  final VoidCallback? onOpenMedals;
  final bool showPersonalTools;

  @override
  Widget build(BuildContext context) {
    final intelligenceTap = () => Navigator.push(context, MaterialPageRoute(builder: (_) => IntelligenceDetailsScreen(user: user)));
    final regularItems = showPersonalTools
        ? [
            _ProfileQuickItem('سطح هوش', Icons.psychology_outlined, intelligenceTap),
            _ProfileQuickItem('برنامه مطالعه', Icons.menu_book_rounded, onOpenStudyPlan),
            _ProfileQuickItem('اشتباهات من', Icons.error_outline_rounded, onOpenMistakes),
            _ProfileQuickItem('مدال‌ها', Icons.military_tech_outlined, onOpenMedals),
          ]
        : [
            _ProfileQuickItem('سطح هوش', Icons.psychology_outlined, intelligenceTap),
            _ProfileQuickItem('مدال‌ها', Icons.military_tech_outlined, onOpenMedals),
          ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 360;
        final grid = GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: regularItems.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisExtent: compact ? 84 : 92,
            crossAxisSpacing: compact ? 8 : 10,
            mainAxisSpacing: compact ? 8 : 10,
          ),
          itemBuilder: (context, index) => ProfileQuickCard(item: regularItems[index]),
        );
        if (!showPersonalTools) return grid;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ProfileQuickWideShopCard(onTap: onOpenShop),
            SizedBox(height: compact ? 8 : 10),
            grid,
          ],
        );
      },
    );
  }
}

class ProfileQuickWideShopCard extends StatelessWidget {
  const ProfileQuickWideShopCard({super.key, this.onTap});
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Container(
          height: 78,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 14, offset: Offset(0, 8))],
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(color: const Color(0xFFF1EDFF), borderRadius: BorderRadius.circular(16)),
                child: const Icon(Icons.storefront_rounded, color: AppPalette.secondary, size: 30),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text('شاپ', textAlign: TextAlign.right, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.ink)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class IntelligenceDetailsScreen extends StatelessWidget {
  const IntelligenceDetailsScreen({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final subjects = user.skills.keys.toList();
    final average = subjects.isEmpty ? 0 : (subjects.map((subject) => user.skills[subject] ?? 50).reduce((a, b) => a + b) / subjects.length).round();
    return Scaffold(
      backgroundColor: AppPalette.canvas,
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('سطح هوش دروس')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 118),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 18, offset: Offset(0, 8))]),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  textDirection: TextDirection.rtl,
                  children: [
                    const Icon(Icons.leaderboard_rounded, color: AppPalette.primary, size: 30),
                    const SizedBox(width: 10),
                    const Expanded(child: Text('سطح هوش دروس', textAlign: TextAlign.right, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppPalette.ink))),
                    Text('$average%', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.primary)),
                  ],
                ),
                const SizedBox(height: 18),
                Text('این درصدها از نتیجه کوییزهایی که برای هر درس انجام می‌دهی محاسبه و به‌روزرسانی می‌شوند.', textAlign: TextAlign.right, style: const TextStyle(fontSize: 13.5, height: 1.8, fontWeight: FontWeight.w700, color: AppPalette.muted)),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(child: _IntelligenceMiniStat(title: 'بازی انجام‌شده', value: faNumber(user.matchesCount), icon: Icons.sports_esports_outlined)),
                    const SizedBox(width: 8),
                    Expanded(child: _IntelligenceMiniStat(title: 'برد', value: faNumber(user.wins), icon: Icons.check_circle_outline_rounded)),
                    const SizedBox(width: 8),
                    Expanded(child: _IntelligenceMiniStat(title: 'باخت', value: faNumber(max(0, user.matchesCount - user.wins)), icon: Icons.cancel_outlined)),
                  ],
                ),
                const SizedBox(height: 18),
                const SizedBox(height: 4),
                for (final subject in subjects) Padding(
                  padding: const EdgeInsets.only(bottom: 18),
                  child: IntelligenceBarRow(subject: subject, percent: user.skills[subject] ?? 50),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StudyTimeSummary extends StatelessWidget {
  const _StudyTimeSummary({required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final safe = max(0, user.studySeconds);
    final hours = safe ~/ 3600;
    final minutes = (safe % 3600) ~/ 60;
    final seconds = safe % 60;
    Widget part(int value, String unit) => Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(faNumber(value), style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.primary, fontSize: 14)),
        Text(unit, style: const TextStyle(fontWeight: FontWeight.w700, color: AppPalette.muted, fontSize: 10.5)),
      ],
    );

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StudyTimeDetailsScreen(user: user))),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFE9EAF2)),
            boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 14, offset: Offset(0, 8))],
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              const Icon(Icons.timer_outlined, color: AppPalette.primary, size: 28),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('زمان مطالعه', textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5, color: AppPalette.ink)),
                    const SizedBox(height: 7),
                    Row(
                      textDirection: TextDirection.rtl,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [part(seconds, 'ثانیه'), part(minutes, 'دقیقه'), part(hours, 'ساعت')],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              const Icon(Icons.chevron_right_rounded, color: AppPalette.muted),
            ],
          ),
        ),
      ),
    );
  }
}

class StudyTimeDetailsScreen extends StatelessWidget {
  const StudyTimeDetailsScreen({super.key, required this.user});
  final AppUser user;

  String _format(int seconds) {
    final safe = max(0, seconds);
    final hours = safe ~/ 3600;
    final minutes = (safe % 3600) ~/ 60;
    if (hours > 0) return '${faNumber(hours)} ساعت و ${faNumber(minutes)} دقیقه';
    return '${faNumber(minutes)} دقیقه';
  }

  @override
  Widget build(BuildContext context) {
    final entries = user.studyByBook.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Scaffold(
      backgroundColor: AppPalette.canvas,
      appBar: AppBar(automaticallyImplyLeading: true, title: const Text('جزئیات زمان مطالعه')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
        children: [
          SectionCard(
            title: 'زمان مطالعه کل',
            child: Text(_format(user.studySeconds), textAlign: TextAlign.right, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.primary)),
          ),
          const SizedBox(height: 10),
          if (entries.isEmpty)
            const SectionCard(title: 'کتاب‌ها', child: Text('هنوز زمان مطالعه‌ای برای کتاب‌ها ثبت نشده است.', textAlign: TextAlign.right, style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)))
          else
            SectionCard(
              title: 'مطالعه به تفکیک کتاب',
              child: Column(
                children: entries.map((entry) => Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  decoration: BoxDecoration(color: AppPalette.canvas, borderRadius: BorderRadius.circular(16)),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      const Icon(Icons.menu_book_rounded, color: AppPalette.primary),
                      const SizedBox(width: 10),
                      Expanded(child: Text(entry.key, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink))),
                      Text(_format(entry.value), style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.primary)),
                    ],
                  ),
                )).toList(),
              ),
            ),
        ],
      ),
    );
  }
}

class _IntelligenceMiniStat extends StatelessWidget {
  const _IntelligenceMiniStat({required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F8FF),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppPalette.primary.withOpacity(.08)),
      ),
      child: Column(
        children: [
          Icon(icon, color: AppPalette.primary, size: 22),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink)),
          const SizedBox(height: 4),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: AppPalette.muted)),
        ],
      ),
    );
  }
}

class _ProfileQuickItem {
  const _ProfileQuickItem(this.title, this.icon, this.onTap);
  final String title;
  final IconData icon;
  final VoidCallback? onTap;
}

class ProfileQuickCard extends StatelessWidget {
  const ProfileQuickCard({super.key, required this.item});
  final _ProfileQuickItem item;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(19),
      child: InkWell(
        borderRadius: BorderRadius.circular(19),
        onTap: item.onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(19),
            boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 14, offset: Offset(0, 8))],
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(color: const Color(0xFFF4F0FF), borderRadius: BorderRadius.circular(15)),
                child: Icon(item.icon, color: AppPalette.secondary, size: 28),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  item.title,
                  maxLines: 2,
                  overflow: TextOverflow.visible,
                  textAlign: TextAlign.right,
                  style: const TextStyle(fontSize: 12.8, height: 1.35, fontWeight: FontWeight.w900, color: AppPalette.ink),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class StableProfileHeader extends StatelessWidget {
  const StableProfileHeader({super.key, required this.user, required this.rank});
  final AppUser user;
  final int rank;

  @override
  Widget build(BuildContext context) {
    final next = max(600, user.level * 320);
    final progress = ((currentCups(user) % next) / next).clamp(0.0, 1.0).toDouble();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: SizedBox(
              width: 112,
              height: 112,
              child: avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 18)]),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [Text('۳۲۴ لایک', style: TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)), SizedBox(width: 8), Icon(Icons.favorite, color: Color(0xFFE91E63))]),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Flexible(child: Text(user.name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppPalette.ink))),
              const SizedBox(width: 8),
              const Icon(Icons.verified_rounded, color: AppPalette.primary),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            alignment: WrapAlignment.end,
            spacing: 8,
            runSpacing: 8,
            children: [
              _StableProfileChip(text: 'Level ${user.level}', icon: Icons.star),
              _StableProfileChip(text: 'پایه ${gradeLabel(user.grade)}', icon: Icons.school),
              _StableProfileChip(text: 'Level ${user.level}', icon: Icons.star_outline_rounded),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Container(width: 54, height: 54, decoration: BoxDecoration(color: const Color(0xFFE9E7FF), borderRadius: BorderRadius.circular(18)), child: const Icon(Icons.shield_rounded, color: AppPalette.primary, size: 30)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: progress, minHeight: 8, backgroundColor: const Color(0xFFEDEBFF), color: AppPalette.primary)),
                    const SizedBox(height: 8),
                    Text('${currentCups(user)} / $next کاپ', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    Text('بیشترین کاپ: ${cupText(bestCups(user))}', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StableProfileChip extends StatelessWidget {
  const _StableProfileChip({required this.text, required this.icon});
  final String text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(color: const Color(0xFFF8F7FF), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE5E1FF))),
      child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 16, color: AppPalette.primary), const SizedBox(width: 6), Text(text, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink))]),
    );
  }
}

class StableProfileStatsGrid extends StatelessWidget {
  const StableProfileStatsGrid({super.key, required this.user, required this.rank});
  final AppUser user;
  final int rank;

  @override
  Widget build(BuildContext context) {
    final items = [
      ('کاپ فعلی', '${currentCups(user)}', Icons.hexagon_outlined),
      ('بیشترین کاپ', '${bestCups(user)}', Icons.emoji_events_rounded),
      ('تعداد بازی', '${user.matchesCount}', Icons.sports_esports_outlined),
      ('برد/باخت', '${user.wins}/${lossesCount(user)}', Icons.check_circle_outline),
    ];
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: items.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisExtent: 96, crossAxisSpacing: 10, mainAxisSpacing: 10),
        itemBuilder: (_, i) => Container(
          decoration: BoxDecoration(color: const Color(0xFFF8FAFF), borderRadius: BorderRadius.circular(18)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(items[i].$3, color: AppPalette.primary, size: 24),
            const SizedBox(height: 6),
            Text(items[i].$2, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
            const SizedBox(height: 3),
            Text(items[i].$1, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
          ]),
        ),
      ),
    );
  }
}

class StableStudyChartCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final values = [240, 430, 180, 80, 210, 115, 380];
    final days = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
    return SectionCard(
      title: 'میزان مطالعه در هفته اخیر',
      child: SizedBox(
        height: 130,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: List.generate(values.length, (i) {
            final h = 24 + (values[i] / 430) * 82;
            return Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(width: 18, height: h, decoration: BoxDecoration(gradient: AppPalette.heroGradient, borderRadius: BorderRadius.circular(9))),
                  const SizedBox(height: 8),
                  Text(days[i], style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted, fontSize: 11)),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}

class StableSkillsCard extends StatelessWidget {
  const StableSkillsCard({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'هوش درسی',
      child: Column(children: user.skills.entries.map((e) => IntelligenceBarRow(subject: e.key, percent: e.value)).toList()),
    );
  }
}

class StableMedalsCard extends StatelessWidget {
  const StableMedalsCard({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final medals = user.medals.isEmpty ? ['قهرمان هفته', 'استاد علوم', '۳۰ روز مطالعه'] : user.medals.take(4).toList();
    final icons = [Icons.functions_rounded, Icons.science_rounded, Icons.calendar_month_rounded, Icons.emoji_events_rounded];
    return SectionCard(
      title: 'مدال‌های کسب شده',
      child: Wrap(
        alignment: WrapAlignment.spaceAround,
        spacing: 14,
        runSpacing: 14,
        children: List.generate(medals.length, (i) => SizedBox(
          width: 92,
          child: Column(children: [
            Container(width: 46, height: 46, decoration: BoxDecoration(gradient: LinearGradient(colors: AppPalette.gradientForIndex(i)), shape: BoxShape.circle), child: Icon(icons[i % icons.length], color: Colors.white, size: 22)),
            const SizedBox(height: 8),
            Text(medals[i], textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppPalette.ink)),
          ]),
        )),
      ),
    );
  }
}

class StableRecordsCard extends StatelessWidget {
  const StableRecordsCard({super.key, required this.user});
  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'رکوردها',
      child: Column(children: [
        _StableKeyValue(title: 'بیشترین کاپ کسب‌شده', value: cupText(bestCups(user))),
        _StableKeyValue(title: 'امتیاز فعلی', value: cupText(currentCups(user))),
        _StableKeyValue(title: 'تعداد بازی / برد / باخت', value: '${user.matchesCount} / ${user.wins} / ${lossesCount(user)}'),
        _StableKeyValue(title: 'درصد پاسخ صحیح', value: '${min(96, 70 + user.level)}٪'),
      ]),
    );
  }
}

class _StableKeyValue extends StatelessWidget {
  const _StableKeyValue({required this.title, required this.value});
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(children: [Text(value, style: const TextStyle(color: AppPalette.primary, fontWeight: FontWeight.w900)), const SizedBox(width: 12), Expanded(child: Text(title, textAlign: TextAlign.right, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)))]),
    );
  }
}

class StableActivityCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = [
      ('+40 کاپ در کوییز ریاضی', Icons.hexagon_outlined, '۲ ساعت پیش'),
      ('مدال قهرمان هفته را کسب کرد', Icons.workspace_premium, 'دیروز'),
      ('رکورد جدید ثبت کرد', Icons.trending_up_rounded, '۳ روز پیش'),
    ];
    return SectionCard(
      title: 'فعالیت اخیر',
      child: Column(children: items.map((item) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(children: [Text(item.$3, style: const TextStyle(color: AppPalette.muted, fontSize: 12)), const Spacer(), Expanded(flex: 4, child: Text(item.$1, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink))), const SizedBox(width: 8), Icon(item.$2, color: AppPalette.primary)]),
      )).toList()),
    );
  }
}

class PublicProfileHero extends StatelessWidget {
  const PublicProfileHero({super.key, required this.user, required this.rank});

  final AppUser user;
  final int rank;

  @override
  Widget build(BuildContext context) {
    final nextLevelXp = max(500, user.level * 250);
    final progress = (currentCups(user) % nextLevelXp) / nextLevelXp;

    return LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth;
        final avatarSize = w < 360 ? 92.0 : 112.0;
        return Container(
          margin: const EdgeInsets.only(bottom: 14),
          padding: EdgeInsets.all(w < 360 ? 14 : 18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [BoxShadow(color: AppPalette.primary.withOpacity(0.07), blurRadius: 24, offset: const Offset(0, 12))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Column(
                  children: [
                    SizedBox(
                      width: avatarSize,
                      height: avatarSize,
                      child: avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 14)]),
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.favorite, color: Colors.pink, size: 18), SizedBox(width: 6), Text('324 لایک', style: TextStyle(fontWeight: FontWeight.w900))]),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Icon(Icons.verified_rounded, color: AppPalette.primary, size: 22),
                  const SizedBox(width: 6),
                  Expanded(child: Text(user.name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppPalette.ink))),
                ],
              ),
              const SizedBox(height: 12),
              Wrap(
                alignment: WrapAlignment.end,
                spacing: 8,
                runSpacing: 8,
                children: [
                  _TinyProfileChip(text: 'Level ${user.level}', icon: Icons.star),
                  _TinyProfileChip(text: 'پایه ${gradeLabel(user.grade)}', icon: Icons.school),
                  _TinyProfileChip(text: 'Level ${user.level}', icon: Icons.star_outline_rounded),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(width: 54, height: 54, decoration: BoxDecoration(color: const Color(0xFFE9E7FF), borderRadius: BorderRadius.circular(18)), child: const Icon(Icons.shield_rounded, color: AppPalette.primary, size: 30)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: progress.clamp(0, 1), minHeight: 8, backgroundColor: const Color(0xFFEDEBFF), color: AppPalette.primary)),
                        const SizedBox(height: 8),
                        Text('${currentCups(user)} / $nextLevelXp کاپ', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
                        Text('بیشترین کاپ: ${cupText(bestCups(user))}', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _TinyProfileChip extends StatelessWidget {
  const _TinyProfileChip({required this.text, required this.icon});

  final String text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(color: const Color(0xFFF8F7FF), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE5E1FF))),
      child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 16, color: AppPalette.primary), const SizedBox(width: 5), Text(text, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink))]),
    );
  }
}

class ProfileDashboardGrid extends StatelessWidget {
  const ProfileDashboardGrid({super.key, required this.user, required this.rank});

  final AppUser user;
  final int rank;

  @override
  Widget build(BuildContext context) {
    final items = [
      ('کل کاپ', '${currentCups(user)}', Icons.hexagon_outlined),
      ('رتبه فعلی', '$rank', Icons.emoji_events_rounded),
      ('برد متوالی', '${user.winStreak}', Icons.local_fire_department_rounded),
      ('مدال‌ها', '${user.medals.length}', Icons.military_tech_rounded),
    ];
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
      child: LayoutBuilder(
        builder: (context, constraints) {
          return GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: items.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisExtent: 86,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemBuilder: (context, index) {
              final item = items[index];
              return Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: const Color(0xFFF8FAFF), borderRadius: BorderRadius.circular(18)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(item.$3, color: AppPalette.primary, size: 22),
                    const SizedBox(height: 6),
                    FittedBox(child: Text(item.$2, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink))),
                    const SizedBox(height: 2),
                    Text(item.$1, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700, fontSize: 12)),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class ProfileStudyChartCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final values = [240, 430, 180, 80, 210, 115, 380];
    final days = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
    return SectionCard(
      title: 'میزان مطالعه در هفته اخیر',
      child: SizedBox(
        height: 125,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(values.length, (i) {
            final h = 24 + (values[i] / 430) * 76;
            return Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Container(width: 18, height: h, decoration: BoxDecoration(gradient: AppPalette.heroGradient, borderRadius: BorderRadius.circular(8))),
                const SizedBox(height: 8),
                Text(days[i], style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted, fontSize: 11)),
              ],
            );
          }),
        ),
      ),
    );
  }
}

class ProfileMedalsPreview extends StatelessWidget {
  const ProfileMedalsPreview({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final medals = user.medals.isEmpty ? ['قهرمان هفته', 'استاد علوم', '۳۰ روز مطالعه', 'تابعه ریاضی'] : user.medals.take(4).toList();
    final icons = [Icons.functions_rounded, Icons.science_rounded, Icons.calendar_month_rounded, Icons.emoji_events_rounded];
    return SectionCard(
      title: 'مدال‌های کسب شده',
      child: LayoutBuilder(
        builder: (context, constraints) {
          final itemWidth = (constraints.maxWidth - 24) / 3;
          return Wrap(
            spacing: 12,
            runSpacing: 12,
            children: List.generate(medals.length, (i) => SizedBox(
              width: itemWidth.clamp(78.0, 120.0).toDouble(),
              child: Column(children: [
                Container(width: 42, height: 42, decoration: BoxDecoration(gradient: LinearGradient(colors: AppPalette.gradientForIndex(i)), shape: BoxShape.circle), child: Icon(icons[i % icons.length], color: Colors.white, size: 20)),
                const SizedBox(height: 8),
                Text(medals[i], textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppPalette.ink)),
              ]),
            )),
          );
        },
      ),
    );
  }
}

class ProfileRecordsCard extends StatelessWidget {
  const ProfileRecordsCard({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'رکوردها',
      child: Column(children: [
        _ProfileRecordLine(title: 'بیشترین کاپ کسب‌شده', value: cupText(bestCups(user))),
        _ProfileRecordLine(title: 'امتیاز فعلی', value: cupText(currentCups(user))),
        _ProfileRecordLine(title: 'تعداد بازی / برد / باخت', value: '${user.matchesCount} / ${user.wins} / ${lossesCount(user)}'),
        _ProfileRecordLine(title: 'درصد پاسخ صحیح', value: '${min(96, 70 + user.level)}٪'),
      ]),
    );
  }
}

class _ProfileRecordLine extends StatelessWidget {
  const _ProfileRecordLine({required this.title, required this.value});

  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(children: [Expanded(child: Text(title, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700))), Text(value, style: const TextStyle(color: AppPalette.primary, fontWeight: FontWeight.w900))]),
    );
  }
}

class ProfileActivityCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = [
      ('+40 کاپ در کوییز ریاضی', Icons.hexagon_outlined, '۲ ساعت پیش'),
      ('مدال قهرمان هفته را کسب کرد', Icons.workspace_premium, 'دیروز'),
      ('رکورد جدید ثبت کرد', Icons.trending_up_rounded, '۳ روز پیش'),
    ];
    return SectionCard(
      title: 'فعالیت اخیر',
      child: Column(children: items.map((item) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(children: [Icon(item.$2, color: AppPalette.primary), const SizedBox(width: 8), Expanded(child: Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.ink))), Text(item.$3, style: const TextStyle(color: AppPalette.muted, fontSize: 12))]),
      )).toList()),
    );
  }
}


class IntelligenceLevelCard extends StatelessWidget {
  const IntelligenceLevelCard({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    final entries = user.skills.entries.toList();
    final average = entries.isEmpty ? 0 : (entries.map((e) => e.value).reduce((a, b) => a + b) / entries.length).round();
    return SectionCard(
      title: 'سطح هوش آموزشی',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: AppPalette.heroGradient,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.bar_chart_rounded, color: Colors.white),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('براساس نتیجه کوییزها تغییر می‌کند', style: TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    const SizedBox(height: 4),
                    Text('میانگین فعلی: $average٪', style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...entries.map((entry) => IntelligenceBarRow(subject: entry.key, percent: entry.value)),
        ],
      ),
    );
  }
}

class IntelligenceBarRow extends StatelessWidget {
  const IntelligenceBarRow({super.key, required this.subject, required this.percent});

  final String subject;
  final int percent;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        children: [
          SizedBox(width: 48, child: Text('$percent٪', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink))),
          const SizedBox(width: 12),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: (percent / 100).clamp(0.0, 1.0).toDouble(),
                minHeight: 9,
                backgroundColor: AppPalette.secondary.withOpacity(0.12),
                valueColor: const AlwaysStoppedAnimation<Color>(AppPalette.secondary),
              ),
            ),
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 112,
            height: 28,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerRight,
              child: Text(
                subject,
                maxLines: 1,
                softWrap: false,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppPalette.muted),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ProfileMistakesSummaryCard extends StatelessWidget {
  const ProfileMistakesSummaryCard({super.key, required this.mistakes, required this.onMistakePracticeFinished});

  final List<MyMistake> mistakes;
  final void Function(QuizResult result) onMistakePracticeFinished;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'اشتباهات من',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: AppPalette.coral.withOpacity(.12),
                child: Icon(Icons.error_outline_rounded, color: AppPalette.coral),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  mistakes.isEmpty ? 'فعلاً اشتباهی ثبت نشده' : '${mistakes.length} سوال برای مرور داری',
                  style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MistakesFullScreen(
                  mistakes: mistakes,
                  onMistakePracticeFinished: onMistakePracticeFinished,
                ),
              ),
            ),
            icon: const Icon(Icons.replay_rounded),
            label: const Text('باز کردن اشتباهات من'),
          ),
        ],
      ),
    );
  }
}

class MistakesFullScreen extends StatelessWidget {
  const MistakesFullScreen({super.key, required this.mistakes, required this.onMistakePracticeFinished});

  final List<MyMistake> mistakes;
  final void Function(QuizResult result) onMistakePracticeFinished;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('اشتباهات من')),
      body: MistakesPanel(mistakes: mistakes, onMistakePracticeFinished: onMistakePracticeFinished),
    );
  }
}

class StudyPlanFullScreen extends StatelessWidget {
  const StudyPlanFullScreen({super.key, required this.user, required this.onAddStudyTask, required this.onToggleStudyTask, required this.onUpdateStudyTask, required this.onDeleteStudyTask});

  final AppUser user;
  final Future<bool> Function(StudyTask task) onAddStudyTask;
  final Future<bool> Function(StudyTask task) onToggleStudyTask;
  final Future<bool> Function(StudyTask oldTask, StudyTask newTask) onUpdateStudyTask;
  final Future<bool> Function(StudyTask task) onDeleteStudyTask;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('برنامه مطالعه')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          children: [
            StudyPlanCard(user: user, onAddStudyTask: onAddStudyTask, onToggleStudyTask: onToggleStudyTask, onUpdateStudyTask: onUpdateStudyTask, onDeleteStudyTask: onDeleteStudyTask),
          ],
        ),
      ),
    );
  }
}

class AppSettingsScreen extends StatelessWidget {
  const AppSettingsScreen({
    super.key,
    required this.user,
    required this.onUpdateProfile,
    required this.onUpdateThemeMode,
    required this.onUpdateAccount,
    required this.onLogout,
  });

  final AppUser user;
  final Future<bool> Function({required String name, required int grade, String? track, String? bio}) onUpdateProfile;
  final void Function(String themeMode) onUpdateThemeMode;
  final Future<bool> Function({required String name, required String phone, required String currentPassword, required String password}) onUpdateAccount;
  final Future<void> Function() onLogout;

  @override
  Widget build(BuildContext context) {
    final items = [
      _SettingsAction('تغییر اطلاعات کاربری', Icons.manage_accounts_outlined, () => Navigator.push(context, MaterialPageRoute(builder: (_) => AccountInfoSettingsPage(user: user, onUpdateAccount: onUpdateAccount)))),
      _SettingsAction('قوانین و حریم خصوصی', Icons.privacy_tip_outlined, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPolicyScreen()))),
      _SettingsAction('ارتباط با پشتیبانی', Icons.support_agent_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SupportScreen()))),
      _SettingsAction('امتیاز دادن به برنامه', Icons.star_rate_rounded, () => unawaited(_openCurrentMarketReview(context))),
      _SettingsAction('درباره ما', Icons.info_outline_rounded, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutAppScreen()))),
    ];
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('تنظیمات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (var index = 0; index < items.length; index++) ...[
            SizedBox(
              height: 72,
              child: Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                  leading: CircleAvatar(backgroundColor: AppPalette.primary.withOpacity(.10), child: Icon(items[index].icon, color: AppPalette.primary)),
                  title: Text(items[index].title, style: const TextStyle(fontWeight: FontWeight.w900)),
                  trailing: const Icon(Icons.chevron_right_rounded, color: AppPalette.muted),
                  onTap: items[index].onTap,
                ),
              ),
            ),
            const SizedBox(height: 10),
          ],
          SizedBox(
            height: 72,
            child: Card(
              color: const Color(0xFFFFF3F3),
              child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16),
              leading: const CircleAvatar(backgroundColor: Color(0xFFFFE4E4), child: Icon(Icons.logout_rounded, color: Color(0xFFD93434))),
              title: const Text('خروج از حساب', style: TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFD93434))),
              subtitle: const Text('نشست این حساب روی دستگاه پایان می‌یابد.', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppPalette.muted)),
              trailing: const Icon(Icons.chevron_right_rounded, color: AppPalette.muted),
              onTap: () async {
                final confirmed = await showDialog<bool>(
                  context: context,
                  barrierColor: Colors.black.withOpacity(.46),
                  builder: (dialogContext) => Dialog(
                    backgroundColor: Colors.transparent,
                    insetPadding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(22, 24, 22, 20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: const [BoxShadow(color: Color(0x2A0F172A), blurRadius: 34, offset: Offset(0, 18))],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 70,
                            height: 70,
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFE9E9),
                              borderRadius: BorderRadius.circular(23),
                            ),
                            child: const Icon(Icons.logout_rounded, color: Color(0xFFD93434), size: 34),
                          ),
                          const SizedBox(height: 16),
                          const Text('خروج از حساب', textAlign: TextAlign.center, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                          const SizedBox(height: 8),
                          const Text('با خروج، نشست این حساب روی این دستگاه پایان می‌یابد. هر زمان بخواهی می‌توانی دوباره وارد شوی.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12.5, height: 1.75, fontWeight: FontWeight.w700, color: AppPalette.muted)),
                          const SizedBox(height: 20),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton(
                                  onPressed: () => Navigator.pop(dialogContext, false),
                                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                                  child: const Text('انصراف', style: TextStyle(fontWeight: FontWeight.w900)),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: FilledButton.icon(
                                  style: FilledButton.styleFrom(backgroundColor: const Color(0xFFD93434), minimumSize: const Size.fromHeight(50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                                  onPressed: () => Navigator.pop(dialogContext, true),
                                  icon: const Icon(Icons.logout_rounded, size: 19),
                                  label: const Text('خروج', style: TextStyle(fontWeight: FontWeight.w900)),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
                if (confirmed != true || !context.mounted) return;
                final navigator = Navigator.of(context);
                await onLogout();
                if (context.mounted) navigator.popUntil((route) => route.isFirst);
              },
            ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsAction {
  const _SettingsAction(this.title, this.icon, this.onTap);
  final String title;
  final IconData icon;
  final VoidCallback onTap;
}


class ThemeModeSettingsPage extends StatefulWidget {
  const ThemeModeSettingsPage({super.key, required this.user, required this.onSave});
  final AppUser user;
  final ValueChanged<String> onSave;

  @override
  State<ThemeModeSettingsPage> createState() => _ThemeModeSettingsPageState();
}

class _ThemeModeSettingsPageState extends State<ThemeModeSettingsPage> {
  late String _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.user.themeMode == 'dark' ? 'dark' : 'light';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('ظاهر برنامه')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('حالت نمایش', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  const Text('انتخاب تو در حساب آنلاین ذخیره می‌شود و در ورود بعدی هم باقی می‌ماند.', style: TextStyle(height: 1.7)),
                  const SizedBox(height: 16),
                  SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(value: 'light', icon: Icon(Icons.light_mode_outlined), label: Text('روشن')),
                      ButtonSegment(value: 'dark', icon: Icon(Icons.dark_mode_outlined), label: Text('تاریک')),
                    ],
                    selected: {_selected},
                    onSelectionChanged: (values) => setState(() => _selected = values.first),
                  ),
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: () {
                      widget.onSave(_selected);
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.save_outlined),
                    label: const Text('ذخیره ظاهر'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AccountInfoSettingsPage extends StatefulWidget {
  const AccountInfoSettingsPage({super.key, required this.user, required this.onUpdateAccount});

  final AppUser user;
  final Future<bool> Function({required String name, required String phone, required String currentPassword, required String password}) onUpdateAccount;

  @override
  State<AccountInfoSettingsPage> createState() => _AccountInfoSettingsPageState();
}

class _AccountInfoSettingsPageState extends State<AccountInfoSettingsPage> {
  late final TextEditingController phoneController;
  final TextEditingController oldPasswordController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController repeatPasswordController = TextEditingController();
  bool showOldPassword = false;
  bool showPassword = false;
  bool showRepeatPassword = false;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    phoneController = TextEditingController(text: widget.user.phone);
  }

  @override
  void dispose() {
    phoneController.dispose();
    oldPasswordController.dispose();
    passwordController.dispose();
    repeatPasswordController.dispose();
    super.dispose();
  }

  bool _validPhone(String value) => RegExp(r'^09\d{9}$').hasMatch(value.trim());
  bool _validPassword(String value) => value.isEmpty || (value.length >= 6 && RegExp(r'[A-Za-z]').hasMatch(value) && RegExp(r'\d').hasMatch(value));

  Future<void> _save() async {
    if (saving) return;
    final phone = phoneController.text.trim();
    final oldPassword = oldPasswordController.text.trim();
    final password = passwordController.text.trim();
    final repeatPassword = repeatPasswordController.text.trim();
    if (!_validPhone(phone)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('شماره تلفن باید با 09 شروع شود و دقیقاً ۱۱ رقم باشد.')));
      return;
    }
    if (password.isNotEmpty) {
      if (oldPassword.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برای تغییر رمز، رمز فعلی را وارد کن.')));
        return;
      }
      if (!_validPassword(password)) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('رمز جدید باید حداقل ۶ کاراکتر و شامل حرف انگلیسی و عدد باشد.')));
        return;
      }
      if (password != repeatPassword) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تکرار رمز جدید با رمز جدید یکی نیست.')));
        return;
      }
    }
    setState(() => saving = true);
    final ok = await widget.onUpdateAccount(name: widget.user.name, phone: phone, currentPassword: oldPassword, password: password);
    if (!mounted) return;
    setState(() => saving = false);
    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اطلاعات کاربری ذخیره شد.')));
      Navigator.pop(context);
    } else {
      final reason = gaminoAppKey.currentState?.saveStatus.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reason == null || reason.isEmpty ? 'ذخیره اطلاعات انجام نشد.' : reason)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !saving,
      child: Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false, title: const Text('تغییر اطلاعات کاربری')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            AppTextField(controller: phoneController, label: 'شماره تلفن', icon: Icons.phone_outlined, keyboardType: TextInputType.phone, maxLength: 11, inputFormatters: [FilteringTextInputFormatter.digitsOnly]),
            const SizedBox(height: 10),
            AppTextField(controller: oldPasswordController, label: 'رمز فعلی', icon: Icons.lock_open_outlined, obscureText: !showOldPassword, suffixIcon: IconButton(onPressed: () => setState(() => showOldPassword = !showOldPassword), icon: Icon(showOldPassword ? Icons.visibility_off : Icons.visibility))),
            const SizedBox(height: 10),
            AppTextField(controller: passwordController, label: 'رمز جدید اختیاری', icon: Icons.lock_outline, obscureText: !showPassword, suffixIcon: IconButton(onPressed: () => setState(() => showPassword = !showPassword), icon: Icon(showPassword ? Icons.visibility_off : Icons.visibility))),
            const SizedBox(height: 10),
            AppTextField(controller: repeatPasswordController, label: 'تکرار رمز جدید', icon: Icons.lock_outline, obscureText: !showRepeatPassword, suffixIcon: IconButton(onPressed: () => setState(() => showRepeatPassword = !showRepeatPassword), icon: Icon(showRepeatPassword ? Icons.visibility_off : Icons.visibility))),
            const SizedBox(height: 8),
            const Text('شماره تلفن باید با 09 شروع شود و ۱۱ رقم باشد. برای تغییر رمز، رمز فعلی لازم است. نام و پایه از بخش ویرایش پروفایل تغییر می‌کنند.', style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: saving ? null : _save,
              icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save_outlined),
              label: Text(saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'),
            ),
          ],
        ),
      ),
    );
  }
}

class GradeSettingsPage extends StatefulWidget {
  const GradeSettingsPage({super.key, required this.user, required this.onUpdateProfile});
  final AppUser user;
  final Future<bool> Function({required String name, required int grade, String? track, String? bio}) onUpdateProfile;

  @override
  State<GradeSettingsPage> createState() => _GradeSettingsPageState();
}

class _GradeSettingsPageState extends State<GradeSettingsPage> {
  late int grade;
  late String track;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    grade = widget.user.grade;
    track = normalizeEducationTrack(grade, widget.user.educationTrack);
  }

  Future<void> _save() async {
    if (saving) return;
    setState(() => saving = true);
    final ok = await widget.onUpdateProfile(name: widget.user.name, grade: grade, track: normalizeEducationTrack(grade, track), bio: widget.user.bio);
    if (!mounted) return;
    setState(() => saving = false);
    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${gradePathText(grade, track)} ذخیره شد.')));
      Navigator.pop(context);
    } else {
      final reason = gaminoAppKey.currentState?.saveStatus.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reason == null || reason.isEmpty ? 'ذخیره پایه انجام نشد.' : reason)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !saving,
      child: Scaffold(
        appBar: AppBar(automaticallyImplyLeading: false, title: const Text('تغییر پایه تحصیلی')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            GradeTrackPicker(
              grade: grade,
              track: track,
              onGradeChanged: (value) => setState(() { grade = value; track = normalizeEducationTrack(value, track); }),
              onTrackChanged: (value) => setState(() => track = value),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: saving ? null : _save,
              icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save_outlined),
              label: Text(saving ? 'در حال ذخیره...' : 'ذخیره پایه'),
            ),
          ],
        ),
      ),
    );
  }
}

class TicketSummary {
  const TicketSummary({
    required this.id,
    required this.number,
    required this.subject,
    required this.categoryLabel,
    required this.status,
    required this.statusLabel,
    required this.lastMessage,
    required this.lastActivity,
    required this.unreadCount,
    required this.archived,
  });

  final String id;
  final int number;
  final String subject;
  final String categoryLabel;
  final String status;
  final String statusLabel;
  final String lastMessage;
  final String lastActivity;
  final int unreadCount;
  final bool archived;

  factory TicketSummary.fromJson(Map<String, dynamic> json) => TicketSummary(
        id: json['id']?.toString() ?? '',
        number: (json['number'] as num?)?.toInt() ?? 0,
        subject: json['subject']?.toString() ?? '',
        categoryLabel: json['categoryLabel']?.toString() ?? '',
        status: json['status']?.toString() ?? 'waiting_support',
        statusLabel: json['statusLabel']?.toString() ?? '',
        lastMessage: json['lastMessage']?.toString() ?? '',
        lastActivity: json['lastActivity']?.toString() ?? '',
        unreadCount: (json['unreadCount'] as num?)?.toInt() ?? 0,
        archived: json['archived'] == true,
      );
}

class TicketMessageItem {
  const TicketMessageItem({
    required this.id,
    required this.senderType,
    required this.message,
    required this.imageUrl,
    required this.createdAt,
    required this.systemEvent,
  });

  final String id;
  final String senderType;
  final String message;
  final String imageUrl;
  final String createdAt;
  final String systemEvent;

  factory TicketMessageItem.fromJson(Map<String, dynamic> json) => TicketMessageItem(
        id: json['id']?.toString() ?? '',
        senderType: json['senderType']?.toString() ?? 'system',
        message: json['message']?.toString() ?? '',
        imageUrl: json['imageUrl']?.toString() ?? '',
        createdAt: json['createdAt']?.toString() ?? '',
        systemEvent: json['systemEvent']?.toString() ?? '',
      );
}

class GaminoNotificationItem {
  const GaminoNotificationItem({
    required this.id,
    required this.type,
    required this.ticketId,
    required this.title,
    required this.body,
    required this.isRead,
    required this.createdAt,
  });

  final String id;
  final String type;
  final String ticketId;
  final String title;
  final String body;
  final bool isRead;
  final String createdAt;

  factory GaminoNotificationItem.fromJson(Map<String, dynamic> json) => GaminoNotificationItem(
        id: json['id']?.toString() ?? '',
        type: json['type']?.toString() ?? '',
        ticketId: json['ticketId']?.toString() ?? '',
        title: json['title']?.toString() ?? '',
        body: json['body']?.toString() ?? '',
        isRead: json['isRead'] == true,
        createdAt: json['createdAt']?.toString() ?? '',
      );
}

String gaminoCompactDate(String raw) {
  final date = DateTime.tryParse(raw)?.toLocal();
  if (date == null) return '';
  final difference = DateTime.now().difference(date);
  if (difference.inMinutes < 1) return 'اکنون';
  if (difference.inMinutes < 60) return '${faNumber(difference.inMinutes)} دقیقه پیش';
  if (difference.inHours < 24) return '${faNumber(difference.inHours)} ساعت پیش';
  if (difference.inDays < 7) return '${faNumber(difference.inDays)} روز پیش';
  return '${faNumber(date.year)}/${faNumber(date.month)}/${faNumber(date.day)}';
}

Color ticketStatusColor(String status) {
  if (status == 'answered') return const Color(0xFF16A34A);
  if (status == 'waiting_support') return const Color(0xFFDC2626);
  return AppPalette.muted;
}

class TicketNotificationBell extends StatefulWidget {
  const TicketNotificationBell({super.key, required this.isGuest});

  final bool isGuest;

  @override
  State<TicketNotificationBell> createState() => _TicketNotificationBellState();
}

class _TicketNotificationBellState extends State<TicketNotificationBell> {
  int unread = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => unawaited(_load()));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (widget.isGuest) {
      if (mounted) setState(() => unread = 0);
      return;
    }
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) return;
    try {
      final payload = await GaminoApiService.request('notifications.list', token: token, get: true);
      if (mounted) setState(() => unread = (payload['unreadCount'] as num?)?.toInt() ?? 0);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        _HeaderIconButton(
          icon: Icons.notifications_none_rounded,
          onTap: widget.isGuest
              ? () => showGuestLockPrompt(context, feature: 'اعلان‌ها')
              : () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const GaminoNotificationCenterScreen()),
                  );
                  await _load();
                },
        ),
        if (unread > 0)
          Positioned(
            top: -3,
            right: -3,
            child: Container(
              constraints: const BoxConstraints(minWidth: 20),
              height: 20,
              padding: const EdgeInsets.symmetric(horizontal: 5),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFFDC2626),
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: Text(
                unread > 99 ? '99+' : faNumber(unread),
                style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900),
              ),
            ),
          ),
      ],
    );
  }
}

class GaminoNotificationCenterScreen extends StatefulWidget {
  const GaminoNotificationCenterScreen({super.key});

  @override
  State<GaminoNotificationCenterScreen> createState() => _GaminoNotificationCenterScreenState();
}

class _GaminoNotificationCenterScreenState extends State<GaminoNotificationCenterScreen> {
  List<GaminoNotificationItem> rows = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  Future<void> _load() async {
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) {
      if (mounted) setState(() => loading = false);
      return;
    }
    try {
      final payload = await GaminoApiService.request('notifications.list', token: token, get: true);
      final loadedRows = (payload['notifications'] as List? ?? const [])
          .whereType<Map>()
          .map((item) => GaminoNotificationItem.fromJson(Map<String, dynamic>.from(item)))
          .toList();
      if (mounted) {
        setState(() {
          rows = loadedRows;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _open(GaminoNotificationItem row) async {
    final token = await RemoteSessionStore.readToken();
    if (token != null && token.isNotEmpty) {
      try {
        await GaminoApiService.request('notifications.read', token: token, body: {'id': row.id});
      } catch (_) {}
    }
    if (!mounted) return;
    if (row.ticketId.isNotEmpty) {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => TicketThreadScreen(ticketId: row.ticketId)),
      );
    }
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('اعلان‌ها')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : rows.isEmpty
              ? const Center(
                  child: Text(
                    'اعلان جدیدی نداری.',
                    style: TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: rows
                      .map(
                        (row) => Card(
                          color: row.isRead ? Colors.white : const Color(0xFFFFF7F7),
                          child: ListTile(
                            onTap: () => _open(row),
                            leading: CircleAvatar(
                              backgroundColor: row.isRead ? const Color(0xFFEFF3FF) : const Color(0xFFFFE4E4),
                              child: Icon(
                                row.type == 'admin_in_app' ? Icons.notifications_active_rounded : Icons.support_agent_rounded,
                                color: row.isRead ? AppPalette.primary : const Color(0xFFDC2626),
                              ),
                            ),
                            title: Text(row.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                            subtitle: Text(
                              '${row.body}\n${gaminoCompactDate(row.createdAt)}',
                              style: const TextStyle(height: 1.55, color: AppPalette.muted, fontWeight: FontWeight.w700),
                            ),
                            isThreeLine: true,
                          ),
                        ),
                      )
                      .toList(),
                ),
    );
  }
}

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});

  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  List<TicketSummary> tickets = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) {
      if (mounted) {
        setState(() {
          loading = false;
          error = 'برای ثبت و مشاهده تیکت وارد حساب کاربری شو.';
        });
      }
      return;
    }
    try {
      final payload = await GaminoApiService.request('tickets.list', token: token, get: true);
      final loadedRows = (payload['tickets'] as List? ?? const [])
          .whereType<Map>()
          .map((item) => TicketSummary.fromJson(Map<String, dynamic>.from(item)))
          .toList();
      if (mounted) {
        setState(() {
          tickets = loadedRows;
          loading = false;
        });
      }
    } on GaminoApiException catch (apiError) {
      if (mounted) {
        setState(() {
          loading = false;
          error = apiError.message;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('تیکت‌ها')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          children: [
            SizedBox(
              height: 54,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0F2B5B),
                  foregroundColor: Colors.white,
                ),
                onPressed: () async {
                  final created = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(builder: (_) => const NewTicketScreen()),
                  );
                  if (created == true) await _load();
                },
                icon: const Icon(Icons.add_rounded),
                label: const Text('ثبت تیکت جدید'),
              ),
            ),
            const SizedBox(height: 16),
            if (loading)
              const Center(child: Padding(padding: EdgeInsets.all(28), child: CircularProgressIndicator()))
            else if (error != null)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Text(
                    error!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted),
                  ),
                ),
              )
            else if (tickets.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(24),
                  child: Text(
                    'هنوز تیکتی ثبت نکرده‌ای.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted),
                  ),
                ),
              )
            else
              ...tickets.map(
                (ticket) => _TicketListCard(
                  ticket: ticket,
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => TicketThreadScreen(ticketId: ticket.id)),
                    );
                    await _load();
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _TicketListCard extends StatelessWidget {
  const _TicketListCard({required this.ticket, required this.onTap});

  final TicketSummary ticket;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = ticketStatusColor(ticket.status);
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(26),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    decoration: BoxDecoration(
                      color: color.withOpacity(.10),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      ticket.statusLabel,
                      style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w900, color: color),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '#${faNumber(ticket.number)}',
                    style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                ticket.subject,
                textAlign: TextAlign.right,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.ink),
              ),
              const SizedBox(height: 5),
              Text(
                ticket.lastMessage.isEmpty ? 'بدون پیام' : ticket.lastMessage,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
                style: const TextStyle(fontSize: 12.5, color: AppPalette.muted, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 7),
              Row(
                children: [
                  if (ticket.unreadCount > 0)
                    Container(
                      width: 9,
                      height: 9,
                      decoration: const BoxDecoration(color: Color(0xFFDC2626), shape: BoxShape.circle),
                    ),
                  const Spacer(),
                  Flexible(
                    child: Text(
                      '${ticket.categoryLabel} • ${gaminoCompactDate(ticket.lastActivity)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 10.5, color: AppPalette.muted, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NewTicketScreen extends StatefulWidget {
  const NewTicketScreen({super.key});

  @override
  State<NewTicketScreen> createState() => _NewTicketScreenState();
}

class _NewTicketScreenState extends State<NewTicketScreen> {
  final TextEditingController subject = TextEditingController();
  final TextEditingController message = TextEditingController();
  String category = 'technical';
  XFile? image;
  bool sending = false;

  @override
  void dispose() {
    subject.dispose();
    message.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final selected = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 1800,
      imageQuality: 82,
    );
    if (selected == null) return;
    if (await selected.length() > 3 * 1024 * 1024) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حجم تصویر باید کمتر از ۳ مگابایت باشد.')),
        );
      }
      return;
    }
    if (mounted) setState(() => image = selected);
  }

  Future<void> _send() async {
    if (sending) return;
    final ticketSubject = subject.text.trim();
    final ticketMessage = message.text.trim();
    if (ticketSubject.length < 3 || ticketMessage.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('موضوع و متن تیکت را کامل وارد کن.')),
      );
      return;
    }
    setState(() => sending = true);
    try {
      final token = await RemoteSessionStore.readToken();
      if (token == null || token.isEmpty) throw const GaminoApiException('نشست کاربری پیدا نشد.');
      var imageBase64 = '';
      if (image != null) imageBase64 = base64Encode(await image!.readAsBytes());
      await GaminoApiService.request(
        'tickets.create',
        token: token,
        body: {
          'subject': ticketSubject,
          'message': ticketMessage,
          'category': category,
          'imageBase64': imageBase64,
        },
      );
      if (mounted) Navigator.pop(context, true);
    } on GaminoApiException catch (apiError) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiError.message)));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('ثبت تیکت جدید')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(labelText: 'دسته‌بندی'),
            items: const [
              DropdownMenuItem(value: 'technical', child: Text('مشکل فنی')),
              DropdownMenuItem(value: 'content', child: Text('محتوا و درس')),
              DropdownMenuItem(value: 'account', child: Text('حساب کاربری')),
              DropdownMenuItem(value: 'payment', child: Text('پرداخت')),
              DropdownMenuItem(value: 'other', child: Text('سایر')),
            ],
            onChanged: (value) => setState(() => category = value ?? 'other'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: subject,
            maxLength: 80,
            decoration: const InputDecoration(labelText: 'موضوع تیکت'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: message,
            maxLines: 7,
            maxLength: 4000,
            decoration: const InputDecoration(labelText: 'متن پیام', alignLabelWithHint: true),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _pick,
            icon: const Icon(Icons.image_outlined),
            label: Text(image == null ? 'افزودن تصویر' : 'تصویر انتخاب شد — تغییر'),
          ),
          if (image != null)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.file(File(image!.path), height: 160, fit: BoxFit.cover),
              ),
            ),
          const SizedBox(height: 16),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF0F2B5B)),
            onPressed: sending ? null : _send,
            icon: sending
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.send_rounded),
            label: const Text('ارسال تیکت'),
          ),
        ],
      ),
    );
  }
}

class TicketThreadScreen extends StatefulWidget {
  const TicketThreadScreen({super.key, required this.ticketId});

  final String ticketId;

  @override
  State<TicketThreadScreen> createState() => _TicketThreadScreenState();
}

class _TicketThreadScreenState extends State<TicketThreadScreen> {
  TicketSummary? ticket;
  List<TicketMessageItem> messages = [];
  final TextEditingController input = TextEditingController();
  XFile? image;
  bool loading = true;
  bool sending = false;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) {
      if (mounted) setState(() => loading = false);
      return;
    }
    try {
      final payload = await GaminoApiService.request(
        'tickets.thread',
        token: token,
        body: {'ticketId': widget.ticketId},
      );
      final loadedTicket = TicketSummary.fromJson(
        Map<String, dynamic>.from(payload['ticket'] as Map? ?? const {}),
      );
      final loadedMessages = (payload['messages'] as List? ?? const [])
          .whereType<Map>()
          .map((item) => TicketMessageItem.fromJson(Map<String, dynamic>.from(item)))
          .toList();
      if (mounted) {
        setState(() {
          ticket = loadedTicket;
          messages = loadedMessages;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _pick() async {
    final selected = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 1800,
      imageQuality: 82,
    );
    if (selected == null) return;
    if (await selected.length() > 3 * 1024 * 1024) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حجم تصویر باید کمتر از ۳ مگابایت باشد.')),
        );
      }
      return;
    }
    if (mounted) setState(() => image = selected);
  }

  Future<void> _send() async {
    if (sending) return;
    final text = input.text.trim();
    if (text.isEmpty && image == null) return;
    setState(() => sending = true);
    try {
      final token = await RemoteSessionStore.readToken();
      if (token == null || token.isEmpty) return;
      var imageBase64 = '';
      if (image != null) imageBase64 = base64Encode(await image!.readAsBytes());
      await GaminoApiService.request(
        'tickets.reply',
        token: token,
        body: {'ticketId': widget.ticketId, 'message': text, 'imageBase64': imageBase64},
      );
      input.clear();
      image = null;
      await _load();
    } on GaminoApiException catch (apiError) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiError.message)));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  Future<void> _reopen() async {
    final token = await RemoteSessionStore.readToken();
    if (token == null || token.isEmpty) return;
    try {
      await GaminoApiService.request('tickets.reopen', token: token, body: {'ticketId': widget.ticketId});
      await _load();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final currentTicket = ticket;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          currentTicket == null ? 'تیکت' : '#${faNumber(currentTicket.number)} — ${currentTicket.subject}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : currentTicket == null
              ? const Center(child: Text('تیکت پیدا نشد.'))
              : Column(
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      color: Colors.white,
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: ticketStatusColor(currentTicket.status).withOpacity(.10),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              currentTicket.statusLabel,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                color: ticketStatusColor(currentTicket.status),
                              ),
                            ),
                          ),
                          const Spacer(),
                          Text(
                            currentTicket.categoryLabel,
                            style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.all(14),
                        children: messages.map(_buildMessage).toList(),
                      ),
                    ),
                    if (currentTicket.status == 'closed')
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14, 8, 14, 14),
                        child: FilledButton.icon(
                          onPressed: _reopen,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('بازکردن مجدد تیکت'),
                        ),
                      )
                    else if (currentTicket.archived)
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'این تیکت آرشیو شده و امکان ارسال پیام جدید ندارد.',
                          style: TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w800),
                        ),
                      )
                    else
                      SafeArea(
                        top: false,
                        child: Container(
                          padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                          color: Colors.white,
                          child: Column(
                            children: [
                              if (image != null)
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(image!.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                                    ),
                                    IconButton(
                                      onPressed: () => setState(() => image = null),
                                      icon: const Icon(Icons.close_rounded),
                                    ),
                                  ],
                                ),
                              Row(
                                children: [
                                  IconButton(
                                    onPressed: _pick,
                                    icon: const Icon(Icons.image_outlined, color: Color(0xFF0F2B5B)),
                                  ),
                                  Expanded(
                                    child: TextField(
                                      controller: input,
                                      minLines: 1,
                                      maxLines: 4,
                                      decoration: const InputDecoration(hintText: 'پیام خود را بنویسید...'),
                                    ),
                                  ),
                                  const SizedBox(width: 7),
                                  IconButton.filled(
                                    style: IconButton.styleFrom(
                                      backgroundColor: const Color(0xFF0F2B5B),
                                      foregroundColor: Colors.white,
                                    ),
                                    onPressed: sending ? null : _send,
                                    icon: sending
                                        ? const SizedBox(
                                            width: 18,
                                            height: 18,
                                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                          )
                                        : const Icon(Icons.send_rounded),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
    );
  }

  Widget _buildMessage(TicketMessageItem message) {
    if (message.senderType == 'system') {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(
          message.message,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 11, color: AppPalette.muted, fontWeight: FontWeight.w700),
        ),
      );
    }

    final mine = message.senderType == 'user';
    final bubble = Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * .78),
        decoration: BoxDecoration(
          color: mine ? const Color(0xFFF0F2F8) : const Color(0xFF0F2B5B),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (message.message.isNotEmpty)
              Text(
                message.message,
                textAlign: TextAlign.right,
                style: TextStyle(
                  height: 1.65,
                  fontWeight: FontWeight.w700,
                  color: mine ? AppPalette.ink : Colors.white,
                ),
              ),
            if (message.imageUrl.isNotEmpty) ...[
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  message.imageUrl,
                  height: 180,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            ],
            const SizedBox(height: 5),
            Text(
              gaminoCompactDate(message.createdAt),
              textAlign: TextAlign.left,
              style: TextStyle(fontSize: 9.5, color: mine ? AppPalette.muted : Colors.white70),
            ),
          ],
        ),
      ),
    );

    if (message.systemEvent != 'image_attached') return bubble;
    return Column(
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 6),
          child: Text(
            'تصویر ارسال شد',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 10.5, color: AppPalette.muted, fontWeight: FontWeight.w700),
          ),
        ),
        bubble,
      ],
    );
  }
}

class RateAppScreen extends StatefulWidget {
  const RateAppScreen({super.key});

  @override
  State<RateAppScreen> createState() => _RateAppScreenState();
}

class _RateAppScreenState extends State<RateAppScreen> {
  bool opening = false;

  Future<void> _openReview(String market, String marketLabel) async {
    if (opening) return;
    setState(() => opening = true);
    try {
      final result = await _gaminoAppControlChannel.invokeMethod<String>('openMarketReview', {'market': market});
      if (!mounted) return;
      if (result != 'opened') {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$marketLabel روی این دستگاه در دسترس نیست.')));
      }
    } on PlatformException catch (error) {
      if (!mounted) return;
      final message = (error.message ?? '').trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message.isEmpty ? 'باز کردن بخش ثبت نظر انجام نشد.' : message)));
    } finally {
      if (mounted) setState(() => opening = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: const Text('امتیاز دادن به برنامه')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const PageTitle(
            title: 'نظر شما برای ما مهم است',
            subtitle: 'مارکتی که گامینو را از آن نصب کرده‌ای انتخاب کن تا بخش ثبت امتیاز و نظر همان مارکت مستقیم باز شود.',
            icon: Icons.star_rate_rounded,
          ),
          const SizedBox(height: 16),
          _MarketReviewCard(
            title: 'ثبت نظر در کافه‌بازار',
            subtitle: 'باز کردن مستقیم پنجره امتیاز و نظر بازار',
            icon: Icons.storefront_rounded,
            enabled: !opening,
            onTap: () => _openReview('bazaar', 'کافه‌بازار'),
          ),
          const SizedBox(height: 12),
          _MarketReviewCard(
            title: 'ثبت نظر در مایکت',
            subtitle: 'باز کردن مستقیم بخش نظر و امتیاز مایکت',
            icon: Icons.apps_rounded,
            enabled: !opening,
            onTap: () => _openReview('myket', 'مایکت'),
          ),
          if (opening) ...[
            const SizedBox(height: 18),
            const Center(child: CircularProgressIndicator()),
          ],
        ],
      ),
    );
  }
}

class _MarketReviewCard extends StatelessWidget {
  const _MarketReviewCard({required this.title, required this.subtitle, required this.icon, required this.enabled, required this.onTap});

  final String title;
  final String subtitle;
  final IconData icon;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppPalette.primary.withOpacity(.10)),
            boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 16, offset: Offset(0, 8))],
          ),
          child: Row(
            textDirection: TextDirection.rtl,
            children: [
              CircleAvatar(
                radius: 25,
                backgroundColor: AppPalette.primary.withOpacity(.10),
                child: Icon(icon, color: AppPalette.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(title, textAlign: TextAlign.right, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    const SizedBox(height: 5),
                    Text(subtitle, textAlign: TextAlign.right, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppPalette.muted)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_left_rounded, color: AppPalette.muted),
            ],
          ),
        ),
      ),
    );
  }
}

class SimpleInfoScreen extends StatelessWidget {
  const SimpleInfoScreen({super.key, required this.title, required this.icon, required this.body});

  final String title;
  final IconData icon;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text(title)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageTitle(title: title, subtitle: body, icon: icon),
        ],
      ),
    );
  }
}

class ProfileStyleSummary extends StatelessWidget {
  const ProfileStyleSummary({super.key, required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(colors: [AppPalette.primary.withOpacity(0.12), AppPalette.cyan.withOpacity(0.10)]),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('استایل فعال فعلی', style: TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              Chip(avatar: const Icon(Icons.face_retouching_natural, size: 18), label: Text(user.avatar)),
              Chip(avatar: const Icon(Icons.crop_square, size: 18), label: Text(user.profileFrame)),
              Chip(avatar: const Icon(Icons.palette_outlined, size: 18), label: Text(user.themeName)),
            ],
          ),
        ],
      ),
    );
  }
}



class GaminoShopScreen extends StatefulWidget {
  const GaminoShopScreen({
    super.key,
    required this.user,
    required this.shopItems,
    required this.cardPackages,
    required this.onBuyShopItem,
    required this.onSelectShopItem,
    required this.onPrepareReward,
    required this.onClaimReward,
    required this.onPurchaseNoAds,
  });

  final AppUser user;
  final List<ShopItem> shopItems;
  final List<CardPackage> cardPackages;
  final Future<bool> Function(ShopItem item) onBuyShopItem;
  final Future<bool> Function(ShopItem item) onSelectShopItem;
  final Future<String?> Function() onPrepareReward;
  final Future<bool> Function(String challenge) onClaimReward;
  final VoidCallback onPurchaseNoAds;

  @override
  State<GaminoShopScreen> createState() => _GaminoShopScreenState();
}

class _GaminoShopScreenState extends State<GaminoShopScreen> {
  static const int maxRewardVideos = 5;
  static const Duration rewardWindowDuration = Duration(hours: 3);

  int _tabIndex = 0;
  int watchedVideos = 0;
  DateTime? rewardWindowStartedAt;
  Timer? _rewardTimer;
  bool _rewardAdOpening = false;
  bool _catalogRefreshing = false;
  bool _cardPurchaseBusy = false;

  String get _rewardPrefix => 'gamino_reward_${widget.user.phone.isNotEmpty ? widget.user.phone : widget.user.name}';
  String get _rewardWatchedKey => '${_rewardPrefix}_watched';
  String get _rewardStartKey => '${_rewardPrefix}_started_at';

  @override
  void initState() {
    super.initState();
    _loadRewardWindow();
    unawaited(_refreshAvatarCatalog());
    unawaited(_recoverPendingCardPurchases());
  }

  Future<void> _refreshAvatarCatalog() async {
    if (_catalogRefreshing) return;
    if (mounted) setState(() => _catalogRefreshing = true);
    final appState = gaminoAppKey.currentState;
    if (appState != null) await appState.refreshAvatarCatalog(silent: true);
    if (mounted) setState(() => _catalogRefreshing = false);
  }

  void _openAvatarTab() {
    if (_tabIndex != 1) setState(() => _tabIndex = 1);
    unawaited(_refreshAvatarCatalog());
  }

  @override
  void dispose() {
    _rewardTimer?.cancel();
    unawaited(GaminoMarketBillingService.dispose());
    super.dispose();
  }

  Future<void> _loadRewardWindow() async {
    final prefs = await SharedPreferences.getInstance();
    final rawStart = prefs.getString(_rewardStartKey);
    final parsedStart = rawStart == null ? null : DateTime.tryParse(rawStart);
    final savedWatched = prefs.getInt(_rewardWatchedKey) ?? 0;
    if (!mounted) return;
    setState(() {
      rewardWindowStartedAt = parsedStart;
      watchedVideos = savedWatched;
      _normalizeRewardWindow();
    });
    _startRewardTicker();
  }

  void _startRewardTicker() {
    _rewardTimer?.cancel();
    _rewardTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(_normalizeRewardWindow);
    });
  }

  void _normalizeRewardWindow() {
    final start = rewardWindowStartedAt;
    if (start == null) return;
    if (DateTime.now().difference(start) >= rewardWindowDuration) {
      rewardWindowStartedAt = null;
      watchedVideos = 0;
      unawaited(_persistRewardWindow());
    }
  }

  Duration get _remainingRewardTime {
    final start = rewardWindowStartedAt;
    if (start == null) return Duration.zero;
    final remaining = start.add(rewardWindowDuration).difference(DateTime.now());
    return remaining.isNegative ? Duration.zero : remaining;
  }

  String get _remainingRewardLabel {
    final remaining = _remainingRewardTime;
    if (remaining == Duration.zero && watchedVideos < maxRewardVideos) return 'اکنون قابل دریافت است';
    final h = remaining.inHours.toString().padLeft(2, '0');
    final m = (remaining.inMinutes % 60).toString().padLeft(2, '0');
    final sec = (remaining.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$sec';
  }

  Future<void> _persistRewardWindow() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_rewardWatchedKey, watchedVideos);
    final start = rewardWindowStartedAt;
    if (start == null) {
      await prefs.remove(_rewardStartKey);
    } else {
      await prefs.setString(_rewardStartKey, start.toIso8601String());
    }
  }

  String? _productIdFor(CardPackage package) {
    if (gaminoCardProductIds.containsValue(package.id)) return package.id;
    return gaminoCardProductIds[package.amount];
  }

  Future<void> _recoverPendingCardPurchases() async {
    final appState = gaminoAppKey.currentState;
    if (appState == null || appState.isGuest || appState.currentUser == null) return;
    try {
      final pending = await GaminoMarketBillingService.pendingPurchases();
      for (final purchase in pending) {
        if (!gaminoCardProductIds.containsValue(purchase.productId) || purchase.developerPayload.isEmpty) continue;
        final claimed = await appState.claimCardPurchase(purchase);
        if (!claimed) continue;
        try {
          await GaminoMarketBillingService.consume(purchase);
        } catch (error) {
          debugPrint('[GaminoIAP] pending purchase consume retry needed: $error');
        }
      }
      final serverCoins = gaminoAppKey.currentState?.currentUser?.coins;
      if (serverCoins != null) widget.user.coins = serverCoins;
      if (mounted) setState(() {});
    } catch (error) {
      debugPrint('[GaminoIAP] pending purchase recovery unavailable: $error');
    }
  }

  Future<void> _buyCoins(CardPackage package) async {
    if (_cardPurchaseBusy) return;
    final productId = _productIdFor(package);
    if (productId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('این بسته به محصول پرداخت متصل نشده است.')));
      return;
    }
    final appState = gaminoAppKey.currentState;
    if (appState == null || appState.isGuest || appState.currentUser == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برای خرید کارت ابتدا وارد حساب شوید.')));
      return;
    }
    setState(() => _cardPurchaseBusy = true);
    try {
      final challenge = await appState.prepareCardPurchase(productId: productId, market: gaminoMarket);
      if (!mounted) return;
      if (challenge == null || challenge.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('مجوز خرید از سرور دریافت نشد. دوباره تلاش کنید.')));
        return;
      }

      final purchase = await GaminoMarketBillingService.purchase(productId: productId, developerPayload: challenge);
      if (purchase.productId != productId || purchase.developerPayload != challenge) {
        throw const GaminoMarketBillingException('اطلاعات خرید با درخواست گامینو همخوانی ندارد.');
      }

      final claimed = await appState.claimCardPurchase(purchase);
      if (!mounted) return;
      if (!claimed) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خرید انجام شد اما تأیید سرور کامل نشد؛ خرید مصرف نشده و قابل بازیابی است.')));
        return;
      }

      var consumeOk = true;
      try {
        await GaminoMarketBillingService.consume(purchase);
      } catch (_) {
        consumeOk = false;
      }
      final serverCoins = gaminoAppKey.currentState?.currentUser?.coins;
      if (serverCoins != null) widget.user.coins = serverCoins;
      if (mounted) setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            consumeOk
                ? '${faNumber(package.amount)} کارت به موجودی اضافه شد.'
                : '${faNumber(package.amount)} کارت اضافه شد؛ مصرف خرید در تلاش بعدی خودکار تکمیل می‌شود.',
          ),
        ),
      );
    } on GaminoMarketBillingException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error.message)));
    } on PlatformException catch (error) {
      if (!mounted) return;
      final message = (error.message ?? '').trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message.isEmpty ? 'خرید تکمیل نشد یا لغو شد.' : message)));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('خرید تکمیل نشد یا لغو شد.')));
      debugPrint('[GaminoIAP] purchase failed: $error');
    } finally {
      if (mounted) setState(() => _cardPurchaseBusy = false);
    }
  }

  Future<void> _watchRewardVideo() async {
    _normalizeRewardWindow();
    if (watchedVideos >= maxRewardVideos) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('سقف ۵ ویدیو پر شده؛ ${_remainingRewardLabel} دوباره فعال می‌شود.')),
      );
      return;
    }
    if (_rewardAdOpening) return;
    setState(() => _rewardAdOpening = true);

    final challenge = await widget.onPrepareReward();
    if (!mounted) return;
    if (challenge == null || challenge.isEmpty) {
      setState(() => _rewardAdOpening = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('مجوز پاداش از سرور دریافت نشد.')));
      return;
    }

    try {
      final outcome = await GaminoAdiveryService.showRewardedVideo();
      if (!mounted) return;
      if (outcome == RewardedVideoOutcome.incomplete) {
        await showDialog<void>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: const Text('ویدیو کامل مشاهده نشد', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900)),
            content: const Text(
              'برای دریافت کارت رایگان، باید تبلیغ ویدیویی را تا انتها تماشا کنید. این ویدیو کامل مشاهده نشد و کارتی به شما تعلق نگرفت.',
              textAlign: TextAlign.center,
              style: TextStyle(height: 1.8, fontWeight: FontWeight.w700),
            ),
            actionsAlignment: MainAxisAlignment.center,
            actions: [
              FilledButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('فهمیدم')),
            ],
          ),
        );
        return;
      }
      if (outcome == RewardedVideoOutcome.unavailable) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('در حال حاضر تبلیغ جایزه‌ای در دسترس نیست؛ کمی بعد دوباره تلاش کنید.')));
        return;
      }

      final claimed = await widget.onClaimReward(challenge);
      if (!mounted) return;
      if (!claimed) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پاداش توسط سرور تأیید نشد.')));
        return;
      }

      if (rewardWindowStartedAt == null) rewardWindowStartedAt = DateTime.now();
      watchedVideos = min(maxRewardVideos, watchedVideos + 1);
      final serverCoins = gaminoAppKey.currentState?.currentUser?.coins;
      if (serverCoins != null) widget.user.coins = serverCoins;
      await _persistRewardWindow();
      if (!mounted) return;
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('۵۰ کارت جایزه دریافت شد.')));
    } finally {
      if (mounted) setState(() => _rewardAdOpening = false);
    }
  }

  Widget _coinTab() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 124),
      children: [
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF7DE),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(color: const Color(0xFFFFE29A)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(width: 34, height: 24, child: Image.asset('assets/gamino_card_home.png', fit: BoxFit.contain)),
                const SizedBox(width: 6),
                Text(faNumber(widget.user.coins), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppPalette.ink)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        _CompactRewardCoinBar(
          watched: watchedVideos,
          maxVideos: maxRewardVideos,
          remainingLabel: _remainingRewardLabel,
          isLoading: _rewardAdOpening,
          onTap: _watchRewardVideo,
        ),
        const SizedBox(height: 22),
        const Text('بسته‌های کارت', textAlign: TextAlign.right, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
        const SizedBox(height: 12),
        LayoutBuilder(
          builder: (context, _) {
            final packages = widget.cardPackages.where((item) => item.published).toList()..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
            if (packages.isEmpty) return const SizedBox.shrink();
            return GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: packages.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1,
              ),
              itemBuilder: (context, index) {
                final package = packages[index];
                final priceLabel = '${faMoney(package.priceToman)} تومان';
                return _CoinPackageCard(
                  amount: package.amount,
                  priceLabel: priceLabel,
                  discountPercent: package.discountPercent,
                  level: index + 1,
                  onTap: () => unawaited(_buyCoins(package)),
                );
              },
            );
          },
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    _normalizeRewardWindow();
    return Scaffold(
      backgroundColor: AppPalette.canvas,
      body: SafeArea(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(18, 8, 18, 8),
              child: Text('شاپ', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: AppPalette.ink)),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 4, 18, 8),
            child: Container(
              padding: const EdgeInsets.all(5),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE7EAF8))),
              child: Row(
                children: [
                  Expanded(child: _ShopTabButton(label: 'کارت', icon: Icons.style_rounded, selected: _tabIndex == 0, onTap: () => setState(() => _tabIndex = 0))),
                  const SizedBox(width: 6),
                  Expanded(child: _ShopTabButton(label: 'آواتار', icon: Icons.face_retouching_natural_rounded, selected: _tabIndex == 1, onTap: _openAvatarTab)),
                ],
              ),
            ),
          ),
            if (!widget.user.hasActiveNoAds) const Padding(
              padding: EdgeInsets.symmetric(horizontal: 18, vertical: 6),
              child: GaminoInlineBanner(slot: 'shop'),
            ),
            if (_catalogRefreshing && _tabIndex == 1)
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 18),
                child: LinearProgressIndicator(minHeight: 3),
              ),
            Expanded(
              child: _tabIndex == 1
                  ? _EmbeddedAvatarShop(
                      user: widget.user,
                      shopItems: widget.shopItems,
                      onBuyShopItem: widget.onBuyShopItem,
                      onSelectShopItem: widget.onSelectShopItem,
                    )
                  : _coinTab(),
            ),
          ],
        ),
      ),
    );
  }
}

class _ShopTabButton extends StatelessWidget {
  const _ShopTabButton({required this.label, required this.icon, required this.selected, required this.onTap});
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? AppPalette.primary : Colors.transparent,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 21, color: selected ? Colors.white : AppPalette.muted),
              const SizedBox(width: 7),
              Text(label, style: TextStyle(fontWeight: FontWeight.w900, color: selected ? Colors.white : AppPalette.ink)),
            ],
          ),
        ),
      ),
    );
  }
}

class _CompactRewardCoinBar extends StatelessWidget {
  const _CompactRewardCoinBar({required this.watched, required this.maxVideos, required this.remainingLabel, required this.isLoading, required this.onTap});
  final int watched;
  final int maxVideos;
  final String remainingLabel;
  final bool isLoading;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final capped = watched >= maxVideos;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(19), border: Border.all(color: const Color(0xFFE8E7FA))),
      child: Row(
        children: [
          SizedBox(width: 50, height: 46, child: Image.asset('assets/gamino_reward_video.png', fit: BoxFit.contain)),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                const Text('کارت رایگان', style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                const SizedBox(height: 3),
                Text('$watched/$maxVideos', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppPalette.muted)),
              ],
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            height: 38,
            child: FilledButton(
              onPressed: capped || isLoading ? null : onTap,
              style: FilledButton.styleFrom(minimumSize: const Size(88, 38), padding: const EdgeInsets.symmetric(horizontal: 13), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13))),
              child: isLoading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('تماشای ویدیو', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    );
  }
}

Future<bool> showGaminoAvatarPurchaseDialog(BuildContext context, AppUser user, ShopItem item) async {
  final remaining = max(0, user.coins - item.price);
  final result = await showModalBottomSheet<bool>(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (sheetContext) => SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 30, offset: Offset(0, -8))],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 42,
              height: 5,
              decoration: BoxDecoration(color: const Color(0xFFE4E6EE), borderRadius: BorderRadius.circular(99)),
            ),
            const SizedBox(height: 18),
            Row(
              textDirection: TextDirection.rtl,
              children: [
                SizedBox(
                  width: 74,
                  height: 74,
                  child: avatarImageForTitle(item.title, fit: BoxFit.contain, remoteUrl: item.imageUrl),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text('تأیید خرید', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                      const SizedBox(height: 5),
                      Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(fontSize: 14, height: 1.5, fontWeight: FontWeight.w800, color: AppPalette.muted)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
              decoration: BoxDecoration(color: const Color(0xFFFFF8DF), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFFFE39A))),
              child: Row(
                textDirection: TextDirection.rtl,
                children: [
                  const Icon(Icons.style_rounded, color: Color(0xFFFFB300), size: 25),
                  const SizedBox(width: 8),
                  Text('${faNumber(item.price)} کارت', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF9A6500))),
                  const Spacer(),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('موجودی ${faNumber(user.coins)}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppPalette.muted)),
                      const SizedBox(height: 2),
                      Text('بعد از خرید ${faNumber(remaining)}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: FilledButton.icon(
                onPressed: () => Navigator.pop(sheetContext, true),
                style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17))),
                icon: const Icon(Icons.shopping_bag_rounded, size: 20),
                label: const Text('خرید آواتار', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
              ),
            ),
            const SizedBox(height: 5),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: () => Navigator.pop(sheetContext, false),
                child: const Text('انصراف', style: TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted)),
              ),
            ),
          ],
        ),
      ),
    ),
  );
  return result == true;
}

class _EmbeddedAvatarShop extends StatefulWidget {
  const _EmbeddedAvatarShop({required this.user, required this.shopItems, required this.onBuyShopItem, required this.onSelectShopItem});
  final AppUser user;
  final List<ShopItem> shopItems;
  final Future<bool> Function(ShopItem item) onBuyShopItem;
  final Future<bool> Function(ShopItem item) onSelectShopItem;

  @override
  State<_EmbeddedAvatarShop> createState() => _EmbeddedAvatarShopState();
}

class _EmbeddedAvatarShopState extends State<_EmbeddedAvatarShop> {
  bool _busy = false;

  Future<void> _buy(ShopItem item) async {
    if (_busy) return;
    if (widget.user.coins < item.price) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کارت کافی برای خرید این آواتار نداری.')));
      return;
    }
    final confirmed = await showGaminoAvatarPurchaseDialog(context, widget.user, item);
    if (confirmed != true || !mounted) return;
    setState(() => _busy = true);
    final ok = await widget.onBuyShopItem(item);
    if (!mounted) return;
    if (ok) {
      widget.user.avatar = item.title;
      widget.user.avatarUrl = item.imageUrl;
      item.isUnlocked = true;
    }
    setState(() => _busy = false);
    if (!ok) {
      final reason = gaminoAppKey.currentState?.saveStatus.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reason == null || reason.isEmpty ? 'خرید انجام نشد.' : reason)));
    }
  }

  Future<void> _select(ShopItem item) async {
    if (_busy) return;
    setState(() => _busy = true);
    final ok = await widget.onSelectShopItem(item);
    if (!mounted) return;
    if (ok) {
      widget.user.avatar = item.title;
      widget.user.avatarUrl = item.imageUrl;
      item.isUnlocked = true;
    }
    setState(() => _busy = false);
    if (!ok) {
      final reason = gaminoAppKey.currentState?.saveStatus.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reason == null || reason.isEmpty ? 'انتخاب آواتار انجام نشد.' : reason)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final avatarItems = widget.shopItems.where((item) => item.type == ShopItemType.avatar).toList()..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 124),
      children: [
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(color: const Color(0xFFFFF7DE), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFFFE29A))),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(width: 30, height: 22, child: Image.asset('assets/gamino_card_home.png', fit: BoxFit.contain)),
                const SizedBox(width: 5),
                Text(faNumber(widget.user.coins), style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink, fontSize: 15)),
              ]),
            ),
            const Spacer(),
            const Text('آواتارها', textAlign: TextAlign.right, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
          ],
        ),
        const SizedBox(height: 14),
        if (avatarItems.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('هنوز آواتاری از پنل مدیریت منتشر نشده است.', textAlign: TextAlign.center)))
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: avatarItems.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: .76),
            itemBuilder: (context, index) {
              final item = avatarItems[index];
              return _AvatarShopCard(user: widget.user, item: item, busy: _busy, onBuy: () => _buy(item), onSelect: () => _select(item));
            },
          ),
      ],
    );
  }
}

class _ShopCurrentCoinsCard extends StatelessWidget {
  const _ShopCurrentCoinsCard({required this.coins});
  final int coins;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 18, offset: Offset(0, 10))]),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(faNumber(coins), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                  const SizedBox(width: 8),
                  const Icon(Icons.style_rounded, color: Color(0xFFFFC107), size: 28),
                ],
              ),
              const SizedBox(height: 4),
              const Text('کارت فعلی شما', style: TextStyle(fontSize: 14, color: AppPalette.muted, fontWeight: FontWeight.w800)),
            ],
          ),
          const Spacer(),
          SizedBox(
            width: 116,
            height: 78,
            child: Stack(
              children: const [
                Positioned(left: 8, bottom: 8, child: Icon(Icons.style_rounded, color: Color(0xFFFFB300), size: 54)),
                Positioned(left: 42, bottom: 18, child: Icon(Icons.style_rounded, color: Color(0xFFFFC107), size: 64)),
                Positioned(left: 20, bottom: 0, child: Icon(Icons.style_rounded, color: Color(0xFFFFD54F), size: 38)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ShopSectionTitle extends StatelessWidget {
  const _ShopSectionTitle({required this.title, required this.icon});
  final String title;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Row(
      textDirection: TextDirection.rtl,
      children: [
        Icon(icon, color: AppPalette.secondary, size: 26),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: AppPalette.ink)),
      ],
    );
  }
}

class _CoinPackageCard extends StatelessWidget {
  const _CoinPackageCard({required this.amount, required this.priceLabel, required this.discountPercent, required this.level, required this.onTap});
  final int amount;
  final String priceLabel;
  final int discountPercent;
  final int level;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final imageSize = level == 1 ? 48.0 : level == 2 ? 53.0 : 58.0;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.fromLTRB(7, 7, 7, 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFE9ECF6)),
            boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 12, offset: Offset(0, 6))],
          ),
          child: Stack(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(faNumber(amount), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.secondary)),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: FittedBox(
                        fit: BoxFit.contain,
                        child: SizedBox(
                          width: imageSize,
                          height: imageSize,
                          child: Image.asset('assets/gamino_card_shop.png', fit: BoxFit.contain),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: double.infinity,
                    constraints: const BoxConstraints(minHeight: 29),
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppPalette.mint,
                      borderRadius: BorderRadius.circular(11),
                    ),
                    alignment: Alignment.center,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(priceLabel, maxLines: 1, style: const TextStyle(color: Colors.white, fontSize: 11.2, fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
              Positioned(
                top: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppPalette.coral,
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Text('${faNumber(discountPercent)}٪', style: const TextStyle(color: Colors.white, fontSize: 8.5, fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NoAdsShopCard extends StatelessWidget {
  const _NoAdsShopCard({required this.enabled, required this.onTap});
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 18, offset: Offset(0, 10))]),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(enabled ? 'بدون تبلیغات فعال است' : 'بدون تبلیغات تا ۳ ماه', textAlign: TextAlign.right, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                const SizedBox(height: 5),
                const Text('حذف تبلیغات بنری؛ ویدیوی جایزه‌ای باقی می‌ماند', textAlign: TextAlign.right, style: TextStyle(fontSize: 11.5, height: 1.5, fontWeight: FontWeight.w700, color: AppPalette.muted)),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(color: AppPalette.secondary.withOpacity(.10), borderRadius: BorderRadius.circular(18)),
            child: Icon(enabled ? Icons.verified_rounded : Icons.block_rounded, color: AppPalette.secondary, size: 32),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: 94,
            height: 36,
            child: FilledButton(
              onPressed: enabled ? null : onTap,
              style: FilledButton.styleFrom(backgroundColor: AppPalette.mint, disabledBackgroundColor: const Color(0xFFE7E8F2), padding: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              child: Text(enabled ? 'فعال' : '۲۰,۰۰۰', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    );
  }
}

class _RewardVideoShopCard extends StatelessWidget {
  const _RewardVideoShopCard({
    required this.watched,
    required this.maxVideos,
    required this.remainingLabel,
    required this.isLoading,
    required this.onTap,
  });

  final int watched;
  final int maxVideos;
  final String remainingLabel;
  final bool isLoading;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final done = watched >= maxVideos;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 18, offset: Offset(0, 10))]),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            textDirection: TextDirection.rtl,
            children: [
              Container(
                width: 62,
                height: 62,
                decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.10), borderRadius: BorderRadius.circular(21)),
                child: const Icon(Icons.video_collection_rounded, color: AppPalette.secondary, size: 36),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('کارت رایگان بگیرید!', textAlign: TextAlign.right, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    SizedBox(height: 6),
                    Text('هر ۳ ساعت فقط ۵ تبلیغ ویدیویی؛ هر ویدیو ۵۰ کارت.', textAlign: TextAlign.right, style: TextStyle(fontSize: 12.5, height: 1.7, fontWeight: FontWeight.w700, color: AppPalette.muted)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(color: const Color(0xFFF2EFFF), borderRadius: BorderRadius.circular(14)),
                child: Text('${faNumber(watched)}/${faNumber(maxVideos)} دیده شده', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: AppPalette.secondary)),
              ),
              const Spacer(),
              SizedBox(
                width: 118,
                height: 36,
                child: FilledButton(
                  onPressed: done || isLoading ? null : onTap,
                  style: FilledButton.styleFrom(backgroundColor: AppPalette.mint, disabledBackgroundColor: const Color(0xFFE7E8F2), padding: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                  child: Text(isLoading ? 'آماده‌سازی...' : done ? 'تمام شد' : 'تماشای ویدیو', style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 11),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.schedule_rounded, size: 17, color: AppPalette.muted),
              const SizedBox(width: 6),
              Text('نوبت بعدی: $remainingLabel', style: const TextStyle(fontSize: 12, color: AppPalette.muted, fontWeight: FontWeight.w800)),
            ],
          ),
        ],
      ),
    );
  }
}

class _AvatarShopEntryCard extends StatelessWidget {
  const _AvatarShopEntryCard({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(26),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 18, offset: Offset(0, 10))]),
        child: Row(
          textDirection: TextDirection.rtl,
          children: [
            Container(
              width: 68,
              height: 68,
              decoration: BoxDecoration(gradient: AppPalette.heroGradient, borderRadius: BorderRadius.circular(22)),
              child: const Icon(Icons.face_retouching_natural_rounded, color: Colors.white, size: 38),
            ),
            const SizedBox(width: 14),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('فروشگاه آواتار', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                  SizedBox(height: 6),
                  Text('آواتارهای رایگان و پولی را اینجا انتخاب کن', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppPalette.muted)),
                ],
              ),
            ),
            const Icon(Icons.close_rounded, color: AppPalette.muted, size: 18),
          ],
        ),
      ),
    );
  }
}

class AvatarShopScreen extends StatefulWidget {
  const AvatarShopScreen({super.key, required this.user, required this.shopItems, required this.onBuyShopItem, required this.onSelectShopItem});

  final AppUser user;
  final List<ShopItem> shopItems;
  final Future<bool> Function(ShopItem item) onBuyShopItem;
  final Future<bool> Function(ShopItem item) onSelectShopItem;

  @override
  State<AvatarShopScreen> createState() => _AvatarShopScreenState();
}


class _AvatarShopScreenState extends State<AvatarShopScreen> {
  bool _busy = false;

  Future<void> _buy(ShopItem item) async {
    if (_busy) return;
    if (widget.user.coins < item.price) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('کارت کافی برای خرید این آواتار نداری.')));
      return;
    }
    final confirmed = await showGaminoAvatarPurchaseDialog(context, widget.user, item);
    if (confirmed != true || !mounted) return;
    setState(() => _busy = true);
    final ok = await widget.onBuyShopItem(item);
    if (!mounted) return;
    if (ok) {
      widget.user.avatar = item.title;
      widget.user.avatarUrl = item.imageUrl;
      item.isUnlocked = true;
    }
    setState(() => _busy = false);
    if (!ok) {
      final reason = gaminoAppKey.currentState?.saveStatus.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reason == null || reason.isEmpty ? 'خرید انجام نشد.' : reason)));
    }
  }

  Future<void> _select(ShopItem item) async {
    if (_busy) return;
    setState(() => _busy = true);
    final ok = await widget.onSelectShopItem(item);
    if (!mounted) return;
    if (ok) {
      widget.user.avatar = item.title;
      widget.user.avatarUrl = item.imageUrl;
      item.isUnlocked = true;
    }
    setState(() => _busy = false);
    if (!ok) {
      final reason = gaminoAppKey.currentState?.saveStatus.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reason == null || reason.isEmpty ? 'انتخاب آواتار انجام نشد.' : reason)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final avatarItems = widget.shopItems.where((item) => item.type == ShopItemType.avatar).toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));

    return Scaffold(
      backgroundColor: AppPalette.canvas,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text('فروشگاه آواتار', style: TextStyle(fontWeight: FontWeight.w900)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                decoration: BoxDecoration(color: const Color(0xFFFFF7DE), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFFFE29A))),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.style_rounded, color: Color(0xFFFFB300), size: 20),
                  const SizedBox(width: 5),
                  Text(faNumber(widget.user.coins), style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink, fontSize: 16)),
                ]),
              ),
              const Spacer(),
              const Text('آواتارها', textAlign: TextAlign.right, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
            ],
          ),
          const SizedBox(height: 14),
          if (avatarItems.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('هنوز آواتاری از پنل مدیریت منتشر نشده است.', textAlign: TextAlign.center)))
          else
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: avatarItems.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: .76,
              ),
              itemBuilder: (context, index) {
                final item = avatarItems[index];
                return _AvatarShopCard(
                  user: widget.user,
                  item: item,
                  busy: _busy,
                  onBuy: () => _buy(item),
                  onSelect: () => _select(item),
                );
              },
            ),
        ],
      ),
    );
  }
}

class _AvatarShopCard extends StatelessWidget {
  const _AvatarShopCard({required this.user, required this.item, required this.busy, required this.onBuy, required this.onSelect});

  final AppUser user;
  final ShopItem item;
  final bool busy;
  final VoidCallback onBuy;
  final VoidCallback onSelect;

  bool get selected => user.avatar == item.title;
  bool get unlocked => item.isUnlocked || item.price == 0;

  Widget _image() => avatarImageForTitle(item.title, fit: BoxFit.contain, remoteUrl: item.imageUrl);

  @override
  Widget build(BuildContext context) {
    final canAfford = user.coins >= item.price;
    final actionText = selected
        ? 'انتخاب شده'
        : unlocked
            ? 'استفاده'
            : item.price == 0
                ? 'رایگان'
                : '${faNumber(item.price)} کارت';

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
      decoration: BoxDecoration(
        color: unlocked ? const Color(0xFFECF9F0) : Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: selected ? AppPalette.primary : unlocked ? const Color(0xFFCDEDD6) : const Color(0xFFE7EAF8), width: selected ? 1.5 : 1),
        boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 16, offset: Offset(0, 8))],
      ),
      child: Column(
        children: [
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child: Icon(selected ? Icons.check_circle_rounded : unlocked ? Icons.lock_open_rounded : Icons.lock_outline_rounded, color: selected ? AppPalette.primary : AppPalette.muted, size: 22),
          ),
          Expanded(
            child: Center(child: SizedBox(width: 124, height: 124, child: _image())),
          ),
          const SizedBox(height: 8),
          Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppPalette.ink)),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: FilledButton(
              onPressed: busy || selected
                  ? null
                  : unlocked
                      ? onSelect
                      : canAfford
                          ? onBuy
                          : null,
              style: FilledButton.styleFrom(
                backgroundColor: selected ? AppPalette.primary.withOpacity(.18) : null,
                foregroundColor: selected ? AppPalette.primary : Colors.white,
                disabledBackgroundColor: selected ? AppPalette.primary.withOpacity(.12) : const Color(0xFFF0F1F5),
                disabledForegroundColor: selected ? AppPalette.primary : AppPalette.muted,
                padding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              child: Text(actionText, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    );
  }
}

class ShopItemTile extends StatelessWidget {
  const ShopItemTile({
    super.key,
    required this.user,
    required this.item,
    required this.canBuy,
    required this.onBuy,
    required this.onSelect,
  });

  final AppUser user;
  final ShopItem item;
  final bool canBuy;
  final VoidCallback onBuy;
  final VoidCallback onSelect;

  bool get isSelected {
    if (item.type == ShopItemType.avatar) return user.avatar == item.title;
    if (item.type == ShopItemType.frame) return user.profileFrame == item.title;
    return user.themeName == item.title;
  }

  String get typeLabel {
    if (item.type == ShopItemType.avatar) return 'آواتار';
    if (item.type == ShopItemType.frame) return 'قاب';
    return 'تم';
  }

  @override
  Widget build(BuildContext context) {
    final lockedByLevel = user.level < item.requiredLevel;
    final notEnoughCoins = user.coins < item.price;
    String actionText;
    VoidCallback? action;
    IconData actionIcon;

    if (isSelected) {
      actionText = 'انتخاب‌شده';
      actionIcon = Icons.check_circle;
      action = null;
    } else if (item.isUnlocked) {
      actionText = 'انتخاب';
      actionIcon = Icons.touch_app_outlined;
      action = onSelect;
    } else if (lockedByLevel) {
      actionText = 'Level ${item.requiredLevel}';
      actionIcon = Icons.lock_outline;
      action = null;
    } else if (notEnoughCoins) {
      actionText = 'کارت کم';
      actionIcon = Icons.style_outlined;
      action = null;
    } else {
      actionText = 'خرید';
      actionIcon = Icons.shopping_bag_outlined;
      action = onBuy;
    }

    final active = item.isUnlocked || canBuy;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isSelected ? AppPalette.primary.withOpacity(0.08) : AppPalette.canvas,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: isSelected ? AppPalette.primary.withOpacity(0.35) : AppPalette.primary.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: isSelected ? AppPalette.actionGradient : null,
              color: isSelected ? null : AppPalette.primary.withOpacity(0.10),
              borderRadius: BorderRadius.circular(15),
            ),
            child: item.type == ShopItemType.avatar
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: avatarImageForTitle(item.title, fit: BoxFit.cover, remoteUrl: item.imageUrl),
                  )
                : Icon(item.icon, color: isSelected ? Colors.white : AppPalette.primary),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w900, color: AppPalette.ink),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    _MiniInfoChip(icon: Icons.category_outlined, label: typeLabel),
                    _MiniInfoChip(icon: Icons.trending_up, label: 'سطح ${item.requiredLevel}'),
                    _MiniInfoChip(icon: Icons.style_outlined, label: item.price == 0 ? 'رایگان' : '${item.price} کارت'),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 96,
            height: 42,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: action == null ? Colors.grey.shade300 : null,
                foregroundColor: action == null ? AppPalette.muted : null,
                minimumSize: const Size(96, 42),
                fixedSize: const Size(96, 42),
                padding: const EdgeInsets.symmetric(horizontal: 4),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: action,
              icon: Icon(actionIcon, size: 16),
              label: Text(actionText, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900), overflow: TextOverflow.ellipsis),
            ),
          ),
        ],
      ),
    );
  }
}

class _MiniInfoChip extends StatelessWidget {
  const _MiniInfoChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppPalette.primary.withOpacity(0.06)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: AppPalette.muted),
          const SizedBox(width: 3),
          Text(label, style: const TextStyle(fontSize: 11.5, color: AppPalette.muted, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class StudyPlanCard extends StatefulWidget {
  const StudyPlanCard({super.key, required this.user, required this.onAddStudyTask, required this.onToggleStudyTask, required this.onUpdateStudyTask, required this.onDeleteStudyTask});

  final AppUser user;
  final Future<bool> Function(StudyTask task) onAddStudyTask;
  final Future<bool> Function(StudyTask task) onToggleStudyTask;
  final Future<bool> Function(StudyTask oldTask, StudyTask newTask) onUpdateStudyTask;
  final Future<bool> Function(StudyTask task) onDeleteStudyTask;

  @override
  State<StudyPlanCard> createState() => _StudyPlanCardState();
}

class _StudyPlanCardState extends State<StudyPlanCard> {
  final TextEditingController titleController = TextEditingController();
  String selectedSubject = 'ریاضی';
  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay.now();
  final Set<String> selectedTaskIds = <String>{};
  List<StudyTask> tasks = <StudyTask>[];
  StudyTask? editingTask;
  bool saving = false;

  List<StudyTask> _authoritativeTasks() => List<StudyTask>.from(
        gaminoAppKey.currentState?.currentUser?.studyTasks ?? widget.user.studyTasks,
      );

  String _taskSignature(Iterable<StudyTask> items) => items
      .map((task) => '${task.id}|${task.title}|${task.subject}|${task.timeLabel}|${task.reminderAt}|${task.isDone}')
      .join('||');

  @override
  void initState() {
    super.initState();
    tasks = _authoritativeTasks();
  }

  @override
  void didUpdateWidget(covariant StudyPlanCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    final incoming = _authoritativeTasks();
    if (_taskSignature(incoming) != _taskSignature(tasks)) {
      tasks = incoming;
      selectedTaskIds.removeWhere((id) => !tasks.any((task) => task.id == id));
      if (editingTask != null && !tasks.any((task) => task.id == editingTask!.id)) {
        _resetForm();
      }
    }
  }

  @override
  void dispose() {
    titleController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final current = gregorianToJalali(selectedDate);
    var jy = current[0];
    var jm = current[1];
    var jd = current[2];
    final nowJ = gregorianToJalali(DateTime.now());
    final picked = await showDialog<DateTime>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) {
          final maxDay = jm <= 6 ? 31 : (jm <= 11 ? 30 : 29);
          if (jd > maxDay) jd = maxDay;
          return AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: const Text('انتخاب تاریخ شمسی'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<int>(value: jy, decoration: const InputDecoration(labelText: 'سال'), items: List.generate(2, (i) => nowJ[0] + i).map((year) => DropdownMenuItem(value: year, child: Text(faNumber(year)))).toList(), onChanged: (value) => setDialogState(() => jy = value ?? jy)),
                const SizedBox(height: 10),
                DropdownButtonFormField<int>(value: jm, decoration: const InputDecoration(labelText: 'ماه'), items: List.generate(12, (i) => i + 1).map((month) => DropdownMenuItem(value: month, child: Text(faNumber(month)))).toList(), onChanged: (value) => setDialogState(() => jm = value ?? jm)),
                const SizedBox(height: 10),
                DropdownButtonFormField<int>(value: jd, decoration: const InputDecoration(labelText: 'روز'), items: List.generate(maxDay, (i) => i + 1).map((day) => DropdownMenuItem(value: day, child: Text(faNumber(day)))).toList(), onChanged: (value) => setDialogState(() => jd = value ?? jd)),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
              FilledButton(onPressed: () => Navigator.pop(context, jalaliToGregorian(jy, jm, jd)), child: const Text('تایید')),
            ],
          );
        },
      ),
    );
    if (picked != null && mounted) setState(() => selectedDate = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: selectedTime, helpText: 'انتخاب ساعت یادآوری');
    if (picked != null && mounted) setState(() => selectedTime = picked);
  }

  DateTime get _selectedDateTime => DateTime(selectedDate.year, selectedDate.month, selectedDate.day, selectedTime.hour, selectedTime.minute);

  void _editTask(StudyTask task) {
    titleController.text = task.title;
    selectedSubject = task.subject;
    final parsed = task.reminderAt.isEmpty ? null : DateTime.tryParse(task.reminderAt);
    if (parsed != null) {
      selectedDate = parsed;
      selectedTime = TimeOfDay(hour: parsed.hour, minute: parsed.minute);
    }
    setState(() => editingTask = task);
  }

  void _resetForm() {
    titleController.clear();
    editingTask = null;
    selectedSubject = 'ریاضی';
    selectedDate = DateTime.now();
    selectedTime = TimeOfDay.now();
  }

  Future<void> _saveTask() async {
    if (saving) return;
    final title = titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('برای ذخیره برنامه، اول عنوان برنامه مطالعه را بنویس.'), behavior: SnackBarBehavior.floating));
      return;
    }
    final task = StudyTask(
      id: editingTask?.id ?? '',
      title: title,
      subject: selectedSubject,
      timeLabel: formatReminderDateTime(_selectedDateTime),
      reminderAt: _selectedDateTime.toIso8601String(),
      isDone: editingTask?.isDone ?? false,
    );
    setState(() => saving = true);
    final old = editingTask;
    final ok = old == null ? await widget.onAddStudyTask(task) : await widget.onUpdateStudyTask(old, task);
    if (!mounted) return;
    setState(() => saving = false);
    if (!ok) {
      final reason = gaminoAppKey.currentState?.saveStatus.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reason == null || reason.isEmpty ? 'ذخیره یادآور انجام نشد.' : reason), behavior: SnackBarBehavior.floating));
      return;
    }
    final latest = _authoritativeTasks();
    setState(() {
      tasks = latest;
      _resetForm();
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(old == null ? 'یادآوری مطالعه ثبت شد' : 'یادآوری مطالعه ویرایش شد'), behavior: SnackBarBehavior.floating));
  }

  Future<bool> _confirmDelete(String title, String message, {String confirm = 'حذف'}) async {
    return await showDialog<bool>(
      context: context,
      builder: (dialogContext) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 52, height: 52, decoration: BoxDecoration(color: AppPalette.coral.withOpacity(.10), shape: BoxShape.circle), child: const Icon(Icons.delete_outline_rounded, color: AppPalette.coral, size: 28)),
              const SizedBox(height: 12),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink)),
              const SizedBox(height: 7),
              Text(message, textAlign: TextAlign.center, style: const TextStyle(height: 1.7, fontWeight: FontWeight.w700, color: AppPalette.muted)),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('انصراف'))),
                const SizedBox(width: 9),
                Expanded(child: FilledButton(style: FilledButton.styleFrom(backgroundColor: AppPalette.coral), onPressed: () => Navigator.pop(dialogContext, true), child: Text(confirm))),
              ]),
            ],
          ),
        ),
      ),
    ) ?? false;
  }

  Future<void> _deleteTask(StudyTask task) async {
    if (!await _confirmDelete('حذف یادآور؟', 'این یادآوری از برنامه مطالعه حذف می‌شود.')) return;
    setState(() => saving = true);
    final ok = await widget.onDeleteStudyTask(task);
    if (!mounted) return;
    setState(() => saving = false);
    if (!ok) {
      final reason = gaminoAppKey.currentState?.saveStatus.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reason == null || reason.isEmpty ? 'حذف یادآور انجام نشد.' : reason), behavior: SnackBarBehavior.floating));
      return;
    }
    final latest = _authoritativeTasks();
    setState(() {
      tasks = latest..removeWhere((item) => item.id == task.id);
      selectedTaskIds.remove(task.id);
      if (editingTask?.id == task.id) _resetForm();
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('یادآور حذف شد'), behavior: SnackBarBehavior.floating));
  }

  Future<void> _toggleDone(StudyTask task) async {
    if (saving) return;
    setState(() => saving = true);
    final ok = await widget.onToggleStudyTask(task);
    if (!mounted) return;
    setState(() => saving = false);
    if (ok) {
      final latest = _authoritativeTasks();
      setState(() => tasks = latest);
    }
  }

  void _toggleTaskSelection(StudyTask task, bool? value) {
    setState(() {
      if (value == true) selectedTaskIds.add(task.id); else selectedTaskIds.remove(task.id);
    });
  }

  void _selectAllTasks() => setState(() {
    selectedTaskIds
      ..clear()
      ..addAll(tasks.map((task) => task.id));
  });

  Future<void> _deleteSelectedTasks() async {
    final items = tasks.where((task) => selectedTaskIds.contains(task.id)).toList();
    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اول برنامه‌هایی که می‌خوای حذف کنی را تیک بزن'), behavior: SnackBarBehavior.floating));
      return;
    }
    if (!await _confirmDelete('حذف یادآورها؟', '${items.length} یادآوری انتخاب‌شده حذف می‌شود.', confirm: 'حذف همه')) return;
    setState(() => saving = true);
    final deletedIds = <String>{};
    for (final task in items) {
      if (await widget.onDeleteStudyTask(task)) deletedIds.add(task.id);
    }
    if (!mounted) return;
    setState(() {
      saving = false;
      tasks.removeWhere((task) => deletedIds.contains(task.id));
      selectedTaskIds.removeAll(deletedIds);
    });
    if (deletedIds.isNotEmpty) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${deletedIds.length} یادآور حذف شد'), behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    final selectedLabel = formatReminderDateTime(_selectedDateTime);
    return SectionCard(
      title: 'برنامه مطالعه و یادآوری',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (editingTask != null)
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(color: AppPalette.primary.withOpacity(.07), borderRadius: BorderRadius.circular(14)),
              child: Row(children: [
                const Icon(Icons.edit_rounded, color: AppPalette.primary, size: 19),
                const SizedBox(width: 7),
                const Expanded(child: Text('در حال ویرایش یادآور', style: TextStyle(fontWeight: FontWeight.w900, color: AppPalette.primary))),
                IconButton(onPressed: saving ? null : () => setState(_resetForm), icon: const Icon(Icons.close_rounded, size: 19)),
              ]),
            ),
          AppTextField(controller: titleController, label: 'مثلاً تمرین فصل اول', icon: Icons.edit_note),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: selectedSubject,
            decoration: InputDecoration(labelText: 'درس', border: OutlineInputBorder(borderRadius: BorderRadius.circular(18))),
            items: ['ریاضی', 'علوم', 'فارسی', 'زبان'].map((subject) => DropdownMenuItem(value: subject, child: Text(subject))).toList(),
            onChanged: saving ? null : (value) => setState(() => selectedSubject = value ?? 'ریاضی'),
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: saving ? null : _pickDate, icon: const Icon(Icons.calendar_today_outlined), label: Text(formatJalaliDate(selectedDate)))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(onPressed: saving ? null : _pickTime, icon: const Icon(Icons.access_time_rounded), label: Text(selectedTime.format(context)))),
          ]),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: saving ? null : _saveTask,
            icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Icon(editingTask == null ? Icons.notifications_active_outlined : Icons.save_outlined),
            label: Text(saving ? 'در حال ذخیره...' : editingTask == null ? 'ذخیره برنامه و تنظیم یادآوری' : 'ذخیره تغییرات یادآور'),
          ),
          const SizedBox(height: 14),
          if (tasks.isNotEmpty) ...[
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: saving ? null : _selectAllTasks, icon: const Icon(Icons.done_all_rounded), label: const Text('انتخاب همه'))),
              const SizedBox(width: 8),
              Expanded(child: FilledButton.icon(onPressed: saving ? null : _deleteSelectedTasks, icon: const Icon(Icons.delete_sweep_rounded), label: const Text('حذف انتخاب‌شده‌ها'))),
            ]),
            const SizedBox(height: 10),
          ],
          ...tasks.map((task) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE9EAF2))),
            child: Row(
              children: [
                Checkbox(value: selectedTaskIds.contains(task.id), onChanged: saving ? null : (value) => _toggleTaskSelection(task, value)),
                Checkbox(value: task.isDone, onChanged: saving ? null : (_) => _toggleDone(task)),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(task.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w900, color: task.isDone ? AppPalette.muted : AppPalette.ink, decoration: task.isDone ? TextDecoration.lineThrough : null)),
                      const SizedBox(height: 4),
                      Text('${task.subject} | ${task.timeLabel}${task.reminderAt.isNotEmpty ? ' | یادآوری فعال' : ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700, fontSize: 12)),
                    ],
                  ),
                ),
                IconButton(tooltip: 'ویرایش', onPressed: saving ? null : () => _editTask(task), icon: const Icon(Icons.edit_outlined, color: AppPalette.primary)),
                IconButton(tooltip: 'حذف', onPressed: saving ? null : () => _deleteTask(task), icon: const Icon(Icons.delete_outline_rounded, color: AppPalette.coral)),
              ],
            ),
          )),
        ],
      ),
    );
  }
}

class HeaderCard extends StatelessWidget {
  const HeaderCard({super.key, required this.user, required this.isGuest});

  final AppUser user;
  final bool isGuest;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(32),
        gradient: AppPalette.heroGradient,
        boxShadow: [
          BoxShadow(
            color: AppPalette.primary.withOpacity(0.28),
            blurRadius: 28,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: -38,
            left: -24,
            child: _SoftCircle(size: 112, color: Colors.white.withOpacity(0.14)),
          ),
          Positioned(
            bottom: -40,
            right: -18,
            child: _SoftCircle(size: 92, color: Colors.white.withOpacity(0.10)),
          ),
          Row(
            children: [
              SizedBox(
                width: 72,
                height: 72,
                child: avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isGuest ? 'حالت مهمان' : 'سلام ${user.name}',
                      style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      isGuest ? 'فقط گام‌به‌گام باز است' : 'پایه ${gradeLabel(user.grade)} | ${user.avatar} | ${user.profileFrame}',
                      style: TextStyle(color: Colors.white.withOpacity(0.82), fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 14),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        GlassChip(label: 'Level ${user.level}', icon: Icons.trending_up),
                        GlassChip(label: '${currentCups(user)} کاپ', icon: Icons.bolt),
                        GlassChip(label: '${user.coins} کارت', icon: Icons.style_outlined),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class HeroFocusCard extends StatelessWidget {
  const HeroFocusCard({super.key, required this.user, required this.isGuest, required this.onPrimaryTap});

  final AppUser user;
  final bool isGuest;
  final VoidCallback onPrimaryTap;

  @override
  Widget build(BuildContext context) {
    final progress = ((currentCups(user) % 500) / 500).clamp(0.0, 1.0).toDouble();
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppPalette.primary.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(color: AppPalette.primary.withOpacity(0.08), blurRadius: 22, offset: const Offset(0, 12)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  gradient: AppPalette.fireGradient,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.local_fire_department, color: Colors.white, size: 30),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('ماموریت رنگی امروز', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                    Text(
                      isGuest ? 'یک فصل گام‌به‌گام را ببین و آماده ثبت‌نام شو' : 'یک کوییز بده، اشتباهاتت را تمرین کن و کارت بگیر',
                      style: const TextStyle(color: AppPalette.muted, height: 1.6),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 10,
              backgroundColor: AppPalette.primary.withOpacity(0.08),
              valueColor: const AlwaysStoppedAnimation<Color>(AppPalette.primary),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: Text('تا Level بعدی: ${(progress * 100).round()}٪', style: const TextStyle(fontWeight: FontWeight.w800))),
              TextButton.icon(
                onPressed: onPrimaryTap,
                icon: const Icon(Icons.bolt_rounded),
                label: Text(isGuest ? 'شروع یادگیری' : 'شروع کوییز'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class GlassChip extends StatelessWidget {
  const GlassChip({super.key, required this.label, required this.icon});

  final String label;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.18),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.white.withOpacity(0.28)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: Colors.white),
          const SizedBox(width: 5),
          Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)),
        ],
      ),
    );
  }
}

class _SoftCircle extends StatelessWidget {
  const _SoftCircle({required this.size, required this.color});

  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    );
  }
}

class _ProfileEditResult {
  const _ProfileEditResult({required this.name, required this.grade, required this.bio});

  final String name;
  final int grade;
  final String bio;
}

class EditProfileDialog extends StatefulWidget {
  const EditProfileDialog({super.key, required this.user, required this.onSave});
  final AppUser user;
  final Future<bool> Function({required String name, required int grade, String? track, String? bio}) onSave;

  @override
  State<EditProfileDialog> createState() => _EditProfileDialogState();
}

class _EditProfileDialogState extends State<EditProfileDialog> {
  late final TextEditingController nameController;
  late final TextEditingController bioController;
  late int selectedGrade;
  late String selectedTrack;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.user.name);
    bioController = TextEditingController(text: widget.user.bio);
    selectedGrade = widget.user.grade.clamp(1, 12).toInt();
    selectedTrack = normalizeEducationTrack(selectedGrade, widget.user.educationTrack);
  }

  @override
  void dispose() {
    nameController.dispose();
    bioController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (saving) return;
    final name = nameController.text.trim();
    final bio = bioController.text.trim();
    final compact = name.replaceAll(RegExp(r'\s+'), '');
    if (compact.length < 3 || compact.length > 30) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نام باید بین ۳ تا ۳۰ کاراکتر باشد.')));
      return;
    }
    if (bio.length > 150) return;
    setState(() => saving = true);
    final ok = await widget.onSave(
      name: name,
      grade: selectedGrade,
      track: normalizeEducationTrack(selectedGrade, selectedTrack),
      bio: bio,
    );
    if (!mounted) return;
    setState(() => saving = false);
    if (ok) {
      Navigator.of(context).pop();
    } else {
      final reason = gaminoAppKey.currentState?.saveStatus.trim();
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(reason == null || reason.isEmpty ? 'ذخیره تغییرات انجام نشد.' : reason)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !saving,
      child: Dialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 22),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('ویرایش پروفایل', textAlign: TextAlign.right, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                const SizedBox(height: 6),
                const Text('اطلاعات اصلی پروفایلت را ویرایش کن.', textAlign: TextAlign.right, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppPalette.muted)),
                const SizedBox(height: 16),
                TextField(controller: nameController, textInputAction: TextInputAction.next, maxLength: 30, decoration: const InputDecoration(labelText: 'نام', prefixIcon: Icon(Icons.person_outline_rounded))),
                const SizedBox(height: 8),
                TextField(controller: bioController, maxLength: 150, minLines: 3, maxLines: 5, textAlignVertical: TextAlignVertical.top, decoration: const InputDecoration(labelText: 'بیو', hintText: 'چند کلمه درباره خودت بنویس', alignLabelWithHint: true, prefixIcon: Icon(Icons.notes_rounded))),
                const SizedBox(height: 8),
                IgnorePointer(
                  ignoring: saving,
                  child: GradeTrackPicker(
                    grade: selectedGrade,
                    track: selectedTrack,
                    showHelper: false,
                    onGradeChanged: (value) => setState(() {
                      selectedGrade = value;
                      selectedTrack = normalizeEducationTrack(value, selectedTrack);
                    }),
                    onTrackChanged: (value) => setState(() => selectedTrack = value),
                  ),
                ),
                const SizedBox(height: 18),
                Row(children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: saving ? null : () => Navigator.of(context).pop(),
                      style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52), padding: const EdgeInsets.symmetric(horizontal: 12)),
                      child: const FittedBox(fit: BoxFit.scaleDown, child: Text('انصراف', maxLines: 1)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: saving ? null : _save,
                      style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), padding: const EdgeInsets.symmetric(horizontal: 12)),
                      icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save_outlined, size: 19),
                      label: FittedBox(fit: BoxFit.scaleDown, child: Text(saving ? 'در حال ذخیره...' : 'ذخیره', maxLines: 1)),
                    ),
                  ),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ProfileHeader extends StatelessWidget {
  const ProfileHeader({super.key, required this.user, required this.onEdit});

  final AppUser user;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(colors: [Color(0xFF00B0FF), Color(0xFF3D5AFE)]),
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  children: [
                    SizedBox(
                      width: 100,
                      height: 100,
                      child: avatarImageForTitle(user.avatar, fit: BoxFit.contain, remoteUrl: user.avatarUrl),
                    ),
                    const SizedBox(height: 12),
                    Text(user.name, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                    Text('پایه ${gradeLabel(user.grade)} | ${user.themeName}', style: const TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
              IconButton.filledTonal(
                onPressed: onEdit,
                icon: const Icon(Icons.edit_outlined),
                tooltip: 'ویرایش پروفایل',
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              Chip(label: Text('Level ${user.level}')),
              Chip(label: Text('${currentCups(user)} کاپ')),
              Chip(label: Text('${user.coins} کارت')),
              Chip(label: Text(user.profileFrame)),
            ],
          ),
        ],
      ),
    );
  }

  IconData _avatarIcon(String avatar) {
    if (avatar.contains('طلایی')) return Icons.face_retouching_natural;
    if (avatar.contains('نابغه')) return Icons.psychology_alt_outlined;
    return Icons.person;
  }
}

class DailyMissionCard extends StatelessWidget {
  const DailyMissionCard({super.key, required this.user, required this.isGuest});

  final AppUser user;
  final bool isGuest;

  @override
  Widget build(BuildContext context) {
    final missions = [
      'یک فصل را کامل کن',
      'یک کوییز زمان‌دار بده',
      'یک اشتباه را دوباره تمرین کن',
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const CircleAvatar(child: Icon(Icons.flag_outlined)),
                const SizedBox(width: 10),
                const Expanded(child: Text('ماموریت‌های امروز', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
                Chip(label: Text(isGuest ? 'قفل' : '+30 کاپ')),
              ],
            ),
            const SizedBox(height: 12),
            ...missions.map((mission) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Icon(isGuest ? Icons.lock_outline : Icons.check_circle_outline, size: 20),
                      const SizedBox(width: 8),
                      Expanded(child: Text(mission)),
                    ],
                  ),
                )),
            const SizedBox(height: 4),
            Text(
              isGuest ? 'بعد از ثبت‌نام، انجام ماموریت‌ها کاپ و کارت می‌دهد.' : 'فعالیت امروز: ${user.dailyActivity} مورد',
              style: const TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.title, required this.value, required this.icon});

  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final colors = AppPalette.gradientForIndex(title.hashCode);
    return Container(
      padding: const EdgeInsets.all(1.2),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: colors),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(23),
        ),
        child: Column(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: colors),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: Colors.white, size: 20),
            ),
            const SizedBox(height: 9),
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
            Text(title, style: const TextStyle(fontSize: 12, color: AppPalette.muted, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}


class SectionHeader extends StatelessWidget {
  const SectionHeader({super.key, required this.title, this.subtitle});

  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 6,
              height: 26,
              decoration: BoxDecoration(
                gradient: AppPalette.actionGradient,
                borderRadius: BorderRadius.circular(99),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink),
              ),
            ),
          ],
        ),
        if (subtitle != null) ...[
          const SizedBox(height: 4),
          Text(subtitle!, style: const TextStyle(color: AppPalette.muted, fontWeight: FontWeight.w700)),
        ],
      ],
    );
  }
}

class QuickFeatureItem {
  const QuickFeatureItem({
    required this.title,
    required this.icon,
    this.onTap,
    this.isLocked = false,
  });

  final String title;
  final IconData icon;
  final VoidCallback? onTap;
  final bool isLocked;
}

class QuickFeatureScroller extends StatelessWidget {
  const QuickFeatureScroller({super.key, required this.items});

  final List<QuickFeatureItem> items;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 126,
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (context, index) => QuickFeatureTile(item: items[index], index: index),
        ),
      ),
    );
  }
}

class QuickFeatureTile extends StatelessWidget {
  const QuickFeatureTile({super.key, required this.item, required this.index});

  final QuickFeatureItem item;
  final int index;

  @override
  Widget build(BuildContext context) {
    final colors = item.isLocked ? [const Color(0xFFCBD5E1), const Color(0xFF94A3B8)] : AppPalette.gradientForIndex(index + item.title.hashCode);
    final enabled = item.onTap != null && !item.isLocked;
    return SizedBox(
      width: 104,
      height: 104,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: enabled ? item.onTap : null,
          child: Ink(
            padding: const EdgeInsets.all(1.2),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: colors),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(color: colors.first.withOpacity(enabled ? .16 : .07), blurRadius: 16, offset: const Offset(0, 8)),
              ],
            ),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(23),
              ),
              child: Directionality(
                textDirection: TextDirection.rtl,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: colors),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Icon(item.isLocked ? Icons.lock_outline : item.icon, color: Colors.white, size: 21),
                    ),
                    const SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 7),
                      child: Text(
                        item.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 12.5, height: 1.25, fontWeight: FontWeight.w900, color: AppPalette.ink),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  const FeatureCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    this.onTap,
    this.isLocked = false,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback? onTap;
  final bool isLocked;

  @override
  Widget build(BuildContext context) {
    final colors = isLocked ? [const Color(0xFFCBD5E1), const Color(0xFF94A3B8)] : AppPalette.gradientForIndex(title.hashCode);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: colors.first.withOpacity(0.10)),
        boxShadow: [
          BoxShadow(color: colors.first.withOpacity(0.08), blurRadius: 18, offset: const Offset(0, 10)),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(26),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(colors: colors),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Icon(isLocked ? Icons.lock_outline : icon, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: AppPalette.ink)),
                      const SizedBox(height: 5),
                      Text(subtitle, style: const TextStyle(color: AppPalette.muted, height: 1.55)),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: colors.first.withOpacity(0.10),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.more_horiz_rounded, color: colors.first),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class PageTitle extends StatelessWidget {
  const PageTitle({super.key, required this.title, required this.subtitle, required this.icon});

  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppPalette.primary.withOpacity(0.07)),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: AppPalette.actionGradient,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Icon(icon, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: AppPalette.muted, height: 1.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class InfoBox extends StatelessWidget {
  const InfoBox({super.key, required this.title, required this.body, required this.icon});

  final String title;
  final String body;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(child: Icon(icon)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                  const SizedBox(height: 8),
                  Text(body, style: const TextStyle(height: 1.8, color: Colors.black87)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SectionCard extends StatelessWidget {
  const SectionCard({super.key, required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(1.1),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [AppPalette.primary.withOpacity(0.16), AppPalette.secondary.withOpacity(0.10)]),
        borderRadius: BorderRadius.circular(26),
      ),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(25),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(width: 8, height: 24, decoration: BoxDecoration(gradient: AppPalette.actionGradient, borderRadius: BorderRadius.circular(999))),
                const SizedBox(width: 8),
                Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppPalette.ink))),
              ],
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class AppTextField extends StatelessWidget {
  const AppTextField({super.key, required this.controller, required this.label, required this.icon, this.keyboardType, this.obscureText = false, this.suffixIcon, this.maxLength, this.inputFormatters});

  final TextEditingController controller;
  final String label;
  final IconData icon;
  final TextInputType? keyboardType;
  final bool obscureText;
  final Widget? suffixIcon;
  final int? maxLength;
  final List<TextInputFormatter>? inputFormatters;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      maxLength: maxLength,
      inputFormatters: inputFormatters,
      buildCounter: maxLength == null ? null : (context, {required currentLength, required isFocused, maxLength}) => null,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
        suffixIcon: suffixIcon,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
        filled: true,
        fillColor: Colors.white,
      ),
    );
  }
}

Future<void> showGuestLockPrompt(BuildContext context, {String feature = 'این بخش'}) async {
  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (sheetContext) => SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.all(14),
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(30)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.lock_outline_rounded, size: 48, color: AppPalette.primary),
            const SizedBox(height: 12),
            Text('$feature برای مهمان قفل است', textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppPalette.ink)),
            const SizedBox(height: 8),
            const Text('برای استفاده از این قابلیت وارد حساب شوید یا یک حساب جدید بسازید.', textAlign: TextAlign.center, style: TextStyle(height: 1.7, color: AppPalette.muted, fontWeight: FontWeight.w700)),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(child: FilledButton(onPressed: () { Navigator.pop(sheetContext); gaminoAppKey.currentState?.openAuthFromGuest(_AuthMode.register); }, child: const Text('ثبت‌نام'))),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton(onPressed: () { Navigator.pop(sheetContext); gaminoAppKey.currentState?.openAuthFromGuest(_AuthMode.login); }, child: const Text('ورود'))),
              ],
            ),
            const SizedBox(height: 6),
            TextButton(onPressed: () { suppressHomeExitBriefly(); Navigator.pop(sheetContext); }, child: const Text('بعداً')),
          ],
        ),
      ),
    ),
  );
}

class LockedScreen extends StatelessWidget {
  const LockedScreen({super.key, required this.title, required this.message});

  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.lock_outline, size: 58, color: AppPalette.ink),
                  const SizedBox(height: 16),
                  Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  Text(message, textAlign: TextAlign.center, style: const TextStyle(height: 1.8, color: Colors.black54)),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton(
                          onPressed: () => gaminoAppKey.currentState?.openAuthFromGuest(_AuthMode.register),
                          child: const Text('ثبت‌نام'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () => gaminoAppKey.currentState?.openAuthFromGuest(_AuthMode.login),
                          child: const Text('ورود'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () {
                      // This is a tab-state action, not a Navigator pop. Popping the
                      // root HomeShell triggers its exit PopScope and used to open the
                      // exit dialog immediately after choosing «بعداً».
                      suppressHomeExitBriefly();
                      gaminoHomeShellKey.currentState?.goHome();
                    },
                    child: const Text('بعداً'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}


class LocalAppSnapshot {
  const LocalAppSnapshot({
    required this.user,
    required this.isGuest,
    required this.mistakes,
    required this.activeRoom,
    required this.unlockedShopItemIds,
    required this.shopItems,
    required this.cardPackages,
    required this.books,
    required this.medals,
  });

  final AppUser user;
  final bool isGuest;
  final List<MyMistake> mistakes;
  final QuizRoom? activeRoom;
  final List<String> unlockedShopItemIds;
  final List<ShopItem> shopItems;
  final List<CardPackage> cardPackages;
  final List<LearningBook> books;
  final List<GaminoMedalItem> medals;

  Map<String, dynamic> toJson() => {
        'user': user.toJson(),
        'isGuest': isGuest,
        'mistakes': mistakes.map((item) => item.toJson()).toList(),
        'activeRoom': activeRoom?.toJson(),
        'unlockedShopItemIds': unlockedShopItemIds,
        'shopItems': shopItems.map((item) => item.toJson()).toList(),
        'cardPackages': cardPackages.map((item) => item.toJson()).toList(),
        'books': books.map((item) => item.toJson()).toList(),
        'medals': medals.map((item) => item.toJson()).toList(),
      };

  factory LocalAppSnapshot.fromJson(Map<String, dynamic> json) {
    return LocalAppSnapshot(
      user: AppUser.fromJson(Map<String, dynamic>.from(json['user'] as Map? ?? {})),
      isGuest: json['isGuest'] == true,
      mistakes: (json['mistakes'] as List? ?? [])
          .whereType<Map>()
          .map((item) => MyMistake.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
      activeRoom: json['activeRoom'] is Map ? QuizRoom.fromJson(Map<String, dynamic>.from(json['activeRoom'] as Map)) : null,
      unlockedShopItemIds: (json['unlockedShopItemIds'] as List? ?? []).map((item) => item.toString()).toList(),
      shopItems: (json['shopItems'] as List? ?? []).whereType<Map>().map((item) => ShopItem.fromJson(Map<String, dynamic>.from(item))).toList(),
      cardPackages: (json['cardPackages'] as List? ?? const []).whereType<Map>().map((item) => CardPackage.fromJson(Map<String, dynamic>.from(item))).toList().isEmpty
          ? List<CardPackage>.of(kDefaultCardPackages)
          : (json['cardPackages'] as List).whereType<Map>().map((item) => CardPackage.fromJson(Map<String, dynamic>.from(item))).toList(),
      books: (json['books'] as List? ?? []).whereType<Map>().map((item) => LearningBook.fromJson(Map<String, dynamic>.from(item))).toList(),
      medals: (json['medals'] as List? ?? []).whereType<Map>().map((item) => GaminoMedalItem.fromJson(Map<String, dynamic>.from(item))).toList(),
    );
  }
}

class LocalSaveService {
  static const String _key = 'gamino_v84_offline_snapshot';

  static Future<void> saveSnapshot(LocalAppSnapshot snapshot) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(snapshot.toJson()));
  }

  static Future<LocalAppSnapshot?> loadSnapshot() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return null;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return null;
      return LocalAppSnapshot.fromJson(Map<String, dynamic>.from(decoded));
    } catch (_) {
      return null;
    }
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}

class GaminoMedalsScreen extends StatefulWidget {
  const GaminoMedalsScreen({super.key, required this.user, required this.medals, this.title = 'مدال‌های من'});
  final AppUser user;
  final List<GaminoMedalItem> medals;
  final String title;

  @override
  State<GaminoMedalsScreen> createState() => _GaminoMedalsScreenState();
}

class _GaminoMedalsScreenState extends State<GaminoMedalsScreen> {
  List<GaminoMedalItem> get _visible => List<GaminoMedalItem>.of(widget.medals)
    ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));

  @override
  Widget build(BuildContext context) {
    final total = widget.medals.length;
    final unlocked = widget.medals.where((item) => item.isUnlocked).length;
    final overall = total == 0 ? 0.0 : unlocked / total;
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),
      appBar: AppBar(automaticallyImplyLeading: true, title: Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w900)), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0xFFE9EAF2))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(children: [
                  Container(width: 56, height: 56, decoration: BoxDecoration(color: const Color(0xFFFFF5CC), borderRadius: BorderRadius.circular(18)), child: const Icon(Icons.workspace_premium_rounded, size: 34, color: Color(0xFFF4A900))),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${faNumber(unlocked)} از ${faNumber(total)} مدال', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppPalette.ink)),
                    const SizedBox(height: 4),
                    const Text('پیشرفت کلی مدال‌ها', style: TextStyle(fontWeight: FontWeight.w700, color: AppPalette.muted)),
                  ])),
                  Text('${faNumber((overall * 100).round())}٪', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppPalette.secondary)),
                ]),
                const SizedBox(height: 14),
                ClipRRect(borderRadius: BorderRadius.circular(999), child: LinearProgressIndicator(value: overall, minHeight: 10, backgroundColor: const Color(0xFFEDEEF4), valueColor: const AlwaysStoppedAnimation<Color>(AppPalette.secondary))),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (widget.medals.isEmpty)
            const Card(child: Padding(padding: EdgeInsets.all(24), child: Text('هنوز مدالی از پنل مدیریت منتشر نشده است.', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted))))
          else
            ..._visible.map((item) => _GaminoMedalListCard(item: item)),
        ],
      ),
    );
  }
}

class _GaminoMedalListCard extends StatelessWidget {
  const _GaminoMedalListCard({required this.item});
  final GaminoMedalItem item;

  Widget _icon() {
    if (item.iconUrl.trim().isNotEmpty) {
      return Image.network(item.iconUrl, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.workspace_premium_rounded, size: 46, color: AppPalette.secondary));
    }
    return const Icon(Icons.workspace_premium_rounded, size: 46, color: AppPalette.secondary);
  }

  @override
  Widget build(BuildContext context) {
    final inProgress = !item.isUnlocked && item.progress > 0;
    final status = item.isUnlocked ? 'تکمیل شد' : inProgress ? 'در حال پیشرفت' : 'قفل';
    final statusColor = item.isUnlocked ? const Color(0xFF16A34A) : inProgress ? AppPalette.secondary : AppPalette.muted;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: item.isUnlocked ? const Color(0xFFFFFDF4) : Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: item.isUnlocked ? const Color(0xFFFFE7A3) : const Color(0xFFE9EAF2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 74, height: 74, child: _icon()),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(children: [
                  Expanded(child: Text(item.title, textAlign: TextAlign.right, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: AppPalette.ink))),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    decoration: BoxDecoration(color: statusColor.withOpacity(.10), borderRadius: BorderRadius.circular(999)),
                    child: Text(status, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w900, color: statusColor)),
                  ),
                ]),
                if (item.description.trim().isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(item.description, textAlign: TextAlign.right, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, height: 1.55, fontWeight: FontWeight.w700, color: AppPalette.muted)),
                ],
                const SizedBox(height: 10),
                ClipRRect(borderRadius: BorderRadius.circular(999), child: LinearProgressIndicator(value: item.progressValue, minHeight: 8, backgroundColor: const Color(0xFFEDEEF4), valueColor: AlwaysStoppedAnimation<Color>(statusColor))),
                const SizedBox(height: 7),
                Row(children: [
                  Text('${faNumber(item.progress)}/${faNumber(item.target)}', style: TextStyle(fontWeight: FontWeight.w900, color: statusColor)),
                  const Spacer(),
                  Text('${faNumber(item.percent)}٪', style: const TextStyle(fontWeight: FontWeight.w800, color: AppPalette.muted)),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AppUser {
  AppUser({
    this.id = '',
    required this.name,
    required this.grade,
    required this.phone,
    required this.password,
    required this.level,
    required this.xp,
    required this.bestXp,
    this.cupsByGrade = const {},
    this.bestCupsByGrade = const {},
    required this.coins,
    required this.matchesCount,
    required this.wins,
    required this.winStreak,
    required this.completedChapters,
    required this.dailyActivity,
    required this.skills,
    required this.medals,
    required this.studyTasks,
    required this.quizHistory,
    required this.avatar,
    this.avatarUrl = '',
    required this.profileFrame,
    required this.themeName,
    required this.noAdsPurchased,
    this.educationTrack = '',
    this.themeMode = 'light',
    this.noAdsUntil,
    this.studySeconds = 0,
    this.studyByBook = const {},
    this.profileLikes = 0,
    this.bio = '',
    this.levelProgress = 0,
    this.levelStartSeconds = 0,
    this.levelNextSeconds = 600,
    this.lastLevelNotified = 1,
  });

  String id;
  String name;
  int grade;
  String educationTrack;
  String themeMode;
  String phone;
  String password;
  int level;
  int xp;
  int bestXp;
  Map<int, int> cupsByGrade;
  Map<int, int> bestCupsByGrade;
  int coins;
  int matchesCount;
  int wins;
  int winStreak;
  int completedChapters;
  int dailyActivity;
  Map<String, int> skills;
  List<String> medals;
  List<StudyTask> studyTasks;
  List<QuizHistoryEntry> quizHistory;
  String avatar;
  String avatarUrl;
  String profileFrame;
  String themeName;
  bool noAdsPurchased;
  DateTime? noAdsUntil;
  int studySeconds;
  Map<String, int> studyByBook;
  int profileLikes;
  String bio;
  double levelProgress;
  int levelStartSeconds;
  int levelNextSeconds;
  int lastLevelNotified;

  bool get hasActiveNoAds {
    if (noAdsUntil != null) {
      return noAdsUntil!.isAfter(DateTime.now());
    }
    return noAdsPurchased;
  }

  factory AppUser.guest({int grade = 7, String track = ''}) {
    return AppUser(
      name: 'مهمان',
      grade: grade,
      educationTrack: normalizeEducationTrack(grade, track),
      phone: '',
      password: '',
      level: 1,
      xp: 0,
      bestXp: 0,
      coins: 0,
      matchesCount: 0,
      wins: 0,
      winStreak: 0,
      completedChapters: 0,
      dailyActivity: 0,
      skills: const {},
      medals: [],
      studyTasks: [],
      quizHistory: [],
      avatar: 'دانش‌آموز ساده پسر',
      profileFrame: 'قاب ساده',
      themeName: 'تم پیش‌فرض',
      noAdsPurchased: false,
      noAdsUntil: null,
      studySeconds: 0,
    );
  }

  factory AppUser.student({required String name, required int grade, String phone = '', String password = ''}) {
    return AppUser(
      name: name,
      grade: grade,
      phone: phone,
      password: password,
      level: 1,
      xp: 0,
      bestXp: 0,
      coins: 80,
      matchesCount: 0,
      wins: 0,
      winStreak: 0,
      completedChapters: 0,
      dailyActivity: 0,
      skills: const {},
      medals: const [],
      studyTasks: const [],
      quizHistory: [],
      avatar: '',
      profileFrame: 'قاب ساده',
      themeName: 'تم پیش‌فرض',
      noAdsPurchased: false,
      noAdsUntil: null,
      studySeconds: 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'grade': grade,
      'track': educationTrack,
      'themeMode': themeMode,
      'phone': phone,
      'password': password,
      'level': level,
      'xp': xp,
      'bestXp': bestXp,
      'cupsByGrade': cupsByGrade.map((key, value) => MapEntry(key.toString(), value)),
      'bestCupsByGrade': bestCupsByGrade.map((key, value) => MapEntry(key.toString(), value)),
      'coins': coins,
      'matchesCount': matchesCount,
      'wins': wins,
      'winStreak': winStreak,
      'completedChapters': completedChapters,
      'dailyActivity': dailyActivity,
      'skills': skills,
      'medals': medals,
      'studyTasks': studyTasks.map((task) => task.toJson()).toList(),
      'quizHistory': quizHistory.map((item) => item.toJson()).toList(),
      'avatar': avatar,
      'avatarUrl': avatarUrl,
      'profileFrame': profileFrame,
      'themeName': themeName,
      'noAdsPurchased': hasActiveNoAds,
      'noAdsUntil': noAdsUntil?.toIso8601String(),
      'studySeconds': studySeconds,
      'studyByBook': studyByBook,
      'profileLikes': profileLikes,
      'bio': bio,
      'levelProgress': levelProgress,
      'levelStartSeconds': levelStartSeconds,
      'levelNextSeconds': levelNextSeconds,
      'lastLevelNotified': lastLevelNotified,
    };
  }

  factory AppUser.fromJson(Map<String, dynamic> json) {
    final skillsValue = json['skills'];
    final studyByBookValue = json['studyByBook'];
    final cupsByGradeValue = json['cupsByGrade'];
    final bestCupsByGradeValue = json['bestCupsByGrade'];
    final rawSkills = skillsValue is Map ? Map<String, dynamic>.from(skillsValue) : <String, dynamic>{};
    final rawStudyByBook = studyByBookValue is Map ? Map<String, dynamic>.from(studyByBookValue) : <String, dynamic>{};
    final rawCupsByGrade = cupsByGradeValue is Map ? Map<String, dynamic>.from(cupsByGradeValue) : <String, dynamic>{};
    final rawBestCupsByGrade = bestCupsByGradeValue is Map ? Map<String, dynamic>.from(bestCupsByGradeValue) : <String, dynamic>{};
    final rawNoAdsUntil = json['noAdsUntil']?.toString();
    final parsedNoAdsUntil = rawNoAdsUntil == null || rawNoAdsUntil.isEmpty ? null : DateTime.tryParse(rawNoAdsUntil);
    final legacyNoAds = json['noAdsPurchased'] == true && parsedNoAdsUntil == null;
    return AppUser(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? 'دانش‌آموز',
      grade: (json['grade'] as num?)?.toInt() ?? 7,
      educationTrack: normalizeEducationTrack((json['grade'] as num?)?.toInt() ?? 7, json['track']?.toString() ?? ''),
      themeMode: json['themeMode']?.toString() == 'dark' ? 'dark' : 'light',
      phone: json['phone']?.toString() ?? '',
      password: json['password']?.toString() ?? '',
      level: (json['level'] as num?)?.toInt() ?? 1,
      xp: (json['xp'] as num?)?.toInt() ?? 0,
      bestXp: (json['bestXp'] as num?)?.toInt() ?? (json['xp'] as num?)?.toInt() ?? 0,
      cupsByGrade: rawCupsByGrade.map((key, value) => MapEntry(int.tryParse(key) ?? 0, max(0, (value as num?)?.toInt() ?? 0)))..remove(0),
      bestCupsByGrade: rawBestCupsByGrade.map((key, value) => MapEntry(int.tryParse(key) ?? 0, max(0, (value as num?)?.toInt() ?? 0)))..remove(0),
      coins: (json['coins'] as num?)?.toInt() ?? 0,
      matchesCount: (json['matchesCount'] as num?)?.toInt() ?? 0,
      wins: (json['wins'] as num?)?.toInt() ?? 0,
      winStreak: (json['winStreak'] as num?)?.toInt() ?? 0,
      completedChapters: (json['completedChapters'] as num?)?.toInt() ?? 0,
      dailyActivity: (json['dailyActivity'] as num?)?.toInt() ?? 0,
      skills: rawSkills.map((key, value) => MapEntry(key, (value as num?)?.toInt() ?? 0)),
      medals: (json['medals'] as List? ?? []).map((item) => item.toString()).toList(),
      studyTasks: (json['studyTasks'] as List? ?? [])
          .whereType<Map>()
          .map((item) => StudyTask.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
      quizHistory: (json['quizHistory'] as List? ?? [])
          .whereType<Map>()
          .map((item) => QuizHistoryEntry.fromJson(Map<String, dynamic>.from(item)))
          .toList(),
      avatar: json['avatar']?.toString() ?? '',
      avatarUrl: json['avatarUrl']?.toString() ?? '',
      profileFrame: json['profileFrame']?.toString() ?? 'قاب ساده',
      themeName: json['themeName']?.toString() ?? 'تم پیش‌فرض',
      noAdsPurchased: (parsedNoAdsUntil?.isAfter(DateTime.now()) == true) || legacyNoAds,
      noAdsUntil: parsedNoAdsUntil ?? (legacyNoAds ? DateTime.now().add(const Duration(days: 90)) : null),
      studySeconds: (json['studySeconds'] as num?)?.toInt() ?? 0,
      studyByBook: rawStudyByBook.map((key, value) => MapEntry(key, max(0, (value as num?)?.toInt() ?? 0))),
      profileLikes: max(0, (json['profileLikes'] as num?)?.toInt() ?? 0),
      bio: json['bio']?.toString() ?? '',
      levelProgress: ((json['levelProgress'] as num?)?.toDouble() ?? 0.0).clamp(0.0, 1.0).toDouble(),
      levelStartSeconds: max(0, (json['levelStartSeconds'] as num?)?.toInt() ?? 0),
      levelNextSeconds: max(0, (json['levelNextSeconds'] as num?)?.toInt() ?? 600),
      lastLevelNotified: max(1, (json['lastLevelNotified'] as num?)?.toInt() ?? (json['level'] as num?)?.toInt() ?? 1),
    );
  }
}

class Subject {
  const Subject({required this.grade, required this.title, required this.chapters});

  final int grade;
  final String title;
  final List<Chapter> chapters;
}

class Chapter {
  const Chapter({required this.title, required this.summary, required this.lesson, required this.sampleQuestion, required this.answer});

  final String title;
  final String summary;
  final String lesson;
  final String sampleQuestion;
  final String answer;
}

class QuizQuestion {
  const QuizQuestion({
    required this.id,
    required this.grade,
    this.track = '',
    required this.subject,
    required this.chapter,
    required this.text,
    required this.options,
    required this.correctIndex,
    required this.explanation,
  });

  final String id;
  final int grade;
  final String track;
  final String subject;
  final String chapter;
  final String text;
  final List<String> options;
  final int correctIndex;
  final String explanation;

  Map<String, dynamic> toJson() => {
        'id': id,
        'grade': grade,
        'track': track,
        'subject': subject,
        'chapter': chapter,
        'text': text,
        'options': options,
        'correctIndex': correctIndex,
        'explanation': explanation,
      };

  factory QuizQuestion.fromJson(Map<String, dynamic> json) {
    final options = (json['options'] as List? ?? []).map((item) => item.toString()).where((item) => item.trim().isNotEmpty).take(4).toList();
    while (options.length < 4) { options.add('گزینه ${options.length + 1}'); }
    final grade = (json['grade'] as num?)?.toInt() ?? 1;
    return QuizQuestion(
      id: json['id']?.toString() ?? 'q_${DateTime.now().microsecondsSinceEpoch}',
      grade: grade,
      track: normalizeEducationTrack(grade, json['track']?.toString() ?? ''),
      subject: json['subject']?.toString() ?? 'عمومی',
      chapter: json['chapter']?.toString() ?? 'درس',
      text: json['text']?.toString() ?? 'سوال',
      options: options,
      correctIndex: ((json['correctIndex'] as num?)?.toInt() ?? 0).clamp(0, 3).toInt(),
      explanation: json['explanation']?.toString() ?? '',
    );
  }
}

class WrongAnswer {
  const WrongAnswer({required this.question, required this.selectedIndex});

  final QuizQuestion question;
  final int selectedIndex;
}

class MyMistake {
  MyMistake({
    required this.question,
    required this.lastSelectedIndex,
    this.repeatCount = 1,
    DateTime? lastSeen,
  }) : lastSeen = lastSeen ?? DateTime.now();

  final QuizQuestion question;
  int lastSelectedIndex;
  int repeatCount;
  DateTime lastSeen;

  Map<String, dynamic> toJson() => {
        'questionId': question.id,
        'lastSelectedIndex': lastSelectedIndex,
        'repeatCount': repeatCount,
        'lastSeen': lastSeen.toIso8601String(),
      };

  factory MyMistake.fromJson(Map<String, dynamic> json) {
    final rawQuestion = json['question'];
    if (rawQuestion is! Map) throw const FormatException('Missing remote question data');
    final question = QuizQuestion.fromJson(Map<String, dynamic>.from(rawQuestion));
    return MyMistake(
      question: question,
      lastSelectedIndex: (json['lastSelectedIndex'] as num?)?.toInt() ?? -1,
      repeatCount: (json['repeatCount'] as num?)?.toInt() ?? 1,
      lastSeen: DateTime.tryParse(json['lastSeen']?.toString() ?? ''),
    );
  }
}

class QuizResult {
  const QuizResult({
    required this.questions,
    required this.correctAnswers,
    required this.totalQuestions,
    required this.xpEarned,
    required this.coinsEarned,
    required this.wrongAnswers,
    required this.answers,
    this.isCompetitive = false,
    this.quizSource = 'standard',
    this.roomCode,
    this.startingCups,
    this.opponentName,
    this.opponentCups,
  });

  final List<QuizQuestion> questions;
  final int correctAnswers;
  final int totalQuestions;
  final int xpEarned;
  final int coinsEarned;
  final List<WrongAnswer> wrongAnswers;
  final Map<String, int> answers;
  final bool isCompetitive;
  final String quizSource;
  final String? roomCode;
  final int? startingCups;
  final String? opponentName;
  final int? opponentCups;

  QuizResult copyWith({int? xpEarned}) {
    return QuizResult(
      questions: questions,
      correctAnswers: correctAnswers,
      totalQuestions: totalQuestions,
      xpEarned: xpEarned ?? this.xpEarned,
      coinsEarned: coinsEarned,
      wrongAnswers: wrongAnswers,
      answers: answers,
      isCompetitive: isCompetitive,
      quizSource: quizSource,
      roomCode: roomCode,
      startingCups: startingCups,
      opponentName: opponentName,
      opponentCups: opponentCups,
    );
  }
}

class QuizHistoryEntry {
  const QuizHistoryEntry({
    this.id = '',
    required this.title,
    required this.subject,
    required this.correctAnswers,
    required this.totalQuestions,
    required this.percent,
    required this.xpEarned,
    required this.coinsEarned,
    required this.createdAt,
  });

  final String id;
  final String title;
  final String subject;
  final int correctAnswers;
  final int totalQuestions;
  final int percent;
  final int xpEarned;
  final int coinsEarned;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'subject': subject,
        'correctAnswers': correctAnswers,
        'totalQuestions': totalQuestions,
        'percent': percent,
        'xpEarned': xpEarned,
        'coinsEarned': coinsEarned,
        'createdAt': createdAt.toIso8601String(),
      };

  factory QuizHistoryEntry.fromJson(Map<String, dynamic> json) {
    return QuizHistoryEntry(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'کوییز',
      subject: json['subject']?.toString() ?? 'عمومی',
      correctAnswers: (json['correctAnswers'] as num?)?.toInt() ?? 0,
      totalQuestions: (json['totalQuestions'] as num?)?.toInt() ?? 0,
      percent: (json['percent'] as num?)?.toInt() ?? 0,
      xpEarned: (json['xpEarned'] as num?)?.toInt() ?? 0,
      coinsEarned: (json['coinsEarned'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.tryParse(json['createdAt']?.toString() ?? '') ?? DateTime.now(),
    );
  }
}

class QuizRoom {
  const QuizRoom({required this.code, required this.link, required this.maxPlayers, required this.roomType, required this.players, this.scoreboard = const []});

  final String code;
  final String link;
  final int maxPlayers;
  final String roomType;
  final List<String> players;
  final List<LeaderRow> scoreboard;

  Map<String, dynamic> toJson() => {
        'code': code,
        'link': link,
        'maxPlayers': maxPlayers,
        'roomType': roomType,
        'players': players,
        'scoreboard': scoreboard.map((row) => {'rank': row.rank, 'name': row.name, 'score': row.xp}).toList(),
      };

  factory QuizRoom.fromJson(Map<String, dynamic> json) {
    return QuizRoom(
      code: json['code']?.toString() ?? '0000',
      link: json['link']?.toString() ?? '',
      maxPlayers: (json['maxPlayers'] as num?)?.toInt() ?? 2,
      roomType: json['roomType']?.toString() ?? 'دو نفره',
      players: (json['players'] as List? ?? []).map((item) => item.toString()).toList(),
      scoreboard: (json['scoreboard'] as List? ?? []).whereType<Map>().map((item) {
        final row = Map<String, dynamic>.from(item);
        return LeaderRow(rank: (row['rank'] as num?)?.toInt() ?? 0, name: row['name']?.toString() ?? 'دانش‌آموز', grade: 0, xp: (row['score'] as num?)?.toInt() ?? 0);
      }).toList(),
    );
  }
}

class StudyTask {
  StudyTask({this.id = '', required this.title, required this.subject, required this.timeLabel, this.reminderAt = '', this.isDone = false});

  final String id;
  final String title;
  final String subject;
  final String timeLabel;
  final String reminderAt;
  bool isDone;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'subject': subject,
        'timeLabel': timeLabel,
        'reminderAt': reminderAt,
        'isDone': isDone,
      };

  factory StudyTask.fromJson(Map<String, dynamic> json) {
    return StudyTask(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'برنامه مطالعه',
      subject: json['subject']?.toString() ?? 'عمومی',
      timeLabel: json['timeLabel']?.toString() ?? 'امروز',
      reminderAt: json['reminderAt']?.toString() ?? '',
      isDone: json['isDone'] == true,
    );
  }
}

enum ShopItemType { avatar, frame, theme }

class ShopItem {
  ShopItem({
    required this.id,
    required this.title,
    required this.type,
    required this.price,
    this.requiredLevel = 1,
    this.icon = Icons.face_rounded,
    this.imageUrl = '',
    this.updatedAt = '',
    this.sortOrder = 0,
    this.isUnlocked = false,
  });

  final String id;
  final String title;
  final ShopItemType type;
  final int price;
  final int requiredLevel;
  final IconData icon;
  final String imageUrl;
  final String updatedAt;
  final int sortOrder;
  bool isUnlocked;

  factory ShopItem.fromJson(Map<String, dynamic> json) {
    final typeName = json['type']?.toString() ?? 'avatar';
    return ShopItem(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'آواتار',
      type: typeName == 'frame' ? ShopItemType.frame : typeName == 'theme' ? ShopItemType.theme : ShopItemType.avatar,
      price: max(0, (json['price'] as num?)?.toInt() ?? 0),
      requiredLevel: max(1, (json['requiredLevel'] as num?)?.toInt() ?? 1),
      imageUrl: json['imageUrl']?.toString() ?? '',
      updatedAt: json['updatedAt']?.toString() ?? '',
      sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
      isUnlocked: json['isUnlocked'] == true,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'type': type.name,
        'price': price,
        'requiredLevel': requiredLevel,
        'imageUrl': imageUrl,
        'updatedAt': updatedAt,
        'sortOrder': sortOrder,
        'isUnlocked': isUnlocked,
      };

  ShopItem copy() {
    return ShopItem(
      id: id,
      title: title,
      type: type,
      price: price,
      requiredLevel: requiredLevel,
      icon: icon,
      imageUrl: imageUrl,
      updatedAt: updatedAt,
      sortOrder: sortOrder,
      isUnlocked: isUnlocked,
    );
  }
}

class LeaderRow {
  const LeaderRow({this.userId = '', required this.rank, required this.name, required this.grade, required this.xp, this.avatar = '', this.avatarUrl = ''});

  final String userId;
  final int rank;
  final String name;
  final int grade;
  final int xp;
  final String avatar;
  final String avatarUrl;
}

class MockData {}
