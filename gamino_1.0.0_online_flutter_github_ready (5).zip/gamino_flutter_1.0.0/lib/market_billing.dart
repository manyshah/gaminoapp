// This file is generated for the selected market by scripts/select_market_iap.py.
// The repository/source ZIP keeps this stub so neither Bazaar nor Myket billing
// plugin is pulled into Android until the workflow explicitly selects a market.

const String gaminoMarket = 'unsupported';
const String gaminoMarketRsaKey = '';

const Map<int, String> gaminoCardProductIds = <int, String>{
  50: 'gamino_cards_50',
  100: 'gamino_cards_100',
  300: 'gamino_cards_300',
};

class GaminoStorePurchase {
  const GaminoStorePurchase({
    required this.market,
    required this.productId,
    required this.purchaseToken,
    required this.orderId,
    required this.packageName,
    required this.originalJson,
    required this.signature,
    required this.developerPayload,
    this.nativePurchase,
  });

  final String market;
  final String productId;
  final String purchaseToken;
  final String orderId;
  final String packageName;
  final String originalJson;
  final String signature;
  final String developerPayload;
  final Object? nativePurchase;

  Map<String, dynamic> toClaimJson() => <String, dynamic>{
        'market': market,
        'productId': productId,
        'purchaseToken': purchaseToken,
        'orderId': orderId,
        'packageName': packageName,
        'originalJson': originalJson,
        'signature': signature,
        'developerPayload': developerPayload,
      };
}

class GaminoMarketBillingException implements Exception {
  const GaminoMarketBillingException(this.message);
  final String message;
  @override
  String toString() => message;
}

class GaminoMarketBillingCancelled implements Exception {
  const GaminoMarketBillingCancelled();
}

class GaminoMarketBillingBusyException implements Exception {
  const GaminoMarketBillingBusyException();
}

class GaminoMarketBillingService {
  static bool get isBazaar => false;
  static bool get isMyket => false;
  static bool get isSupportedBuild => false;
  static String get marketLabel => 'مارکت';

  static Future<void> ensureReady() async => _unsupported();
  static Future<GaminoStorePurchase> purchase({required String productId, required String developerPayload}) async => _unsupported();
  static Future<List<GaminoStorePurchase>> pendingPurchases() async => _unsupported();
  static Future<void> consume(GaminoStorePurchase purchase) async => _unsupported();
  static Future<void> dispose() async {}

  static Never _unsupported() => throw const GaminoMarketBillingException(
        'بیلد مارکت انتخاب نشده است. برنامه باید از Workflow بازار/مایکت ساخته شود.',
      );
}
