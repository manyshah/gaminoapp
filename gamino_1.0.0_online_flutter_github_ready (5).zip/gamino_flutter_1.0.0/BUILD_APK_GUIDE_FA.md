# ساخت خروجی‌های Android گامینو 1.0.0

نسخه برنامه: `1.0.0+1`

Workflow گیت‌هاب `build-gamino-markets.yml` باید در مسیر `.github/workflows/` قرار بگیرد. این Workflow از ZIP سورس با هر نامی، یک Codebase مشترک را تشخیص می‌دهد و دقیقاً سه خروجی Release امضاشده می‌سازد:

1. `gamino-1.0.0-bazaar.apk`
2. `gamino-1.0.0-bazaar.aab`
3. `gamino-1.0.0-myket.apk`

## تنظیمات Build

- Flutter: `3.29.3`
- Gradle Wrapper: `8.7`
- Android Gradle Plugin: `8.6.0`
- Kotlin: `2.1.10`
- Java: `21`
- compileSdk: `36`
- Version Name: `1.0.0`
- Version Code: `1`

## Flavorها

- `bazaar`: ثبت نظر و خرید کارت فقط از کافه‌بازار.
- `myket`: ثبت نظر و خرید کارت فقط از مایکت.

Workflow قبل از Build با `scripts/select_market_iap.py` فقط Plugin پرداخت همان مارکت را فعال می‌کند؛ بنابراین Poolakey و Myket IAP هیچ‌وقت هم‌زمان در یک Android Build حضور ندارند. سپس کلید عمومی RSA متناظر همان مارکت با `--dart-define` وارد همان Build می‌شود.

## محصولات Consumable

- `gamino_cards_50` → ۵۰ کارت
- `gamino_cards_100` → ۱۰۰ کارت
- `gamino_cards_300` → ۳۰۰ کارت

## کنترل‌های CI

- Android SDK 36 آماده می‌شود.
- `scripts/prepare_android.py` تنظیمات Flavor، Java 21، Adivery، Firebase، ثبت نظر و Repository موردنیاز Poolakey را Verify می‌کند.
- برای Bazaar ابتدا فقط `flutter_poolakey` فعال و `flutter pub get` اجرا می‌شود؛ برای Myket فقط `myket_iap` فعال و `flutter pub get` دوباره اجرا می‌شود.
- فایل `.flutter-plugins-dependencies` قبل از هر Build بررسی می‌شود تا Plugin مارکت مقابل حضور نداشته باشد.
- `flutter analyze --no-fatal-infos --no-fatal-warnings` اجرا می‌شود.
- Buildها بدون Minify/Shrink انجام می‌شوند.
- در پایان Workflow تعداد فایل‌های پوشه Artifact باید دقیقاً ۳ باشد؛ در غیر این صورت Build Fail می‌شود.

## اصلاح جداسازی Analyzer برای پرداخت مارکت‌ها
Templateهای پرداخت بازار و مایکت خارج از پوشه `lib/` نگهداری می‌شوند. اسکریپت `scripts/select_market_iap.py` قبل از هر Build فقط implementation مارکت فعال را به `lib/market_billing.dart` کپی می‌کند. بنابراین `flutter analyze` هیچ‌وقت فایل مارکت غیرفعال را با dependency حذف‌شده تحلیل نمی‌کند.
