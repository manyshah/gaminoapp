# Adivery, Firebase and the selected market IAP plugin use bundled consumer rules.
