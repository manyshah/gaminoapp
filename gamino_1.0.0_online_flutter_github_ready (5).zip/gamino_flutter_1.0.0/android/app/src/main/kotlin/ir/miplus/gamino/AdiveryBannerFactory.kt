package ir.miplus.gamino

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.adivery.sdk.AdiveryAdListener
import com.adivery.sdk.AdiveryBannerAdView
import com.adivery.sdk.BannerSize
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory

class AdiveryBannerFactory(private val messenger: BinaryMessenger) : PlatformViewFactory(StandardMessageCodec.INSTANCE) {
    companion object {
        const val VIEW_TYPE = "ir.miplus.gamino/adivery_banner"
    }

    override fun create(context: Context, viewId: Int, args: Any?): PlatformView =
        AdiveryBannerView(context, viewId, messenger, args)
}

private class AdiveryBannerView(
    context: Context,
    viewId: Int,
    messenger: BinaryMessenger,
    args: Any?,
) : PlatformView {
    private val layout = LinearLayout(context)
    private val channel = MethodChannel(messenger, "ir.miplus.gamino/adivery_banner/$viewId")
    private val placementId = ((args as? Map<*, *>)?.get("placementId") as? String).orEmpty()
    private var adView: AdiveryBannerAdView? = null
    private var started = false

    init {
        channel.setMethodCallHandler { call, result ->
            if (call.method == "load") {
                if (!started) {
                    started = true
                    requestAd()
                }
                result.success(true)
            } else {
                result.notImplemented()
            }
        }
    }

    private fun requestAd() {
        if (placementId.isBlank()) {
            channel.invokeMethod("onError", "placement_missing")
            return
        }
        try {
            val banner = AdiveryBannerAdView(layout.context)
            banner.setPlacementId(placementId)
            banner.setBannerSize(BannerSize.LARGE_BANNER)
            banner.setBannerAdListener(object : AdiveryAdListener() {
                override fun onAdLoaded() {
                    channel.invokeMethod("onLoaded", null)
                }

                override fun onAdClicked() {
                    channel.invokeMethod("onClicked", null)
                }

                override fun onError(reason: String) {
                    channel.invokeMethod("onError", reason)
                }
            })
            banner.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
            adView = banner
            layout.removeAllViews()
            layout.addView(banner)
            banner.loadAd()
        } catch (error: Throwable) {
            channel.invokeMethod("onError", error.message ?: "banner_error")
        }
    }

    override fun getView(): View = layout

    override fun dispose() {
        channel.setMethodCallHandler(null)
        layout.removeAllViews()
        adView = null
    }
}
