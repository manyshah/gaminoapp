package ir.miplus.gamino

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean

object GaminoPushReporter {
    private const val PREFS = "gamino_push_tracking_v1"
    private const val KEY_PENDING = "pending_events"
    private val flushing = AtomicBoolean(false)
    private val lock = Any()

    fun recordEvent(
        context: Context,
        eventUrl: String,
        deliveryId: String,
        trackingToken: String,
        event: String,
    ) {
        if (eventUrl.isBlank() || deliveryId.isBlank() || trackingToken.isBlank()) return
        if (event != "displayed" && event != "click") return
        val raw = JSONObject()
            .put("eventUrl", eventUrl)
            .put("deliveryId", deliveryId)
            .put("trackingToken", trackingToken)
            .put("event", event)
            .toString()
        val appContext = context.applicationContext
        synchronized(lock) {
            val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val next = (prefs.getStringSet(KEY_PENDING, emptySet()) ?: emptySet()).toMutableSet()
            next.add(raw)
            while (next.size > 500) next.remove(next.first())
            prefs.edit().putStringSet(KEY_PENDING, next).apply()
        }
        flushAsync(appContext)
    }

    fun flushAsync(context: Context) {
        val appContext = context.applicationContext
        if (!flushing.compareAndSet(false, true)) return
        Thread {
            try {
                flush(appContext)
            } finally {
                flushing.set(false)
            }
        }.start()
    }

    private fun flush(context: Context) {
        val snapshot = synchronized(lock) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            (prefs.getStringSet(KEY_PENDING, emptySet()) ?: emptySet()).toList()
        }
        for (raw in snapshot) {
            val item = try { JSONObject(raw) } catch (_: Throwable) {
                remove(context, raw)
                continue
            }
            val eventUrl = item.optString("eventUrl")
            val payload = JSONObject()
                .put("deliveryId", item.optString("deliveryId"))
                .put("trackingToken", item.optString("trackingToken"))
                .put("event", item.optString("event"))
                .toString()
            if (eventUrl.isBlank()) {
                remove(context, raw)
                continue
            }
            if (postJson(eventUrl, payload)) remove(context, raw)
        }
    }

    private fun remove(context: Context, raw: String) {
        synchronized(lock) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val next = (prefs.getStringSet(KEY_PENDING, emptySet()) ?: emptySet()).toMutableSet()
            next.remove(raw)
            prefs.edit().putStringSet(KEY_PENDING, next).apply()
        }
    }

    private fun postJson(url: String, body: String): Boolean {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8_000
                readTimeout = 8_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            val bytes = body.toByteArray(StandardCharsets.UTF_8)
            connection.outputStream.use { it.write(bytes) }
            val status = connection.responseCode
            status in 200..299
        } catch (_: Throwable) {
            false
        } finally {
            connection?.disconnect()
        }
    }
}
