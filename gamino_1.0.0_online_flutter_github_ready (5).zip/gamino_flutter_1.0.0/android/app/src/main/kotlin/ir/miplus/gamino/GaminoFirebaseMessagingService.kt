package ir.miplus.gamino

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class GaminoFirebaseMessagingService : FirebaseMessagingService() {
    companion object {
        const val ACTION_OPEN = "ir.miplus.gamino.PUSH_OPEN"
        const val EXTRA_EVENT_URL = "gamino_event_url"
        const val EXTRA_DELIVERY_ID = "gamino_delivery_id"
        const val EXTRA_TRACKING_TOKEN = "gamino_tracking_token"
        const val EXTRA_DESTINATION_TYPE = "gamino_destination_type"
        const val EXTRA_DESTINATION_URL = "gamino_destination_url"
        private const val CHANNEL_ID = "gamino_real_push"
        private const val CHANNEL_NAME = "اعلان‌های گامینو"
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val data = message.data
        if (data["gaminoPush"] != "1") return
        val title = data["title"].orEmpty().trim()
        val body = data["body"].orEmpty().trim()
        val eventUrl = data["eventUrl"].orEmpty().trim()
        val deliveryId = data["deliveryId"].orEmpty().trim()
        val trackingToken = data["trackingToken"].orEmpty().trim()
        val destinationType = data["destinationType"].orEmpty().ifBlank { "app" }
        val destinationUrl = data["destinationUrl"].orEmpty().trim()
        if (title.isEmpty() || body.isEmpty() || deliveryId.isEmpty() || trackingToken.isEmpty()) return

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
                description = "اعلان‌های واقعی ارسال‌شده از گامینو"
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !manager.areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.getNotificationChannel(CHANNEL_ID)?.importance == NotificationManager.IMPORTANCE_NONE) return

        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_OPEN
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_EVENT_URL, eventUrl)
            putExtra(EXTRA_DELIVERY_ID, deliveryId)
            putExtra(EXTRA_TRACKING_TOKEN, trackingToken)
            putExtra(EXTRA_DESTINATION_TYPE, destinationType)
            putExtra(EXTRA_DESTINATION_URL, destinationUrl)
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            deliveryId.hashCode(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        builder
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            @Suppress("DEPRECATION")
            builder.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
        }

        manager.notify(deliveryId.hashCode() and 0x7fffffff, builder.build())
        GaminoPushReporter.recordEvent(this, eventUrl, deliveryId, trackingToken, "displayed")
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        getSharedPreferences("gamino_push_native_v1", MODE_PRIVATE).edit().putString("latest_fcm_token", token).apply()
        GaminoPushReporter.flushAsync(this)
    }
}
