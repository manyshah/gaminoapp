package ir.miplus.gamino;

import androidx.fragment.app.FragmentActivity;

import com.adivery.sdk.Adivery;
import com.adivery.sdk.AdiveryListener;

import java.util.HashMap;
import java.util.Map;

import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public final class AdiveryNativeBridge {
    public static final String CHANNEL = "ir.miplus.gamino/adivery_native";
    public static final String APP_ID = "5022e2c9-1da8-4a59-97ba-91699c379b51";
    public static final String INTERSTITIAL_ID = "92f6ad3f-078f-4fed-bb40-afa09e1e41f7";
    public static final String REWARDED_ID = "b2550d7c-eed0-40a8-8657-2f536b68d1f7";

    private final FragmentActivity activity;
    private MethodChannel channel;
    private boolean configured = false;

    private final AdiveryListener listener = new AdiveryListener() {
        @Override
        public void onRewardedAdShown(String placementId) {
            channel.invokeMethod("onRewardedShown", placementId);
        }

        @Override
        public void onRewardedAdLoaded(String placementId) {
            channel.invokeMethod("onRewardedLoaded", placementId);
        }

        @Override
        public void onRewardedAdClosed(String placementId, boolean isRewarded) {
            Map<String, Object> payload = new HashMap<>();
            payload.put("placement", placementId);
            payload.put("isRewarded", isRewarded);
            channel.invokeMethod("onRewardedClosed", payload);
        }

        @Override
        public void onRewardedAdClicked(String placementId) {
            channel.invokeMethod("onRewardedClicked", placementId);
        }

        @Override
        public void onInterstitialAdShown(String placementId) {
            channel.invokeMethod("onInterstitialShown", placementId);
        }

        @Override
        public void onInterstitialAdLoaded(String placementId) {
            channel.invokeMethod("onInterstitialLoaded", placementId);
        }

        @Override
        public void onInterstitialAdClosed(String placementId) {
            channel.invokeMethod("onInterstitialClosed", placementId);
        }

        @Override
        public void onInterstitialAdClicked(String placementId) {
            channel.invokeMethod("onInterstitialClicked", placementId);
        }

        @Override
        public void onAppOpenAdLoaded(String placementId) { }

        @Override
        public void onAppOpenAdShown(String placementId) { }

        @Override
        public void onAppOpenAdClosed(String placementId) { }

        @Override
        public void onAppOpenAdClicked(String placementId) { }

        @Override
        public void log(String placementId, String reason) {
            Map<String, Object> payload = new HashMap<>();
            payload.put("placement", placementId);
            payload.put("reason", reason);
            channel.invokeMethod("onError", payload);
        }
    };

    public AdiveryNativeBridge(FragmentActivity activity) {
        this.activity = activity;
    }

    public void register(FlutterEngine flutterEngine) {
        channel = new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL);
        ensureConfigured();
        channel.setMethodCallHandler((call, result) -> {
            try {
                switch (call.method) {
                    case "prepareInterstitial": {
                        String placement = call.arguments instanceof String ? (String) call.arguments : INTERSTITIAL_ID;
                        Adivery.prepareInterstitialAd(activity, placement);
                        result.success(true);
                        break;
                    }
                    case "prepareRewarded": {
                        String placement = call.arguments instanceof String ? (String) call.arguments : REWARDED_ID;
                        Adivery.prepareRewardedAd(activity, placement);
                        result.success(true);
                        break;
                    }
                    case "isLoaded": {
                        String placement = call.arguments instanceof String ? (String) call.arguments : "";
                        result.success(!placement.isEmpty() && Adivery.isLoaded(placement));
                        break;
                    }
                    case "show": {
                        String placement = call.arguments instanceof String ? (String) call.arguments : "";
                        if (placement.isEmpty() || !Adivery.isLoaded(placement)) {
                            result.success(false);
                        } else {
                            Adivery.showAd(placement);
                            result.success(true);
                        }
                        break;
                    }
                    default:
                        result.notImplemented();
                }
            } catch (Throwable error) {
                result.error("ADIVERY", error.getMessage() != null ? error.getMessage() : "Adivery operation failed", null);
            }
        });
    }

    private void ensureConfigured() {
        if (configured) return;
        Adivery.configure(activity.getApplication(), APP_ID);
        Adivery.setLoggingEnabled(false);
        Adivery.addGlobalListener(listener);
        Adivery.prepareInterstitialAd(activity, INTERSTITIAL_ID);
        Adivery.prepareRewardedAd(activity, REWARDED_ID);
        configured = true;
    }
}
