import 'dart:convert';

import 'package:flutter_poolakey/flutter_poolakey.dart';
import 'package:myket_iap/myket_iap.dart';
import 'package:myket_iap/util/iab_result.dart';
import 'package:myket_iap/util/inventory.dart';
import 'package:myket_iap/util/purchase.dart' as myket;

const String gaminoMarket = String.fromEnvironment('GAMINO_MARKET', defaultValue: 'unsupported');
const String gaminoMarketRsaKey = String.fromEnvironment('GAMINO_MARKET_RSA', defaultValue: '');

const Map<int, String> gaminoCardProductIds = <int, String>{
  50: 'gamino_cards_50',
  100: 'gamino_cards_100',
  300: 'gamino_cards_300',
};

class GaminoStorePurchase {
  const GaminoStorePurchase({
    required this.market,
    required this.productId,
    required this.purchaseToken,
    required this.orderId,
    required this.packageName,
    required this.originalJson,
    required this.signature,
    required this.developerPayload,
    this.nativePurchase,
  });

  final String market;
  final String productId;
  final String purchaseToken;
  final String orderId;
  final String packageName;
  final String originalJson;
  final String signature;
  final String developerPayload;
  final Object? nativePurchase;

  Map<String, dynamic> toClaimJson() => <String, dynamic>{
        'market': market,
        'productId': productId,
        'purchaseToken': purchaseToken,
        'orderId': orderId,
        'packageName': packageName,
        'originalJson': originalJson,
        'signature': signature,
        'developerPayload': developerPayload,
      };
}

class GaminoMarketBillingException implements Exception {
  const GaminoMarketBillingException(this.message);
  final String message;
  @override
  String toString() => message;
}

class GaminoMarketBillingService {
  static bool _bazaarConnected = false;
  static bool _myketInitialized = false;

  static bool get isBazaar => gaminoMarket == 'bazaar';
  static bool get isMyket => gaminoMarket == 'myket';
  static bool get isSupportedBuild => isBazaar || isMyket;

  static String get marketLabel => isMyket ? 'مایکت' : (isBazaar ? 'کافه‌بازار' : 'مارکت');

  static Future<void> ensureReady() async {
    if (!isSupportedBuild) throw const GaminoMarketBillingException('نسخه مارکت برنامه معتبر نیست.');
    if (gaminoMarketRsaKey.trim().isEmpty) {
      throw GaminoMarketBillingException('کلید پرداخت $marketLabel در این بیلد تنظیم نشده است.');
    }
    if (isBazaar) {
      if (_bazaarConnected) return;
      var connected = false;
      await FlutterPoolakey.connect(
        gaminoMarketRsaKey,
        onSucceed: () => connected = true,
        onFailed: () => connected = false,
        onDisconnected: () => _bazaarConnected = false,
      );
      _bazaarConnected = connected;
      if (!_bazaarConnected) {
        throw const GaminoMarketBillingException('اتصال به پرداخت کافه‌بازار برقرار نشد.');
      }
      return;
    }

    if (_myketInitialized) return;
    final IabResult? result = await MyketIAP.init(rsaKey: gaminoMarketRsaKey, enableDebugLogging: false);
    if (result == null || result.isFailure()) {
      throw GaminoMarketBillingException('اتصال به پرداخت مایکت برقرار نشد${result == null ? '.' : ': $result'}');
    }
    _myketInitialized = true;
  }

  static Future<GaminoStorePurchase> purchase({
    required String productId,
    required String developerPayload,
  }) async {
    await ensureReady();
    if (!gaminoCardProductIds.containsValue(productId)) {
      throw const GaminoMarketBillingException('شناسه محصول کارت معتبر نیست.');
    }
    if (isBazaar) {
      final PurchaseInfo purchase = await FlutterPoolakey.purchase(productId, payload: developerPayload);
      return _fromBazaar(purchase);
    }

    final Map result = await MyketIAP.launchPurchaseFlow(sku: productId, payload: developerPayload);
    final IabResult? iabResult = result[MyketIAP.RESULT] as IabResult?;
    final myket.Purchase? purchase = result[MyketIAP.PURCHASE] as myket.Purchase?;
    if (iabResult == null || iabResult.isFailure() || purchase == null) {
      throw GaminoMarketBillingException(iabResult == null ? 'خرید مایکت تکمیل نشد.' : 'خرید مایکت تکمیل نشد: $iabResult');
    }
    return _fromMyket(purchase);
  }

  static Future<List<GaminoStorePurchase>> pendingPurchases() async {
    await ensureReady();
    if (isBazaar) {
      final List<PurchaseInfo> rows = await FlutterPoolakey.getAllPurchasedProducts();
      return rows
          .where((item) => gaminoCardProductIds.containsValue(item.productId))
          .map(_fromBazaar)
          .toList(growable: false);
    }

    final Map result = await MyketIAP.queryInventory(
      querySkuDetails: false,
      skus: gaminoCardProductIds.values.toList(growable: false),
    );
    final IabResult? iabResult = result[MyketIAP.RESULT] as IabResult?;
    if (iabResult == null || iabResult.isFailure()) {
      throw GaminoMarketBillingException(iabResult == null ? 'دریافت خریدهای مایکت انجام نشد.' : 'دریافت خریدهای مایکت انجام نشد: $iabResult');
    }
    final Inventory? inventory = result[MyketIAP.INVENTORY] as Inventory?;
    if (inventory == null) return const <GaminoStorePurchase>[];
    return inventory.mPurchaseMap.values
        .where((item) => gaminoCardProductIds.containsValue(item.mSku))
        .map(_fromMyket)
        .toList(growable: false);
  }

  static Future<void> consume(GaminoStorePurchase purchase) async {
    await ensureReady();
    if (purchase.market != gaminoMarket) {
      throw const GaminoMarketBillingException('مارکت خرید با نسخه نصب‌شده همخوانی ندارد.');
    }
    if (isBazaar) {
      final ok = await FlutterPoolakey.consume(purchase.purchaseToken);
      if (!ok) throw const GaminoMarketBillingException('مصرف خرید کافه‌بازار تکمیل نشد.');
      return;
    }

    final native = purchase.nativePurchase;
    myket.Purchase? myketPurchase = native is myket.Purchase ? native : null;
    if (myketPurchase == null) {
      try {
        final decoded = jsonDecode(purchase.originalJson);
        if (decoded is Map) myketPurchase = myket.Purchase.fromJson(Map<String, dynamic>.from(decoded));
      } catch (_) {
        myketPurchase = null;
      }
    }
    if (myketPurchase == null) throw const GaminoMarketBillingException('اطلاعات خرید مایکت برای مصرف کامل نیست.');
    final Map result = await MyketIAP.consume(purchase: myketPurchase);
    final IabResult? iabResult = result[MyketIAP.RESULT] as IabResult?;
    if (iabResult == null || iabResult.isFailure()) {
      throw GaminoMarketBillingException(iabResult == null ? 'مصرف خرید مایکت تکمیل نشد.' : 'مصرف خرید مایکت تکمیل نشد: $iabResult');
    }
  }

  static Future<void> dispose() async {
    if (isBazaar && _bazaarConnected) {
      try {
        await FlutterPoolakey.disconnect();
      } catch (_) {}
      _bazaarConnected = false;
    }
    if (isMyket && _myketInitialized) {
      try {
        await MyketIAP.dispose();
      } catch (_) {}
      _myketInitialized = false;
    }
  }

  static GaminoStorePurchase _fromBazaar(PurchaseInfo purchase) => GaminoStorePurchase(
        market: 'bazaar',
        productId: purchase.productId,
        purchaseToken: purchase.purchaseToken,
        orderId: purchase.orderId,
        packageName: purchase.packageName,
        originalJson: purchase.originalJson,
        signature: purchase.dataSignature,
        developerPayload: purchase.payload,
      );

  static GaminoStorePurchase _fromMyket(myket.Purchase purchase) => GaminoStorePurchase(
        market: 'myket',
        productId: purchase.mSku,
        purchaseToken: purchase.mToken,
        orderId: purchase.mOrderId,
        packageName: purchase.mPackageName,
        originalJson: purchase.mOriginalJson,
        signature: purchase.mSignature,
        developerPayload: purchase.mDeveloperPayload ?? '',
        nativePurchase: purchase,
      );
}
