# ساخت خروجی‌های Android گامینو 1.0.0

نسخه برنامه: `1.0.0+1`

فایل `codemagic.yaml` با یک Workflow مارکت‌محور تنظیم شده است و از یک سورس مشترک دقیقاً سه خروجی Release امضاشده می‌سازد:

1. `gamino-1.0.0-bazaar.apk`
2. `gamino-1.0.0-bazaar.aab`
3. `gamino-1.0.0-myket.apk`

## تنظیمات Build

- Flutter: `3.29.3`
- Gradle Wrapper: `8.7`
- Android Gradle Plugin: `8.6.0`
- Kotlin: `2.1.10`
- Java: `21`
- compileSdk: `36`
- Version Name: `1.0.0`
- Version Code: `1`

## Flavorها

- `bazaar`: ثبت نظر و خرید کارت فقط از کافه‌بازار.
- `myket`: ثبت نظر و خرید کارت فقط از مایکت.

Workflow مقدار `GAMINO_MARKET` و کلید عمومی RSA متناظر همان مارکت را هنگام Compile با `--dart-define` وارد همان Build می‌کند.

## محصولات Consumable

- `gamino_cards_50` → ۵۰ کارت
- `gamino_cards_100` → ۱۰۰ کارت
- `gamino_cards_300` → ۳۰۰ کارت

## کنترل‌های CI

- Android SDK 36 آماده می‌شود.
- `scripts/prepare_android.py` تنظیمات Flavor، Java 21، Adivery، Firebase، ثبت نظر و Repository موردنیاز Poolakey را Verify می‌کند.
- `flutter pub get` اجرا می‌شود.
- `flutter analyze --no-fatal-infos --no-fatal-warnings` اجرا می‌شود.
- Buildها بدون Minify/Shrink انجام می‌شوند.
- در پایان Workflow تعداد فایل‌های پوشه Artifact باید دقیقاً ۳ باشد؛ در غیر این صورت Build Fail می‌شود.
