# Adivery, Firebase, Poolakey and Myket IAP use bundled consumer rules.
