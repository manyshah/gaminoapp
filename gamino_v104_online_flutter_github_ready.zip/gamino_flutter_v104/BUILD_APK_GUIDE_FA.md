# ساخت APK گامینو v104

نسخه برنامه: `1.104.0+104`

Workflow دائمی `build-apk-gamino-auto.yml` نسخه و نام ZIP را ثابت نمی‌کند. برای این سورس Flutter `3.29.3` و Gradle `8.7` از فایل‌های `build_support/flutter-version.txt` و `build_support/gradle-version.txt` خوانده می‌شوند؛ Kotlin `2.1.10` و compileSdk `36` نیز توسط سورس/اسکریپت Android تثبیت می‌شوند.

## نکات Build

- Android SDK 36 پیش از Build نصب و بررسی می‌شود.
- `scripts/prepare_android.py` تنظیمات Android/Tapsell را idempotent Verify می‌کند.
- Static Analysis با `--no-fatal-infos --no-fatal-warnings` اجرا می‌شود؛ Error واقعی Build را متوقف می‌کند.
- نام APK از `name` و `version` داخل `pubspec.yaml` ساخته می‌شود؛ برای این نسخه خروجی `gamino-1.104.0-104.apk` است.
- Workflow در v104 تغییر نکرده است.
