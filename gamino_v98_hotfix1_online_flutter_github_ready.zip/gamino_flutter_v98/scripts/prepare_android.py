from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = "ir.miplus.gamino"
APP_NAME = "گامینو"
MIN_SDK = "23"
COMPILE_SDK = "36"
KOTLIN_VERSION = "2.1.10"
TAPSELL_MEDIATION_APP_ID = "98796f77-5797-4a57-9c7c-c7e520c7ae71"
TAPSELL_NATIVE_VERSION = "1.2.0"
TAPSELL_LEGACY_ADAPTER_VERSION = "1.2.0"

MAIN_ACTIVITY = r'''package ir.miplus.gamino

import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterFragmentActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        flutterEngine.platformViewsController.registry.registerViewFactory(
            InlineBannerFactory.VIEW_TYPE,
            InlineBannerFactory(this, flutterEngine.dartExecutor.binaryMessenger),
        )

        TapsellNativeBridge(this).register(flutterEngine)
    }
}
'''

TAPSELL_NATIVE_BRIDGE = r'''package ir.miplus.gamino

import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.FragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import ir.tapsell.mediation.Tapsell
import ir.tapsell.mediation.ad.AdStateListener
import ir.tapsell.mediation.ad.request.RequestResultListener
import ir.tapsell.mediation.ad.show.AdShowCompletionState
import java.util.concurrent.atomic.AtomicBoolean

class TapsellNativeBridge(private val activity: FragmentActivity) {
    companion object {
        const val CHANNEL = "ir.miplus.gamino/tapsell_native"
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    fun register(flutterEngine: FlutterEngine) {
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result -> handle(call, result) }
    }

    private fun handle(call: MethodCall, result: MethodChannel.Result) {
        if (call.method == "openUrl") {
            val url = call.argument<String>("url")?.trim().orEmpty()
            if (url.isEmpty()) { result.success("invalid"); return }
            try {
                val uri = Uri.parse(url)
                val scheme = uri.scheme?.lowercase().orEmpty()
                if (scheme != "http" && scheme != "https") { result.success("invalid"); return }
                activity.startActivity(Intent(Intent.ACTION_VIEW, uri))
                result.success("opened")
            } catch (_: Throwable) {
                result.success("unavailable")
            }
            return
        }

        val zoneId = call.argument<String>("zoneId")?.trim().orEmpty()
        if (zoneId.isEmpty()) {
            result.success("unavailable")
            return
        }

        when (call.method) {
            "showInterstitial" -> showInterstitial(zoneId, result)
            "showRewarded" -> showRewarded(zoneId, result)
            else -> result.notImplemented()
        }
    }

    private fun completeOnce(
        completed: AtomicBoolean,
        result: MethodChannel.Result,
        value: String,
    ) {
        mainHandler.post {
            if (completed.compareAndSet(false, true)) {
                result.success(value)
            }
        }
    }

    private fun showInterstitial(zoneId: String, result: MethodChannel.Result) {
        val completed = AtomicBoolean(false)

        try {
            Tapsell.requestInterstitialAd(zoneId, object : RequestResultListener {
                override fun onFailure(message: String) {
                    completeOnce(completed, result, "unavailable")
                }

                override fun onSuccess(adId: String) {
                    activity.runOnUiThread {
                        if (activity.isFinishing || activity.isDestroyed) {
                            completeOnce(completed, result, "unavailable")
                            return@runOnUiThread
                        }

                        try {
                            Tapsell.showInterstitialAd(
                                adId,
                                activity,
                                object : AdStateListener.Interstitial {
                                    override fun onAdClicked() = Unit

                                    override fun onAdClosed(completionState: AdShowCompletionState) {
                                        completeOnce(completed, result, "closed")
                                    }

                                    override fun onAdFailed(message: String) {
                                        completeOnce(completed, result, "unavailable")
                                    }

                                    override fun onAdImpression() = Unit
                                },
                            )
                        } catch (_: Throwable) {
                            completeOnce(completed, result, "unavailable")
                        }
                    }
                }
            })
        } catch (_: Throwable) {
            completeOnce(completed, result, "unavailable")
        }
    }

    private fun showRewarded(zoneId: String, result: MethodChannel.Result) {
        val completed = AtomicBoolean(false)
        val rewarded = AtomicBoolean(false)

        try {
            Tapsell.requestRewardedAd(zoneId, object : RequestResultListener {
                override fun onFailure(message: String) {
                    completeOnce(completed, result, "unavailable")
                }

                override fun onSuccess(adId: String) {
                    activity.runOnUiThread {
                        if (activity.isFinishing || activity.isDestroyed) {
                            completeOnce(completed, result, "unavailable")
                            return@runOnUiThread
                        }

                        try {
                            Tapsell.showRewardedAd(
                                adId,
                                activity,
                                object : AdStateListener.Rewarded {
                                    override fun onAdClicked() = Unit

                                    override fun onAdClosed(completionState: AdShowCompletionState) {
                                        // Some adapters may dispatch reward immediately before close.
                                        // A tiny grace period prevents a close callback racing the
                                        // official onRewarded callback from being classified as skipped.
                                        mainHandler.postDelayed(
                                            {
                                                completeOnce(
                                                    completed,
                                                    result,
                                                    if (rewarded.get()) "rewarded" else "incomplete",
                                                )
                                            },
                                            350L,
                                        )
                                    }

                                    override fun onAdFailed(message: String) {
                                        completeOnce(completed, result, "unavailable")
                                    }

                                    override fun onAdImpression() = Unit

                                    override fun onRewarded() {
                                        rewarded.set(true)
                                    }
                                },
                            )
                        } catch (_: Throwable) {
                            completeOnce(completed, result, "unavailable")
                        }
                    }
                }
            })
        } catch (_: Throwable) {
            completeOnce(completed, result, "unavailable")
        }
    }
}
'''

INLINE_BANNER_VIEW = r'''package ir.miplus.gamino

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import androidx.fragment.app.FragmentActivity
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.StandardMessageCodec
import io.flutter.plugin.platform.PlatformView
import io.flutter.plugin.platform.PlatformViewFactory
import ir.tapsell.mediation.Tapsell
import ir.tapsell.mediation.ad.AdStateListener
import ir.tapsell.mediation.ad.request.BannerSize
import ir.tapsell.mediation.ad.request.RequestResultListener
import ir.tapsell.mediation.ad.views.banner.BannerContainer

class InlineBannerFactory(
    private val activity: FragmentActivity,
    private val messenger: BinaryMessenger,
) : PlatformViewFactory(StandardMessageCodec.INSTANCE) {
    companion object {
        const val VIEW_TYPE = "ir.miplus.gamino/tapsell_inline_banner"
    }

    override fun create(context: Context, viewId: Int, args: Any?): PlatformView {
        val params = args as? Map<*, *> ?: emptyMap<Any, Any>()
        return InlineBannerView(context, activity, params, viewId, messenger)
    }
}

private class InlineBannerView(
    context: Context,
    private val activity: FragmentActivity,
    params: Map<*, *>,
    viewId: Int,
    messenger: BinaryMessenger,
) : PlatformView {
    private val root = FrameLayout(context)
    private val bannerContainer = BannerContainer(context)
    private val zoneId = params["zoneId"]?.toString()?.trim().orEmpty()
    private val stateChannel = MethodChannel(messenger, "ir.miplus.gamino/tapsell_inline_banner/$viewId")
    private var disposed = false

    init {
        root.addView(
            bannerContainer,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER,
            ),
        )
        if (zoneId.isNotEmpty()) requestBanner() else sendState("hidden")
    }

    private fun sendState(state: String) {
        if (disposed) return
        activity.runOnUiThread {
            if (!disposed) {
                try {
                    stateChannel.invokeMethod("state", state)
                } catch (_: Throwable) {
                    // Banner visibility is best-effort and must never affect the page.
                }
            }
        }
    }

    private fun requestBanner() {
        activity.runOnUiThread {
            if (disposed || activity.isFinishing || activity.isDestroyed) return@runOnUiThread
            try {
                Tapsell.requestBannerAd(
                    zoneId,
                    BannerSize.BANNER_320_100,
                    object : RequestResultListener {
                        override fun onSuccess(adId: String) {
                            if (disposed || activity.isFinishing || activity.isDestroyed) return
                            showBanner(adId)
                        }

                        override fun onFailure(message: String) {
                            sendState("hidden")
                        }
                    },
                )
            } catch (_: Throwable) {
                sendState("hidden")
            }
        }
    }

    private fun showBanner(adId: String) {
        activity.runOnUiThread {
            if (disposed || activity.isFinishing || activity.isDestroyed) return@runOnUiThread
            try {
                Tapsell.showBannerAd(
                    adId,
                    bannerContainer,
                    activity,
                    object : AdStateListener.Banner {
                        override fun onAdImpression() = Unit
                        override fun onAdClicked() = Unit
                        override fun onAdFailed(message: String) {
                            sendState("hidden")
                        }
                    },
                )
                sendState("loaded")
            } catch (_: Throwable) {
                sendState("hidden")
            }
        }
    }

    override fun getView(): View = root

    override fun dispose() {
        disposed = true
        root.removeAllViews()
        try {
            stateChannel.setMethodCallHandler(null)
        } catch (_: Throwable) {
            // Ignore cleanup failures.
        }
    }
}
'''


def patch_settings() -> None:
    for path in (ROOT / "android" / "settings.gradle", ROOT / "android" / "settings.gradle.kts"):
        if not path.exists():
            continue
        text = path.read_text()
        text = re.sub(
            r'(id\s*[\( ]?["\']org\.jetbrains\.kotlin\.android["\']\)?\s*version\s*[= ]*?["\'])[^"\']+(["\'])',
            rf'\g<1>{KOTLIN_VERSION}\g<2>',
            text,
        )
        path.write_text(text)


def patch_app_groovy() -> None:
    path = ROOT / "android" / "app" / "build.gradle"
    if not path.exists():
        return
    text = f'''plugins {{
    id "com.android.application"
    id "kotlin-android"
    id "dev.flutter.flutter-gradle-plugin"
}}


def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {{
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}}


def tapsellMediationAppId = project.findProperty("TAPSELL_MEDIATION_APP_ID")?.toString()?.trim()
if (!tapsellMediationAppId) {{
    throw new GradleException("TAPSELL_MEDIATION_APP_ID is not configured in android/gradle.properties")
}}

android {{
    namespace = "{PACKAGE}"
    compileSdk = {COMPILE_SDK}
    ndkVersion = flutter.ndkVersion

    compileOptions {{
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }}

    kotlinOptions {{
        jvmTarget = JavaVersion.VERSION_17
    }}

    buildFeatures {{
        buildConfig = true
    }}

    signingConfigs {{
        release {{
            if (keystorePropertiesFile.exists()) {{
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
            }}
        }}
    }}

    defaultConfig {{
        applicationId = "{PACKAGE}"
        minSdk = {MIN_SDK}
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        manifestPlaceholders = [TapsellMediationAppKey: tapsellMediationAppId]
    }}

    buildTypes {{
        release {{
            signingConfig = signingConfigs.release
            minifyEnabled false
            shrinkResources false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }}
    }}
}}

dependencies {{
    // Native-only Tapsell Mediation integration. This follows Tapsell's
    // official Android sample and avoids mixing the Flutter bridge AAR with
    // native Mediation classes (the cause of v92/v93 dependency/API errors).
    implementation "ir.tapsell:tapsell:{TAPSELL_NATIVE_VERSION}"
    implementation "ir.tapsell.mediation.adapter:legacy:{TAPSELL_LEGACY_ADAPTER_VERSION}"
}}

flutter {{
    source = "../.."
}}
'''
    path.write_text(text)


def patch_gradle_properties() -> None:
    path = ROOT / "android" / "gradle.properties"
    lines = path.read_text().splitlines() if path.exists() else []
    remove = {
        'TAPSELL_APP_KEY', 'TAPSELL_REWARDED_ZONE_ID', 'TAPSELL_STANDARD_BANNER_ZONE_ID',
        'TAPSELL_INTERSTITIAL_ZONE_ID', 'TAPSELL_MEDIATION_APP_ID',
        'android.suppressUnsupportedCompileSdk',
    }
    kept = [ln for ln in lines if not ('=' in ln and ln.split('=', 1)[0] in remove)]
    kept += [
        f'android.suppressUnsupportedCompileSdk={COMPILE_SDK}',
        f'TAPSELL_MEDIATION_APP_ID={TAPSELL_MEDIATION_APP_ID}',
    ]
    path.write_text('\n'.join(kept).rstrip() + '\n')


def patch_manifest() -> None:
    path = ROOT / "android" / "app" / "src" / "main" / "AndroidManifest.xml"
    text = path.read_text()
    base = '<manifest xmlns:android="http://schemas.android.com/apk/res/android">'
    if 'android.permission.INTERNET' not in text:
        text = text.replace(base, base + '\n    <uses-permission android:name="android.permission.INTERNET" />', 1)
    if 'android.permission.ACCESS_NETWORK_STATE' not in text:
        text = text.replace(
            '<uses-permission android:name="android.permission.INTERNET" />',
            '<uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
            1,
        )
    if 'com.google.android.gms.permission.AD_ID' not in text:
        insert_after = '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />'
        text = text.replace(insert_after, insert_after + '\n    <uses-permission android:name="com.google.android.gms.permission.AD_ID" />', 1)
    text = re.sub(r'android:label="[^"]+"', f'android:label="{APP_NAME}"', text, count=1)
    text = re.sub(r'android:icon="[^"]+"', 'android:icon="@mipmap/ic_launcher"', text, count=1)
    path.write_text(text)


def patch_native() -> None:
    package_dir = ROOT / "android" / "app" / "src" / "main" / "kotlin" / "ir" / "miplus" / "gamino"
    package_dir.mkdir(parents=True, exist_ok=True)
    (package_dir / "MainActivity.kt").write_text(MAIN_ACTIVITY)
    (package_dir / "TapsellNativeBridge.kt").write_text(TAPSELL_NATIVE_BRIDGE)
    (package_dir / "InlineBannerView.kt").write_text(INLINE_BANNER_VIEW)
    stale = package_dir / 'GaminoApplication.kt'
    if stale.exists():
        stale.unlink()


def install_launcher_icon() -> None:
    src_root = ROOT / "assets" / "android_icon"
    res_root = ROOT / "android" / "app" / "src" / "main" / "res"
    if not src_root.exists():
        return
    for src in src_root.glob("mipmap-*/*.png"):
        dest = res_root / src.parent.name / src.name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dest)


def patch_repositories() -> None:
    path = ROOT / "android" / "build.gradle"
    if path.exists():
        text = path.read_text()
        if 'https://maven.tapsell.ir' not in text:
            text = text.replace('repositories {', 'repositories {\n        maven { url "https://maven.tapsell.ir" }', 1)
        path.write_text(text)


def verify() -> None:
    pubspec = (ROOT / 'pubspec.yaml').read_text()
    if 'tapsell_mediation:' in pubspec or 'tapsell_mediation_legacy:' in pubspec:
        raise RuntimeError('Flutter Tapsell bridge packages must be absent in native-only Gamino build')

    app_text = (ROOT / 'android' / 'app' / 'build.gradle').read_text()
    if 'TapsellMediationAppKey' not in app_text:
        raise RuntimeError('TapsellMediationAppKey manifest placeholder is missing')
    required = (
        f'ir.tapsell:tapsell:{TAPSELL_NATIVE_VERSION}',
        f'ir.tapsell.mediation.adapter:legacy:{TAPSELL_LEGACY_ADAPTER_VERSION}',
    )
    if any(dep not in app_text for dep in required):
        raise RuntimeError('Official native Tapsell/legacy dependencies are incomplete')
    forbidden = ('tapsell-flutter', 'ir.tapsell.mediation:tapsell:1.2.0\"')
    if any(dep in app_text for dep in forbidden):
        raise RuntimeError('Flutter bridge/direct mediation core conflict remains')

    manifest = (ROOT / 'android' / 'app' / 'src' / 'main' / 'AndroidManifest.xml').read_text()
    if 'com.google.android.gms.permission.AD_ID' not in manifest:
        raise RuntimeError('Google Advertising ID permission is missing')

    native_dir = ROOT / 'android' / 'app' / 'src' / 'main' / 'kotlin' / 'ir' / 'miplus' / 'gamino'
    inline_text = (native_dir / 'InlineBannerView.kt').read_text()
    bridge_text = (native_dir / 'TapsellNativeBridge.kt').read_text()
    main_text = (native_dir / 'MainActivity.kt').read_text()

    if 'Tapsell.requestBannerAd(\n                    zoneId,\n                    BannerSize.BANNER_320_100,\n                    object : RequestResultListener' not in inline_text:
        raise RuntimeError('Banner request does not match native Mediation API')
    if 'Tapsell.showBannerAd(' not in inline_text or 'bannerContainer' not in inline_text:
        raise RuntimeError('Inline native banner show bridge is missing')
    if 'FlutterFragmentActivity' not in main_text or 'TapsellNativeBridge(this).register' not in main_text:
        raise RuntimeError('FragmentActivity/native MethodChannel registration is missing')
    if 'requestInterstitialAd(zoneId, object : RequestResultListener' not in bridge_text:
        raise RuntimeError('Native interstitial request bridge is missing')
    if 'requestRewardedAd(zoneId, object : RequestResultListener' not in bridge_text:
        raise RuntimeError('Native rewarded request bridge is missing')
    if 'override fun onRewarded()' not in bridge_text:
        raise RuntimeError('Official rewarded callback is not handled')

    settings = ''.join(p.read_text() for p in [ROOT/'android/settings.gradle', ROOT/'android/settings.gradle.kts'] if p.exists())
    if KOTLIN_VERSION not in settings:
        raise RuntimeError(f'Kotlin {KOTLIN_VERSION} is not configured')
    if not re.search(rf'compileSdk\s*=\s*{COMPILE_SDK}\b', app_text):
        raise RuntimeError(f'compileSdk {COMPILE_SDK} is not configured')


def main() -> None:
    patch_settings()
    patch_app_groovy()
    patch_gradle_properties()
    patch_repositories()
    patch_manifest()
    patch_native()
    install_launcher_icon()
    (ROOT / 'android' / 'app' / 'proguard-rules.pro').write_text(
        '# Tapsell Mediation native integration; SDK/adapter consumer rules are bundled by dependencies.\n'
    )
    verify()


if __name__ == '__main__':
    main()
