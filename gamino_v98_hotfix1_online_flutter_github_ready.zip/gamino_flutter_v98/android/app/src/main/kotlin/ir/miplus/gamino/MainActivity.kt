package ir.miplus.gamino

import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterFragmentActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        flutterEngine.platformViewsController.registry.registerViewFactory(
            InlineBannerFactory.VIEW_TYPE,
            InlineBannerFactory(this, flutterEngine.dartExecutor.binaryMessenger),
        )

        TapsellNativeBridge(this).register(flutterEngine)
    }
}
